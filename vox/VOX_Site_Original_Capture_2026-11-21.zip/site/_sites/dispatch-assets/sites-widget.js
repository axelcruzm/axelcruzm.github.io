var Mw = Object.create, tg = Object.defineProperty, Rw = Object.getOwnPropertyDescriptor, Nw = Object.getOwnPropertyNames, Dw = Object.getPrototypeOf, zw = Object.prototype.hasOwnProperty, bn = (e, a) => () => (a || e((a = { exports: {} }).exports, a), a.exports), Lw = (e, a, r, l) => {
  if (a && typeof a == "object" || typeof a == "function")
    for (var s = Nw(a), c = 0, d = s.length, h; c < d; c++)
      h = s[c], !zw.call(e, h) && h !== r && tg(e, h, {
        get: ((m) => a[m]).bind(null, h),
        enumerable: !(l = Rw(a, h)) || l.enumerable
      });
  return e;
}, Zd = (e, a, r) => (r = e != null ? Mw(Dw(e)) : {}, Lw(a || !e || !e.__esModule ? tg(r, "default", {
  value: e,
  enumerable: !0
}) : r, e)), Hw = 336 * 60 * 60;
function jw(e, a = Date.now()) {
  if (e === null) return !1;
  const r = Date.parse(e);
  return Number.isFinite(r) && r <= a && a - r < Hw * 1e3;
}
function Bw(e, a, r) {
  const l = a.current_user_role;
  if (!l) return null;
  const { toolbarOrigin: s, mobileEnabled: c } = e;
  if (s && (l !== "viewer" || e.viewerRemixEnabled)) return {
    kind: "sites-toolbar",
    currentUserRole: l,
    toolbarOrigin: s,
    ...e.shareLoginOrigin && { shareLoginEnabled: !0 },
    mobileEnabled: c
  };
  if (l === "viewer") return null;
  const d = a.editor_invitation;
  return l === "editor" && !r && e.invitationBanner && d && jw(d.granted_at) ? {
    kind: "invitation-banner",
    ownerName: d.owner_name,
    mobileEnabled: c
  } : e.shareLoginOrigin ? {
    kind: "sites-toolbar",
    currentUserRole: l,
    toolbarOrigin: e.shareLoginOrigin,
    shareLoginEnabled: !0,
    mobileEnabled: c
  } : {
    kind: "editor-composer",
    mobileEnabled: c
  };
}
function Uw(e) {
  return /(?:^|\s)CodexBrowser(?:\/|\s|$)/i.test(e ?? "");
}
function ng(e) {
  return /iPad|iPhone|iPod/.test(e);
}
function kw(e) {
  return /Android/.test(e);
}
function Pw(e) {
  return ng(e) && e.includes("CriOS");
}
function Iw(e) {
  return ng(e) || kw(e) || Pw(e);
}
var Zw = [
  "; wv",
  "webview",
  "fbav",
  "fb_iab",
  "fban",
  "instagram",
  "line/",
  "kakaotalk",
  "snapchat",
  "tiktok"
];
function Gw(e) {
  const a = e.trim();
  if (!a) return !1;
  const r = /iPhone|iPad|iPod/.test(a), l = /Android/.test(a), s = r && !/Safari/.test(a), c = l && /Version\/\d+\.\d+/.test(a), d = Zw.some((h) => a.toLowerCase().includes(h));
  return s || c || d;
}
function Vw(e) {
  return Uw(e) || Gw(e ?? "");
}
function ag(e) {
  var a, r, l = "";
  if (typeof e == "string" || typeof e == "number") l += e;
  else if (typeof e == "object") if (Array.isArray(e)) {
    var s = e.length;
    for (a = 0; a < s; a++) e[a] && (r = ag(e[a])) && (l && (l += " "), l += r);
  } else for (r in e) e[r] && (l && (l += " "), l += r);
  return l;
}
function Be() {
  for (var e, a, r = 0, l = "", s = arguments.length; r < s; r++) (e = arguments[r]) && (a = ag(e)) && (l && (l += " "), l += a);
  return l;
}
var $w = /* @__PURE__ */ bn(((e) => {
  var a = /* @__PURE__ */ Symbol.for("react.transitional.element"), r = /* @__PURE__ */ Symbol.for("react.portal"), l = /* @__PURE__ */ Symbol.for("react.fragment"), s = /* @__PURE__ */ Symbol.for("react.strict_mode"), c = /* @__PURE__ */ Symbol.for("react.profiler"), d = /* @__PURE__ */ Symbol.for("react.consumer"), h = /* @__PURE__ */ Symbol.for("react.context"), m = /* @__PURE__ */ Symbol.for("react.forward_ref"), y = /* @__PURE__ */ Symbol.for("react.suspense"), p = /* @__PURE__ */ Symbol.for("react.memo"), _ = /* @__PURE__ */ Symbol.for("react.lazy"), w = /* @__PURE__ */ Symbol.for("react.activity"), E = Symbol.iterator;
  function x(O) {
    return O === null || typeof O != "object" ? null : (O = E && O[E] || O["@@iterator"], typeof O == "function" ? O : null);
  }
  var C = {
    isMounted: function() {
      return !1;
    },
    enqueueForceUpdate: function() {
    },
    enqueueReplaceState: function() {
    },
    enqueueSetState: function() {
    }
  }, T = Object.assign, M = {};
  function D(O, $, re) {
    this.props = O, this.context = $, this.refs = M, this.updater = re || C;
  }
  D.prototype.isReactComponent = {}, D.prototype.setState = function(O, $) {
    if (typeof O != "object" && typeof O != "function" && O != null) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, O, $, "setState");
  }, D.prototype.forceUpdate = function(O) {
    this.updater.enqueueForceUpdate(this, O, "forceUpdate");
  };
  function j() {
  }
  j.prototype = D.prototype;
  function H(O, $, re) {
    this.props = O, this.context = $, this.refs = M, this.updater = re || C;
  }
  var k = H.prototype = new j();
  k.constructor = H, T(k, D.prototype), k.isPureReactComponent = !0;
  var B = Array.isArray;
  function Q() {
  }
  var K = {
    H: null,
    A: null,
    T: null,
    S: null
  }, q = Object.prototype.hasOwnProperty;
  function F(O, $, re) {
    var le = re.ref;
    return {
      $$typeof: a,
      type: O,
      key: $,
      ref: le !== void 0 ? le : null,
      props: re
    };
  }
  function ee(O, $) {
    return F(O.type, $, O.props);
  }
  function ce(O) {
    return typeof O == "object" && O !== null && O.$$typeof === a;
  }
  function V(O) {
    var $ = {
      "=": "=0",
      ":": "=2"
    };
    return "$" + O.replace(/[=:]/g, function(re) {
      return $[re];
    });
  }
  var ie = /\/+/g;
  function se(O, $) {
    return typeof O == "object" && O !== null && O.key != null ? V("" + O.key) : $.toString(36);
  }
  function L(O) {
    switch (O.status) {
      case "fulfilled":
        return O.value;
      case "rejected":
        throw O.reason;
      default:
        switch (typeof O.status == "string" ? O.then(Q, Q) : (O.status = "pending", O.then(function($) {
          O.status === "pending" && (O.status = "fulfilled", O.value = $);
        }, function($) {
          O.status === "pending" && (O.status = "rejected", O.reason = $);
        })), O.status) {
          case "fulfilled":
            return O.value;
          case "rejected":
            throw O.reason;
        }
    }
    throw O;
  }
  function A(O, $, re, le, ye) {
    var _e = typeof O;
    (_e === "undefined" || _e === "boolean") && (O = null);
    var ue = !1;
    if (O === null) ue = !0;
    else switch (_e) {
      case "bigint":
      case "string":
      case "number":
        ue = !0;
        break;
      case "object":
        switch (O.$$typeof) {
          case a:
          case r:
            ue = !0;
            break;
          case _:
            return ue = O._init, A(ue(O._payload), $, re, le, ye);
        }
    }
    if (ue) return ye = ye(O), ue = le === "" ? "." + se(O, 0) : le, B(ye) ? (re = "", ue != null && (re = ue.replace(ie, "$&/") + "/"), A(ye, $, re, "", function(Ce) {
      return Ce;
    })) : ye != null && (ce(ye) && (ye = ee(ye, re + (ye.key == null || O && O.key === ye.key ? "" : ("" + ye.key).replace(ie, "$&/") + "/") + ue)), $.push(ye)), 1;
    ue = 0;
    var me = le === "" ? "." : le + ":";
    if (B(O)) for (var Te = 0; Te < O.length; Te++) le = O[Te], _e = me + se(le, Te), ue += A(le, $, re, _e, ye);
    else if (Te = x(O), typeof Te == "function") for (O = Te.call(O), Te = 0; !(le = O.next()).done; ) le = le.value, _e = me + se(le, Te++), ue += A(le, $, re, _e, ye);
    else if (_e === "object") {
      if (typeof O.then == "function") return A(L(O), $, re, le, ye);
      throw $ = String(O), Error("Objects are not valid as a React child (found: " + ($ === "[object Object]" ? "object with keys {" + Object.keys(O).join(", ") + "}" : $) + "). If you meant to render a collection of children, use an array instead.");
    }
    return ue;
  }
  function N(O, $, re) {
    if (O == null) return O;
    var le = [], ye = 0;
    return A(O, le, "", "", function(_e) {
      return $.call(re, _e, ye++);
    }), le;
  }
  function te(O) {
    if (O._status === -1) {
      var $ = O._result;
      $ = $(), $.then(function(re) {
        (O._status === 0 || O._status === -1) && (O._status = 1, O._result = re);
      }, function(re) {
        (O._status === 0 || O._status === -1) && (O._status = 2, O._result = re);
      }), O._status === -1 && (O._status = 0, O._result = $);
    }
    if (O._status === 1) return O._result.default;
    throw O._result;
  }
  var oe = typeof reportError == "function" ? reportError : function(O) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var $ = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof O == "object" && O !== null && typeof O.message == "string" ? String(O.message) : String(O),
        error: O
      });
      if (!window.dispatchEvent($)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", O);
      return;
    }
    console.error(O);
  }, Ee = {
    map: N,
    forEach: function(O, $, re) {
      N(O, function() {
        $.apply(this, arguments);
      }, re);
    },
    count: function(O) {
      var $ = 0;
      return N(O, function() {
        $++;
      }), $;
    },
    toArray: function(O) {
      return N(O, function($) {
        return $;
      }) || [];
    },
    only: function(O) {
      if (!ce(O)) throw Error("React.Children.only expected to receive a single React element child.");
      return O;
    }
  };
  e.Activity = w, e.Children = Ee, e.Component = D, e.Fragment = l, e.Profiler = c, e.PureComponent = H, e.StrictMode = s, e.Suspense = y, e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = K, e.__COMPILER_RUNTIME = {
    __proto__: null,
    c: function(O) {
      return K.H.useMemoCache(O);
    }
  }, e.cache = function(O) {
    return function() {
      return O.apply(null, arguments);
    };
  }, e.cacheSignal = function() {
    return null;
  }, e.cloneElement = function(O, $, re) {
    if (O == null) throw Error("The argument must be a React element, but you passed " + O + ".");
    var le = T({}, O.props), ye = O.key;
    if ($ != null) for (_e in $.key !== void 0 && (ye = "" + $.key), $) !q.call($, _e) || _e === "key" || _e === "__self" || _e === "__source" || _e === "ref" && $.ref === void 0 || (le[_e] = $[_e]);
    var _e = arguments.length - 2;
    if (_e === 1) le.children = re;
    else if (1 < _e) {
      for (var ue = Array(_e), me = 0; me < _e; me++) ue[me] = arguments[me + 2];
      le.children = ue;
    }
    return F(O.type, ye, le);
  }, e.createContext = function(O) {
    return O = {
      $$typeof: h,
      _currentValue: O,
      _currentValue2: O,
      _threadCount: 0,
      Provider: null,
      Consumer: null
    }, O.Provider = O, O.Consumer = {
      $$typeof: d,
      _context: O
    }, O;
  }, e.createElement = function(O, $, re) {
    var le, ye = {}, _e = null;
    if ($ != null) for (le in $.key !== void 0 && (_e = "" + $.key), $) q.call($, le) && le !== "key" && le !== "__self" && le !== "__source" && (ye[le] = $[le]);
    var ue = arguments.length - 2;
    if (ue === 1) ye.children = re;
    else if (1 < ue) {
      for (var me = Array(ue), Te = 0; Te < ue; Te++) me[Te] = arguments[Te + 2];
      ye.children = me;
    }
    if (O && O.defaultProps) for (le in ue = O.defaultProps, ue) ye[le] === void 0 && (ye[le] = ue[le]);
    return F(O, _e, ye);
  }, e.createRef = function() {
    return { current: null };
  }, e.forwardRef = function(O) {
    return {
      $$typeof: m,
      render: O
    };
  }, e.isValidElement = ce, e.lazy = function(O) {
    return {
      $$typeof: _,
      _payload: {
        _status: -1,
        _result: O
      },
      _init: te
    };
  }, e.memo = function(O, $) {
    return {
      $$typeof: p,
      type: O,
      compare: $ === void 0 ? null : $
    };
  }, e.startTransition = function(O) {
    var $ = K.T, re = {};
    K.T = re;
    try {
      var le = O(), ye = K.S;
      ye !== null && ye(re, le), typeof le == "object" && le !== null && typeof le.then == "function" && le.then(Q, oe);
    } catch (_e) {
      oe(_e);
    } finally {
      $ !== null && re.types !== null && ($.types = re.types), K.T = $;
    }
  }, e.unstable_useCacheRefresh = function() {
    return K.H.useCacheRefresh();
  }, e.use = function(O) {
    return K.H.use(O);
  }, e.useActionState = function(O, $, re) {
    return K.H.useActionState(O, $, re);
  }, e.useCallback = function(O, $) {
    return K.H.useCallback(O, $);
  }, e.useContext = function(O) {
    return K.H.useContext(O);
  }, e.useDebugValue = function() {
  }, e.useDeferredValue = function(O, $) {
    return K.H.useDeferredValue(O, $);
  }, e.useEffect = function(O, $) {
    return K.H.useEffect(O, $);
  }, e.useEffectEvent = function(O) {
    return K.H.useEffectEvent(O);
  }, e.useId = function() {
    return K.H.useId();
  }, e.useImperativeHandle = function(O, $, re) {
    return K.H.useImperativeHandle(O, $, re);
  }, e.useInsertionEffect = function(O, $) {
    return K.H.useInsertionEffect(O, $);
  }, e.useLayoutEffect = function(O, $) {
    return K.H.useLayoutEffect(O, $);
  }, e.useMemo = function(O, $) {
    return K.H.useMemo(O, $);
  }, e.useOptimistic = function(O, $) {
    return K.H.useOptimistic(O, $);
  }, e.useReducer = function(O, $, re) {
    return K.H.useReducer(O, $, re);
  }, e.useRef = function(O) {
    return K.H.useRef(O);
  }, e.useState = function(O) {
    return K.H.useState(O);
  }, e.useSyncExternalStore = function(O, $, re) {
    return K.H.useSyncExternalStore(O, $, re);
  }, e.useTransition = function() {
    return K.H.useTransition();
  }, e.version = "19.2.8";
})), Gd = /* @__PURE__ */ bn(((e, a) => {
  a.exports = $w();
})), b = /* @__PURE__ */ Zd(Gd()), dd = function(e, a) {
  return dd = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(r, l) {
    r.__proto__ = l;
  } || function(r, l) {
    for (var s in l) Object.prototype.hasOwnProperty.call(l, s) && (r[s] = l[s]);
  }, dd(e, a);
};
function zn(e, a) {
  if (typeof a != "function" && a !== null) throw new TypeError("Class extends value " + String(a) + " is not a constructor or null");
  dd(e, a);
  function r() {
    this.constructor = e;
  }
  e.prototype = a === null ? Object.create(a) : (r.prototype = a.prototype, new r());
}
var de = function() {
  return de = Object.assign || function(a) {
    for (var r, l = 1, s = arguments.length; l < s; l++) {
      r = arguments[l];
      for (var c in r) Object.prototype.hasOwnProperty.call(r, c) && (a[c] = r[c]);
    }
    return a;
  }, de.apply(this, arguments);
};
function Ca(e, a) {
  var r = {};
  for (var l in e) Object.prototype.hasOwnProperty.call(e, l) && a.indexOf(l) < 0 && (r[l] = e[l]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var s = 0, l = Object.getOwnPropertySymbols(e); s < l.length; s++) a.indexOf(l[s]) < 0 && Object.prototype.propertyIsEnumerable.call(e, l[s]) && (r[l[s]] = e[l[s]]);
  return r;
}
function Gn(e, a, r) {
  if (r || arguments.length === 2)
    for (var l = 0, s = a.length, c; l < s; l++) (c || !(l in a)) && (c || (c = Array.prototype.slice.call(a, 0, l)), c[l] = a[l]);
  return e.concat(c || Array.prototype.slice.call(a));
}
function Kn(e, a) {
  var r = a && a.cache ? a.cache : Kw, l = a && a.serializer ? a.serializer : Ww;
  return (a && a.strategy ? a.strategy : qw)(e, {
    cache: r,
    serializer: l
  });
}
function Fw(e) {
  return e == null || typeof e == "number" || typeof e == "boolean";
}
function ig(e, a, r, l) {
  var s = Fw(l) ? l : r(l), c = a.get(s);
  return typeof c > "u" && (c = e.call(this, l), a.set(s, c)), c;
}
function rg(e, a, r) {
  var l = Array.prototype.slice.call(arguments, 3), s = r(l), c = a.get(s);
  return typeof c > "u" && (c = e.apply(this, l), a.set(s, c)), c;
}
function Vd(e, a, r, l, s) {
  return r.bind(a, e, l, s);
}
function qw(e, a) {
  var r = e.length === 1 ? ig : rg;
  return Vd(e, this, r, a.cache.create(), a.serializer);
}
function Xw(e, a) {
  return Vd(e, this, rg, a.cache.create(), a.serializer);
}
function Yw(e, a) {
  return Vd(e, this, ig, a.cache.create(), a.serializer);
}
var Ww = function() {
  return JSON.stringify(arguments);
}, Qw = (function() {
  function e() {
    this.cache = /* @__PURE__ */ Object.create(null);
  }
  return e.prototype.get = function(a) {
    return this.cache[a];
  }, e.prototype.set = function(a, r) {
    this.cache[a] = r;
  }, e;
})(), Kw = { create: function() {
  return new Qw();
} }, Jn = {
  variadic: Xw,
  monadic: Yw
}, Le;
(function(e) {
  e[e.EXPECT_ARGUMENT_CLOSING_BRACE = 1] = "EXPECT_ARGUMENT_CLOSING_BRACE", e[e.EMPTY_ARGUMENT = 2] = "EMPTY_ARGUMENT", e[e.MALFORMED_ARGUMENT = 3] = "MALFORMED_ARGUMENT", e[e.EXPECT_ARGUMENT_TYPE = 4] = "EXPECT_ARGUMENT_TYPE", e[e.INVALID_ARGUMENT_TYPE = 5] = "INVALID_ARGUMENT_TYPE", e[e.EXPECT_ARGUMENT_STYLE = 6] = "EXPECT_ARGUMENT_STYLE", e[e.INVALID_NUMBER_SKELETON = 7] = "INVALID_NUMBER_SKELETON", e[e.INVALID_DATE_TIME_SKELETON = 8] = "INVALID_DATE_TIME_SKELETON", e[e.EXPECT_NUMBER_SKELETON = 9] = "EXPECT_NUMBER_SKELETON", e[e.EXPECT_DATE_TIME_SKELETON = 10] = "EXPECT_DATE_TIME_SKELETON", e[e.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE", e[e.EXPECT_SELECT_ARGUMENT_OPTIONS = 12] = "EXPECT_SELECT_ARGUMENT_OPTIONS", e[e.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR = 15] = "EXPECT_SELECT_ARGUMENT_SELECTOR", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16] = "EXPECT_PLURAL_ARGUMENT_SELECTOR", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT", e[e.INVALID_PLURAL_ARGUMENT_SELECTOR = 19] = "INVALID_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR", e[e.MISSING_OTHER_CLAUSE = 22] = "MISSING_OTHER_CLAUSE", e[e.INVALID_TAG = 23] = "INVALID_TAG", e[e.INVALID_TAG_NAME = 25] = "INVALID_TAG_NAME", e[e.UNMATCHED_CLOSING_TAG = 26] = "UNMATCHED_CLOSING_TAG", e[e.UNCLOSED_TAG = 27] = "UNCLOSED_TAG";
})(Le || (Le = {}));
var et;
(function(e) {
  e[e.literal = 0] = "literal", e[e.argument = 1] = "argument", e[e.number = 2] = "number", e[e.date = 3] = "date", e[e.time = 4] = "time", e[e.select = 5] = "select", e[e.plural = 6] = "plural", e[e.pound = 7] = "pound", e[e.tag = 8] = "tag";
})(et || (et = {}));
var Lr;
(function(e) {
  e[e.number = 0] = "number", e[e.dateTime = 1] = "dateTime";
})(Lr || (Lr = {}));
function _0(e) {
  return e.type === et.literal;
}
function Jw(e) {
  return e.type === et.argument;
}
function og(e) {
  return e.type === et.number;
}
function lg(e) {
  return e.type === et.date;
}
function sg(e) {
  return e.type === et.time;
}
function ug(e) {
  return e.type === et.select;
}
function cg(e) {
  return e.type === et.plural;
}
function eS(e) {
  return e.type === et.pound;
}
function fg(e) {
  return e.type === et.tag;
}
function dg(e) {
  return !!(e && typeof e == "object" && e.type === Lr.number);
}
function hd(e) {
  return !!(e && typeof e == "object" && e.type === Lr.dateTime);
}
var hg = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/, tS = /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g;
function nS(e) {
  var a = {};
  return e.replace(tS, function(r) {
    var l = r.length;
    switch (r[0]) {
      case "G":
        a.era = l === 4 ? "long" : l === 5 ? "narrow" : "short";
        break;
      case "y":
        a.year = l === 2 ? "2-digit" : "numeric";
        break;
      case "Y":
      case "u":
      case "U":
      case "r":
        throw new RangeError("`Y/u/U/r` (year) patterns are not supported, use `y` instead");
      case "q":
      case "Q":
        throw new RangeError("`q/Q` (quarter) patterns are not supported");
      case "M":
      case "L":
        a.month = [
          "numeric",
          "2-digit",
          "short",
          "long",
          "narrow"
        ][l - 1];
        break;
      case "w":
      case "W":
        throw new RangeError("`w/W` (week) patterns are not supported");
      case "d":
        a.day = ["numeric", "2-digit"][l - 1];
        break;
      case "D":
      case "F":
      case "g":
        throw new RangeError("`D/F/g` (day) patterns are not supported, use `d` instead");
      case "E":
        a.weekday = l === 4 ? "long" : l === 5 ? "narrow" : "short";
        break;
      case "e":
        if (l < 4) throw new RangeError("`e..eee` (weekday) patterns are not supported");
        a.weekday = [
          "short",
          "long",
          "narrow",
          "short"
        ][l - 4];
        break;
      case "c":
        if (l < 4) throw new RangeError("`c..ccc` (weekday) patterns are not supported");
        a.weekday = [
          "short",
          "long",
          "narrow",
          "short"
        ][l - 4];
        break;
      case "a":
        a.hour12 = !0;
        break;
      case "b":
      case "B":
        throw new RangeError("`b/B` (period) patterns are not supported, use `a` instead");
      case "h":
        a.hourCycle = "h12", a.hour = ["numeric", "2-digit"][l - 1];
        break;
      case "H":
        a.hourCycle = "h23", a.hour = ["numeric", "2-digit"][l - 1];
        break;
      case "K":
        a.hourCycle = "h11", a.hour = ["numeric", "2-digit"][l - 1];
        break;
      case "k":
        a.hourCycle = "h24", a.hour = ["numeric", "2-digit"][l - 1];
        break;
      case "j":
      case "J":
      case "C":
        throw new RangeError("`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead");
      case "m":
        a.minute = ["numeric", "2-digit"][l - 1];
        break;
      case "s":
        a.second = ["numeric", "2-digit"][l - 1];
        break;
      case "S":
      case "A":
        throw new RangeError("`S/A` (second) patterns are not supported, use `s` instead");
      case "z":
        a.timeZoneName = l < 4 ? "short" : "long";
        break;
      case "Z":
      case "O":
      case "v":
      case "V":
      case "X":
      case "x":
        throw new RangeError("`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead");
    }
    return "";
  }), a;
}
var aS = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
function iS(e) {
  if (e.length === 0) throw new Error("Number skeleton cannot be empty");
  for (var a = e.split(aS).filter(function(p) {
    return p.length > 0;
  }), r = [], l = 0, s = a; l < s.length; l++) {
    var c = s[l].split("/");
    if (c.length === 0) throw new Error("Invalid number skeleton");
    for (var d = c[0], h = c.slice(1), m = 0, y = h; m < y.length; m++) if (y[m].length === 0) throw new Error("Invalid number skeleton");
    r.push({
      stem: d,
      options: h
    });
  }
  return r;
}
function rS(e) {
  return e.replace(/^(.*?)-/, "");
}
var w0 = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g, mg = /^(@+)?(\+|#+)?[rs]?$/g, oS = /(\*)(0+)|(#+)(0+)|(0+)/g, pg = /^(0+)$/;
function S0(e) {
  var a = {};
  return e[e.length - 1] === "r" ? a.roundingPriority = "morePrecision" : e[e.length - 1] === "s" && (a.roundingPriority = "lessPrecision"), e.replace(mg, function(r, l, s) {
    return typeof s != "string" ? (a.minimumSignificantDigits = l.length, a.maximumSignificantDigits = l.length) : s === "+" ? a.minimumSignificantDigits = l.length : l[0] === "#" ? a.maximumSignificantDigits = l.length : (a.minimumSignificantDigits = l.length, a.maximumSignificantDigits = l.length + (typeof s == "string" ? s.length : 0)), "";
  }), a;
}
function vg(e) {
  switch (e) {
    case "sign-auto":
      return { signDisplay: "auto" };
    case "sign-accounting":
    case "()":
      return { currencySign: "accounting" };
    case "sign-always":
    case "+!":
      return { signDisplay: "always" };
    case "sign-accounting-always":
    case "()!":
      return {
        signDisplay: "always",
        currencySign: "accounting"
      };
    case "sign-except-zero":
    case "+?":
      return { signDisplay: "exceptZero" };
    case "sign-accounting-except-zero":
    case "()?":
      return {
        signDisplay: "exceptZero",
        currencySign: "accounting"
      };
    case "sign-never":
    case "+_":
      return { signDisplay: "never" };
  }
}
function lS(e) {
  var a;
  if (e[0] === "E" && e[1] === "E" ? (a = { notation: "engineering" }, e = e.slice(2)) : e[0] === "E" && (a = { notation: "scientific" }, e = e.slice(1)), a) {
    var r = e.slice(0, 2);
    if (r === "+!" ? (a.signDisplay = "always", e = e.slice(2)) : r === "+?" && (a.signDisplay = "exceptZero", e = e.slice(2)), !pg.test(e)) throw new Error("Malformed concise eng/scientific notation");
    a.minimumIntegerDigits = e.length;
  }
  return a;
}
function E0(e) {
  var a = {}, r = vg(e);
  return r || a;
}
function sS(e) {
  for (var a = {}, r = 0, l = e; r < l.length; r++) {
    var s = l[r];
    switch (s.stem) {
      case "percent":
      case "%":
        a.style = "percent";
        continue;
      case "%x100":
        a.style = "percent", a.scale = 100;
        continue;
      case "currency":
        a.style = "currency", a.currency = s.options[0];
        continue;
      case "group-off":
      case ",_":
        a.useGrouping = !1;
        continue;
      case "precision-integer":
      case ".":
        a.maximumFractionDigits = 0;
        continue;
      case "measure-unit":
      case "unit":
        a.style = "unit", a.unit = rS(s.options[0]);
        continue;
      case "compact-short":
      case "K":
        a.notation = "compact", a.compactDisplay = "short";
        continue;
      case "compact-long":
      case "KK":
        a.notation = "compact", a.compactDisplay = "long";
        continue;
      case "scientific":
        a = de(de(de({}, a), { notation: "scientific" }), s.options.reduce(function(m, y) {
          return de(de({}, m), E0(y));
        }, {}));
        continue;
      case "engineering":
        a = de(de(de({}, a), { notation: "engineering" }), s.options.reduce(function(m, y) {
          return de(de({}, m), E0(y));
        }, {}));
        continue;
      case "notation-simple":
        a.notation = "standard";
        continue;
      case "unit-width-narrow":
        a.currencyDisplay = "narrowSymbol", a.unitDisplay = "narrow";
        continue;
      case "unit-width-short":
        a.currencyDisplay = "code", a.unitDisplay = "short";
        continue;
      case "unit-width-full-name":
        a.currencyDisplay = "name", a.unitDisplay = "long";
        continue;
      case "unit-width-iso-code":
        a.currencyDisplay = "symbol";
        continue;
      case "scale":
        a.scale = parseFloat(s.options[0]);
        continue;
      case "rounding-mode-floor":
        a.roundingMode = "floor";
        continue;
      case "rounding-mode-ceiling":
        a.roundingMode = "ceil";
        continue;
      case "rounding-mode-down":
        a.roundingMode = "trunc";
        continue;
      case "rounding-mode-up":
        a.roundingMode = "expand";
        continue;
      case "rounding-mode-half-even":
        a.roundingMode = "halfEven";
        continue;
      case "rounding-mode-half-down":
        a.roundingMode = "halfTrunc";
        continue;
      case "rounding-mode-half-up":
        a.roundingMode = "halfExpand";
        continue;
      case "integer-width":
        if (s.options.length > 1) throw new RangeError("integer-width stems only accept a single optional option");
        s.options[0].replace(oS, function(m, y, p, _, w, E) {
          if (y) a.minimumIntegerDigits = p.length;
          else {
            if (_ && w) throw new Error("We currently do not support maximum integer digits");
            if (E) throw new Error("We currently do not support exact integer digits");
          }
          return "";
        });
        continue;
    }
    if (pg.test(s.stem)) {
      a.minimumIntegerDigits = s.stem.length;
      continue;
    }
    if (w0.test(s.stem)) {
      if (s.options.length > 1) throw new RangeError("Fraction-precision stems only accept a single optional option");
      s.stem.replace(w0, function(m, y, p, _, w, E) {
        return p === "*" ? a.minimumFractionDigits = y.length : _ && _[0] === "#" ? a.maximumFractionDigits = _.length : w && E ? (a.minimumFractionDigits = w.length, a.maximumFractionDigits = w.length + E.length) : (a.minimumFractionDigits = y.length, a.maximumFractionDigits = y.length), "";
      });
      var c = s.options[0];
      c === "w" ? a = de(de({}, a), { trailingZeroDisplay: "stripIfInteger" }) : c && (a = de(de({}, a), S0(c)));
      continue;
    }
    if (mg.test(s.stem)) {
      a = de(de({}, a), S0(s.stem));
      continue;
    }
    var d = vg(s.stem);
    d && (a = de(de({}, a), d));
    var h = lS(s.stem);
    h && (a = de(de({}, a), h));
  }
  return a;
}
var Ts = {
  "001": ["H", "h"],
  419: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  AC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  AD: ["H", "hB"],
  AE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  AF: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  AG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  AI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  AL: [
    "h",
    "H",
    "hB"
  ],
  AM: ["H", "hB"],
  AO: ["H", "hB"],
  AR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  AS: ["h", "H"],
  AT: ["H", "hB"],
  AU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  AW: ["H", "hB"],
  AX: ["H"],
  AZ: [
    "H",
    "hB",
    "h"
  ],
  BA: [
    "H",
    "hB",
    "h"
  ],
  BB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BD: [
    "h",
    "hB",
    "H"
  ],
  BE: ["H", "hB"],
  BF: ["H", "hB"],
  BG: [
    "H",
    "hB",
    "h"
  ],
  BH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  BI: ["H", "h"],
  BJ: ["H", "hB"],
  BL: ["H", "hB"],
  BM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BN: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  BO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  BQ: ["H"],
  BR: ["H", "hB"],
  BS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BT: ["h", "H"],
  BW: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BY: ["H", "h"],
  BZ: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CA: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  CC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CD: ["hB", "H"],
  CF: [
    "H",
    "h",
    "hB"
  ],
  CG: ["H", "hB"],
  CH: [
    "H",
    "hB",
    "h"
  ],
  CI: ["H", "hB"],
  CK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CL: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  CM: [
    "H",
    "h",
    "hB"
  ],
  CN: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  CO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  CP: ["H"],
  CR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  CU: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  CV: ["H", "hB"],
  CW: ["H", "hB"],
  CX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CY: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  CZ: ["H"],
  DE: ["H", "hB"],
  DG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  DJ: ["h", "H"],
  DK: ["H"],
  DM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  DO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  DZ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  EC: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  EE: ["H", "hB"],
  EG: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  ER: ["h", "H"],
  ES: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  ET: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  FI: ["H"],
  FJ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  FM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FO: ["H", "h"],
  FR: ["H", "hB"],
  GA: ["H", "hB"],
  GB: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GD: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GE: [
    "H",
    "hB",
    "h"
  ],
  GF: ["H", "hB"],
  GG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GH: ["h", "H"],
  GI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GL: ["H", "h"],
  GM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GN: ["H", "hB"],
  GP: ["H", "hB"],
  GQ: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  GR: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  GT: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  GU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GW: ["H", "hB"],
  GY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  HK: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  HN: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  HR: ["H", "hB"],
  HU: ["H", "h"],
  IC: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  ID: ["H"],
  IE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IL: ["H", "hB"],
  IM: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IN: ["h", "H"],
  IO: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IQ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  IR: ["hB", "H"],
  IS: ["H"],
  IT: ["H", "hB"],
  JE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  JM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  JO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  JP: [
    "H",
    "K",
    "h"
  ],
  KE: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  KG: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KH: [
    "hB",
    "h",
    "H",
    "hb"
  ],
  KI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KM: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KN: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KP: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KW: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  KY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KZ: ["H", "hB"],
  LA: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  LB: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LI: [
    "H",
    "hB",
    "h"
  ],
  LK: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  LR: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LS: ["h", "H"],
  LT: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  LU: [
    "H",
    "h",
    "hB"
  ],
  LV: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  LY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MC: ["H", "hB"],
  MD: ["H", "hB"],
  ME: [
    "H",
    "hB",
    "h"
  ],
  MF: ["H", "hB"],
  MG: ["H", "h"],
  MH: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  ML: ["H"],
  MM: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  MN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MP: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MQ: ["H", "hB"],
  MR: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MS: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MT: ["H", "h"],
  MU: ["H", "h"],
  MV: ["H", "h"],
  MW: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MX: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  MY: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  MZ: ["H", "hB"],
  NA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  NC: ["H", "hB"],
  NE: ["H"],
  NF: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NI: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  NL: ["H", "hB"],
  NO: ["H", "h"],
  NP: [
    "H",
    "h",
    "hB"
  ],
  NR: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NU: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  OM: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PE: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PF: [
    "H",
    "h",
    "hB"
  ],
  PG: ["h", "H"],
  PH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PK: [
    "h",
    "hB",
    "H"
  ],
  PL: ["H", "h"],
  PM: ["H", "hB"],
  PN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  PR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PS: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PT: ["H", "hB"],
  PW: ["h", "H"],
  PY: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  QA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  RE: ["H", "hB"],
  RO: ["H", "hB"],
  RS: [
    "H",
    "hB",
    "h"
  ],
  RU: ["H"],
  RW: ["H", "h"],
  SA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SC: [
    "H",
    "h",
    "hB"
  ],
  SD: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SE: ["H"],
  SG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SH: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SI: ["H", "hB"],
  SJ: ["H"],
  SK: ["H"],
  SL: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SM: [
    "H",
    "h",
    "hB"
  ],
  SN: [
    "H",
    "h",
    "hB"
  ],
  SO: ["h", "H"],
  SR: ["H", "hB"],
  SS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  ST: ["H", "hB"],
  SV: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  SX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  TC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TD: [
    "h",
    "H",
    "hB"
  ],
  TF: [
    "H",
    "h",
    "hB"
  ],
  TG: ["H", "hB"],
  TH: ["H", "h"],
  TJ: ["H", "h"],
  TL: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  TM: ["H", "h"],
  TN: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  TO: ["h", "H"],
  TR: ["H", "hB"],
  TT: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TW: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  TZ: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  UA: [
    "H",
    "hB",
    "h"
  ],
  UG: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  UM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  US: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  UY: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  UZ: [
    "H",
    "hB",
    "h"
  ],
  VA: [
    "H",
    "h",
    "hB"
  ],
  VC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VE: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  VG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VN: ["H", "h"],
  VU: ["h", "H"],
  WF: ["H", "hB"],
  WS: ["h", "H"],
  XK: [
    "H",
    "hB",
    "h"
  ],
  YE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  YT: ["H", "hB"],
  ZA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  ZM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  ZW: ["H", "h"],
  "af-ZA": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "ar-001": [
    "h",
    "hB",
    "hb",
    "H"
  ],
  "ca-ES": [
    "H",
    "h",
    "hB"
  ],
  "en-001": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "en-HK": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "en-IL": [
    "H",
    "h",
    "hb",
    "hB"
  ],
  "en-MY": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "es-BR": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-ES": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-GQ": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "fr-CA": [
    "H",
    "h",
    "hB"
  ],
  "gl-ES": [
    "H",
    "h",
    "hB"
  ],
  "gu-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "hi-IN": [
    "hB",
    "h",
    "H"
  ],
  "it-CH": [
    "H",
    "h",
    "hB"
  ],
  "it-IT": [
    "H",
    "h",
    "hB"
  ],
  "kn-IN": [
    "hB",
    "h",
    "H"
  ],
  "ml-IN": [
    "hB",
    "h",
    "H"
  ],
  "mr-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "pa-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "ta-IN": [
    "hB",
    "h",
    "hb",
    "H"
  ],
  "te-IN": [
    "hB",
    "h",
    "H"
  ],
  "zu-ZA": [
    "H",
    "hB",
    "hb",
    "h"
  ]
};
function uS(e, a) {
  for (var r = "", l = 0; l < e.length; l++) {
    var s = e.charAt(l);
    if (s === "j") {
      for (var c = 0; l + 1 < e.length && e.charAt(l + 1) === s; )
        c++, l++;
      var d = 1 + (c & 1), h = c < 2 ? 1 : 3 + (c >> 1), m = "a", y = cS(a);
      for ((y == "H" || y == "k") && (h = 0); h-- > 0; ) r += m;
      for (; d-- > 0; ) r = y + r;
    } else s === "J" ? r += "H" : r += s;
  }
  return r;
}
function cS(e) {
  var a = e.hourCycle;
  if (a === void 0 && e.hourCycles && e.hourCycles.length && (a = e.hourCycles[0]), a) switch (a) {
    case "h24":
      return "k";
    case "h23":
      return "H";
    case "h12":
      return "h";
    case "h11":
      return "K";
    default:
      throw new Error("Invalid hourCycle");
  }
  var r = e.language, l;
  return r !== "root" && (l = e.maximize().region), (Ts[l || ""] || Ts[r || ""] || Ts["".concat(r, "-001")] || Ts["001"])[0];
}
var Pf, fS = new RegExp("^".concat(hg.source, "*")), dS = new RegExp("".concat(hg.source, "*$"));
function He(e, a) {
  return {
    start: e,
    end: a
  };
}
var hS = !!String.prototype.startsWith && "_a".startsWith("a", 1), mS = !!String.fromCodePoint, pS = !!Object.fromEntries, vS = !!String.prototype.codePointAt, gS = !!String.prototype.trimStart, yS = !!String.prototype.trimEnd, bS = Number.isSafeInteger ? Number.isSafeInteger : function(e) {
  return typeof e == "number" && isFinite(e) && Math.floor(e) === e && Math.abs(e) <= 9007199254740991;
}, md = !0;
try {
  md = ((Pf = yg("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu").exec("a")) === null || Pf === void 0 ? void 0 : Pf[0]) === "a";
} catch {
  md = !1;
}
var T0 = hS ? function(a, r, l) {
  return a.startsWith(r, l);
} : function(a, r, l) {
  return a.slice(l, l + r.length) === r;
}, pd = mS ? String.fromCodePoint : function() {
  for (var a = [], r = 0; r < arguments.length; r++) a[r] = arguments[r];
  for (var l = "", s = a.length, c = 0, d; s > c; ) {
    if (d = a[c++], d > 1114111) throw RangeError(d + " is not a valid code point");
    l += d < 65536 ? String.fromCharCode(d) : String.fromCharCode(((d -= 65536) >> 10) + 55296, d % 1024 + 56320);
  }
  return l;
}, C0 = pS ? Object.fromEntries : function(a) {
  for (var r = {}, l = 0, s = a; l < s.length; l++) {
    var c = s[l], d = c[0];
    r[d] = c[1];
  }
  return r;
}, gg = vS ? function(a, r) {
  return a.codePointAt(r);
} : function(a, r) {
  var l = a.length;
  if (!(r < 0 || r >= l)) {
    var s = a.charCodeAt(r), c;
    return s < 55296 || s > 56319 || r + 1 === l || (c = a.charCodeAt(r + 1)) < 56320 || c > 57343 ? s : (s - 55296 << 10) + (c - 56320) + 65536;
  }
}, _S = gS ? function(a) {
  return a.trimStart();
} : function(a) {
  return a.replace(fS, "");
}, wS = yS ? function(a) {
  return a.trimEnd();
} : function(a) {
  return a.replace(dS, "");
};
function yg(e, a) {
  return new RegExp(e, a);
}
var vd;
if (md) {
  var A0 = yg("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  vd = function(a, r) {
    var l;
    return A0.lastIndex = r, (l = A0.exec(a)[1]) !== null && l !== void 0 ? l : "";
  };
} else vd = function(a, r) {
  for (var l = []; ; ) {
    var s = gg(a, r);
    if (s === void 0 || bg(s) || CS(s)) break;
    l.push(s), r += s >= 65536 ? 2 : 1;
  }
  return pd.apply(void 0, l);
};
var SS = (function() {
  function e(a, r) {
    r === void 0 && (r = {}), this.message = a, this.position = {
      offset: 0,
      line: 1,
      column: 1
    }, this.ignoreTag = !!r.ignoreTag, this.locale = r.locale, this.requiresOtherClause = !!r.requiresOtherClause, this.shouldParseSkeletons = !!r.shouldParseSkeletons;
  }
  return e.prototype.parse = function() {
    if (this.offset() !== 0) throw Error("parser can only be used once");
    return this.parseMessage(0, "", !1);
  }, e.prototype.parseMessage = function(a, r, l) {
    for (var s = []; !this.isEOF(); ) {
      var c = this.char();
      if (c === 123) {
        var d = this.parseArgument(a, l);
        if (d.err) return d;
        s.push(d.val);
      } else {
        if (c === 125 && a > 0) break;
        if (c === 35 && (r === "plural" || r === "selectordinal")) {
          var h = this.clonePosition();
          this.bump(), s.push({
            type: et.pound,
            location: He(h, this.clonePosition())
          });
        } else if (c === 60 && !this.ignoreTag && this.peek() === 47) {
          if (l) break;
          return this.error(Le.UNMATCHED_CLOSING_TAG, He(this.clonePosition(), this.clonePosition()));
        } else if (c === 60 && !this.ignoreTag && gd(this.peek() || 0)) {
          var d = this.parseTag(a, r);
          if (d.err) return d;
          s.push(d.val);
        } else {
          var d = this.parseLiteral(a, r);
          if (d.err) return d;
          s.push(d.val);
        }
      }
    }
    return {
      val: s,
      err: null
    };
  }, e.prototype.parseTag = function(a, r) {
    var l = this.clonePosition();
    this.bump();
    var s = this.parseTagName();
    if (this.bumpSpace(), this.bumpIf("/>")) return {
      val: {
        type: et.literal,
        value: "<".concat(s, "/>"),
        location: He(l, this.clonePosition())
      },
      err: null
    };
    if (this.bumpIf(">")) {
      var c = this.parseMessage(a + 1, r, !0);
      if (c.err) return c;
      var d = c.val, h = this.clonePosition();
      if (this.bumpIf("</")) {
        if (this.isEOF() || !gd(this.char())) return this.error(Le.INVALID_TAG, He(h, this.clonePosition()));
        var m = this.clonePosition();
        return s !== this.parseTagName() ? this.error(Le.UNMATCHED_CLOSING_TAG, He(m, this.clonePosition())) : (this.bumpSpace(), this.bumpIf(">") ? {
          val: {
            type: et.tag,
            value: s,
            children: d,
            location: He(l, this.clonePosition())
          },
          err: null
        } : this.error(Le.INVALID_TAG, He(h, this.clonePosition())));
      } else return this.error(Le.UNCLOSED_TAG, He(l, this.clonePosition()));
    } else return this.error(Le.INVALID_TAG, He(l, this.clonePosition()));
  }, e.prototype.parseTagName = function() {
    var a = this.offset();
    for (this.bump(); !this.isEOF() && TS(this.char()); ) this.bump();
    return this.message.slice(a, this.offset());
  }, e.prototype.parseLiteral = function(a, r) {
    for (var l = this.clonePosition(), s = ""; ; ) {
      var c = this.tryParseQuote(r);
      if (c) {
        s += c;
        continue;
      }
      var d = this.tryParseUnquoted(a, r);
      if (d) {
        s += d;
        continue;
      }
      var h = this.tryParseLeftAngleBracket();
      if (h) {
        s += h;
        continue;
      }
      break;
    }
    var m = He(l, this.clonePosition());
    return {
      val: {
        type: et.literal,
        value: s,
        location: m
      },
      err: null
    };
  }, e.prototype.tryParseLeftAngleBracket = function() {
    return !this.isEOF() && this.char() === 60 && (this.ignoreTag || !ES(this.peek() || 0)) ? (this.bump(), "<") : null;
  }, e.prototype.tryParseQuote = function(a) {
    if (this.isEOF() || this.char() !== 39) return null;
    switch (this.peek()) {
      case 39:
        return this.bump(), this.bump(), "'";
      case 123:
      case 60:
      case 62:
      case 125:
        break;
      case 35:
        if (a === "plural" || a === "selectordinal") break;
        return null;
      default:
        return null;
    }
    this.bump();
    var r = [this.char()];
    for (this.bump(); !this.isEOF(); ) {
      var l = this.char();
      if (l === 39) if (this.peek() === 39)
        r.push(39), this.bump();
      else {
        this.bump();
        break;
      }
      else r.push(l);
      this.bump();
    }
    return pd.apply(void 0, r);
  }, e.prototype.tryParseUnquoted = function(a, r) {
    if (this.isEOF()) return null;
    var l = this.char();
    return l === 60 || l === 123 || l === 35 && (r === "plural" || r === "selectordinal") || l === 125 && a > 0 ? null : (this.bump(), pd(l));
  }, e.prototype.parseArgument = function(a, r) {
    var l = this.clonePosition();
    if (this.bump(), this.bumpSpace(), this.isEOF()) return this.error(Le.EXPECT_ARGUMENT_CLOSING_BRACE, He(l, this.clonePosition()));
    if (this.char() === 125)
      return this.bump(), this.error(Le.EMPTY_ARGUMENT, He(l, this.clonePosition()));
    var s = this.parseIdentifierIfPossible().value;
    if (!s) return this.error(Le.MALFORMED_ARGUMENT, He(l, this.clonePosition()));
    if (this.bumpSpace(), this.isEOF()) return this.error(Le.EXPECT_ARGUMENT_CLOSING_BRACE, He(l, this.clonePosition()));
    switch (this.char()) {
      case 125:
        return this.bump(), {
          val: {
            type: et.argument,
            value: s,
            location: He(l, this.clonePosition())
          },
          err: null
        };
      case 44:
        return this.bump(), this.bumpSpace(), this.isEOF() ? this.error(Le.EXPECT_ARGUMENT_CLOSING_BRACE, He(l, this.clonePosition())) : this.parseArgumentOptions(a, r, s, l);
      default:
        return this.error(Le.MALFORMED_ARGUMENT, He(l, this.clonePosition()));
    }
  }, e.prototype.parseIdentifierIfPossible = function() {
    var a = this.clonePosition(), r = this.offset(), l = vd(this.message, r), s = r + l.length;
    return this.bumpTo(s), {
      value: l,
      location: He(a, this.clonePosition())
    };
  }, e.prototype.parseArgumentOptions = function(a, r, l, s) {
    var c, d = this.clonePosition(), h = this.parseIdentifierIfPossible().value, m = this.clonePosition();
    switch (h) {
      case "":
        return this.error(Le.EXPECT_ARGUMENT_TYPE, He(d, m));
      case "number":
      case "date":
      case "time":
        this.bumpSpace();
        var y = null;
        if (this.bumpIf(",")) {
          this.bumpSpace();
          var p = this.clonePosition(), _ = this.parseSimpleArgStyleIfPossible();
          if (_.err) return _;
          var w = wS(_.val);
          if (w.length === 0) return this.error(Le.EXPECT_ARGUMENT_STYLE, He(this.clonePosition(), this.clonePosition()));
          y = {
            style: w,
            styleLocation: He(p, this.clonePosition())
          };
        }
        var H = this.tryParseArgumentClose(s);
        if (H.err) return H;
        var E = He(s, this.clonePosition());
        if (y && T0(y?.style, "::", 0)) {
          var x = _S(y.style.slice(2));
          if (h === "number") {
            var _ = this.parseNumberSkeletonFromString(x, y.styleLocation);
            return _.err ? _ : {
              val: {
                type: et.number,
                value: l,
                location: E,
                style: _.val
              },
              err: null
            };
          } else {
            if (x.length === 0) return this.error(Le.EXPECT_DATE_TIME_SKELETON, E);
            var C = x;
            this.locale && (C = uS(x, this.locale));
            var w = {
              type: Lr.dateTime,
              pattern: C,
              location: y.styleLocation,
              parsedOptions: this.shouldParseSkeletons ? nS(C) : {}
            };
            return {
              val: {
                type: h === "date" ? et.date : et.time,
                value: l,
                location: E,
                style: w
              },
              err: null
            };
          }
        }
        return {
          val: {
            type: h === "number" ? et.number : h === "date" ? et.date : et.time,
            value: l,
            location: E,
            style: (c = y?.style) !== null && c !== void 0 ? c : null
          },
          err: null
        };
      case "plural":
      case "selectordinal":
      case "select":
        var T = this.clonePosition();
        if (this.bumpSpace(), !this.bumpIf(",")) return this.error(Le.EXPECT_SELECT_ARGUMENT_OPTIONS, He(T, de({}, T)));
        this.bumpSpace();
        var M = this.parseIdentifierIfPossible(), D = 0;
        if (h !== "select" && M.value === "offset") {
          if (!this.bumpIf(":")) return this.error(Le.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, He(this.clonePosition(), this.clonePosition()));
          this.bumpSpace();
          var _ = this.tryParseDecimalInteger(Le.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, Le.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE);
          if (_.err) return _;
          this.bumpSpace(), M = this.parseIdentifierIfPossible(), D = _.val;
        }
        var j = this.tryParsePluralOrSelectOptions(a, h, r, M);
        if (j.err) return j;
        var H = this.tryParseArgumentClose(s);
        if (H.err) return H;
        var k = He(s, this.clonePosition());
        return h === "select" ? {
          val: {
            type: et.select,
            value: l,
            options: C0(j.val),
            location: k
          },
          err: null
        } : {
          val: {
            type: et.plural,
            value: l,
            options: C0(j.val),
            offset: D,
            pluralType: h === "plural" ? "cardinal" : "ordinal",
            location: k
          },
          err: null
        };
      default:
        return this.error(Le.INVALID_ARGUMENT_TYPE, He(d, m));
    }
  }, e.prototype.tryParseArgumentClose = function(a) {
    return this.isEOF() || this.char() !== 125 ? this.error(Le.EXPECT_ARGUMENT_CLOSING_BRACE, He(a, this.clonePosition())) : (this.bump(), {
      val: !0,
      err: null
    });
  }, e.prototype.parseSimpleArgStyleIfPossible = function() {
    for (var a = 0, r = this.clonePosition(); !this.isEOF(); ) switch (this.char()) {
      case 39:
        this.bump();
        var l = this.clonePosition();
        if (!this.bumpUntil("'")) return this.error(Le.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE, He(l, this.clonePosition()));
        this.bump();
        break;
      case 123:
        a += 1, this.bump();
        break;
      case 125:
        if (a > 0) a -= 1;
        else return {
          val: this.message.slice(r.offset, this.offset()),
          err: null
        };
        break;
      default:
        this.bump();
        break;
    }
    return {
      val: this.message.slice(r.offset, this.offset()),
      err: null
    };
  }, e.prototype.parseNumberSkeletonFromString = function(a, r) {
    var l = [];
    try {
      l = iS(a);
    } catch {
      return this.error(Le.INVALID_NUMBER_SKELETON, r);
    }
    return {
      val: {
        type: Lr.number,
        tokens: l,
        location: r,
        parsedOptions: this.shouldParseSkeletons ? sS(l) : {}
      },
      err: null
    };
  }, e.prototype.tryParsePluralOrSelectOptions = function(a, r, l, s) {
    for (var c, d = !1, h = [], m = /* @__PURE__ */ new Set(), y = s.value, p = s.location; ; ) {
      if (y.length === 0) {
        var _ = this.clonePosition();
        if (r !== "select" && this.bumpIf("=")) {
          var w = this.tryParseDecimalInteger(Le.EXPECT_PLURAL_ARGUMENT_SELECTOR, Le.INVALID_PLURAL_ARGUMENT_SELECTOR);
          if (w.err) return w;
          p = He(_, this.clonePosition()), y = this.message.slice(_.offset, this.offset());
        } else break;
      }
      if (m.has(y)) return this.error(r === "select" ? Le.DUPLICATE_SELECT_ARGUMENT_SELECTOR : Le.DUPLICATE_PLURAL_ARGUMENT_SELECTOR, p);
      y === "other" && (d = !0), this.bumpSpace();
      var E = this.clonePosition();
      if (!this.bumpIf("{")) return this.error(r === "select" ? Le.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT : Le.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT, He(this.clonePosition(), this.clonePosition()));
      var x = this.parseMessage(a + 1, r, l);
      if (x.err) return x;
      var C = this.tryParseArgumentClose(E);
      if (C.err) return C;
      h.push([y, {
        value: x.val,
        location: He(E, this.clonePosition())
      }]), m.add(y), this.bumpSpace(), c = this.parseIdentifierIfPossible(), y = c.value, p = c.location;
    }
    return h.length === 0 ? this.error(r === "select" ? Le.EXPECT_SELECT_ARGUMENT_SELECTOR : Le.EXPECT_PLURAL_ARGUMENT_SELECTOR, He(this.clonePosition(), this.clonePosition())) : this.requiresOtherClause && !d ? this.error(Le.MISSING_OTHER_CLAUSE, He(this.clonePosition(), this.clonePosition())) : {
      val: h,
      err: null
    };
  }, e.prototype.tryParseDecimalInteger = function(a, r) {
    var l = 1, s = this.clonePosition();
    this.bumpIf("+") || this.bumpIf("-") && (l = -1);
    for (var c = !1, d = 0; !this.isEOF(); ) {
      var h = this.char();
      if (h >= 48 && h <= 57)
        c = !0, d = d * 10 + (h - 48), this.bump();
      else break;
    }
    var m = He(s, this.clonePosition());
    return c ? (d *= l, bS(d) ? {
      val: d,
      err: null
    } : this.error(r, m)) : this.error(a, m);
  }, e.prototype.offset = function() {
    return this.position.offset;
  }, e.prototype.isEOF = function() {
    return this.offset() === this.message.length;
  }, e.prototype.clonePosition = function() {
    return {
      offset: this.position.offset,
      line: this.position.line,
      column: this.position.column
    };
  }, e.prototype.char = function() {
    var a = this.position.offset;
    if (a >= this.message.length) throw Error("out of bound");
    var r = gg(this.message, a);
    if (r === void 0) throw Error("Offset ".concat(a, " is at invalid UTF-16 code unit boundary"));
    return r;
  }, e.prototype.error = function(a, r) {
    return {
      val: null,
      err: {
        kind: a,
        message: this.message,
        location: r
      }
    };
  }, e.prototype.bump = function() {
    if (!this.isEOF()) {
      var a = this.char();
      a === 10 ? (this.position.line += 1, this.position.column = 1, this.position.offset += 1) : (this.position.column += 1, this.position.offset += a < 65536 ? 1 : 2);
    }
  }, e.prototype.bumpIf = function(a) {
    if (T0(this.message, a, this.offset())) {
      for (var r = 0; r < a.length; r++) this.bump();
      return !0;
    }
    return !1;
  }, e.prototype.bumpUntil = function(a) {
    var r = this.offset(), l = this.message.indexOf(a, r);
    return l >= 0 ? (this.bumpTo(l), !0) : (this.bumpTo(this.message.length), !1);
  }, e.prototype.bumpTo = function(a) {
    if (this.offset() > a) throw Error("targetOffset ".concat(a, " must be greater than or equal to the current offset ").concat(this.offset()));
    for (a = Math.min(a, this.message.length); ; ) {
      var r = this.offset();
      if (r === a) break;
      if (r > a) throw Error("targetOffset ".concat(a, " is at invalid UTF-16 code unit boundary"));
      if (this.bump(), this.isEOF()) break;
    }
  }, e.prototype.bumpSpace = function() {
    for (; !this.isEOF() && bg(this.char()); ) this.bump();
  }, e.prototype.peek = function() {
    if (this.isEOF()) return null;
    var a = this.char(), r = this.offset(), l = this.message.charCodeAt(r + (a >= 65536 ? 2 : 1));
    return l ?? null;
  }, e;
})();
function gd(e) {
  return e >= 97 && e <= 122 || e >= 65 && e <= 90;
}
function ES(e) {
  return gd(e) || e === 47;
}
function TS(e) {
  return e === 45 || e === 46 || e >= 48 && e <= 57 || e === 95 || e >= 97 && e <= 122 || e >= 65 && e <= 90 || e == 183 || e >= 192 && e <= 214 || e >= 216 && e <= 246 || e >= 248 && e <= 893 || e >= 895 && e <= 8191 || e >= 8204 && e <= 8205 || e >= 8255 && e <= 8256 || e >= 8304 && e <= 8591 || e >= 11264 && e <= 12271 || e >= 12289 && e <= 55295 || e >= 63744 && e <= 64975 || e >= 65008 && e <= 65533 || e >= 65536 && e <= 983039;
}
function bg(e) {
  return e >= 9 && e <= 13 || e === 32 || e === 133 || e >= 8206 && e <= 8207 || e === 8232 || e === 8233;
}
function CS(e) {
  return e >= 33 && e <= 35 || e === 36 || e >= 37 && e <= 39 || e === 40 || e === 41 || e === 42 || e === 43 || e === 44 || e === 45 || e >= 46 && e <= 47 || e >= 58 && e <= 59 || e >= 60 && e <= 62 || e >= 63 && e <= 64 || e === 91 || e === 92 || e === 93 || e === 94 || e === 96 || e === 123 || e === 124 || e === 125 || e === 126 || e === 161 || e >= 162 && e <= 165 || e === 166 || e === 167 || e === 169 || e === 171 || e === 172 || e === 174 || e === 176 || e === 177 || e === 182 || e === 187 || e === 191 || e === 215 || e === 247 || e >= 8208 && e <= 8213 || e >= 8214 && e <= 8215 || e === 8216 || e === 8217 || e === 8218 || e >= 8219 && e <= 8220 || e === 8221 || e === 8222 || e === 8223 || e >= 8224 && e <= 8231 || e >= 8240 && e <= 8248 || e === 8249 || e === 8250 || e >= 8251 && e <= 8254 || e >= 8257 && e <= 8259 || e === 8260 || e === 8261 || e === 8262 || e >= 8263 && e <= 8273 || e === 8274 || e === 8275 || e >= 8277 && e <= 8286 || e >= 8592 && e <= 8596 || e >= 8597 && e <= 8601 || e >= 8602 && e <= 8603 || e >= 8604 && e <= 8607 || e === 8608 || e >= 8609 && e <= 8610 || e === 8611 || e >= 8612 && e <= 8613 || e === 8614 || e >= 8615 && e <= 8621 || e === 8622 || e >= 8623 && e <= 8653 || e >= 8654 && e <= 8655 || e >= 8656 && e <= 8657 || e === 8658 || e === 8659 || e === 8660 || e >= 8661 && e <= 8691 || e >= 8692 && e <= 8959 || e >= 8960 && e <= 8967 || e === 8968 || e === 8969 || e === 8970 || e === 8971 || e >= 8972 && e <= 8991 || e >= 8992 && e <= 8993 || e >= 8994 && e <= 9e3 || e === 9001 || e === 9002 || e >= 9003 && e <= 9083 || e === 9084 || e >= 9085 && e <= 9114 || e >= 9115 && e <= 9139 || e >= 9140 && e <= 9179 || e >= 9180 && e <= 9185 || e >= 9186 && e <= 9254 || e >= 9255 && e <= 9279 || e >= 9280 && e <= 9290 || e >= 9291 && e <= 9311 || e >= 9472 && e <= 9654 || e === 9655 || e >= 9656 && e <= 9664 || e === 9665 || e >= 9666 && e <= 9719 || e >= 9720 && e <= 9727 || e >= 9728 && e <= 9838 || e === 9839 || e >= 9840 && e <= 10087 || e === 10088 || e === 10089 || e === 10090 || e === 10091 || e === 10092 || e === 10093 || e === 10094 || e === 10095 || e === 10096 || e === 10097 || e === 10098 || e === 10099 || e === 10100 || e === 10101 || e >= 10132 && e <= 10175 || e >= 10176 && e <= 10180 || e === 10181 || e === 10182 || e >= 10183 && e <= 10213 || e === 10214 || e === 10215 || e === 10216 || e === 10217 || e === 10218 || e === 10219 || e === 10220 || e === 10221 || e === 10222 || e === 10223 || e >= 10224 && e <= 10239 || e >= 10240 && e <= 10495 || e >= 10496 && e <= 10626 || e === 10627 || e === 10628 || e === 10629 || e === 10630 || e === 10631 || e === 10632 || e === 10633 || e === 10634 || e === 10635 || e === 10636 || e === 10637 || e === 10638 || e === 10639 || e === 10640 || e === 10641 || e === 10642 || e === 10643 || e === 10644 || e === 10645 || e === 10646 || e === 10647 || e === 10648 || e >= 10649 && e <= 10711 || e === 10712 || e === 10713 || e === 10714 || e === 10715 || e >= 10716 && e <= 10747 || e === 10748 || e === 10749 || e >= 10750 && e <= 11007 || e >= 11008 && e <= 11055 || e >= 11056 && e <= 11076 || e >= 11077 && e <= 11078 || e >= 11079 && e <= 11084 || e >= 11085 && e <= 11123 || e >= 11124 && e <= 11125 || e >= 11126 && e <= 11157 || e === 11158 || e >= 11159 && e <= 11263 || e >= 11776 && e <= 11777 || e === 11778 || e === 11779 || e === 11780 || e === 11781 || e >= 11782 && e <= 11784 || e === 11785 || e === 11786 || e === 11787 || e === 11788 || e === 11789 || e >= 11790 && e <= 11798 || e === 11799 || e >= 11800 && e <= 11801 || e === 11802 || e === 11803 || e === 11804 || e === 11805 || e >= 11806 && e <= 11807 || e === 11808 || e === 11809 || e === 11810 || e === 11811 || e === 11812 || e === 11813 || e === 11814 || e === 11815 || e === 11816 || e === 11817 || e >= 11818 && e <= 11822 || e === 11823 || e >= 11824 && e <= 11833 || e >= 11834 && e <= 11835 || e >= 11836 && e <= 11839 || e === 11840 || e === 11841 || e === 11842 || e >= 11843 && e <= 11855 || e >= 11856 && e <= 11857 || e === 11858 || e >= 11859 && e <= 11903 || e >= 12289 && e <= 12291 || e === 12296 || e === 12297 || e === 12298 || e === 12299 || e === 12300 || e === 12301 || e === 12302 || e === 12303 || e === 12304 || e === 12305 || e >= 12306 && e <= 12307 || e === 12308 || e === 12309 || e === 12310 || e === 12311 || e === 12312 || e === 12313 || e === 12314 || e === 12315 || e === 12316 || e === 12317 || e >= 12318 && e <= 12319 || e === 12320 || e === 12336 || e === 64830 || e === 64831 || e >= 65093 && e <= 65094;
}
function yd(e) {
  e.forEach(function(a) {
    if (delete a.location, ug(a) || cg(a)) for (var r in a.options)
      delete a.options[r].location, yd(a.options[r].value);
    else og(a) && dg(a.style) || (lg(a) || sg(a)) && hd(a.style) ? delete a.style.location : fg(a) && yd(a.children);
  });
}
function AS(e, a) {
  a === void 0 && (a = {}), a = de({
    shouldParseSkeletons: !0,
    requiresOtherClause: !0
  }, a);
  var r = new SS(e, a).parse();
  if (r.err) {
    var l = SyntaxError(Le[r.err.kind]);
    throw l.location = r.err.location, l.originalMessage = r.err.message, l;
  }
  return a?.captureLocation || yd(r.val), r.val;
}
var na;
(function(e) {
  e.MISSING_VALUE = "MISSING_VALUE", e.INVALID_VALUE = "INVALID_VALUE", e.MISSING_INTL_API = "MISSING_INTL_API";
})(na || (na = {}));
var ii = (function(e) {
  zn(a, e);
  function a(r, l, s) {
    var c = e.call(this, r) || this;
    return c.code = l, c.originalMessage = s, c;
  }
  return a.prototype.toString = function() {
    return "[formatjs Error: ".concat(this.code, "] ").concat(this.message);
  }, a;
})(Error), x0 = (function(e) {
  zn(a, e);
  function a(r, l, s, c) {
    return e.call(this, 'Invalid values for "'.concat(r, '": "').concat(l, '". Options are "').concat(Object.keys(s).join('", "'), '"'), na.INVALID_VALUE, c) || this;
  }
  return a;
})(ii), xS = (function(e) {
  zn(a, e);
  function a(r, l, s) {
    return e.call(this, 'Value for "'.concat(r, '" must be of type ').concat(l), na.INVALID_VALUE, s) || this;
  }
  return a;
})(ii), OS = (function(e) {
  zn(a, e);
  function a(r, l) {
    return e.call(this, 'The intl string context variable "'.concat(r, '" was not provided to the string "').concat(l, '"'), na.MISSING_VALUE, l) || this;
  }
  return a;
})(ii), Vt;
(function(e) {
  e[e.literal = 0] = "literal", e[e.object = 1] = "object";
})(Vt || (Vt = {}));
function MS(e) {
  return e.length < 2 ? e : e.reduce(function(a, r) {
    var l = a[a.length - 1];
    return !l || l.type !== Vt.literal || r.type !== Vt.literal ? a.push(r) : l.value += r.value, a;
  }, []);
}
function _g(e) {
  return typeof e == "function";
}
function ks(e, a, r, l, s, c, d) {
  if (e.length === 1 && _0(e[0])) return [{
    type: Vt.literal,
    value: e[0].value
  }];
  for (var h = [], m = 0, y = e; m < y.length; m++) {
    var p = y[m];
    if (_0(p)) {
      h.push({
        type: Vt.literal,
        value: p.value
      });
      continue;
    }
    if (eS(p)) {
      typeof c == "number" && h.push({
        type: Vt.literal,
        value: r.getNumberFormat(a).format(c)
      });
      continue;
    }
    var _ = p.value;
    if (!(s && _ in s)) throw new OS(_, d);
    var w = s[_];
    if (Jw(p)) {
      (!w || typeof w == "string" || typeof w == "number") && (w = typeof w == "string" || typeof w == "number" ? String(w) : ""), h.push({
        type: typeof w == "string" ? Vt.literal : Vt.object,
        value: w
      });
      continue;
    }
    if (lg(p)) {
      var E = typeof p.style == "string" ? l.date[p.style] : hd(p.style) ? p.style.parsedOptions : void 0;
      h.push({
        type: Vt.literal,
        value: r.getDateTimeFormat(a, E).format(w)
      });
      continue;
    }
    if (sg(p)) {
      var E = typeof p.style == "string" ? l.time[p.style] : hd(p.style) ? p.style.parsedOptions : l.time.medium;
      h.push({
        type: Vt.literal,
        value: r.getDateTimeFormat(a, E).format(w)
      });
      continue;
    }
    if (og(p)) {
      var E = typeof p.style == "string" ? l.number[p.style] : dg(p.style) ? p.style.parsedOptions : void 0;
      E && E.scale && (w = w * (E.scale || 1)), h.push({
        type: Vt.literal,
        value: r.getNumberFormat(a, E).format(w)
      });
      continue;
    }
    if (fg(p)) {
      var x = p.children, C = p.value, T = s[C];
      if (!_g(T)) throw new xS(C, "function", d);
      var M = T(ks(x, a, r, l, s, c).map(function(H) {
        return H.value;
      }));
      Array.isArray(M) || (M = [M]), h.push.apply(h, M.map(function(H) {
        return {
          type: typeof H == "string" ? Vt.literal : Vt.object,
          value: H
        };
      }));
    }
    if (ug(p)) {
      var D = p.options[w] || p.options.other;
      if (!D) throw new x0(p.value, w, Object.keys(p.options), d);
      h.push.apply(h, ks(D.value, a, r, l, s));
      continue;
    }
    if (cg(p)) {
      var D = p.options["=".concat(w)];
      if (!D) {
        if (!Intl.PluralRules) throw new ii(`Intl.PluralRules is not available in this environment.
Try polyfilling it using "@formatjs/intl-pluralrules"
`, na.MISSING_INTL_API, d);
        var j = r.getPluralRules(a, { type: p.pluralType }).select(w - (p.offset || 0));
        D = p.options[j] || p.options.other;
      }
      if (!D) throw new x0(p.value, w, Object.keys(p.options), d);
      h.push.apply(h, ks(D.value, a, r, l, s, w - (p.offset || 0)));
      continue;
    }
  }
  return MS(h);
}
function RS(e, a) {
  return a ? de(de(de({}, e || {}), a || {}), Object.keys(e).reduce(function(r, l) {
    return r[l] = de(de({}, e[l]), a[l] || {}), r;
  }, {})) : e;
}
function NS(e, a) {
  return a ? Object.keys(e).reduce(function(r, l) {
    return r[l] = RS(e[l], a[l]), r;
  }, de({}, e)) : e;
}
function If(e) {
  return { create: function() {
    return {
      get: function(a) {
        return e[a];
      },
      set: function(a, r) {
        e[a] = r;
      }
    };
  } };
}
function DS(e) {
  return e === void 0 && (e = {
    number: {},
    dateTime: {},
    pluralRules: {}
  }), {
    getNumberFormat: Kn(function() {
      for (var a, r = [], l = 0; l < arguments.length; l++) r[l] = arguments[l];
      return new ((a = Intl.NumberFormat).bind.apply(a, Gn([void 0], r, !1)))();
    }, {
      cache: If(e.number),
      strategy: Jn.variadic
    }),
    getDateTimeFormat: Kn(function() {
      for (var a, r = [], l = 0; l < arguments.length; l++) r[l] = arguments[l];
      return new ((a = Intl.DateTimeFormat).bind.apply(a, Gn([void 0], r, !1)))();
    }, {
      cache: If(e.dateTime),
      strategy: Jn.variadic
    }),
    getPluralRules: Kn(function() {
      for (var a, r = [], l = 0; l < arguments.length; l++) r[l] = arguments[l];
      return new ((a = Intl.PluralRules).bind.apply(a, Gn([void 0], r, !1)))();
    }, {
      cache: If(e.pluralRules),
      strategy: Jn.variadic
    })
  };
}
var wg = (function() {
  function e(a, r, l, s) {
    r === void 0 && (r = e.defaultLocale);
    var c = this;
    if (this.formatterCache = {
      number: {},
      dateTime: {},
      pluralRules: {}
    }, this.format = function(m) {
      var y = c.formatToParts(m);
      if (y.length === 1) return y[0].value;
      var p = y.reduce(function(_, w) {
        return !_.length || w.type !== Vt.literal || typeof _[_.length - 1] != "string" ? _.push(w.value) : _[_.length - 1] += w.value, _;
      }, []);
      return p.length <= 1 ? p[0] || "" : p;
    }, this.formatToParts = function(m) {
      return ks(c.ast, c.locales, c.formatters, c.formats, m, void 0, c.message);
    }, this.resolvedOptions = function() {
      var m;
      return { locale: ((m = c.resolvedLocale) === null || m === void 0 ? void 0 : m.toString()) || Intl.NumberFormat.supportedLocalesOf(c.locales)[0] };
    }, this.getAst = function() {
      return c.ast;
    }, this.locales = r, this.resolvedLocale = e.resolveLocale(r), typeof a == "string") {
      if (this.message = a, !e.__parse) throw new TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
      var d = s || {};
      d.formatters;
      var h = Ca(d, ["formatters"]);
      this.ast = e.__parse(a, de(de({}, h), { locale: this.resolvedLocale }));
    } else this.ast = a;
    if (!Array.isArray(this.ast)) throw new TypeError("A message must be provided as a String or AST.");
    this.formats = NS(e.formats, l), this.formatters = s && s.formatters || DS(this.formatterCache);
  }
  return Object.defineProperty(e, "defaultLocale", {
    get: function() {
      return e.memoizedDefaultLocale || (e.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale), e.memoizedDefaultLocale;
    },
    enumerable: !1,
    configurable: !0
  }), e.memoizedDefaultLocale = null, e.resolveLocale = function(a) {
    if (!(typeof Intl.Locale > "u")) {
      var r = Intl.NumberFormat.supportedLocalesOf(a);
      return r.length > 0 ? new Intl.Locale(r[0]) : new Intl.Locale(typeof a == "string" ? a : a[0]);
    }
  }, e.__parse = AS, e.formats = {
    number: {
      integer: { maximumFractionDigits: 0 },
      currency: { style: "currency" },
      percent: { style: "percent" }
    },
    date: {
      short: {
        month: "numeric",
        day: "numeric",
        year: "2-digit"
      },
      medium: {
        month: "short",
        day: "numeric",
        year: "numeric"
      },
      long: {
        month: "long",
        day: "numeric",
        year: "numeric"
      },
      full: {
        weekday: "long",
        month: "long",
        day: "numeric",
        year: "numeric"
      }
    },
    time: {
      short: {
        hour: "numeric",
        minute: "numeric"
      },
      medium: {
        hour: "numeric",
        minute: "numeric",
        second: "numeric"
      },
      long: {
        hour: "numeric",
        minute: "numeric",
        second: "numeric",
        timeZoneName: "short"
      },
      full: {
        hour: "numeric",
        minute: "numeric",
        second: "numeric",
        timeZoneName: "short"
      }
    }
  }, e;
})(), Ri;
(function(e) {
  e.FORMAT_ERROR = "FORMAT_ERROR", e.UNSUPPORTED_FORMATTER = "UNSUPPORTED_FORMATTER", e.INVALID_CONFIG = "INVALID_CONFIG", e.MISSING_DATA = "MISSING_DATA", e.MISSING_TRANSLATION = "MISSING_TRANSLATION";
})(Ri || (Ri = {}));
var Jo = (function(e) {
  zn(a, e);
  function a(r, l, s) {
    var c = this, d = s ? s instanceof Error ? s : new Error(String(s)) : void 0;
    return c = e.call(this, "[@formatjs/intl Error ".concat(r, "] ").concat(l, `
`).concat(d ? `
`.concat(d.message, `
`).concat(d.stack) : "")) || this, c.code = r, typeof Error.captureStackTrace == "function" && Error.captureStackTrace(c, a), c;
  }
  return a;
})(Error), zS = (function(e) {
  zn(a, e);
  function a(r, l) {
    return e.call(this, Ri.UNSUPPORTED_FORMATTER, r, l) || this;
  }
  return a;
})(Jo), LS = (function(e) {
  zn(a, e);
  function a(r, l) {
    return e.call(this, Ri.INVALID_CONFIG, r, l) || this;
  }
  return a;
})(Jo), O0 = (function(e) {
  zn(a, e);
  function a(r, l) {
    return e.call(this, Ri.MISSING_DATA, r, l) || this;
  }
  return a;
})(Jo), Ln = (function(e) {
  zn(a, e);
  function a(r, l, s) {
    var c = e.call(this, Ri.FORMAT_ERROR, "".concat(r, `
Locale: `).concat(l, `
`), s) || this;
    return c.locale = l, c;
  }
  return a;
})(Jo), Zf = (function(e) {
  zn(a, e);
  function a(r, l, s, c) {
    var d = e.call(this, "".concat(r, `
MessageID: `).concat(s?.id, `
Default Message: `).concat(s?.defaultMessage, `
Description: `).concat(s?.description, `
`), l, c) || this;
    return d.descriptor = s, d.locale = l, d;
  }
  return a;
})(Ln), HS = (function(e) {
  zn(a, e);
  function a(r, l) {
    var s = e.call(this, Ri.MISSING_TRANSLATION, 'Missing message: "'.concat(r.id, '" for locale "').concat(l, '", using ').concat(r.defaultMessage ? "default message (".concat(typeof r.defaultMessage == "string" ? r.defaultMessage : r.defaultMessage.map(function(c) {
      var d;
      return (d = c.value) !== null && d !== void 0 ? d : JSON.stringify(c);
    }).join(), ")") : "id", " as fallback.")) || this;
    return s.descriptor = r, s;
  }
  return a;
})(Jo);
function jS(e, a, r) {
  if (r === void 0 && (r = Error), !e) throw new r(a);
}
function Ir(e, a, r) {
  return r === void 0 && (r = {}), a.reduce(function(l, s) {
    return s in e ? l[s] = e[s] : s in r && (l[s] = r[s]), l;
  }, {});
}
var BS = function(e) {
}, US = function(e) {
}, Sg = {
  formats: {},
  messages: {},
  timeZone: void 0,
  defaultLocale: "en",
  defaultFormats: {},
  fallbackOnEmptyString: !0,
  onError: BS,
  onWarn: US
};
function Eg() {
  return {
    dateTime: {},
    number: {},
    message: {},
    relativeTime: {},
    pluralRules: {},
    list: {},
    displayNames: {}
  };
}
function Oi(e) {
  return { create: function() {
    return {
      get: function(a) {
        return e[a];
      },
      set: function(a, r) {
        e[a] = r;
      }
    };
  } };
}
function kS(e) {
  e === void 0 && (e = Eg());
  var a = Intl.RelativeTimeFormat, r = Intl.ListFormat, l = Intl.DisplayNames, s = Kn(function() {
    for (var h, m = [], y = 0; y < arguments.length; y++) m[y] = arguments[y];
    return new ((h = Intl.DateTimeFormat).bind.apply(h, Gn([void 0], m, !1)))();
  }, {
    cache: Oi(e.dateTime),
    strategy: Jn.variadic
  }), c = Kn(function() {
    for (var h, m = [], y = 0; y < arguments.length; y++) m[y] = arguments[y];
    return new ((h = Intl.NumberFormat).bind.apply(h, Gn([void 0], m, !1)))();
  }, {
    cache: Oi(e.number),
    strategy: Jn.variadic
  }), d = Kn(function() {
    for (var h, m = [], y = 0; y < arguments.length; y++) m[y] = arguments[y];
    return new ((h = Intl.PluralRules).bind.apply(h, Gn([void 0], m, !1)))();
  }, {
    cache: Oi(e.pluralRules),
    strategy: Jn.variadic
  });
  return {
    getDateTimeFormat: s,
    getNumberFormat: c,
    getMessageFormat: Kn(function(h, m, y, p) {
      return new wg(h, m, y, de({ formatters: {
        getNumberFormat: c,
        getDateTimeFormat: s,
        getPluralRules: d
      } }, p || {}));
    }, {
      cache: Oi(e.message),
      strategy: Jn.variadic
    }),
    getRelativeTimeFormat: Kn(function() {
      for (var h = [], m = 0; m < arguments.length; m++) h[m] = arguments[m];
      return new (a.bind.apply(a, Gn([void 0], h, !1)))();
    }, {
      cache: Oi(e.relativeTime),
      strategy: Jn.variadic
    }),
    getPluralRules: d,
    getListFormat: Kn(function() {
      for (var h = [], m = 0; m < arguments.length; m++) h[m] = arguments[m];
      return new (r.bind.apply(r, Gn([void 0], h, !1)))();
    }, {
      cache: Oi(e.list),
      strategy: Jn.variadic
    }),
    getDisplayNames: Kn(function() {
      for (var h = [], m = 0; m < arguments.length; m++) h[m] = arguments[m];
      return new (l.bind.apply(l, Gn([void 0], h, !1)))();
    }, {
      cache: Oi(e.displayNames),
      strategy: Jn.variadic
    })
  };
}
function $d(e, a, r, l) {
  var s = e && e[a], c;
  if (s && (c = s[r]), c) return c;
  l(new zS("No ".concat(a, " format named: ").concat(r)));
}
function Cs(e, a) {
  return Object.keys(e).reduce(function(r, l) {
    return r[l] = de({ timeZone: a }, e[l]), r;
  }, {});
}
function M0(e, a) {
  return Object.keys(de(de({}, e), a)).reduce(function(r, l) {
    return r[l] = de(de({}, e[l] || {}), a[l] || {}), r;
  }, {});
}
function R0(e, a) {
  if (!a) return e;
  var r = wg.formats;
  return de(de(de({}, r), e), {
    date: M0(Cs(r.date, a), Cs(e.date || {}, a)),
    time: M0(Cs(r.time, a), Cs(e.time || {}, a))
  });
}
var bd = function(e, a, r, l, s) {
  var c = e.locale, d = e.formats, h = e.messages, m = e.defaultLocale, y = e.defaultFormats, p = e.fallbackOnEmptyString, _ = e.onError, w = e.timeZone, E = e.defaultRichTextElements;
  r === void 0 && (r = { id: "" });
  var x = r.id, C = r.defaultMessage;
  jS(!!x, "[@formatjs/intl] An `id` must be provided to format a message. You can either:\n1. Configure your build toolchain with [babel-plugin-formatjs](https://formatjs.github.io/docs/tooling/babel-plugin)\nor [@formatjs/ts-transformer](https://formatjs.github.io/docs/tooling/ts-transformer) OR\n2. Configure your `eslint` config to include [eslint-plugin-formatjs](https://formatjs.github.io/docs/tooling/linter#enforce-id)\nto autofix this issue");
  var T = String(x), M = h && Object.prototype.hasOwnProperty.call(h, T) && h[T];
  if (Array.isArray(M) && M.length === 1 && M[0].type === et.literal) return M[0].value;
  if (!l && M && typeof M == "string" && !E) return M.replace(/'\{(.*?)\}'/gi, "{$1}");
  if (l = de(de({}, E), l || {}), d = R0(d, w), y = R0(y, w), !M) {
    if (p === !1 && M === "") return M;
    if ((!C || c && c.toLowerCase() !== m.toLowerCase()) && _(new HS(r, c)), C) try {
      var D = a.getMessageFormat(C, m, y, s);
      return D.format(l);
    } catch (j) {
      return _(new Zf('Error formatting default message for: "'.concat(T, '", rendering default message verbatim'), c, r, j)), typeof C == "string" ? C : T;
    }
    return T;
  }
  try {
    var D = a.getMessageFormat(M, c, d, de({ formatters: a }, s || {}));
    return D.format(l);
  } catch (j) {
    _(new Zf('Error formatting message: "'.concat(T, '", using ').concat(C ? "default message" : "id", " as fallback."), c, r, j));
  }
  if (C) try {
    var D = a.getMessageFormat(C, m, y, s);
    return D.format(l);
  } catch (j) {
    _(new Zf('Error formatting the default message for: "'.concat(T, '", rendering message verbatim'), c, r, j));
  }
  return typeof M == "string" ? M : typeof C == "string" ? C : T;
}, PS = [
  "formatMatcher",
  "timeZone",
  "hour12",
  "weekday",
  "era",
  "year",
  "month",
  "day",
  "hour",
  "minute",
  "second",
  "timeZoneName",
  "hourCycle",
  "dateStyle",
  "timeStyle",
  "calendar",
  "numberingSystem",
  "fractionalSecondDigits"
];
function el(e, a, r, l) {
  var s = e.locale, c = e.formats, d = e.onError, h = e.timeZone;
  l === void 0 && (l = {});
  var m = l.format, y = de(de({}, h && { timeZone: h }), m && $d(c, a, m, d)), p = Ir(l, PS, y);
  return a === "time" && !p.hour && !p.minute && !p.second && !p.timeStyle && !p.dateStyle && (p = de(de({}, p), {
    hour: "numeric",
    minute: "numeric"
  })), r(s, p);
}
function IS(e, a) {
  for (var r = [], l = 2; l < arguments.length; l++) r[l - 2] = arguments[l];
  var s = r[0], c = r[1], d = c === void 0 ? {} : c, h = typeof s == "string" ? new Date(s || 0) : s;
  try {
    return el(e, "date", a, d).format(h);
  } catch (m) {
    e.onError(new Ln("Error formatting date.", e.locale, m));
  }
  return String(h);
}
function ZS(e, a) {
  for (var r = [], l = 2; l < arguments.length; l++) r[l - 2] = arguments[l];
  var s = r[0], c = r[1], d = c === void 0 ? {} : c, h = typeof s == "string" ? new Date(s || 0) : s;
  try {
    return el(e, "time", a, d).format(h);
  } catch (m) {
    e.onError(new Ln("Error formatting time.", e.locale, m));
  }
  return String(h);
}
function GS(e, a) {
  for (var r = [], l = 2; l < arguments.length; l++) r[l - 2] = arguments[l];
  var s = r[0], c = r[1], d = r[2], h = d === void 0 ? {} : d, m = typeof s == "string" ? new Date(s || 0) : s, y = typeof c == "string" ? new Date(c || 0) : c;
  try {
    return el(e, "dateTimeRange", a, h).formatRange(m, y);
  } catch (p) {
    e.onError(new Ln("Error formatting date time range.", e.locale, p));
  }
  return String(m);
}
function VS(e, a) {
  for (var r = [], l = 2; l < arguments.length; l++) r[l - 2] = arguments[l];
  var s = r[0], c = r[1], d = c === void 0 ? {} : c, h = typeof s == "string" ? new Date(s || 0) : s;
  try {
    return el(e, "date", a, d).formatToParts(h);
  } catch (m) {
    e.onError(new Ln("Error formatting date.", e.locale, m));
  }
  return [];
}
function $S(e, a) {
  for (var r = [], l = 2; l < arguments.length; l++) r[l - 2] = arguments[l];
  var s = r[0], c = r[1], d = c === void 0 ? {} : c, h = typeof s == "string" ? new Date(s || 0) : s;
  try {
    return el(e, "time", a, d).formatToParts(h);
  } catch (m) {
    e.onError(new Ln("Error formatting time.", e.locale, m));
  }
  return [];
}
var FS = [
  "style",
  "type",
  "fallback",
  "languageDisplay"
];
function qS(e, a, r, l) {
  var s = e.locale, c = e.onError;
  Intl.DisplayNames || c(new ii(`Intl.DisplayNames is not available in this environment.
Try polyfilling it using "@formatjs/intl-displaynames"
`, na.MISSING_INTL_API));
  var d = Ir(l, FS);
  try {
    return a(s, d).of(r);
  } catch (h) {
    c(new Ln("Error formatting display name.", s, h));
  }
}
var XS = ["type", "style"], N0 = Date.now();
function YS(e) {
  return "".concat(N0, "_").concat(e, "_").concat(N0);
}
function WS(e, a, r, l) {
  l === void 0 && (l = {});
  var s = Tg(e, a, r, l).reduce(function(c, d) {
    var h = d.value;
    return typeof h != "string" ? c.push(h) : typeof c[c.length - 1] == "string" ? c[c.length - 1] += h : c.push(h), c;
  }, []);
  return s.length === 1 ? s[0] : s.length === 0 ? "" : s;
}
function Tg(e, a, r, l) {
  var s = e.locale, c = e.onError;
  l === void 0 && (l = {}), Intl.ListFormat || c(new ii(`Intl.ListFormat is not available in this environment.
Try polyfilling it using "@formatjs/intl-listformat"
`, na.MISSING_INTL_API));
  var d = Ir(l, XS);
  try {
    var h = {}, m = r.map(function(y, p) {
      if (typeof y == "object") {
        var _ = YS(p);
        return h[_] = y, _;
      }
      return String(y);
    });
    return a(s, d).formatToParts(m).map(function(y) {
      return y.type === "literal" ? y : de(de({}, y), { value: h[y.value] || y.value });
    });
  } catch (y) {
    c(new Ln("Error formatting list.", s, y));
  }
  return r;
}
var QS = ["type"];
function KS(e, a, r, l) {
  var s = e.locale, c = e.onError;
  l === void 0 && (l = {}), Intl.PluralRules || c(new ii(`Intl.PluralRules is not available in this environment.
Try polyfilling it using "@formatjs/intl-pluralrules"
`, na.MISSING_INTL_API));
  var d = Ir(l, QS);
  try {
    return a(s, d).select(r);
  } catch (h) {
    c(new Ln("Error formatting plural.", s, h));
  }
  return "other";
}
var JS = ["numeric", "style"];
function eE(e, a, r) {
  var l = e.locale, s = e.formats, c = e.onError;
  r === void 0 && (r = {});
  var d = r.format, h = !!d && $d(s, "relative", d, c) || {};
  return a(l, Ir(r, JS, h));
}
function tE(e, a, r, l, s) {
  s === void 0 && (s = {}), l || (l = "second"), Intl.RelativeTimeFormat || e.onError(new ii(`Intl.RelativeTimeFormat is not available in this environment.
Try polyfilling it using "@formatjs/intl-relativetimeformat"
`, na.MISSING_INTL_API));
  try {
    return eE(e, a, s).format(r, l);
  } catch (c) {
    e.onError(new Ln("Error formatting relative time.", e.locale, c));
  }
  return String(r);
}
var nE = [
  "style",
  "currency",
  "unit",
  "unitDisplay",
  "useGrouping",
  "minimumIntegerDigits",
  "minimumFractionDigits",
  "maximumFractionDigits",
  "minimumSignificantDigits",
  "maximumSignificantDigits",
  "compactDisplay",
  "currencyDisplay",
  "currencySign",
  "notation",
  "signDisplay",
  "unit",
  "unitDisplay",
  "numberingSystem",
  "trailingZeroDisplay",
  "roundingPriority",
  "roundingIncrement",
  "roundingMode"
];
function Cg(e, a, r) {
  var l = e.locale, s = e.formats, c = e.onError;
  r === void 0 && (r = {});
  var d = r.format, h = d && $d(s, "number", d, c) || {};
  return a(l, Ir(r, nE, h));
}
function aE(e, a, r, l) {
  l === void 0 && (l = {});
  try {
    return Cg(e, a, l).format(r);
  } catch (s) {
    e.onError(new Ln("Error formatting number.", e.locale, s));
  }
  return String(r);
}
function iE(e, a, r, l) {
  l === void 0 && (l = {});
  try {
    return Cg(e, a, l).formatToParts(r);
  } catch (s) {
    e.onError(new Ln("Error formatting number.", e.locale, s));
  }
  return [];
}
function rE(e) {
  return typeof (e ? e[Object.keys(e)[0]] : void 0) == "string";
}
function oE(e) {
  e.onWarn && e.defaultRichTextElements && rE(e.messages || {}) && e.onWarn(`[@formatjs/intl] "defaultRichTextElements" was specified but "message" was not pre-compiled. 
Please consider using "@formatjs/cli" to pre-compile your messages for performance.
For more details see https://formatjs.github.io/docs/getting-started/message-distribution`);
}
function lE(e, a) {
  var r = kS(a), l = de(de({}, Sg), e), s = l.locale, c = l.defaultLocale, d = l.onError;
  return s ? !Intl.NumberFormat.supportedLocalesOf(s).length && d ? d(new O0('Missing locale data for locale: "'.concat(s, '" in Intl.NumberFormat. Using default locale: "').concat(c, '" as fallback. See https://formatjs.github.io/docs/react-intl#runtime-requirements for more details'))) : !Intl.DateTimeFormat.supportedLocalesOf(s).length && d && d(new O0('Missing locale data for locale: "'.concat(s, '" in Intl.DateTimeFormat. Using default locale: "').concat(c, '" as fallback. See https://formatjs.github.io/docs/react-intl#runtime-requirements for more details'))) : (d && d(new LS('"locale" was not configured, using "'.concat(c, '" as fallback. See https://formatjs.github.io/docs/react-intl/api#intlshape for more details'))), l.locale = l.defaultLocale || "en"), oE(l), de(de({}, l), {
    formatters: r,
    formatNumber: aE.bind(null, l, r.getNumberFormat),
    formatNumberToParts: iE.bind(null, l, r.getNumberFormat),
    formatRelativeTime: tE.bind(null, l, r.getRelativeTimeFormat),
    formatDate: IS.bind(null, l, r.getDateTimeFormat),
    formatDateToParts: VS.bind(null, l, r.getDateTimeFormat),
    formatTime: ZS.bind(null, l, r.getDateTimeFormat),
    formatDateTimeRange: GS.bind(null, l, r.getDateTimeFormat),
    formatTimeToParts: $S.bind(null, l, r.getDateTimeFormat),
    formatPlural: KS.bind(null, l, r.getPluralRules),
    formatMessage: bd.bind(null, l, r),
    $t: bd.bind(null, l, r),
    formatList: WS.bind(null, l, r.getListFormat),
    formatListToParts: Tg.bind(null, l, r.getListFormat),
    formatDisplayName: qS.bind(null, l, r.getDisplayNames)
  });
}
function sE(e, a, r) {
  if (r === void 0 && (r = Error), !e) throw new r(a);
}
function Ag(e) {
  sE(e, "[React Intl] Could not find required `intl` object. <IntlProvider> needs to exist in the component ancestry.");
}
var xg = de(de({}, Sg), { textComponent: b.Fragment }), uE = { key: 42 }, cE = function(e) {
  return b.isValidElement(e) ? b.createElement(b.Fragment, uE, e) : e;
}, fE = function(e) {
  var a;
  return (a = b.Children.map(e, cE)) !== null && a !== void 0 ? a : [];
};
function dE(e) {
  return function(a) {
    return e(b.Children.toArray(a));
  };
}
function _d(e, a) {
  if (e === a) return !0;
  if (!e || !a) return !1;
  var r = Object.keys(e), l = Object.keys(a), s = r.length;
  if (l.length !== s) return !1;
  for (var c = 0; c < s; c++) {
    var d = r[c];
    if (e[d] !== a[d] || !Object.prototype.hasOwnProperty.call(a, d)) return !1;
  }
  return !0;
}
var hE = /* @__PURE__ */ bn(((e) => {
  var a = typeof Symbol == "function" && Symbol.for, r = a ? /* @__PURE__ */ Symbol.for("react.element") : 60103, l = a ? /* @__PURE__ */ Symbol.for("react.portal") : 60106, s = a ? /* @__PURE__ */ Symbol.for("react.fragment") : 60107, c = a ? /* @__PURE__ */ Symbol.for("react.strict_mode") : 60108, d = a ? /* @__PURE__ */ Symbol.for("react.profiler") : 60114, h = a ? /* @__PURE__ */ Symbol.for("react.provider") : 60109, m = a ? /* @__PURE__ */ Symbol.for("react.context") : 60110, y = a ? /* @__PURE__ */ Symbol.for("react.async_mode") : 60111, p = a ? /* @__PURE__ */ Symbol.for("react.concurrent_mode") : 60111, _ = a ? /* @__PURE__ */ Symbol.for("react.forward_ref") : 60112, w = a ? /* @__PURE__ */ Symbol.for("react.suspense") : 60113, E = a ? /* @__PURE__ */ Symbol.for("react.suspense_list") : 60120, x = a ? /* @__PURE__ */ Symbol.for("react.memo") : 60115, C = a ? /* @__PURE__ */ Symbol.for("react.lazy") : 60116, T = a ? /* @__PURE__ */ Symbol.for("react.block") : 60121, M = a ? /* @__PURE__ */ Symbol.for("react.fundamental") : 60117, D = a ? /* @__PURE__ */ Symbol.for("react.responder") : 60118, j = a ? /* @__PURE__ */ Symbol.for("react.scope") : 60119;
  function H(B) {
    if (typeof B == "object" && B !== null) {
      var Q = B.$$typeof;
      switch (Q) {
        case r:
          switch (B = B.type, B) {
            case y:
            case p:
            case s:
            case d:
            case c:
            case w:
              return B;
            default:
              switch (B = B && B.$$typeof, B) {
                case m:
                case _:
                case C:
                case x:
                case h:
                  return B;
                default:
                  return Q;
              }
          }
        case l:
          return Q;
      }
    }
  }
  function k(B) {
    return H(B) === p;
  }
  e.AsyncMode = y, e.ConcurrentMode = p, e.ContextConsumer = m, e.ContextProvider = h, e.Element = r, e.ForwardRef = _, e.Fragment = s, e.Lazy = C, e.Memo = x, e.Portal = l, e.Profiler = d, e.StrictMode = c, e.Suspense = w, e.isAsyncMode = function(B) {
    return k(B) || H(B) === y;
  }, e.isConcurrentMode = k, e.isContextConsumer = function(B) {
    return H(B) === m;
  }, e.isContextProvider = function(B) {
    return H(B) === h;
  }, e.isElement = function(B) {
    return typeof B == "object" && B !== null && B.$$typeof === r;
  }, e.isForwardRef = function(B) {
    return H(B) === _;
  }, e.isFragment = function(B) {
    return H(B) === s;
  }, e.isLazy = function(B) {
    return H(B) === C;
  }, e.isMemo = function(B) {
    return H(B) === x;
  }, e.isPortal = function(B) {
    return H(B) === l;
  }, e.isProfiler = function(B) {
    return H(B) === d;
  }, e.isStrictMode = function(B) {
    return H(B) === c;
  }, e.isSuspense = function(B) {
    return H(B) === w;
  }, e.isValidElementType = function(B) {
    return typeof B == "string" || typeof B == "function" || B === s || B === p || B === d || B === c || B === w || B === E || typeof B == "object" && B !== null && (B.$$typeof === C || B.$$typeof === x || B.$$typeof === h || B.$$typeof === m || B.$$typeof === _ || B.$$typeof === M || B.$$typeof === D || B.$$typeof === j || B.$$typeof === T);
  }, e.typeOf = H;
})), mE = /* @__PURE__ */ bn(((e, a) => {
  a.exports = hE();
})), pE = /* @__PURE__ */ bn(((e, a) => {
  var r = mE(), l = {
    childContextTypes: !0,
    contextType: !0,
    contextTypes: !0,
    defaultProps: !0,
    displayName: !0,
    getDefaultProps: !0,
    getDerivedStateFromError: !0,
    getDerivedStateFromProps: !0,
    mixins: !0,
    propTypes: !0,
    type: !0
  }, s = {
    name: !0,
    length: !0,
    prototype: !0,
    caller: !0,
    callee: !0,
    arguments: !0,
    arity: !0
  }, c = {
    $$typeof: !0,
    render: !0,
    defaultProps: !0,
    displayName: !0,
    propTypes: !0
  }, d = {
    $$typeof: !0,
    compare: !0,
    defaultProps: !0,
    displayName: !0,
    propTypes: !0,
    type: !0
  }, h = {};
  h[r.ForwardRef] = c, h[r.Memo] = d;
  function m(T) {
    return r.isMemo(T) ? d : h[T.$$typeof] || l;
  }
  var y = Object.defineProperty, p = Object.getOwnPropertyNames, _ = Object.getOwnPropertySymbols, w = Object.getOwnPropertyDescriptor, E = Object.getPrototypeOf, x = Object.prototype;
  function C(T, M, D) {
    if (typeof M != "string") {
      if (x) {
        var j = E(M);
        j && j !== x && C(T, j, D);
      }
      var H = p(M);
      _ && (H = H.concat(_(M)));
      for (var k = m(T), B = m(M), Q = 0; Q < H.length; ++Q) {
        var K = H[Q];
        if (!s[K] && !(D && D[K]) && !(B && B[K]) && !(k && k[K])) {
          var q = w(M, K);
          try {
            y(T, K, q);
          } catch {
          }
        }
      }
    }
    return T;
  }
  a.exports = C;
})), kM = /* @__PURE__ */ Zd(pE()), Fd = b.createContext(null), PM = Fd.Consumer, vE = Fd.Provider, gE = vE, yE = Fd;
function Fe() {
  var e = b.useContext(yE);
  return Ag(e), e;
}
var wd;
(function(e) {
  e.formatDate = "FormattedDate", e.formatTime = "FormattedTime", e.formatNumber = "FormattedNumber", e.formatList = "FormattedList", e.formatDisplayName = "FormattedDisplayName";
})(wd || (wd = {}));
var Sd;
(function(e) {
  e.formatDate = "FormattedDateParts", e.formatTime = "FormattedTimeParts", e.formatNumber = "FormattedNumberParts", e.formatList = "FormattedListParts";
})(Sd || (Sd = {}));
var Og = function(e) {
  var a = Fe(), r = e.value, l = e.children, s = Ca(e, ["value", "children"]);
  return l(a.formatNumberToParts(r, s));
};
Og.displayName = "FormattedNumberParts";
Og.displayName = "FormattedNumberParts";
function Mg(e) {
  var a = function(r) {
    var l = Fe(), s = r.value, c = r.children, d = Ca(r, ["value", "children"]), h = typeof s == "string" ? new Date(s || 0) : s;
    return c(e === "formatDate" ? l.formatDateToParts(h, d) : l.formatTimeToParts(h, d));
  };
  return a.displayName = Sd[e], a;
}
function tl(e) {
  var a = function(r) {
    var l = Fe(), s = r.value, c = r.children, d = Ca(r, ["value", "children"]), h = l[e](s, d);
    if (typeof c == "function") return c(h);
    var m = l.textComponent || b.Fragment;
    return b.createElement(m, null, h);
  };
  return a.displayName = wd[e], a;
}
function Rg(e) {
  return e && Object.keys(e).reduce(function(a, r) {
    var l = e[r];
    return a[r] = _g(l) ? dE(l) : l, a;
  }, {});
}
var D0 = function(e, a, r, l) {
  for (var s = [], c = 4; c < arguments.length; c++) s[c - 4] = arguments[c];
  var d = Rg(l), h = bd.apply(void 0, Gn([
    e,
    a,
    r,
    d
  ], s, !1));
  return Array.isArray(h) ? fE(h) : h;
}, z0 = function(e, a) {
  var r = e.defaultRichTextElements, l = Ca(e, ["defaultRichTextElements"]), s = Rg(r), c = lE(de(de(de({}, xg), l), { defaultRichTextElements: s }), a), d = {
    locale: c.locale,
    timeZone: c.timeZone,
    fallbackOnEmptyString: c.fallbackOnEmptyString,
    formats: c.formats,
    defaultLocale: c.defaultLocale,
    defaultFormats: c.defaultFormats,
    messages: c.messages,
    onError: c.onError,
    defaultRichTextElements: s
  };
  return de(de({}, c), {
    formatMessage: D0.bind(null, d, c.formatters),
    $t: D0.bind(null, d, c.formatters)
  });
};
function bE(e, a) {
  var r = e.values, l = Ca(e, ["values"]), s = a.values, c = Ca(a, ["values"]);
  return _d(s, r) && _d(l, c);
}
function Ng(e) {
  var a = Fe(), r = a.formatMessage, l = a.textComponent, s = l === void 0 ? b.Fragment : l, c = e.id, d = e.description, h = e.defaultMessage, m = e.values, y = e.children, p = e.tagName, _ = p === void 0 ? s : p, w = e.ignoreTag, E = r({
    id: c,
    description: d,
    defaultMessage: h
  }, m, { ignoreTag: w });
  return typeof y == "function" ? y(Array.isArray(E) ? E : [E]) : _ ? b.createElement(_, null, E) : b.createElement(b.Fragment, null, E);
}
Ng.displayName = "FormattedMessage";
var Ja = b.memo(Ng, bE);
Ja.displayName = "MemoizedFormattedMessage";
function Gf(e) {
  return {
    locale: e.locale,
    timeZone: e.timeZone,
    fallbackOnEmptyString: e.fallbackOnEmptyString,
    formats: e.formats,
    textComponent: e.textComponent,
    messages: e.messages,
    defaultLocale: e.defaultLocale,
    defaultFormats: e.defaultFormats,
    onError: e.onError,
    onWarn: e.onWarn,
    wrapRichTextChunksInFragment: e.wrapRichTextChunksInFragment,
    defaultRichTextElements: e.defaultRichTextElements
  };
}
var _E = (function(e) {
  zn(a, e);
  function a() {
    var r = e !== null && e.apply(this, arguments) || this;
    return r.cache = Eg(), r.state = {
      cache: r.cache,
      intl: z0(Gf(r.props), r.cache),
      prevConfig: Gf(r.props)
    }, r;
  }
  return a.getDerivedStateFromProps = function(r, l) {
    var s = l.prevConfig, c = l.cache, d = Gf(r);
    return _d(s, d) ? null : {
      intl: z0(d, c),
      prevConfig: d
    };
  }, a.prototype.render = function() {
    return Ag(this.state.intl), b.createElement(gE, { value: this.state.intl }, this.props.children);
  }, a.displayName = "IntlProvider", a.defaultProps = xg, a;
})(b.PureComponent);
var IM = tl("formatDate"), ZM = tl("formatTime"), GM = tl("formatNumber"), VM = tl("formatList"), $M = tl("formatDisplayName"), FM = Mg("formatDate"), qM = Mg("formatTime"), L0 = (e) => {
  let a;
  const r = /* @__PURE__ */ new Set(), l = (y, p) => {
    const _ = typeof y == "function" ? y(a) : y;
    if (!Object.is(_, a)) {
      const w = a;
      a = p ?? (typeof _ != "object" || _ === null) ? _ : Object.assign({}, a, _), r.forEach((E) => E(a, w));
    }
  }, s = () => a, h = {
    setState: l,
    getState: s,
    getInitialState: () => m,
    subscribe: (y) => (r.add(y), () => r.delete(y))
  }, m = a = e(l, s, h);
  return h;
}, qd = ((e) => e ? L0(e) : L0), wE = (e) => e;
function au(e, a = wE) {
  const r = b.useSyncExternalStore(e.subscribe, b.useCallback(() => a(e.getState()), [e, a]), b.useCallback(() => a(e.getInitialState()), [e, a]));
  return b.useDebugValue(r), r;
}
var $o = "en-US", Dg = [
  "am",
  "ar",
  "bg-BG",
  "bn-BD",
  "bs-BA",
  "ca-ES",
  "cs-CZ",
  "da-DK",
  "de-DE",
  "el-GR",
  "es-419",
  "es-ES",
  "et-EE",
  "fa",
  "fi-FI",
  "fr-CA",
  "fr-FR",
  "gu-IN",
  "hi-IN",
  "hr-HR",
  "hu-HU",
  "hy-AM",
  "id-ID",
  "is-IS",
  "it-IT",
  "ja-JP",
  "ka-GE",
  "kk",
  "kn-IN",
  "ko-KR",
  "lt",
  "lv-LV",
  "mk-MK",
  "ml",
  "mn",
  "mr-IN",
  "ms-MY",
  "my-MM",
  "nb-NO",
  "nl-NL",
  "pa",
  "pl-PL",
  "pt-BR",
  "pt-PT",
  "ro-RO",
  "ru-RU",
  "sk-SK",
  "sl-SI",
  "so-SO",
  "sq-AL",
  "sr-RS",
  "sv-SE",
  "sw-TZ",
  "ta-IN",
  "te-IN",
  "th-TH",
  "tl",
  "tr-TR",
  "uk-UA",
  "ur",
  "vi-VN",
  "zh-CN",
  "zh-HK",
  "zh-TW"
], SE = new Map(Dg.map((e) => [e.toLowerCase(), e])), It = new Map([[$o.toLowerCase(), $o], ...SE]);
for (const e of [$o, ...Dg]) {
  const a = new Intl.Locale(e).language.toLowerCase();
  It.set(a, It.get(a) ?? e);
}
It.set("es", "es-ES");
It.set("fr", "fr-FR");
It.set("bn-in", "bn-BD");
It.set("en-in", $o);
It.set("ml-in", "ml");
It.set("pa-guru", "pa");
It.set("pa-guru-in", "pa");
for (const e of [
  "pt-ao",
  "pt-ch",
  "pt-cv",
  "pt-fr",
  "pt-gq",
  "pt-gw",
  "pt-lu",
  "pt-mo",
  "pt-mz",
  "pt-st",
  "pt-tl"
]) It.set(e, "pt-PT");
It.set("ur-in", "ur");
It.set("zh-hant", "zh-TW");
It.set("zh-hant-tw", "zh-TW");
It.set("zh-hant-hk", "zh-HK");
function EE(e) {
  const a = e.trim().replaceAll("_", "-").toLowerCase();
  if (!a || a === "pa-arab" || a.startsWith("pa-arab-")) return;
  if (a.startsWith("es-") && a !== "es-es" && a !== "es-419") return "es-419";
  const r = It.get(a);
  if (r) return r;
  const l = a.split("-");
  for (let s = l.length - 1; s >= 1; s -= 1) {
    const c = It.get(l.slice(0, s).join("-"));
    if (c) return c;
  }
}
function Oa(e) {
  const a = e.split("-", 1)[0];
  return a && [
    "ar",
    "fa",
    "ur"
  ].includes(a) ? "rtl" : "ltr";
}
var Ye = {
  editorWidgetMobileMenu: {
    id: "sites.dispatch.widget.editor.mobile_menu",
    defaultMessage: "Site toolbar",
    description: "Accessible label for the draggable mobile Site toolbar and its actions popup."
  },
  editorWidgetMobileClose: {
    id: "sites.dispatch.widget.editor.mobile_close",
    defaultMessage: "Close",
    description: "Mobile Site toolbar action that closes the menu without hiding the toolbar or changing its saved preference."
  },
  editorWidgetHideHint: {
    id: "sites.dispatch.widget.editor.hide_hint",
    defaultMessage: "Hover over this corner to bring back the toolbar.",
    description: "Tooltip at the corner after first hiding the Site editor widget, and on sustained hover over the hidden widget corner. A restore keyboard shortcut is shown beside this text."
  },
  editorWidgetRestoreAction: {
    id: "sites.dispatch.widget.editor.restore_action",
    defaultMessage: "Bring back toolbar",
    description: "Action beside the keyboard shortcut that restores the tucked Site editor widget."
  },
  editorWidgetHideHintBottomCenter: {
    id: "sites.dispatch.widget.editor.hide_hint.bottom_center",
    defaultMessage: "Hover here to bring back the toolbar.",
    description: "Tooltip above the restore target at the bottom center of a Site after the toolbar is hidden. Hovering over this target reveals the toolbar; a restore keyboard shortcut is shown beside this text."
  },
  invitationBannerLabel: {
    id: "sites.dispatch.widget.invitation_banner.label",
    defaultMessage: "Site editing controls",
    description: "Accessible label for the banner inviting someone to edit a ChatGPT Site."
  },
  invitationBannerMessage: {
    id: "sites.dispatch.widget.invitation_banner.message",
    defaultMessage: "You have been invited to edit this site.",
    description: "Message shown to someone who has been invited to edit a ChatGPT Site when the owner's name is unavailable."
  },
  invitationBannerMessageWithOwner: {
    id: "sites.dispatch.widget.invitation_banner.message_with_owner",
    defaultMessage: "<strong>{ownerName}</strong> has invited you to edit this site.",
    description: "Message shown to someone invited to edit a ChatGPT Site. ownerName is the site owner's display name."
  },
  invitationBannerEditAction: {
    id: "sites.dispatch.widget.invitation_banner.edit_action",
    defaultMessage: "Edit in ChatGPT",
    description: "Link that opens ChatGPT so an invited editor can edit a ChatGPT Site."
  },
  editorWidgetDefaultEditPrompt: {
    id: "sites.dispatch.widget.editor.default_edit_prompt",
    defaultMessage: "{site} make these changes…",
    description: "Default editable prompt when the Site widget logo opens ChatGPT. Matches the desktop Site edit prompt. site is the complete Site reference and must remain a placeholder."
  },
  invitationBannerEditPrompt: {
    id: "sites.dispatch.widget.invitation_banner.edit_prompt",
    defaultMessage: "Make the following changes to {site}:",
    description: "Prompt prefilled in ChatGPT when an invited editor opens a Site. site is the complete Site reference and must remain a placeholder."
  },
  invitationBannerDismissAction: {
    id: "sites.dispatch.widget.invitation_banner.dismiss_action",
    defaultMessage: "Dismiss",
    description: "Accessible label for the button that dismisses a ChatGPT Site editing invitation banner."
  },
  editorWidgetLaunchAction: {
    id: "sites.dispatch.widget.editor.launch_action",
    defaultMessage: "Edit site",
    description: "Short button label in the floating editor-only widget on a hosted website. Opens a text composer for describing changes to that website. Site means a hosted website, not a physical location. No placeholders."
  },
  editorWidgetOpenAction: {
    id: "sites.dispatch.widget.editor.open_action",
    defaultMessage: "Edit site in ChatGPT",
    description: "Accessible label and tooltip for the ChatGPT logo link in the floating editor-only Site widget. Opens this website's full-screen editor in ChatGPT in a new tab. Short action label; no placeholders."
  },
  editorWidgetLaunchTooltip: {
    id: "sites.dispatch.widget.editor.launch_tooltip",
    defaultMessage: "Describe your changes to ChatGPT",
    description: "Tooltip on the Edit site button in the floating editor-only Site widget. The button opens a text composer for describing desired changes to this website. Short action phrase; no placeholders."
  },
  editorWidgetComposerLabel: {
    id: "sites.dispatch.widget.editor.composer_label",
    defaultMessage: "Describe your edits",
    description: "Screen-reader label for the plain-text composer in the floating editor-only widget on a hosted website. Asks the editor to describe changes they want ChatGPT to make to this website. No placeholders."
  },
  editorWidgetComposerPlaceholder: {
    id: "sites.dispatch.widget.editor.composer_placeholder",
    defaultMessage: "Describe your edits",
    description: "Short placeholder in the empty plain-text composer in the floating editor-only widget on a hosted website. Asks the editor to describe changes they want ChatGPT to make to this website. No placeholders."
  },
  editorWidgetSendAction: {
    id: "sites.dispatch.widget.editor.send_action",
    defaultMessage: "Send edits",
    description: "Accessible label for the button that sends requested Site edits to ChatGPT."
  },
  editorWidgetHideAction: {
    id: "sites.dispatch.widget.editor.hide_action",
    defaultMessage: "Hide toolbar",
    description: "Accessible label and tooltip for the X button in the floating editor-only widget on a hosted website. Hides this editing widget from the current page without changing the website or its access permissions. Short action label; no placeholders."
  }
}, XM = Object.freeze({ status: "aborted" });
function Y(e, a, r) {
  function l(h, m) {
    var y;
    Object.defineProperty(h, "_zod", {
      value: h._zod ?? {},
      enumerable: !1
    }), (y = h._zod).traits ?? (y.traits = /* @__PURE__ */ new Set()), h._zod.traits.add(e), a(h, m);
    for (const p in d.prototype) p in h || Object.defineProperty(h, p, { value: d.prototype[p].bind(h) });
    h._zod.constr = d, h._zod.def = m;
  }
  const s = r?.Parent ?? Object;
  class c extends s {
  }
  Object.defineProperty(c, "name", { value: e });
  function d(h) {
    var m;
    const y = r?.Parent ? new c() : this;
    l(y, h), (m = y._zod).deferred ?? (m.deferred = []);
    for (const p of y._zod.deferred) p();
    return y;
  }
  return Object.defineProperty(d, "init", { value: l }), Object.defineProperty(d, Symbol.hasInstance, { value: (h) => r?.Parent && h instanceof r.Parent ? !0 : h?._zod?.traits?.has(e) }), Object.defineProperty(d, "name", { value: e }), d;
}
var Dr = class extends Error {
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}, zg = class extends Error {
  constructor(e) {
    super(`Encountered unidirectional transform during encode: ${e}`), this.name = "ZodEncodeError";
  }
}, Ed = {};
function Ni(e) {
  return e && Object.assign(Ed, e), Ed;
}
function TE(e) {
  const a = Object.values(e).filter((r) => typeof r == "number");
  return Object.entries(e).filter(([r, l]) => a.indexOf(+r) === -1).map(([r, l]) => l);
}
function Td(e, a) {
  return typeof a == "bigint" ? a.toString() : a;
}
function iu(e) {
  return { get value() {
    {
      const a = e();
      return Object.defineProperty(this, "value", { value: a }), a;
    }
    throw new Error("cached value already set");
  } };
}
function Xd(e) {
  return e == null;
}
function Yd(e) {
  const a = e.startsWith("^") ? 1 : 0, r = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(a, r);
}
function CE(e, a) {
  const r = (e.toString().split(".")[1] || "").length, l = a.toString();
  let s = (l.split(".")[1] || "").length;
  if (s === 0 && /\d?e-\d?/.test(l)) {
    const d = l.match(/\d?e-(\d?)/);
    d?.[1] && (s = Number.parseInt(d[1]));
  }
  const c = r > s ? r : s;
  return Number.parseInt(e.toFixed(c).replace(".", "")) % Number.parseInt(a.toFixed(c).replace(".", "")) / 10 ** c;
}
var H0 = /* @__PURE__ */ Symbol("evaluating");
function We(e, a, r) {
  let l;
  Object.defineProperty(e, a, {
    get() {
      if (l !== H0)
        return l === void 0 && (l = H0, l = r()), l;
    },
    set(s) {
      Object.defineProperty(e, a, { value: s });
    },
    configurable: !0
  });
}
function Ui(e, a, r) {
  Object.defineProperty(e, a, {
    value: r,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
function ki(...e) {
  const a = {};
  for (const r of e) Object.assign(a, Object.getOwnPropertyDescriptors(r));
  return Object.defineProperties({}, a);
}
function j0(e) {
  return JSON.stringify(e);
}
var Lg = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function Fo(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
var AE = iu(() => {
  if (typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare")) return !1;
  try {
    return new Function(""), !0;
  } catch {
    return !1;
  }
});
function qo(e) {
  if (Fo(e) === !1) return !1;
  const a = e.constructor;
  if (a === void 0) return !0;
  const r = a.prototype;
  return !(Fo(r) === !1 || Object.prototype.hasOwnProperty.call(r, "isPrototypeOf") === !1);
}
function Hg(e) {
  return qo(e) ? { ...e } : Array.isArray(e) ? [...e] : e;
}
var xE = /* @__PURE__ */ new Set([
  "string",
  "number",
  "symbol"
]);
function Hr(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function ri(e, a, r) {
  const l = new e._zod.constr(a ?? e._zod.def);
  return (!a || r?.parent) && (l._zod.parent = e), l;
}
function ge(e) {
  const a = e;
  if (!a) return {};
  if (typeof a == "string") return { error: () => a };
  if (a?.message !== void 0) {
    if (a?.error !== void 0) throw new Error("Cannot specify both `message` and `error` params");
    a.error = a.message;
  }
  return delete a.message, typeof a.error == "string" ? {
    ...a,
    error: () => a.error
  } : a;
}
function OE(e) {
  return Object.keys(e).filter((a) => e[a]._zod.optin === "optional" && e[a]._zod.optout === "optional");
}
var ME = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
};
function RE(e, a) {
  const r = e._zod.def;
  return ri(e, ki(e._zod.def, {
    get shape() {
      const l = {};
      for (const s in a) {
        if (!(s in r.shape)) throw new Error(`Unrecognized key: "${s}"`);
        a[s] && (l[s] = r.shape[s]);
      }
      return Ui(this, "shape", l), l;
    },
    checks: []
  }));
}
function NE(e, a) {
  const r = e._zod.def;
  return ri(e, ki(e._zod.def, {
    get shape() {
      const l = { ...e._zod.def.shape };
      for (const s in a) {
        if (!(s in r.shape)) throw new Error(`Unrecognized key: "${s}"`);
        a[s] && delete l[s];
      }
      return Ui(this, "shape", l), l;
    },
    checks: []
  }));
}
function DE(e, a) {
  if (!qo(a)) throw new Error("Invalid input to extend: expected a plain object");
  const r = e._zod.def.checks;
  if (r && r.length > 0) throw new Error("Object schemas containing refinements cannot be extended. Use `.safeExtend()` instead.");
  return ri(e, ki(e._zod.def, {
    get shape() {
      const l = {
        ...e._zod.def.shape,
        ...a
      };
      return Ui(this, "shape", l), l;
    },
    checks: []
  }));
}
function zE(e, a) {
  if (!qo(a)) throw new Error("Invalid input to safeExtend: expected a plain object");
  return ri(e, {
    ...e._zod.def,
    get shape() {
      const r = {
        ...e._zod.def.shape,
        ...a
      };
      return Ui(this, "shape", r), r;
    },
    checks: e._zod.def.checks
  });
}
function LE(e, a) {
  return ri(e, ki(e._zod.def, {
    get shape() {
      const r = {
        ...e._zod.def.shape,
        ...a._zod.def.shape
      };
      return Ui(this, "shape", r), r;
    },
    get catchall() {
      return a._zod.def.catchall;
    },
    checks: []
  }));
}
function HE(e, a, r) {
  return ri(a, ki(a._zod.def, {
    get shape() {
      const l = a._zod.def.shape, s = { ...l };
      if (r) for (const c in r) {
        if (!(c in l)) throw new Error(`Unrecognized key: "${c}"`);
        r[c] && (s[c] = e ? new e({
          type: "optional",
          innerType: l[c]
        }) : l[c]);
      }
      else for (const c in l) s[c] = e ? new e({
        type: "optional",
        innerType: l[c]
      }) : l[c];
      return Ui(this, "shape", s), s;
    },
    checks: []
  }));
}
function jE(e, a, r) {
  return ri(a, ki(a._zod.def, {
    get shape() {
      const l = a._zod.def.shape, s = { ...l };
      if (r) for (const c in r) {
        if (!(c in s)) throw new Error(`Unrecognized key: "${c}"`);
        r[c] && (s[c] = new e({
          type: "nonoptional",
          innerType: l[c]
        }));
      }
      else for (const c in l) s[c] = new e({
        type: "nonoptional",
        innerType: l[c]
      });
      return Ui(this, "shape", s), s;
    },
    checks: []
  }));
}
function Rr(e, a = 0) {
  if (e.aborted === !0) return !0;
  for (let r = a; r < e.issues.length; r++) if (e.issues[r]?.continue !== !0) return !0;
  return !1;
}
function jg(e, a) {
  return a.map((r) => {
    var l;
    return (l = r).path ?? (l.path = []), r.path.unshift(e), r;
  });
}
function As(e) {
  return typeof e == "string" ? e : e?.message;
}
function Di(e, a, r) {
  const l = {
    ...e,
    path: e.path ?? []
  };
  return e.message || (l.message = As(e.inst?._zod.def?.error?.(e)) ?? As(a?.error?.(e)) ?? As(r.customError?.(e)) ?? As(r.localeError?.(e)) ?? "Invalid input"), delete l.inst, delete l.continue, a?.reportInput || delete l.input, l;
}
function Wd(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
function Xo(...e) {
  const [a, r, l] = e;
  return typeof a == "string" ? {
    message: a,
    code: "custom",
    input: r,
    inst: l
  } : { ...a };
}
var Bg = (e, a) => {
  e.name = "$ZodError", Object.defineProperty(e, "_zod", {
    value: e._zod,
    enumerable: !1
  }), Object.defineProperty(e, "issues", {
    value: a,
    enumerable: !1
  }), e.message = JSON.stringify(a, Td, 2), Object.defineProperty(e, "toString", {
    value: () => e.message,
    enumerable: !1
  });
}, Ug = Y("$ZodError", Bg), kg = Y("$ZodError", Bg, { Parent: Error });
function BE(e, a = (r) => r.message) {
  const r = {}, l = [];
  for (const s of e.issues) s.path.length > 0 ? (r[s.path[0]] = r[s.path[0]] || [], r[s.path[0]].push(a(s))) : l.push(a(s));
  return {
    formErrors: l,
    fieldErrors: r
  };
}
function UE(e, a = (r) => r.message) {
  const r = { _errors: [] }, l = (s) => {
    for (const c of s.issues) if (c.code === "invalid_union" && c.errors.length) c.errors.map((d) => l({ issues: d }));
    else if (c.code === "invalid_key") l({ issues: c.issues });
    else if (c.code === "invalid_element") l({ issues: c.issues });
    else if (c.path.length === 0) r._errors.push(a(c));
    else {
      let d = r, h = 0;
      for (; h < c.path.length; ) {
        const m = c.path[h];
        h !== c.path.length - 1 ? d[m] = d[m] || { _errors: [] } : (d[m] = d[m] || { _errors: [] }, d[m]._errors.push(a(c))), d = d[m], h++;
      }
    }
  };
  return l(e), r;
}
var Qd = (e) => (a, r, l, s) => {
  const c = l ? Object.assign(l, { async: !1 }) : { async: !1 }, d = a._zod.run({
    value: r,
    issues: []
  }, c);
  if (d instanceof Promise) throw new Dr();
  if (d.issues.length) {
    const h = new (s?.Err ?? e)(d.issues.map((m) => Di(m, c, Ni())));
    throw Lg(h, s?.callee), h;
  }
  return d.value;
};
var Kd = (e) => async (a, r, l, s) => {
  const c = l ? Object.assign(l, { async: !0 }) : { async: !0 };
  let d = a._zod.run({
    value: r,
    issues: []
  }, c);
  if (d instanceof Promise && (d = await d), d.issues.length) {
    const h = new (s?.Err ?? e)(d.issues.map((m) => Di(m, c, Ni())));
    throw Lg(h, s?.callee), h;
  }
  return d.value;
};
var ru = (e) => (a, r, l) => {
  const s = l ? {
    ...l,
    async: !1
  } : { async: !1 }, c = a._zod.run({
    value: r,
    issues: []
  }, s);
  if (c instanceof Promise) throw new Dr();
  return c.issues.length ? {
    success: !1,
    error: new (e ?? Ug)(c.issues.map((d) => Di(d, s, Ni())))
  } : {
    success: !0,
    data: c.value
  };
}, kE = /* @__PURE__ */ ru(kg), ou = (e) => async (a, r, l) => {
  const s = l ? Object.assign(l, { async: !0 }) : { async: !0 };
  let c = a._zod.run({
    value: r,
    issues: []
  }, s);
  return c instanceof Promise && (c = await c), c.issues.length ? {
    success: !1,
    error: new e(c.issues.map((d) => Di(d, s, Ni())))
  } : {
    success: !0,
    data: c.value
  };
}, PE = /* @__PURE__ */ ou(kg), IE = (e) => (a, r, l) => {
  const s = l ? Object.assign(l, { direction: "backward" }) : { direction: "backward" };
  return Qd(e)(a, r, s);
};
var ZE = (e) => (a, r, l) => Qd(e)(a, r, l);
var GE = (e) => async (a, r, l) => {
  const s = l ? Object.assign(l, { direction: "backward" }) : { direction: "backward" };
  return Kd(e)(a, r, s);
};
var VE = (e) => async (a, r, l) => Kd(e)(a, r, l);
var $E = (e) => (a, r, l) => {
  const s = l ? Object.assign(l, { direction: "backward" }) : { direction: "backward" };
  return ru(e)(a, r, s);
};
var FE = (e) => (a, r, l) => ru(e)(a, r, l);
var qE = (e) => async (a, r, l) => {
  const s = l ? Object.assign(l, { direction: "backward" }) : { direction: "backward" };
  return ou(e)(a, r, s);
};
var XE = (e) => async (a, r, l) => ou(e)(a, r, l);
var YE = /^[cC][^\s-]{8,}$/, WE = /^[0-9a-z]+$/, QE = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/, KE = /^[0-9a-vA-V]{20}$/, JE = /^[A-Za-z0-9]{27}$/, eT = /^[a-zA-Z0-9_-]{21}$/, tT = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, nT = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, B0 = (e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, aT = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, iT = "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";
function rT() {
  return new RegExp(iT, "u");
}
var oT = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, lT = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, sT = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, uT = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, cT = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, Pg = /^[A-Za-z0-9_-]*$/, fT = /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/, dT = /^\+(?:[0-9]){6,14}[0-9]$/, Ig = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))", hT = /* @__PURE__ */ new RegExp(`^${Ig}$`);
function Zg(e) {
  const a = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${a}` : e.precision === 0 ? `${a}:[0-5]\\d` : `${a}:[0-5]\\d\\.\\d{${e.precision}}` : `${a}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function mT(e) {
  return new RegExp(`^${Zg(e)}$`);
}
function pT(e) {
  const a = Zg({ precision: e.precision }), r = ["Z"];
  e.local && r.push(""), e.offset && r.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  const l = `${a}(?:${r.join("|")})`;
  return new RegExp(`^${Ig}T(?:${l})$`);
}
var vT = (e) => {
  const a = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
  return new RegExp(`^${a}$`);
}, gT = /^-?\d+$/, yT = /^-?\d+(?:\.\d+)?/, bT = /^(?:true|false)$/i, _T = /^null$/i, wT = /^[^A-Z]*$/, ST = /^[^a-z]*$/, an = /* @__PURE__ */ Y("$ZodCheck", (e, a) => {
  var r;
  e._zod ?? (e._zod = {}), e._zod.def = a, (r = e._zod).onattach ?? (r.onattach = []);
}), Gg = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, Vg = /* @__PURE__ */ Y("$ZodCheckLessThan", (e, a) => {
  an.init(e, a);
  const r = Gg[typeof a.value];
  e._zod.onattach.push((l) => {
    const s = l._zod.bag, c = (a.inclusive ? s.maximum : s.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    a.value < c && (a.inclusive ? s.maximum = a.value : s.exclusiveMaximum = a.value);
  }), e._zod.check = (l) => {
    (a.inclusive ? l.value <= a.value : l.value < a.value) || l.issues.push({
      origin: r,
      code: "too_big",
      maximum: a.value,
      input: l.value,
      inclusive: a.inclusive,
      inst: e,
      continue: !a.abort
    });
  };
}), $g = /* @__PURE__ */ Y("$ZodCheckGreaterThan", (e, a) => {
  an.init(e, a);
  const r = Gg[typeof a.value];
  e._zod.onattach.push((l) => {
    const s = l._zod.bag, c = (a.inclusive ? s.minimum : s.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    a.value > c && (a.inclusive ? s.minimum = a.value : s.exclusiveMinimum = a.value);
  }), e._zod.check = (l) => {
    (a.inclusive ? l.value >= a.value : l.value > a.value) || l.issues.push({
      origin: r,
      code: "too_small",
      minimum: a.value,
      input: l.value,
      inclusive: a.inclusive,
      inst: e,
      continue: !a.abort
    });
  };
}), ET = /* @__PURE__ */ Y("$ZodCheckMultipleOf", (e, a) => {
  an.init(e, a), e._zod.onattach.push((r) => {
    var l;
    (l = r._zod.bag).multipleOf ?? (l.multipleOf = a.value);
  }), e._zod.check = (r) => {
    if (typeof r.value != typeof a.value) throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof r.value == "bigint" ? r.value % a.value === BigInt(0) : CE(r.value, a.value) === 0) || r.issues.push({
      origin: typeof r.value,
      code: "not_multiple_of",
      divisor: a.value,
      input: r.value,
      inst: e,
      continue: !a.abort
    });
  };
}), TT = /* @__PURE__ */ Y("$ZodCheckNumberFormat", (e, a) => {
  an.init(e, a), a.format = a.format || "float64";
  const r = a.format?.includes("int"), l = r ? "int" : "number", [s, c] = ME[a.format];
  e._zod.onattach.push((d) => {
    const h = d._zod.bag;
    h.format = a.format, h.minimum = s, h.maximum = c, r && (h.pattern = gT);
  }), e._zod.check = (d) => {
    const h = d.value;
    if (r) {
      if (!Number.isInteger(h)) {
        d.issues.push({
          expected: l,
          format: a.format,
          code: "invalid_type",
          continue: !1,
          input: h,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(h)) {
        h > 0 ? d.issues.push({
          input: h,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: l,
          continue: !a.abort
        }) : d.issues.push({
          input: h,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: l,
          continue: !a.abort
        });
        return;
      }
    }
    h < s && d.issues.push({
      origin: "number",
      input: h,
      code: "too_small",
      minimum: s,
      inclusive: !0,
      inst: e,
      continue: !a.abort
    }), h > c && d.issues.push({
      origin: "number",
      input: h,
      code: "too_big",
      maximum: c,
      inst: e
    });
  };
}), CT = /* @__PURE__ */ Y("$ZodCheckMaxLength", (e, a) => {
  var r;
  an.init(e, a), (r = e._zod.def).when ?? (r.when = (l) => {
    const s = l.value;
    return !Xd(s) && s.length !== void 0;
  }), e._zod.onattach.push((l) => {
    const s = l._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    a.maximum < s && (l._zod.bag.maximum = a.maximum);
  }), e._zod.check = (l) => {
    const s = l.value;
    if (s.length <= a.maximum) return;
    const c = Wd(s);
    l.issues.push({
      origin: c,
      code: "too_big",
      maximum: a.maximum,
      inclusive: !0,
      input: s,
      inst: e,
      continue: !a.abort
    });
  };
}), AT = /* @__PURE__ */ Y("$ZodCheckMinLength", (e, a) => {
  var r;
  an.init(e, a), (r = e._zod.def).when ?? (r.when = (l) => {
    const s = l.value;
    return !Xd(s) && s.length !== void 0;
  }), e._zod.onattach.push((l) => {
    const s = l._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    a.minimum > s && (l._zod.bag.minimum = a.minimum);
  }), e._zod.check = (l) => {
    const s = l.value;
    if (s.length >= a.minimum) return;
    const c = Wd(s);
    l.issues.push({
      origin: c,
      code: "too_small",
      minimum: a.minimum,
      inclusive: !0,
      input: s,
      inst: e,
      continue: !a.abort
    });
  };
}), xT = /* @__PURE__ */ Y("$ZodCheckLengthEquals", (e, a) => {
  var r;
  an.init(e, a), (r = e._zod.def).when ?? (r.when = (l) => {
    const s = l.value;
    return !Xd(s) && s.length !== void 0;
  }), e._zod.onattach.push((l) => {
    const s = l._zod.bag;
    s.minimum = a.length, s.maximum = a.length, s.length = a.length;
  }), e._zod.check = (l) => {
    const s = l.value, c = s.length;
    if (c === a.length) return;
    const d = Wd(s), h = c > a.length;
    l.issues.push({
      origin: d,
      ...h ? {
        code: "too_big",
        maximum: a.length
      } : {
        code: "too_small",
        minimum: a.length
      },
      inclusive: !0,
      exact: !0,
      input: l.value,
      inst: e,
      continue: !a.abort
    });
  };
}), lu = /* @__PURE__ */ Y("$ZodCheckStringFormat", (e, a) => {
  var r, l;
  an.init(e, a), e._zod.onattach.push((s) => {
    const c = s._zod.bag;
    c.format = a.format, a.pattern && (c.patterns ?? (c.patterns = /* @__PURE__ */ new Set()), c.patterns.add(a.pattern));
  }), a.pattern ? (r = e._zod).check ?? (r.check = (s) => {
    a.pattern.lastIndex = 0, !a.pattern.test(s.value) && s.issues.push({
      origin: "string",
      code: "invalid_format",
      format: a.format,
      input: s.value,
      ...a.pattern ? { pattern: a.pattern.toString() } : {},
      inst: e,
      continue: !a.abort
    });
  }) : (l = e._zod).check ?? (l.check = () => {
  });
}), OT = /* @__PURE__ */ Y("$ZodCheckRegex", (e, a) => {
  lu.init(e, a), e._zod.check = (r) => {
    a.pattern.lastIndex = 0, !a.pattern.test(r.value) && r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: r.value,
      pattern: a.pattern.toString(),
      inst: e,
      continue: !a.abort
    });
  };
}), MT = /* @__PURE__ */ Y("$ZodCheckLowerCase", (e, a) => {
  a.pattern ?? (a.pattern = wT), lu.init(e, a);
}), RT = /* @__PURE__ */ Y("$ZodCheckUpperCase", (e, a) => {
  a.pattern ?? (a.pattern = ST), lu.init(e, a);
}), NT = /* @__PURE__ */ Y("$ZodCheckIncludes", (e, a) => {
  an.init(e, a);
  const r = Hr(a.includes), l = new RegExp(typeof a.position == "number" ? `^.{${a.position}}${r}` : r);
  a.pattern = l, e._zod.onattach.push((s) => {
    const c = s._zod.bag;
    c.patterns ?? (c.patterns = /* @__PURE__ */ new Set()), c.patterns.add(l);
  }), e._zod.check = (s) => {
    s.value.includes(a.includes, a.position) || s.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: a.includes,
      input: s.value,
      inst: e,
      continue: !a.abort
    });
  };
}), DT = /* @__PURE__ */ Y("$ZodCheckStartsWith", (e, a) => {
  an.init(e, a);
  const r = new RegExp(`^${Hr(a.prefix)}.*`);
  a.pattern ?? (a.pattern = r), e._zod.onattach.push((l) => {
    const s = l._zod.bag;
    s.patterns ?? (s.patterns = /* @__PURE__ */ new Set()), s.patterns.add(r);
  }), e._zod.check = (l) => {
    l.value.startsWith(a.prefix) || l.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: a.prefix,
      input: l.value,
      inst: e,
      continue: !a.abort
    });
  };
}), zT = /* @__PURE__ */ Y("$ZodCheckEndsWith", (e, a) => {
  an.init(e, a);
  const r = new RegExp(`.*${Hr(a.suffix)}$`);
  a.pattern ?? (a.pattern = r), e._zod.onattach.push((l) => {
    const s = l._zod.bag;
    s.patterns ?? (s.patterns = /* @__PURE__ */ new Set()), s.patterns.add(r);
  }), e._zod.check = (l) => {
    l.value.endsWith(a.suffix) || l.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: a.suffix,
      input: l.value,
      inst: e,
      continue: !a.abort
    });
  };
}), LT = /* @__PURE__ */ Y("$ZodCheckOverwrite", (e, a) => {
  an.init(e, a), e._zod.check = (r) => {
    r.value = a.tx(r.value);
  };
}), HT = class {
  constructor(e = []) {
    this.content = [], this.indent = 0, this && (this.args = e);
  }
  indented(e) {
    this.indent += 1, e(this), this.indent -= 1;
  }
  write(e) {
    if (typeof e == "function") {
      e(this, { execution: "sync" }), e(this, { execution: "async" });
      return;
    }
    const a = e.split(`
`).filter((s) => s), r = Math.min(...a.map((s) => s.length - s.trimStart().length)), l = a.map((s) => s.slice(r)).map((s) => " ".repeat(this.indent * 2) + s);
    for (const s of l) this.content.push(s);
  }
  compile() {
    const e = Function, a = this?.args, r = [...(this?.content ?? [""]).map((l) => `  ${l}`)];
    return new e(...a, r.join(`
`));
  }
}, jT = {
  major: 4,
  minor: 1,
  patch: 12
}, at = /* @__PURE__ */ Y("$ZodType", (e, a) => {
  var r;
  e ?? (e = {}), e._zod.def = a, e._zod.bag = e._zod.bag || {}, e._zod.version = jT;
  const l = [...e._zod.def.checks ?? []];
  e._zod.traits.has("$ZodCheck") && l.unshift(e);
  for (const s of l) for (const c of s._zod.onattach) c(e);
  if (l.length === 0)
    (r = e._zod).deferred ?? (r.deferred = []), e._zod.deferred?.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    const s = (d, h, m) => {
      let y = Rr(d), p;
      for (const _ of h) {
        if (_._zod.def.when) {
          if (!_._zod.def.when(d)) continue;
        } else if (y) continue;
        const w = d.issues.length, E = _._zod.check(d);
        if (E instanceof Promise && m?.async === !1) throw new Dr();
        if (p || E instanceof Promise) p = (p ?? Promise.resolve()).then(async () => {
          await E, d.issues.length !== w && (y || (y = Rr(d, w)));
        });
        else {
          if (d.issues.length === w) continue;
          y || (y = Rr(d, w));
        }
      }
      return p ? p.then(() => d) : d;
    }, c = (d, h, m) => {
      if (Rr(d))
        return d.aborted = !0, d;
      const y = s(h, l, m);
      if (y instanceof Promise) {
        if (m.async === !1) throw new Dr();
        return y.then((p) => e._zod.parse(p, m));
      }
      return e._zod.parse(y, m);
    };
    e._zod.run = (d, h) => {
      if (h.skipChecks) return e._zod.parse(d, h);
      if (h.direction === "backward") {
        const y = e._zod.parse({
          value: d.value,
          issues: []
        }, {
          ...h,
          skipChecks: !0
        });
        return y instanceof Promise ? y.then((p) => c(p, d, h)) : c(y, d, h);
      }
      const m = e._zod.parse(d, h);
      if (m instanceof Promise) {
        if (h.async === !1) throw new Dr();
        return m.then((y) => s(y, l, h));
      }
      return s(m, l, h);
    };
  }
  e["~standard"] = {
    validate: (s) => {
      try {
        const c = kE(e, s);
        return c.success ? { value: c.data } : { issues: c.error?.issues };
      } catch {
        return PE(e, s).then((d) => d.success ? { value: d.data } : { issues: d.error?.issues });
      }
    },
    vendor: "zod",
    version: 1
  };
}), Jd = /* @__PURE__ */ Y("$ZodString", (e, a) => {
  at.init(e, a), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? vT(e._zod.bag), e._zod.parse = (r, l) => {
    if (a.coerce) try {
      r.value = String(r.value);
    } catch {
    }
    return typeof r.value == "string" || r.issues.push({
      expected: "string",
      code: "invalid_type",
      input: r.value,
      inst: e
    }), r;
  };
}), nt = /* @__PURE__ */ Y("$ZodStringFormat", (e, a) => {
  lu.init(e, a), Jd.init(e, a);
}), BT = /* @__PURE__ */ Y("$ZodGUID", (e, a) => {
  a.pattern ?? (a.pattern = nT), nt.init(e, a);
}), UT = /* @__PURE__ */ Y("$ZodUUID", (e, a) => {
  if (a.version) {
    const r = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[a.version];
    if (r === void 0) throw new Error(`Invalid UUID version: "${a.version}"`);
    a.pattern ?? (a.pattern = B0(r));
  } else a.pattern ?? (a.pattern = B0());
  nt.init(e, a);
}), kT = /* @__PURE__ */ Y("$ZodEmail", (e, a) => {
  a.pattern ?? (a.pattern = aT), nt.init(e, a);
}), PT = /* @__PURE__ */ Y("$ZodURL", (e, a) => {
  nt.init(e, a), e._zod.check = (r) => {
    try {
      const l = r.value.trim(), s = new URL(l);
      a.hostname && (a.hostname.lastIndex = 0, a.hostname.test(s.hostname) || r.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: fT.source,
        input: r.value,
        inst: e,
        continue: !a.abort
      })), a.protocol && (a.protocol.lastIndex = 0, a.protocol.test(s.protocol.endsWith(":") ? s.protocol.slice(0, -1) : s.protocol) || r.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: a.protocol.source,
        input: r.value,
        inst: e,
        continue: !a.abort
      })), a.normalize ? r.value = s.href : r.value = l;
      return;
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "url",
        input: r.value,
        inst: e,
        continue: !a.abort
      });
    }
  };
}), IT = /* @__PURE__ */ Y("$ZodEmoji", (e, a) => {
  a.pattern ?? (a.pattern = rT()), nt.init(e, a);
}), ZT = /* @__PURE__ */ Y("$ZodNanoID", (e, a) => {
  a.pattern ?? (a.pattern = eT), nt.init(e, a);
}), GT = /* @__PURE__ */ Y("$ZodCUID", (e, a) => {
  a.pattern ?? (a.pattern = YE), nt.init(e, a);
}), VT = /* @__PURE__ */ Y("$ZodCUID2", (e, a) => {
  a.pattern ?? (a.pattern = WE), nt.init(e, a);
}), $T = /* @__PURE__ */ Y("$ZodULID", (e, a) => {
  a.pattern ?? (a.pattern = QE), nt.init(e, a);
}), FT = /* @__PURE__ */ Y("$ZodXID", (e, a) => {
  a.pattern ?? (a.pattern = KE), nt.init(e, a);
}), qT = /* @__PURE__ */ Y("$ZodKSUID", (e, a) => {
  a.pattern ?? (a.pattern = JE), nt.init(e, a);
}), XT = /* @__PURE__ */ Y("$ZodISODateTime", (e, a) => {
  a.pattern ?? (a.pattern = pT(a)), nt.init(e, a);
}), YT = /* @__PURE__ */ Y("$ZodISODate", (e, a) => {
  a.pattern ?? (a.pattern = hT), nt.init(e, a);
}), WT = /* @__PURE__ */ Y("$ZodISOTime", (e, a) => {
  a.pattern ?? (a.pattern = mT(a)), nt.init(e, a);
}), QT = /* @__PURE__ */ Y("$ZodISODuration", (e, a) => {
  a.pattern ?? (a.pattern = tT), nt.init(e, a);
}), KT = /* @__PURE__ */ Y("$ZodIPv4", (e, a) => {
  a.pattern ?? (a.pattern = oT), nt.init(e, a), e._zod.onattach.push((r) => {
    const l = r._zod.bag;
    l.format = "ipv4";
  });
}), JT = /* @__PURE__ */ Y("$ZodIPv6", (e, a) => {
  a.pattern ?? (a.pattern = lT), nt.init(e, a), e._zod.onattach.push((r) => {
    const l = r._zod.bag;
    l.format = "ipv6";
  }), e._zod.check = (r) => {
    try {
      new URL(`http://[${r.value}]`);
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "ipv6",
        input: r.value,
        inst: e,
        continue: !a.abort
      });
    }
  };
}), eC = /* @__PURE__ */ Y("$ZodCIDRv4", (e, a) => {
  a.pattern ?? (a.pattern = sT), nt.init(e, a);
}), tC = /* @__PURE__ */ Y("$ZodCIDRv6", (e, a) => {
  a.pattern ?? (a.pattern = uT), nt.init(e, a), e._zod.check = (r) => {
    const l = r.value.split("/");
    try {
      if (l.length !== 2) throw new Error();
      const [s, c] = l;
      if (!c) throw new Error();
      const d = Number(c);
      if (`${d}` !== c) throw new Error();
      if (d < 0 || d > 128) throw new Error();
      new URL(`http://[${s}]`);
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "cidrv6",
        input: r.value,
        inst: e,
        continue: !a.abort
      });
    }
  };
});
function Fg(e) {
  if (e === "") return !0;
  if (e.length % 4 !== 0) return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
var nC = /* @__PURE__ */ Y("$ZodBase64", (e, a) => {
  a.pattern ?? (a.pattern = cT), nt.init(e, a), e._zod.onattach.push((r) => {
    r._zod.bag.contentEncoding = "base64";
  }), e._zod.check = (r) => {
    Fg(r.value) || r.issues.push({
      code: "invalid_format",
      format: "base64",
      input: r.value,
      inst: e,
      continue: !a.abort
    });
  };
});
function aC(e) {
  if (!Pg.test(e)) return !1;
  const a = e.replace(/[-_]/g, (r) => r === "-" ? "+" : "/");
  return Fg(a.padEnd(Math.ceil(a.length / 4) * 4, "="));
}
var iC = /* @__PURE__ */ Y("$ZodBase64URL", (e, a) => {
  a.pattern ?? (a.pattern = Pg), nt.init(e, a), e._zod.onattach.push((r) => {
    r._zod.bag.contentEncoding = "base64url";
  }), e._zod.check = (r) => {
    aC(r.value) || r.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: r.value,
      inst: e,
      continue: !a.abort
    });
  };
}), rC = /* @__PURE__ */ Y("$ZodE164", (e, a) => {
  a.pattern ?? (a.pattern = dT), nt.init(e, a);
});
function oC(e, a = null) {
  try {
    const r = e.split(".");
    if (r.length !== 3) return !1;
    const [l] = r;
    if (!l) return !1;
    const s = JSON.parse(atob(l));
    return !("typ" in s && s?.typ !== "JWT" || !s.alg || a && (!("alg" in s) || s.alg !== a));
  } catch {
    return !1;
  }
}
var lC = /* @__PURE__ */ Y("$ZodJWT", (e, a) => {
  nt.init(e, a), e._zod.check = (r) => {
    oC(r.value, a.alg) || r.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: r.value,
      inst: e,
      continue: !a.abort
    });
  };
}), qg = /* @__PURE__ */ Y("$ZodNumber", (e, a) => {
  at.init(e, a), e._zod.pattern = e._zod.bag.pattern ?? yT, e._zod.parse = (r, l) => {
    if (a.coerce) try {
      r.value = Number(r.value);
    } catch {
    }
    const s = r.value;
    if (typeof s == "number" && !Number.isNaN(s) && Number.isFinite(s)) return r;
    const c = typeof s == "number" ? Number.isNaN(s) ? "NaN" : Number.isFinite(s) ? void 0 : "Infinity" : void 0;
    return r.issues.push({
      expected: "number",
      code: "invalid_type",
      input: s,
      inst: e,
      ...c ? { received: c } : {}
    }), r;
  };
}), sC = /* @__PURE__ */ Y("$ZodNumber", (e, a) => {
  TT.init(e, a), qg.init(e, a);
}), uC = /* @__PURE__ */ Y("$ZodBoolean", (e, a) => {
  at.init(e, a), e._zod.pattern = bT, e._zod.parse = (r, l) => {
    if (a.coerce) try {
      r.value = !!r.value;
    } catch {
    }
    const s = r.value;
    return typeof s == "boolean" || r.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: s,
      inst: e
    }), r;
  };
}), cC = /* @__PURE__ */ Y("$ZodNull", (e, a) => {
  at.init(e, a), e._zod.pattern = _T, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (r, l) => {
    const s = r.value;
    return s === null || r.issues.push({
      expected: "null",
      code: "invalid_type",
      input: s,
      inst: e
    }), r;
  };
}), fC = /* @__PURE__ */ Y("$ZodUnknown", (e, a) => {
  at.init(e, a), e._zod.parse = (r) => r;
}), dC = /* @__PURE__ */ Y("$ZodNever", (e, a) => {
  at.init(e, a), e._zod.parse = (r, l) => (r.issues.push({
    expected: "never",
    code: "invalid_type",
    input: r.value,
    inst: e
  }), r);
});
function U0(e, a, r) {
  e.issues.length && a.issues.push(...jg(r, e.issues)), a.value[r] = e.value;
}
var hC = /* @__PURE__ */ Y("$ZodArray", (e, a) => {
  at.init(e, a), e._zod.parse = (r, l) => {
    const s = r.value;
    if (!Array.isArray(s))
      return r.issues.push({
        expected: "array",
        code: "invalid_type",
        input: s,
        inst: e
      }), r;
    r.value = Array(s.length);
    const c = [];
    for (let d = 0; d < s.length; d++) {
      const h = s[d], m = a.element._zod.run({
        value: h,
        issues: []
      }, l);
      m instanceof Promise ? c.push(m.then((y) => U0(y, r, d))) : U0(m, r, d);
    }
    return c.length ? Promise.all(c).then(() => r) : r;
  };
});
function $s(e, a, r, l) {
  e.issues.length && a.issues.push(...jg(r, e.issues)), e.value === void 0 ? r in l && (a.value[r] = void 0) : a.value[r] = e.value;
}
function Xg(e) {
  const a = Object.keys(e.shape);
  for (const l of a) if (!e.shape?.[l]?._zod?.traits?.has("$ZodType")) throw new Error(`Invalid element at key "${l}": expected a Zod schema`);
  const r = OE(e.shape);
  return {
    ...e,
    keys: a,
    keySet: new Set(a),
    numKeys: a.length,
    optionalKeys: new Set(r)
  };
}
function Yg(e, a, r, l, s, c) {
  const d = [], h = s.keySet, m = s.catchall._zod, y = m.def.type;
  for (const p of Object.keys(a)) {
    if (h.has(p)) continue;
    if (y === "never") {
      d.push(p);
      continue;
    }
    const _ = m.run({
      value: a[p],
      issues: []
    }, l);
    _ instanceof Promise ? e.push(_.then((w) => $s(w, r, p, a))) : $s(_, r, p, a);
  }
  return d.length && r.issues.push({
    code: "unrecognized_keys",
    keys: d,
    input: a,
    inst: c
  }), e.length ? Promise.all(e).then(() => r) : r;
}
var mC = /* @__PURE__ */ Y("$ZodObject", (e, a) => {
  if (at.init(e, a), !Object.getOwnPropertyDescriptor(a, "shape")?.get) {
    const d = a.shape;
    Object.defineProperty(a, "shape", { get: () => {
      const h = { ...d };
      return Object.defineProperty(a, "shape", { value: h }), h;
    } });
  }
  const r = iu(() => Xg(a));
  We(e._zod, "propValues", () => {
    const d = a.shape, h = {};
    for (const m in d) {
      const y = d[m]._zod;
      if (y.values) {
        h[m] ?? (h[m] = /* @__PURE__ */ new Set());
        for (const p of y.values) h[m].add(p);
      }
    }
    return h;
  });
  const l = Fo, s = a.catchall;
  let c;
  e._zod.parse = (d, h) => {
    c ?? (c = r.value);
    const m = d.value;
    if (!l(m))
      return d.issues.push({
        expected: "object",
        code: "invalid_type",
        input: m,
        inst: e
      }), d;
    d.value = {};
    const y = [], p = c.shape;
    for (const _ of c.keys) {
      const w = p[_]._zod.run({
        value: m[_],
        issues: []
      }, h);
      w instanceof Promise ? y.push(w.then((E) => $s(E, d, _, m))) : $s(w, d, _, m);
    }
    return s ? Yg(y, m, d, h, r.value, e) : y.length ? Promise.all(y).then(() => d) : d;
  };
}), pC = /* @__PURE__ */ Y("$ZodObjectJIT", (e, a) => {
  mC.init(e, a);
  const r = e._zod.parse, l = iu(() => Xg(a)), s = (w) => {
    const E = new HT([
      "shape",
      "payload",
      "ctx"
    ]), x = l.value, C = (j) => {
      const H = j0(j);
      return `shape[${H}]._zod.run({ value: input[${H}], issues: [] }, ctx)`;
    };
    E.write("const input = payload.value;");
    const T = /* @__PURE__ */ Object.create(null);
    let M = 0;
    for (const j of x.keys) T[j] = `key_${M++}`;
    E.write("const newResult = {};");
    for (const j of x.keys) {
      const H = T[j], k = j0(j);
      E.write(`const ${H} = ${C(j)};`), E.write(`
        if (${H}.issues.length) {
          payload.issues = payload.issues.concat(${H}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${k}, ...iss.path] : [${k}]
          })));
        }
        
        
        if (${H}.value === undefined) {
          if (${k} in input) {
            newResult[${k}] = undefined;
          }
        } else {
          newResult[${k}] = ${H}.value;
        }
        
      `);
    }
    E.write("payload.value = newResult;"), E.write("return payload;");
    const D = E.compile();
    return (j, H) => D(w, j, H);
  };
  let c;
  const d = Fo, h = !Ed.jitless, y = h && AE.value, p = a.catchall;
  let _;
  e._zod.parse = (w, E) => {
    _ ?? (_ = l.value);
    const x = w.value;
    return d(x) ? h && y && E?.async === !1 && E.jitless !== !0 ? (c || (c = s(a.shape)), w = c(w, E), p ? Yg([], x, w, E, _, e) : w) : r(w, E) : (w.issues.push({
      expected: "object",
      code: "invalid_type",
      input: x,
      inst: e
    }), w);
  };
});
function k0(e, a, r, l) {
  for (const c of e) if (c.issues.length === 0)
    return a.value = c.value, a;
  const s = e.filter((c) => !Rr(c));
  return s.length === 1 ? (a.value = s[0].value, s[0]) : (a.issues.push({
    code: "invalid_union",
    input: a.value,
    inst: r,
    errors: e.map((c) => c.issues.map((d) => Di(d, l, Ni())))
  }), a);
}
var Wg = /* @__PURE__ */ Y("$ZodUnion", (e, a) => {
  at.init(e, a), We(e._zod, "optin", () => a.options.some((s) => s._zod.optin === "optional") ? "optional" : void 0), We(e._zod, "optout", () => a.options.some((s) => s._zod.optout === "optional") ? "optional" : void 0), We(e._zod, "values", () => {
    if (a.options.every((s) => s._zod.values)) return new Set(a.options.flatMap((s) => Array.from(s._zod.values)));
  }), We(e._zod, "pattern", () => {
    if (a.options.every((s) => s._zod.pattern)) {
      const s = a.options.map((c) => c._zod.pattern);
      return new RegExp(`^(${s.map((c) => Yd(c.source)).join("|")})$`);
    }
  });
  const r = a.options.length === 1, l = a.options[0]._zod.run;
  e._zod.parse = (s, c) => {
    if (r) return l(s, c);
    let d = !1;
    const h = [];
    for (const m of a.options) {
      const y = m._zod.run({
        value: s.value,
        issues: []
      }, c);
      if (y instanceof Promise)
        h.push(y), d = !0;
      else {
        if (y.issues.length === 0) return y;
        h.push(y);
      }
    }
    return d ? Promise.all(h).then((m) => k0(m, s, e, c)) : k0(h, s, e, c);
  };
}), vC = /* @__PURE__ */ Y("$ZodDiscriminatedUnion", (e, a) => {
  Wg.init(e, a);
  const r = e._zod.parse;
  We(e._zod, "propValues", () => {
    const s = {};
    for (const c of a.options) {
      const d = c._zod.propValues;
      if (!d || Object.keys(d).length === 0) throw new Error(`Invalid discriminated union option at index "${a.options.indexOf(c)}"`);
      for (const [h, m] of Object.entries(d)) {
        s[h] || (s[h] = /* @__PURE__ */ new Set());
        for (const y of m) s[h].add(y);
      }
    }
    return s;
  });
  const l = iu(() => {
    const s = a.options, c = /* @__PURE__ */ new Map();
    for (const d of s) {
      const h = d._zod.propValues?.[a.discriminator];
      if (!h || h.size === 0) throw new Error(`Invalid discriminated union option at index "${a.options.indexOf(d)}"`);
      for (const m of h) {
        if (c.has(m)) throw new Error(`Duplicate discriminator value "${String(m)}"`);
        c.set(m, d);
      }
    }
    return c;
  });
  e._zod.parse = (s, c) => {
    const d = s.value;
    if (!Fo(d))
      return s.issues.push({
        code: "invalid_type",
        expected: "object",
        input: d,
        inst: e
      }), s;
    const h = l.value.get(d?.[a.discriminator]);
    return h ? h._zod.run(s, c) : a.unionFallback ? r(s, c) : (s.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: a.discriminator,
      input: d,
      path: [a.discriminator],
      inst: e
    }), s);
  };
}), gC = /* @__PURE__ */ Y("$ZodIntersection", (e, a) => {
  at.init(e, a), e._zod.parse = (r, l) => {
    const s = r.value, c = a.left._zod.run({
      value: s,
      issues: []
    }, l), d = a.right._zod.run({
      value: s,
      issues: []
    }, l);
    return c instanceof Promise || d instanceof Promise ? Promise.all([c, d]).then(([h, m]) => P0(r, h, m)) : P0(r, c, d);
  };
});
function Cd(e, a) {
  if (e === a) return {
    valid: !0,
    data: e
  };
  if (e instanceof Date && a instanceof Date && +e == +a) return {
    valid: !0,
    data: e
  };
  if (qo(e) && qo(a)) {
    const r = Object.keys(a), l = Object.keys(e).filter((c) => r.indexOf(c) !== -1), s = {
      ...e,
      ...a
    };
    for (const c of l) {
      const d = Cd(e[c], a[c]);
      if (!d.valid) return {
        valid: !1,
        mergeErrorPath: [c, ...d.mergeErrorPath]
      };
      s[c] = d.data;
    }
    return {
      valid: !0,
      data: s
    };
  }
  if (Array.isArray(e) && Array.isArray(a)) {
    if (e.length !== a.length) return {
      valid: !1,
      mergeErrorPath: []
    };
    const r = [];
    for (let l = 0; l < e.length; l++) {
      const s = e[l], c = a[l], d = Cd(s, c);
      if (!d.valid) return {
        valid: !1,
        mergeErrorPath: [l, ...d.mergeErrorPath]
      };
      r.push(d.data);
    }
    return {
      valid: !0,
      data: r
    };
  }
  return {
    valid: !1,
    mergeErrorPath: []
  };
}
function P0(e, a, r) {
  if (a.issues.length && e.issues.push(...a.issues), r.issues.length && e.issues.push(...r.issues), Rr(e)) return e;
  const l = Cd(a.value, r.value);
  if (!l.valid) throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(l.mergeErrorPath)}`);
  return e.value = l.data, e;
}
var yC = /* @__PURE__ */ Y("$ZodEnum", (e, a) => {
  at.init(e, a);
  const r = TE(a.entries), l = new Set(r);
  e._zod.values = l, e._zod.pattern = new RegExp(`^(${r.filter((s) => xE.has(typeof s)).map((s) => typeof s == "string" ? Hr(s) : s.toString()).join("|")})$`), e._zod.parse = (s, c) => {
    const d = s.value;
    return l.has(d) || s.issues.push({
      code: "invalid_value",
      values: r,
      input: d,
      inst: e
    }), s;
  };
}), bC = /* @__PURE__ */ Y("$ZodLiteral", (e, a) => {
  if (at.init(e, a), a.values.length === 0) throw new Error("Cannot create literal schema with no valid values");
  e._zod.values = new Set(a.values), e._zod.pattern = new RegExp(`^(${a.values.map((r) => typeof r == "string" ? Hr(r) : r ? Hr(r.toString()) : String(r)).join("|")})$`), e._zod.parse = (r, l) => {
    const s = r.value;
    return e._zod.values.has(s) || r.issues.push({
      code: "invalid_value",
      values: a.values,
      input: s,
      inst: e
    }), r;
  };
}), _C = /* @__PURE__ */ Y("$ZodTransform", (e, a) => {
  at.init(e, a), e._zod.parse = (r, l) => {
    if (l.direction === "backward") throw new zg(e.constructor.name);
    const s = a.transform(r.value, r);
    if (l.async) return (s instanceof Promise ? s : Promise.resolve(s)).then((c) => (r.value = c, r));
    if (s instanceof Promise) throw new Dr();
    return r.value = s, r;
  };
});
function I0(e, a) {
  return e.issues.length && a === void 0 ? {
    issues: [],
    value: void 0
  } : e;
}
var wC = /* @__PURE__ */ Y("$ZodOptional", (e, a) => {
  at.init(e, a), e._zod.optin = "optional", e._zod.optout = "optional", We(e._zod, "values", () => a.innerType._zod.values ? /* @__PURE__ */ new Set([...a.innerType._zod.values, void 0]) : void 0), We(e._zod, "pattern", () => {
    const r = a.innerType._zod.pattern;
    return r ? new RegExp(`^(${Yd(r.source)})?$`) : void 0;
  }), e._zod.parse = (r, l) => {
    if (a.innerType._zod.optin === "optional") {
      const s = a.innerType._zod.run(r, l);
      return s instanceof Promise ? s.then((c) => I0(c, r.value)) : I0(s, r.value);
    }
    return r.value === void 0 ? r : a.innerType._zod.run(r, l);
  };
}), SC = /* @__PURE__ */ Y("$ZodNullable", (e, a) => {
  at.init(e, a), We(e._zod, "optin", () => a.innerType._zod.optin), We(e._zod, "optout", () => a.innerType._zod.optout), We(e._zod, "pattern", () => {
    const r = a.innerType._zod.pattern;
    return r ? new RegExp(`^(${Yd(r.source)}|null)$`) : void 0;
  }), We(e._zod, "values", () => a.innerType._zod.values ? /* @__PURE__ */ new Set([...a.innerType._zod.values, null]) : void 0), e._zod.parse = (r, l) => r.value === null ? r : a.innerType._zod.run(r, l);
}), EC = /* @__PURE__ */ Y("$ZodDefault", (e, a) => {
  at.init(e, a), e._zod.optin = "optional", We(e._zod, "values", () => a.innerType._zod.values), e._zod.parse = (r, l) => {
    if (l.direction === "backward") return a.innerType._zod.run(r, l);
    if (r.value === void 0)
      return r.value = a.defaultValue, r;
    const s = a.innerType._zod.run(r, l);
    return s instanceof Promise ? s.then((c) => Z0(c, a)) : Z0(s, a);
  };
});
function Z0(e, a) {
  return e.value === void 0 && (e.value = a.defaultValue), e;
}
var TC = /* @__PURE__ */ Y("$ZodPrefault", (e, a) => {
  at.init(e, a), e._zod.optin = "optional", We(e._zod, "values", () => a.innerType._zod.values), e._zod.parse = (r, l) => (l.direction === "backward" || r.value === void 0 && (r.value = a.defaultValue), a.innerType._zod.run(r, l));
}), CC = /* @__PURE__ */ Y("$ZodNonOptional", (e, a) => {
  at.init(e, a), We(e._zod, "values", () => {
    const r = a.innerType._zod.values;
    return r ? new Set([...r].filter((l) => l !== void 0)) : void 0;
  }), e._zod.parse = (r, l) => {
    const s = a.innerType._zod.run(r, l);
    return s instanceof Promise ? s.then((c) => G0(c, e)) : G0(s, e);
  };
});
function G0(e, a) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: a
  }), e;
}
var AC = /* @__PURE__ */ Y("$ZodCatch", (e, a) => {
  at.init(e, a), We(e._zod, "optin", () => a.innerType._zod.optin), We(e._zod, "optout", () => a.innerType._zod.optout), We(e._zod, "values", () => a.innerType._zod.values), e._zod.parse = (r, l) => {
    if (l.direction === "backward") return a.innerType._zod.run(r, l);
    const s = a.innerType._zod.run(r, l);
    return s instanceof Promise ? s.then((c) => (r.value = c.value, c.issues.length && (r.value = a.catchValue({
      ...r,
      error: { issues: c.issues.map((d) => Di(d, l, Ni())) },
      input: r.value
    }), r.issues = []), r)) : (r.value = s.value, s.issues.length && (r.value = a.catchValue({
      ...r,
      error: { issues: s.issues.map((c) => Di(c, l, Ni())) },
      input: r.value
    }), r.issues = []), r);
  };
}), xC = /* @__PURE__ */ Y("$ZodPipe", (e, a) => {
  at.init(e, a), We(e._zod, "values", () => a.in._zod.values), We(e._zod, "optin", () => a.in._zod.optin), We(e._zod, "optout", () => a.out._zod.optout), We(e._zod, "propValues", () => a.in._zod.propValues), e._zod.parse = (r, l) => {
    if (l.direction === "backward") {
      const c = a.out._zod.run(r, l);
      return c instanceof Promise ? c.then((d) => xs(d, a.in, l)) : xs(c, a.in, l);
    }
    const s = a.in._zod.run(r, l);
    return s instanceof Promise ? s.then((c) => xs(c, a.out, l)) : xs(s, a.out, l);
  };
});
function xs(e, a, r) {
  return e.issues.length ? (e.aborted = !0, e) : a._zod.run({
    value: e.value,
    issues: e.issues
  }, r);
}
var OC = /* @__PURE__ */ Y("$ZodReadonly", (e, a) => {
  at.init(e, a), We(e._zod, "propValues", () => a.innerType._zod.propValues), We(e._zod, "values", () => a.innerType._zod.values), We(e._zod, "optin", () => a.innerType._zod.optin), We(e._zod, "optout", () => a.innerType._zod.optout), e._zod.parse = (r, l) => {
    if (l.direction === "backward") return a.innerType._zod.run(r, l);
    const s = a.innerType._zod.run(r, l);
    return s instanceof Promise ? s.then(V0) : V0(s);
  };
});
function V0(e) {
  return e.value = Object.freeze(e.value), e;
}
var MC = /* @__PURE__ */ Y("$ZodCustom", (e, a) => {
  an.init(e, a), at.init(e, a), e._zod.parse = (r, l) => r, e._zod.check = (r) => {
    const l = r.value, s = a.fn(l);
    if (s instanceof Promise) return s.then((c) => $0(c, r, l, e));
    $0(s, r, l, e);
  };
});
function $0(e, a, r, l) {
  if (!e) {
    const s = {
      code: "custom",
      input: r,
      inst: l,
      path: [...l._zod.def.path ?? []],
      continue: !l._zod.def.abort
    };
    l._zod.def.params && (s.params = l._zod.def.params), a.issues.push(Xo(s));
  }
}
var RC = class {
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(e, ...a) {
    const r = a[0];
    if (this._map.set(e, r), r && typeof r == "object" && "id" in r) {
      if (this._idmap.has(r.id)) throw new Error(`ID ${r.id} already exists in the registry`);
      this._idmap.set(r.id, e);
    }
    return this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(e) {
    const a = this._map.get(e);
    return a && typeof a == "object" && "id" in a && this._idmap.delete(a.id), this._map.delete(e), this;
  }
  get(e) {
    const a = e._zod.parent;
    if (a) {
      const r = { ...this.get(a) ?? {} };
      delete r.id;
      const l = {
        ...r,
        ...this._map.get(e)
      };
      return Object.keys(l).length ? l : void 0;
    }
    return this._map.get(e);
  }
  has(e) {
    return this._map.has(e);
  }
};
function NC() {
  return new RC();
}
var Os = /* @__PURE__ */ NC();
function DC(e, a) {
  return new e({
    type: "string",
    ...ge(a)
  });
}
function Qg(e, a) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function F0(e, a) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function zC(e, a) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function LC(e, a) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...ge(a)
  });
}
function HC(e, a) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...ge(a)
  });
}
function jC(e, a) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...ge(a)
  });
}
function BC(e, a) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function UC(e, a) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function kC(e, a) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function PC(e, a) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function IC(e, a) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function ZC(e, a) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function GC(e, a) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function VC(e, a) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function $C(e, a) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function FC(e, a) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function qC(e, a) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function XC(e, a) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function YC(e, a) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function WC(e, a) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function QC(e, a) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function KC(e, a) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...ge(a)
  });
}
function JC(e, a) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...ge(a)
  });
}
function e3(e, a) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...ge(a)
  });
}
function t3(e, a) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...ge(a)
  });
}
function n3(e, a) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...ge(a)
  });
}
function a3(e, a) {
  return new e({
    type: "number",
    checks: [],
    ...ge(a)
  });
}
function i3(e, a) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...ge(a)
  });
}
function r3(e, a) {
  return new e({
    type: "boolean",
    ...ge(a)
  });
}
function o3(e, a) {
  return new e({
    type: "null",
    ...ge(a)
  });
}
function l3(e) {
  return new e({ type: "unknown" });
}
function s3(e, a) {
  return new e({
    type: "never",
    ...ge(a)
  });
}
function q0(e, a) {
  return new Vg({
    check: "less_than",
    ...ge(a),
    value: e,
    inclusive: !1
  });
}
function Vf(e, a) {
  return new Vg({
    check: "less_than",
    ...ge(a),
    value: e,
    inclusive: !0
  });
}
function X0(e, a) {
  return new $g({
    check: "greater_than",
    ...ge(a),
    value: e,
    inclusive: !1
  });
}
function $f(e, a) {
  return new $g({
    check: "greater_than",
    ...ge(a),
    value: e,
    inclusive: !0
  });
}
function Y0(e, a) {
  return new ET({
    check: "multiple_of",
    ...ge(a),
    value: e
  });
}
function Kg(e, a) {
  return new CT({
    check: "max_length",
    ...ge(a),
    maximum: e
  });
}
function Fs(e, a) {
  return new AT({
    check: "min_length",
    ...ge(a),
    minimum: e
  });
}
function Jg(e, a) {
  return new xT({
    check: "length_equals",
    ...ge(a),
    length: e
  });
}
function u3(e, a) {
  return new OT({
    check: "string_format",
    format: "regex",
    ...ge(a),
    pattern: e
  });
}
function c3(e) {
  return new MT({
    check: "string_format",
    format: "lowercase",
    ...ge(e)
  });
}
function f3(e) {
  return new RT({
    check: "string_format",
    format: "uppercase",
    ...ge(e)
  });
}
function d3(e, a) {
  return new NT({
    check: "string_format",
    format: "includes",
    ...ge(a),
    includes: e
  });
}
function h3(e, a) {
  return new DT({
    check: "string_format",
    format: "starts_with",
    ...ge(a),
    prefix: e
  });
}
function m3(e, a) {
  return new zT({
    check: "string_format",
    format: "ends_with",
    ...ge(a),
    suffix: e
  });
}
function nl(e) {
  return new LT({
    check: "overwrite",
    tx: e
  });
}
function p3(e) {
  return nl((a) => a.normalize(e));
}
function v3() {
  return nl((e) => e.trim());
}
function g3() {
  return nl((e) => e.toLowerCase());
}
function y3() {
  return nl((e) => e.toUpperCase());
}
function b3(e, a, r) {
  return new e({
    type: "array",
    element: a,
    ...ge(r)
  });
}
function _3(e, a, r) {
  return new e({
    type: "custom",
    check: "custom",
    fn: a,
    ...ge(r)
  });
}
function w3(e) {
  const a = S3((r) => (r.addIssue = (l) => {
    if (typeof l == "string") r.issues.push(Xo(l, r.value, a._zod.def));
    else {
      const s = l;
      s.fatal && (s.continue = !1), s.code ?? (s.code = "custom"), s.input ?? (s.input = r.value), s.inst ?? (s.inst = a), s.continue ?? (s.continue = !a._zod.def.abort), r.issues.push(Xo(s));
    }
  }, e(r.value, r)));
  return a;
}
function S3(e, a) {
  const r = new an({
    check: "custom",
    ...ge(a)
  });
  return r._zod.check = e, r;
}
var E3 = /* @__PURE__ */ Y("ZodISODateTime", (e, a) => {
  XT.init(e, a), it.init(e, a);
});
function T3(e) {
  return JC(E3, e);
}
var C3 = /* @__PURE__ */ Y("ZodISODate", (e, a) => {
  YT.init(e, a), it.init(e, a);
});
function A3(e) {
  return e3(C3, e);
}
var x3 = /* @__PURE__ */ Y("ZodISOTime", (e, a) => {
  WT.init(e, a), it.init(e, a);
});
function O3(e) {
  return t3(x3, e);
}
var M3 = /* @__PURE__ */ Y("ZodISODuration", (e, a) => {
  QT.init(e, a), it.init(e, a);
});
function R3(e) {
  return n3(M3, e);
}
var ey = (e, a) => {
  Ug.init(e, a), e.name = "ZodError", Object.defineProperties(e, {
    format: { value: (r) => UE(e, r) },
    flatten: { value: (r) => BE(e, r) },
    addIssue: { value: (r) => {
      e.issues.push(r), e.message = JSON.stringify(e.issues, Td, 2);
    } },
    addIssues: { value: (r) => {
      e.issues.push(...r), e.message = JSON.stringify(e.issues, Td, 2);
    } },
    isEmpty: { get() {
      return e.issues.length === 0;
    } }
  });
}, YM = Y("ZodError", ey), Hn = Y("ZodError", ey, { Parent: Error }), N3 = /* @__PURE__ */ Qd(Hn), D3 = /* @__PURE__ */ Kd(Hn), z3 = /* @__PURE__ */ ru(Hn), L3 = /* @__PURE__ */ ou(Hn), H3 = /* @__PURE__ */ IE(Hn), j3 = /* @__PURE__ */ ZE(Hn), B3 = /* @__PURE__ */ GE(Hn), U3 = /* @__PURE__ */ VE(Hn), k3 = /* @__PURE__ */ $E(Hn), P3 = /* @__PURE__ */ FE(Hn), I3 = /* @__PURE__ */ qE(Hn), Z3 = /* @__PURE__ */ XE(Hn), st = /* @__PURE__ */ Y("ZodType", (e, a) => (at.init(e, a), e.def = a, e.type = a.type, Object.defineProperty(e, "_def", { value: a }), e.check = (...r) => e.clone(ki(a, { checks: [...a.checks ?? [], ...r.map((l) => typeof l == "function" ? { _zod: {
  check: l,
  def: { check: "custom" },
  onattach: []
} } : l)] })), e.clone = (r, l) => ri(e, r, l), e.brand = () => e, e.register = ((r, l) => (r.add(e, l), e)), e.parse = (r, l) => N3(e, r, l, { callee: e.parse }), e.safeParse = (r, l) => z3(e, r, l), e.parseAsync = async (r, l) => D3(e, r, l, { callee: e.parseAsync }), e.safeParseAsync = async (r, l) => L3(e, r, l), e.spa = e.safeParseAsync, e.encode = (r, l) => H3(e, r, l), e.decode = (r, l) => j3(e, r, l), e.encodeAsync = async (r, l) => B3(e, r, l), e.decodeAsync = async (r, l) => U3(e, r, l), e.safeEncode = (r, l) => k3(e, r, l), e.safeDecode = (r, l) => P3(e, r, l), e.safeEncodeAsync = async (r, l) => I3(e, r, l), e.safeDecodeAsync = async (r, l) => Z3(e, r, l), e.refine = (r, l) => e.check(z4(r, l)), e.superRefine = (r) => e.check(L4(r)), e.overwrite = (r) => e.check(nl(r)), e.optional = () => J0(e), e.nullable = () => e1(e), e.nullish = () => J0(e1(e)), e.nonoptional = (r) => A4(e, r), e.array = () => Zn(e), e.or = (r) => sy([e, r]), e.and = (r) => g4(e, r), e.transform = (r) => t1(e, _4(r)), e.default = (r) => E4(e, r), e.prefault = (r) => C4(e, r), e.catch = (r) => O4(e, r), e.pipe = (r) => t1(e, r), e.readonly = () => N4(e), e.describe = (r) => {
  const l = e.clone();
  return Os.add(l, { description: r }), l;
}, Object.defineProperty(e, "description", {
  get() {
    return Os.get(e)?.description;
  },
  configurable: !0
}), e.meta = (...r) => {
  if (r.length === 0) return Os.get(e);
  const l = e.clone();
  return Os.add(l, r[0]), l;
}, e.isOptional = () => e.safeParse(void 0).success, e.isNullable = () => e.safeParse(null).success, e)), ty = /* @__PURE__ */ Y("_ZodString", (e, a) => {
  Jd.init(e, a), st.init(e, a);
  const r = e._zod.bag;
  e.format = r.format ?? null, e.minLength = r.minimum ?? null, e.maxLength = r.maximum ?? null, e.regex = (...l) => e.check(u3(...l)), e.includes = (...l) => e.check(d3(...l)), e.startsWith = (...l) => e.check(h3(...l)), e.endsWith = (...l) => e.check(m3(...l)), e.min = (...l) => e.check(Fs(...l)), e.max = (...l) => e.check(Kg(...l)), e.length = (...l) => e.check(Jg(...l)), e.nonempty = (...l) => e.check(Fs(1, ...l)), e.lowercase = (l) => e.check(c3(l)), e.uppercase = (l) => e.check(f3(l)), e.trim = () => e.check(v3()), e.normalize = (...l) => e.check(p3(...l)), e.toLowerCase = () => e.check(g3()), e.toUpperCase = () => e.check(y3());
}), G3 = /* @__PURE__ */ Y("ZodString", (e, a) => {
  Jd.init(e, a), ty.init(e, a), e.email = (r) => e.check(Qg(ny, r)), e.url = (r) => e.check(BC($3, r)), e.jwt = (r) => e.check(KC(o4, r)), e.emoji = (r) => e.check(UC(F3, r)), e.guid = (r) => e.check(F0(W0, r)), e.uuid = (r) => e.check(zC(Ms, r)), e.uuidv4 = (r) => e.check(LC(Ms, r)), e.uuidv6 = (r) => e.check(HC(Ms, r)), e.uuidv7 = (r) => e.check(jC(Ms, r)), e.nanoid = (r) => e.check(kC(q3, r)), e.guid = (r) => e.check(F0(W0, r)), e.cuid = (r) => e.check(PC(X3, r)), e.cuid2 = (r) => e.check(IC(Y3, r)), e.ulid = (r) => e.check(ZC(W3, r)), e.base64 = (r) => e.check(YC(a4, r)), e.base64url = (r) => e.check(WC(i4, r)), e.xid = (r) => e.check(GC(Q3, r)), e.ksuid = (r) => e.check(VC(K3, r)), e.ipv4 = (r) => e.check($C(J3, r)), e.ipv6 = (r) => e.check(FC(e4, r)), e.cidrv4 = (r) => e.check(qC(t4, r)), e.cidrv6 = (r) => e.check(XC(n4, r)), e.e164 = (r) => e.check(QC(r4, r)), e.datetime = (r) => e.check(T3(r)), e.date = (r) => e.check(A3(r)), e.time = (r) => e.check(O3(r)), e.duration = (r) => e.check(R3(r));
});
function _t(e) {
  return DC(G3, e);
}
var it = /* @__PURE__ */ Y("ZodStringFormat", (e, a) => {
  nt.init(e, a), ty.init(e, a);
}), ny = /* @__PURE__ */ Y("ZodEmail", (e, a) => {
  kT.init(e, a), it.init(e, a);
});
function V3(e) {
  return Qg(ny, e);
}
var W0 = /* @__PURE__ */ Y("ZodGUID", (e, a) => {
  BT.init(e, a), it.init(e, a);
}), Ms = /* @__PURE__ */ Y("ZodUUID", (e, a) => {
  UT.init(e, a), it.init(e, a);
}), $3 = /* @__PURE__ */ Y("ZodURL", (e, a) => {
  PT.init(e, a), it.init(e, a);
}), F3 = /* @__PURE__ */ Y("ZodEmoji", (e, a) => {
  IT.init(e, a), it.init(e, a);
}), q3 = /* @__PURE__ */ Y("ZodNanoID", (e, a) => {
  ZT.init(e, a), it.init(e, a);
}), X3 = /* @__PURE__ */ Y("ZodCUID", (e, a) => {
  GT.init(e, a), it.init(e, a);
}), Y3 = /* @__PURE__ */ Y("ZodCUID2", (e, a) => {
  VT.init(e, a), it.init(e, a);
}), W3 = /* @__PURE__ */ Y("ZodULID", (e, a) => {
  $T.init(e, a), it.init(e, a);
}), Q3 = /* @__PURE__ */ Y("ZodXID", (e, a) => {
  FT.init(e, a), it.init(e, a);
}), K3 = /* @__PURE__ */ Y("ZodKSUID", (e, a) => {
  qT.init(e, a), it.init(e, a);
}), J3 = /* @__PURE__ */ Y("ZodIPv4", (e, a) => {
  KT.init(e, a), it.init(e, a);
}), e4 = /* @__PURE__ */ Y("ZodIPv6", (e, a) => {
  JT.init(e, a), it.init(e, a);
}), t4 = /* @__PURE__ */ Y("ZodCIDRv4", (e, a) => {
  eC.init(e, a), it.init(e, a);
}), n4 = /* @__PURE__ */ Y("ZodCIDRv6", (e, a) => {
  tC.init(e, a), it.init(e, a);
}), a4 = /* @__PURE__ */ Y("ZodBase64", (e, a) => {
  nC.init(e, a), it.init(e, a);
}), i4 = /* @__PURE__ */ Y("ZodBase64URL", (e, a) => {
  iC.init(e, a), it.init(e, a);
}), r4 = /* @__PURE__ */ Y("ZodE164", (e, a) => {
  rC.init(e, a), it.init(e, a);
}), o4 = /* @__PURE__ */ Y("ZodJWT", (e, a) => {
  lC.init(e, a), it.init(e, a);
}), ay = /* @__PURE__ */ Y("ZodNumber", (e, a) => {
  qg.init(e, a), st.init(e, a), e.gt = (l, s) => e.check(X0(l, s)), e.gte = (l, s) => e.check($f(l, s)), e.min = (l, s) => e.check($f(l, s)), e.lt = (l, s) => e.check(q0(l, s)), e.lte = (l, s) => e.check(Vf(l, s)), e.max = (l, s) => e.check(Vf(l, s)), e.int = (l) => e.check(Q0(l)), e.safe = (l) => e.check(Q0(l)), e.positive = (l) => e.check(X0(0, l)), e.nonnegative = (l) => e.check($f(0, l)), e.negative = (l) => e.check(q0(0, l)), e.nonpositive = (l) => e.check(Vf(0, l)), e.multipleOf = (l, s) => e.check(Y0(l, s)), e.step = (l, s) => e.check(Y0(l, s)), e.finite = () => e;
  const r = e._zod.bag;
  e.minValue = Math.max(r.minimum ?? Number.NEGATIVE_INFINITY, r.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null, e.maxValue = Math.min(r.maximum ?? Number.POSITIVE_INFINITY, r.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null, e.isInt = (r.format ?? "").includes("int") || Number.isSafeInteger(r.multipleOf ?? 0.5), e.isFinite = !0, e.format = r.format ?? null;
});
function eh(e) {
  return a3(ay, e);
}
var l4 = /* @__PURE__ */ Y("ZodNumberFormat", (e, a) => {
  sC.init(e, a), ay.init(e, a);
});
function Q0(e) {
  return i3(l4, e);
}
var s4 = /* @__PURE__ */ Y("ZodBoolean", (e, a) => {
  uC.init(e, a), st.init(e, a);
});
function $t(e) {
  return r3(s4, e);
}
var u4 = /* @__PURE__ */ Y("ZodNull", (e, a) => {
  cC.init(e, a), st.init(e, a);
});
function c4(e) {
  return o3(u4, e);
}
var f4 = /* @__PURE__ */ Y("ZodUnknown", (e, a) => {
  fC.init(e, a), st.init(e, a);
});
function K0() {
  return l3(f4);
}
var d4 = /* @__PURE__ */ Y("ZodNever", (e, a) => {
  dC.init(e, a), st.init(e, a);
});
function iy(e) {
  return s3(d4, e);
}
var h4 = /* @__PURE__ */ Y("ZodArray", (e, a) => {
  hC.init(e, a), st.init(e, a), e.element = a.element, e.min = (r, l) => e.check(Fs(r, l)), e.nonempty = (r) => e.check(Fs(1, r)), e.max = (r, l) => e.check(Kg(r, l)), e.length = (r, l) => e.check(Jg(r, l)), e.unwrap = () => e.element;
});
function Zn(e, a) {
  return b3(h4, e, a);
}
var ry = /* @__PURE__ */ Y("ZodObject", (e, a) => {
  pC.init(e, a), st.init(e, a), We(e, "shape", () => a.shape), e.keyof = () => gn(Object.keys(e._zod.def.shape)), e.catchall = (r) => e.clone({
    ...e._zod.def,
    catchall: r
  }), e.passthrough = () => e.clone({
    ...e._zod.def,
    catchall: K0()
  }), e.loose = () => e.clone({
    ...e._zod.def,
    catchall: K0()
  }), e.strict = () => e.clone({
    ...e._zod.def,
    catchall: iy()
  }), e.strip = () => e.clone({
    ...e._zod.def,
    catchall: void 0
  }), e.extend = (r) => DE(e, r), e.safeExtend = (r) => zE(e, r), e.merge = (r) => LE(e, r), e.pick = (r) => RE(e, r), e.omit = (r) => NE(e, r), e.partial = (...r) => HE(uy, e, r[0]), e.required = (...r) => jE(cy, e, r[0]);
});
function Pt(e, a) {
  return new ry({
    type: "object",
    shape: e ?? {},
    ...ge(a)
  });
}
function oy(e, a) {
  return new ry({
    type: "object",
    shape: e,
    catchall: iy(),
    ...ge(a)
  });
}
var ly = /* @__PURE__ */ Y("ZodUnion", (e, a) => {
  Wg.init(e, a), st.init(e, a), e.options = a.options;
});
function sy(e, a) {
  return new ly({
    type: "union",
    options: e,
    ...ge(a)
  });
}
var m4 = /* @__PURE__ */ Y("ZodDiscriminatedUnion", (e, a) => {
  ly.init(e, a), vC.init(e, a);
});
function p4(e, a, r) {
  return new m4({
    type: "union",
    options: a,
    discriminator: e,
    ...ge(r)
  });
}
var v4 = /* @__PURE__ */ Y("ZodIntersection", (e, a) => {
  gC.init(e, a), st.init(e, a);
});
function g4(e, a) {
  return new v4({
    type: "intersection",
    left: e,
    right: a
  });
}
var Ad = /* @__PURE__ */ Y("ZodEnum", (e, a) => {
  yC.init(e, a), st.init(e, a), e.enum = a.entries, e.options = Object.values(a.entries);
  const r = new Set(Object.keys(a.entries));
  e.extract = (l, s) => {
    const c = {};
    for (const d of l) if (r.has(d)) c[d] = a.entries[d];
    else throw new Error(`Key ${d} not found in enum`);
    return new Ad({
      ...a,
      checks: [],
      ...ge(s),
      entries: c
    });
  }, e.exclude = (l, s) => {
    const c = { ...a.entries };
    for (const d of l) if (r.has(d)) delete c[d];
    else throw new Error(`Key ${d} not found in enum`);
    return new Ad({
      ...a,
      checks: [],
      ...ge(s),
      entries: c
    });
  };
});
function gn(e, a) {
  return new Ad({
    type: "enum",
    entries: Array.isArray(e) ? Object.fromEntries(e.map((r) => [r, r])) : e,
    ...ge(a)
  });
}
var y4 = /* @__PURE__ */ Y("ZodLiteral", (e, a) => {
  bC.init(e, a), st.init(e, a), e.values = new Set(a.values), Object.defineProperty(e, "value", { get() {
    if (a.values.length > 1) throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
    return a.values[0];
  } });
});
function zi(e, a) {
  return new y4({
    type: "literal",
    values: Array.isArray(e) ? e : [e],
    ...ge(a)
  });
}
var b4 = /* @__PURE__ */ Y("ZodTransform", (e, a) => {
  _C.init(e, a), st.init(e, a), e._zod.parse = (r, l) => {
    if (l.direction === "backward") throw new zg(e.constructor.name);
    r.addIssue = (c) => {
      if (typeof c == "string") r.issues.push(Xo(c, r.value, a));
      else {
        const d = c;
        d.fatal && (d.continue = !1), d.code ?? (d.code = "custom"), d.input ?? (d.input = r.value), d.inst ?? (d.inst = e), r.issues.push(Xo(d));
      }
    };
    const s = a.transform(r.value, r);
    return s instanceof Promise ? s.then((c) => (r.value = c, r)) : (r.value = s, r);
  };
});
function _4(e) {
  return new b4({
    type: "transform",
    transform: e
  });
}
var uy = /* @__PURE__ */ Y("ZodOptional", (e, a) => {
  wC.init(e, a), st.init(e, a), e.unwrap = () => e._zod.def.innerType;
});
function J0(e) {
  return new uy({
    type: "optional",
    innerType: e
  });
}
var w4 = /* @__PURE__ */ Y("ZodNullable", (e, a) => {
  SC.init(e, a), st.init(e, a), e.unwrap = () => e._zod.def.innerType;
});
function e1(e) {
  return new w4({
    type: "nullable",
    innerType: e
  });
}
var S4 = /* @__PURE__ */ Y("ZodDefault", (e, a) => {
  EC.init(e, a), st.init(e, a), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function E4(e, a) {
  return new S4({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof a == "function" ? a() : Hg(a);
    }
  });
}
var T4 = /* @__PURE__ */ Y("ZodPrefault", (e, a) => {
  TC.init(e, a), st.init(e, a), e.unwrap = () => e._zod.def.innerType;
});
function C4(e, a) {
  return new T4({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof a == "function" ? a() : Hg(a);
    }
  });
}
var cy = /* @__PURE__ */ Y("ZodNonOptional", (e, a) => {
  CC.init(e, a), st.init(e, a), e.unwrap = () => e._zod.def.innerType;
});
function A4(e, a) {
  return new cy({
    type: "nonoptional",
    innerType: e,
    ...ge(a)
  });
}
var x4 = /* @__PURE__ */ Y("ZodCatch", (e, a) => {
  AC.init(e, a), st.init(e, a), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function O4(e, a) {
  return new x4({
    type: "catch",
    innerType: e,
    catchValue: typeof a == "function" ? a : () => a
  });
}
var M4 = /* @__PURE__ */ Y("ZodPipe", (e, a) => {
  xC.init(e, a), st.init(e, a), e.in = a.in, e.out = a.out;
});
function t1(e, a) {
  return new M4({
    type: "pipe",
    in: e,
    out: a
  });
}
var R4 = /* @__PURE__ */ Y("ZodReadonly", (e, a) => {
  OC.init(e, a), st.init(e, a), e.unwrap = () => e._zod.def.innerType;
});
function N4(e) {
  return new R4({
    type: "readonly",
    innerType: e
  });
}
var D4 = /* @__PURE__ */ Y("ZodCustom", (e, a) => {
  MC.init(e, a), st.init(e, a);
});
function z4(e, a = {}) {
  return _3(D4, e, a);
}
function L4(e) {
  return w3(e);
}
var fy = [
  "owner",
  "editor",
  "viewer"
];
function dy(e, a) {
  switch (a) {
    case "owner":
      return e === "owner";
    case "editor":
      return e === "owner" || e === "editor";
    case "viewer":
      return e === "owner" || e === "editor" || e === "viewer";
    default:
      return !1;
  }
}
var H4 = Pt({
  current_user_role: gn(fy).optional(),
  editor_invitation: Pt({
    granted_at: _t().nullable(),
    owner_name: _t().nullable()
  }).optional(),
  access_summary: p4("kind", [
    Pt({ kind: gn([
      "private",
      "public",
      "inviteOnly",
      "admins",
      "share",
      "manageAccess"
    ]) }),
    Pt({
      kind: zi("workspace"),
      workspace_name: _t().max(256).optional()
    }),
    Pt({
      kind: zi("people"),
      count: eh().int().min(2)
    })
  ]).optional().catch(void 0),
  hidden: $t(),
  remix_tooltip_hidden: $t().optional(),
  remix_enabled: $t().optional(),
  edit_context: Pt({
    codex_thread_id: _t().nullable(),
    chatgpt_conversation_id: _t().nullable()
  })
}), j4 = sy([Pt({ current_user_role: c4() }), H4]), th = "/_sites/dispatch-assets/app-openai.svg", B4 = "/_internal/sites_widget/log_event", U4 = "/_internal/sites_widget/editor/config", k4 = "/_internal/sites_widget/auth/start";
function P4(e) {
  return `sites-toolbar-auth-${e}`;
}
var hy = {};
function my(e) {
  hy = e;
}
function At(e, a) {
  const r = B4;
  fetch(a ? new URL(r, a) : r, {
    method: "POST",
    credentials: a ? "include" : "same-origin",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      interaction_type: e,
      ...e.startsWith("toolbar_") && hy
    }),
    keepalive: !0
  }).catch(() => {
  });
}
var qt = {
  editorWidgetCorner: "oai/sites-toolbar/corner",
  editorWidgetMobileAnchor: "oai/sites-toolbar/mobileAnchor",
  editorWidgetInteracted: "oai/sites-toolbar/interacted",
  editorWidgetHideHintSeen: "oai/sites-toolbar/hideHintSeen",
  remixTooltipSeen: "oai/sites-toolbar/remixTooltipSeen"
}, Ff = {
  parse: (e) => e === "true",
  serialize: (e) => String(e)
}, n1 = {
  [qt.editorWidgetCorner]: {
    parse: (e) => e === "top-left" || e === "top-right" || e === "bottom-left" || e === "bottom-right" || e === "bottom-center" ? e : "bottom-right",
    serialize: (e) => e
  },
  [qt.editorWidgetMobileAnchor]: {
    parse: (e) => e === "top-left" || e === "top-right" || e === "bottom-left" || e === "bottom-right" ? e : "bottom-center",
    serialize: (e) => e
  },
  [qt.editorWidgetInteracted]: Ff,
  [qt.editorWidgetHideHintSeen]: Ff,
  [qt.remixTooltipSeen]: Ff
};
function I4() {
  try {
    return localStorage;
  } catch {
    return null;
  }
}
function su(e = I4()) {
  return {
    read: (a) => {
      let r = null;
      try {
        r = e?.getItem(a) ?? null;
      } catch {
      }
      return n1[a].parse(r);
    },
    write: (a, r) => {
      try {
        e?.setItem(a, n1[a].serialize(r));
      } catch {
      }
    }
  };
}
async function Z4() {
  const e = await fetch(U4, {
    credentials: "same-origin",
    cache: "no-store",
    redirect: "error",
    signal: AbortSignal.timeout(1e4)
  });
  if (!e.ok) throw new Error("Unable to load editor widget configuration");
  const a = j4.parse(await e.json());
  return my({ site_user_role: a.current_user_role ?? void 0 }), a.current_user_role === null ? null : (su().read(qt.remixTooltipSeen) && (a.remix_tooltip_hidden = !0), a);
}
async function py(e) {
  try {
    if (!(await fetch("/_internal/sites_widget/editor/config", {
      method: "POST",
      credentials: "same-origin",
      redirect: "error",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(e),
      keepalive: !0,
      signal: AbortSignal.timeout(1e4)
    })).ok) throw new Error("Unable to save editor widget preference");
  } catch {
    console.warn("Unable to save editor widget preference");
  }
}
function G4() {
  return su().write(qt.remixTooltipSeen, !0), py({ remix_tooltip_hidden: !0 });
}
function nh() {
  let e = Promise.resolve();
  return (a) => (e = e.then(() => py({ hidden: a })), e);
}
var V4 = "_Button_wzun0_1", $4 = "_ButtonInner_wzun0_137", F4 = "_ButtonLoader_wzun0_154", Zo = {
  Button: V4,
  ButtonInner: $4,
  ButtonLoader: F4
};
function vy(e) {
  const a = e.currentTarget.offsetWidth;
  let r = 0.985;
  a <= 80 ? r = 0.96 : a <= 150 ? r = 0.97 : a <= 220 ? r = 0.98 : a > 600 && (r = 0.995), e.currentTarget.style.setProperty("--button-press-scale", String(r));
}
var q4 = "_LoadingIndicator_1mmfp_1", X4 = "_rotate_1mmfp_1", Y4 = {
  LoadingIndicator: q4,
  rotate: X4
}, W4 = /* @__PURE__ */ bn(((e) => {
  var a = /* @__PURE__ */ Symbol.for("react.transitional.element"), r = /* @__PURE__ */ Symbol.for("react.fragment");
  function l(s, c, d) {
    var h = null;
    if (d !== void 0 && (h = "" + d), c.key !== void 0 && (h = "" + c.key), "key" in c) {
      d = {};
      for (var m in c) m !== "key" && (d[m] = c[m]);
    } else d = c;
    return c = d.ref, {
      $$typeof: a,
      type: s,
      key: h,
      ref: c !== void 0 ? c : null,
      props: d
    };
  }
  e.Fragment = r, e.jsx = l, e.jsxs = l;
})), Q4 = /* @__PURE__ */ bn(((e, a) => {
  a.exports = W4();
})), g = Q4();
function Yo({ className: e, size: a }) {
  return /* @__PURE__ */ (0, g.jsx)("span", {
    "aria-hidden": "true",
    className: Be(Y4.LoadingIndicator, e),
    style: a === void 0 ? void 0 : { "--indicator-size": `${a}px` }
  });
}
function qs(e) {
  if (typeof window.requestAnimationFrame != "function" || document.visibilityState === "hidden") {
    const l = window.setTimeout(e);
    return () => window.clearTimeout(l);
  }
  let a = 2, r = window.requestAnimationFrame(function l() {
    a -= 1, a === 0 ? e() : r = window.requestAnimationFrame(l);
  });
  return () => window.cancelAnimationFrame(r);
}
function K4(e) {
  const a = {};
  for (const [r, l] of Object.entries(e))
    l !== void 0 && (a[r.startsWith("--") ? r : `--${r}`] = typeof l == "number" ? `${l}px` : l);
  return a;
}
var qf = (e) => String(e), Qn = (e) => `${e}ms`;
function Xf(e) {
  return typeof e == "number" ? `${e}deg` : e;
}
function Yf({ x: e, y: a, scale: r, rotate: l, skewX: s, skewY: c } = {}) {
  const d = [
    e == null ? null : `translateX(${e}px)`,
    a == null ? null : `translateY(${a}px)`,
    r == null ? null : `scale(${r})`,
    l == null ? null : `rotate(${Xf(l)})`,
    s == null ? null : `skewX(${Xf(s)})`,
    c == null ? null : `skewY(${Xf(c)})`
  ].filter(Boolean);
  return d.length ? d.join(" ") : "none";
}
function Wf({ blur: e } = {}) {
  return e == null ? "none" : `blur(${e}px)`;
}
function Rs(e) {
  const a = [];
  return b.Children.forEach(e, (r) => {
    r && typeof r == "object" && "key" in r && r.key && a.push(r);
  }), a;
}
var Cr = () => {
};
function Ar(e) {
  const a = (0, b.useRef)(e);
  return a.current = e, (0, b.useCallback)((r) => a.current(r), []);
}
function J4(e, a, r, l) {
  const s = new Set(e.map((m) => m.key)), c = new Set(a.map((m) => m.component.key)), d = e.filter((m) => !c.has(m.key)).map(r), h = a.map((m) => ({
    ...m,
    component: e.find(({ key: y }) => y === m.component.key) ?? m.component,
    shouldRender: s.has(m.component.key)
  }));
  return l === "append" ? h.concat(d) : d.concat(h);
}
var e9 = "_TransitionGroupChild_1d6a5_1", t9 = { TransitionGroupChild: e9 }, gy = {
  enter: !1,
  enterActive: !1,
  exit: !1,
  exitActive: !1,
  interrupted: !1
}, n9 = (e) => ({
  ...gy,
  enter: !e
});
function a9(e, a) {
  switch (a.type) {
    case "enter-before":
      return {
        enter: !0,
        enterActive: !1,
        exit: !1,
        exitActive: !1,
        interrupted: e.interrupted || e.exit
      };
    case "enter-active":
      return {
        enter: !0,
        enterActive: !0,
        exit: !1,
        exitActive: !1,
        interrupted: !1
      };
    case "exit-before":
      return {
        enter: !1,
        enterActive: !1,
        exit: !0,
        exitActive: !1,
        interrupted: e.interrupted || e.enter
      };
    case "exit-active":
      return {
        enter: !1,
        enterActive: !1,
        exit: !0,
        exitActive: !0,
        interrupted: !1
      };
    case "done":
      return gy;
  }
}
function i9({ as: e, children: a, className: r, style: l, preventMountTransition: s, shouldRender: c, enterDuration: d, exitDuration: h, removeChild: m, onEnter: y, onEnterActive: p, onEnterComplete: _, onExit: w, onExitActive: E, onExitComplete: x }) {
  const [C, T] = (0, b.useReducer)(a9, n9(s)), M = (0, b.useRef)(!1), D = (0, b.useRef)(null), j = (0, b.useRef)(d), H = (0, b.useRef)(h), k = (0, b.useRef)(null);
  j.current = d, H.current = h;
  const B = (0, b.useCallback)((Q) => {
    const K = D.current;
    !K || Q === k.current || (k.current = Q, {
      enter: y,
      "enter-active": p,
      "enter-complete": _,
      exit: w,
      "exit-active": E,
      "exit-complete": x
    }[Q](K));
  }, [
    y,
    p,
    _,
    w,
    E,
    x
  ]);
  return (0, b.useLayoutEffect)(() => {
    if (!c) {
      let q;
      T({ type: "exit-before" }), B("exit");
      const F = qs(() => {
        T({ type: "exit-active" }), B("exit-active"), q = window.setTimeout(() => {
          B("exit-complete"), m();
        }, H.current);
      });
      return () => {
        F(), q !== void 0 && window.clearTimeout(q);
      };
    }
    if (s && !M.current) {
      M.current = !0;
      return;
    }
    let Q;
    T({ type: "enter-before" }), B("enter");
    const K = qs(() => {
      T({ type: "enter-active" }), B("enter-active"), Q = window.setTimeout(() => {
        T({ type: "done" }), B("enter-complete");
      }, j.current);
    });
    return () => {
      K(), Q !== void 0 && window.clearTimeout(Q);
    };
  }, [
    s,
    m,
    c,
    B
  ]), (0, b.useEffect)(() => () => {
    M.current = !1;
  }, []), /* @__PURE__ */ (0, g.jsx)(e, {
    ref: D,
    className: Be(r, t9.TransitionGroupChild),
    style: l,
    "data-entering": C.enter ? "" : void 0,
    "data-entering-active": C.enterActive ? "" : void 0,
    "data-exiting": C.exit ? "" : void 0,
    "data-exiting-active": C.exitActive ? "" : void 0,
    "data-interrupted": C.interrupted ? "" : void 0,
    children: a
  });
}
function r9(e) {
  const a = e.preventMountTransition ? void 0 : e.enterMountDelay, [r, l] = (0, b.useState)(a === void 0);
  return (0, b.useEffect)(() => {
    if (r) return;
    const s = window.setTimeout(() => l(!0), a);
    return () => window.clearTimeout(s);
  }, [a, r]), r ? /* @__PURE__ */ (0, g.jsx)(i9, { ...e }) : null;
}
function Wo(e) {
  const { as: a = "span", children: r, className: l, style: s, enterDuration: c = 0, exitDuration: d = 0, enterMountDelay: h, preventInitialTransition: m = !0, insertMethod: y = "append", disableAnimations: p } = e, _ = Ar(e.onEnter ?? Cr), w = Ar(e.onEnterActive ?? Cr), E = Ar(e.onEnterComplete ?? Cr), x = Ar(e.onExit ?? Cr), C = Ar(e.onExitActive ?? Cr), T = Ar(e.onExitComplete ?? Cr);
  b.Children.forEach(r, (k) => {
    if (k && typeof k == "object" && !("key" in k && k.key)) throw new Error("Child elements of <TransitionGroup /> must include a key");
  });
  const M = (0, b.useCallback)((k) => ({
    component: k,
    shouldRender: !0,
    preventMountTransition: !1,
    removeChild: () => {
      j((B) => B.filter(({ component: Q }) => Q.key !== k.key));
    },
    onEnter: _,
    onEnterActive: w,
    onEnterComplete: E,
    onExit: x,
    onExitActive: C,
    onExitComplete: T
  }), [
    _,
    w,
    E,
    x,
    C,
    T
  ]), [D, j] = (0, b.useState)(() => Rs(r).map((k) => ({
    ...M(k),
    preventMountTransition: m
  })));
  if ((0, b.useLayoutEffect)(() => {
    j((k) => J4(Rs(r), k, M, y));
  }, [
    r,
    M,
    y
  ]), p) return Rs(r).map((k) => /* @__PURE__ */ (0, g.jsx)(a, {
    className: l,
    style: s,
    children: k
  }, k.key));
  const H = new Map(Rs(r).map((k) => [k.key, k]));
  return D.map(({ component: k, ...B }) => {
    const Q = H.get(k.key) ?? k;
    return /* @__PURE__ */ (0, g.jsx)(r9, {
      ...B,
      as: a,
      className: l,
      enterDuration: c,
      exitDuration: d,
      enterMountDelay: h,
      style: s,
      children: Q
    }, Q.key);
  });
}
function ft({ type: e = "button", color: a = "primary", variant: r = "solid", pill: l = !1, uniform: s = !1, size: c = "md", iconSize: d, children: h, className: m, disabled: y, loading: p = !1, onClick: _, onPointerEnter: w, ...E }) {
  const x = y || p, C = (0, b.useCallback)((M) => {
    x || _?.(M);
  }, [x, _]), T = (0, b.useCallback)((M) => {
    vy(M), w?.(M);
  }, [w]);
  return /* @__PURE__ */ (0, g.jsxs)("button", {
    ...E,
    type: e,
    className: Be(Zo.Button, m),
    "data-color": a,
    "data-variant": r,
    "data-pill": l ? "" : void 0,
    "data-uniform": s ? "" : void 0,
    "data-size": c,
    "data-icon-size": d,
    "data-disabled": y ? "" : void 0,
    "data-loading": p ? "" : void 0,
    disabled: x,
    "aria-disabled": x || void 0,
    "aria-busy": p || E["aria-busy"],
    onClick: C,
    onPointerEnter: T,
    children: [/* @__PURE__ */ (0, g.jsx)(Wo, {
      as: "span",
      className: Zo.ButtonLoader,
      enterDuration: 150,
      exitDuration: 150,
      disableAnimations: !1,
      children: p && /* @__PURE__ */ (0, g.jsx)(Yo, {}, "loader")
    }), /* @__PURE__ */ (0, g.jsx)("span", {
      className: Zo.ButtonInner,
      children: h
    })]
  });
}
function ah({ color: e = "primary", variant: a = "solid", pill: r = !1, uniform: l = !1, size: s = "md", iconSize: c, children: d, className: h, onPointerEnter: m, ...y }) {
  return /* @__PURE__ */ (0, g.jsx)("a", {
    ...y,
    className: Be(Zo.Button, h),
    "data-color": e,
    "data-variant": a,
    "data-pill": r ? "" : void 0,
    "data-uniform": l ? "" : void 0,
    "data-size": s,
    "data-icon-size": c,
    onPointerEnter: (p) => {
      vy(p), m?.(p);
    },
    children: /* @__PURE__ */ (0, g.jsx)("span", {
      className: Zo.ButtonInner,
      children: d
    })
  });
}
function o9(e, a) {
  const r = (0, b.useRef)(0), l = (0, b.useRef)(null), s = (0, b.useCallback)((c, d = "") => {
    c.style.height = "0px";
    const { scrollHeight: h, offsetHeight: m, offsetWidth: y, clientHeight: p } = c, _ = h + (m - p);
    c.style.height = `${_}px`, r.current < h && c.selectionEnd === d.length && (c.scrollTop = h), r.current = c.scrollHeight, l.current = y;
  }, []);
  (0, b.useLayoutEffect)(() => {
    const c = e.current;
    c !== null && s(c, a);
  }, [
    s,
    e,
    a
  ]), (0, b.useEffect)(() => {
    const c = e.current;
    if (c === null) return;
    const d = new ResizeObserver(() => {
      const h = c.offsetWidth;
      (l.current === null || h !== l.current) && s(c, c.value);
    });
    return d.observe(c), () => d.disconnect();
  }, [s, e]);
}
var l9 = typeof navigator < "u", s9 = l9 ? navigator.userAgent ?? "" : "";
function Xs() {
  return Iw(s9) || u9();
}
function u9() {
  return typeof navigator < "u" && navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1;
}
function c9() {
  return typeof navigator < "u" && /Mac|iPhone|iPad/.test(navigator.platform);
}
var f9 = () => {
  const e = (0, b.useRef)(!1), a = (0, b.useRef)(null);
  (0, b.useEffect)(() => () => {
    a.current !== null && clearTimeout(a.current);
  }, []);
  const r = (0, b.useCallback)(() => {
    a.current !== null && (clearTimeout(a.current), a.current = null);
  }, []), l = (0, b.useCallback)(() => {
    r(), a.current = setTimeout(() => {
      e.current = !1, a.current = null;
    }, 0);
  }, [r]), s = (0, b.useCallback)(() => {
    r(), e.current = !0;
  }, [r]), c = (0, b.useCallback)(() => {
    e.current = !0, l();
  }, [l]), d = (0, b.useCallback)((h) => {
    const m = "nativeEvent" in h ? h.nativeEvent : h;
    return m.isComposing || e.current || m.keyCode === 229;
  }, []);
  return {
    resetComposition: (0, b.useCallback)(() => {
      r(), e.current = !1;
    }, [r]),
    handleCompositionStart: s,
    handleCompositionEnd: c,
    isComposing: d
  };
};
function d9({ textareaRef: e, value: a, onChange: r, onKeyDown: l, onCompositionStart: s, onCompositionEnd: c, ...d }) {
  o9(e, a);
  const { handleCompositionStart: h, handleCompositionEnd: m, isComposing: y } = f9();
  return /* @__PURE__ */ (0, g.jsx)("textarea", {
    ...d,
    ref: e,
    rows: 1,
    value: a,
    onChange: r,
    onCompositionStart: (p) => {
      h(), s?.(p);
    },
    onCompositionEnd: (p) => {
      m(), c?.(p);
    },
    onKeyDown: (p) => {
      l?.(p), !(p.defaultPrevented || p.key !== "Enter" || p.shiftKey || y(p) || Xs()) && (p.preventDefault(), p.repeat || p.currentTarget.form?.requestSubmit());
    }
  });
}
var h9 = "_Image_1l1xj_1", m9 = { Image: h9 }, a1 = /* @__PURE__ */ new Set();
function ih({ src: e, className: a, draggable: r = !1, onLoad: l, onError: s, forceRenderAfterLoadFail: c = !1, ...d }) {
  const [h, m] = (0, b.useState)(() => e && a1.has(e)), [y, p] = (0, b.useState)(!1), _ = h || y && c;
  return !e || !c && y ? null : /* @__PURE__ */ (0, g.jsx)("img", {
    ...d,
    src: e,
    className: Be(m9.Image, a),
    onLoad: (w) => {
      m(!0), a1.add(e), l?.(w);
    },
    onError: (w) => {
      p(!0), s?.(w);
    },
    "data-loaded": _ ? "" : void 0,
    draggable: r
  });
}
var p9 = /* @__PURE__ */ bn(((e) => {
  var a = Gd();
  function r(y) {
    var p = "https://react.dev/errors/" + y;
    if (1 < arguments.length) {
      p += "?args[]=" + encodeURIComponent(arguments[1]);
      for (var _ = 2; _ < arguments.length; _++) p += "&args[]=" + encodeURIComponent(arguments[_]);
    }
    return "Minified React error #" + y + "; visit " + p + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  function l() {
  }
  var s = {
    d: {
      f: l,
      r: function() {
        throw Error(r(522));
      },
      D: l,
      C: l,
      L: l,
      m: l,
      X: l,
      S: l,
      M: l
    },
    p: 0,
    findDOMNode: null
  }, c = /* @__PURE__ */ Symbol.for("react.portal");
  function d(y, p, _) {
    var w = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: c,
      key: w == null ? null : "" + w,
      children: y,
      containerInfo: p,
      implementation: _
    };
  }
  var h = a.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
  function m(y, p) {
    if (y === "font") return "";
    if (typeof p == "string") return p === "use-credentials" ? p : "";
  }
  e.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = s, e.createPortal = function(y, p) {
    var _ = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!p || p.nodeType !== 1 && p.nodeType !== 9 && p.nodeType !== 11) throw Error(r(299));
    return d(y, p, null, _);
  }, e.flushSync = function(y) {
    var p = h.T, _ = s.p;
    try {
      if (h.T = null, s.p = 2, y) return y();
    } finally {
      h.T = p, s.p = _, s.d.f();
    }
  }, e.preconnect = function(y, p) {
    typeof y == "string" && (p ? (p = p.crossOrigin, p = typeof p == "string" ? p === "use-credentials" ? p : "" : void 0) : p = null, s.d.C(y, p));
  }, e.prefetchDNS = function(y) {
    typeof y == "string" && s.d.D(y);
  }, e.preinit = function(y, p) {
    if (typeof y == "string" && p && typeof p.as == "string") {
      var _ = p.as, w = m(_, p.crossOrigin), E = typeof p.integrity == "string" ? p.integrity : void 0, x = typeof p.fetchPriority == "string" ? p.fetchPriority : void 0;
      _ === "style" ? s.d.S(y, typeof p.precedence == "string" ? p.precedence : void 0, {
        crossOrigin: w,
        integrity: E,
        fetchPriority: x
      }) : _ === "script" && s.d.X(y, {
        crossOrigin: w,
        integrity: E,
        fetchPriority: x,
        nonce: typeof p.nonce == "string" ? p.nonce : void 0
      });
    }
  }, e.preinitModule = function(y, p) {
    if (typeof y == "string") if (typeof p == "object" && p !== null) {
      if (p.as == null || p.as === "script") {
        var _ = m(p.as, p.crossOrigin);
        s.d.M(y, {
          crossOrigin: _,
          integrity: typeof p.integrity == "string" ? p.integrity : void 0,
          nonce: typeof p.nonce == "string" ? p.nonce : void 0
        });
      }
    } else p ?? s.d.M(y);
  }, e.preload = function(y, p) {
    if (typeof y == "string" && typeof p == "object" && p !== null && typeof p.as == "string") {
      var _ = p.as, w = m(_, p.crossOrigin);
      s.d.L(y, _, {
        crossOrigin: w,
        integrity: typeof p.integrity == "string" ? p.integrity : void 0,
        nonce: typeof p.nonce == "string" ? p.nonce : void 0,
        type: typeof p.type == "string" ? p.type : void 0,
        fetchPriority: typeof p.fetchPriority == "string" ? p.fetchPriority : void 0,
        referrerPolicy: typeof p.referrerPolicy == "string" ? p.referrerPolicy : void 0,
        imageSrcSet: typeof p.imageSrcSet == "string" ? p.imageSrcSet : void 0,
        imageSizes: typeof p.imageSizes == "string" ? p.imageSizes : void 0,
        media: typeof p.media == "string" ? p.media : void 0
      });
    }
  }, e.preloadModule = function(y, p) {
    if (typeof y == "string") if (p) {
      var _ = m(p.as, p.crossOrigin);
      s.d.m(y, {
        as: typeof p.as == "string" && p.as !== "script" ? p.as : void 0,
        crossOrigin: _,
        integrity: typeof p.integrity == "string" ? p.integrity : void 0
      });
    } else s.d.m(y);
  }, e.requestFormReset = function(y) {
    s.d.r(y);
  }, e.unstable_batchedUpdates = function(y, p) {
    return y(p);
  }, e.useFormState = function(y, p, _) {
    return h.H.useFormState(y, p, _);
  }, e.useFormStatus = function() {
    return h.H.useHostTransitionStatus();
  }, e.version = "19.2.8";
})), yy = /* @__PURE__ */ bn(((e, a) => {
  function r() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r);
      } catch (l) {
        console.error(l);
      }
  }
  r(), a.exports = p9();
}));
function i1(e, a) {
  if (typeof e == "function") return e(a);
  e != null && (e.current = a);
}
function by(...e) {
  return (a) => {
    let r = !1;
    const l = e.map((s) => {
      const c = i1(s, a);
      return !r && typeof c == "function" && (r = !0), c;
    });
    if (r) return () => {
      for (let s = 0; s < l.length; s++) {
        const c = l[s];
        typeof c == "function" ? c() : i1(e[s], null);
      }
    };
  };
}
function rn(...e) {
  return b.useCallback(by(...e), e);
}
var al = b.forwardRef((e, a) => {
  const { children: r, ...l } = e, s = b.Children.toArray(r), c = s.find(v9);
  if (c) {
    const d = c.props.children, h = s.map((m) => m === c ? b.Children.count(d) > 1 ? b.Children.only(null) : b.isValidElement(d) ? d.props.children : null : m);
    return /* @__PURE__ */ (0, g.jsx)(xd, {
      ...l,
      ref: a,
      children: b.isValidElement(d) ? b.cloneElement(d, void 0, h) : null
    });
  }
  return /* @__PURE__ */ (0, g.jsx)(xd, {
    ...l,
    ref: a,
    children: r
  });
});
al.displayName = "Slot";
var xd = b.forwardRef((e, a) => {
  const { children: r, ...l } = e;
  if (b.isValidElement(r)) {
    const s = y9(r), c = g9(l, r.props);
    return r.type !== b.Fragment && (c.ref = a ? by(a, s) : s), b.cloneElement(r, c);
  }
  return b.Children.count(r) > 1 ? b.Children.only(null) : null;
});
xd.displayName = "SlotClone";
var _y = ({ children: e }) => /* @__PURE__ */ (0, g.jsx)(g.Fragment, { children: e });
function v9(e) {
  return b.isValidElement(e) && e.type === _y;
}
function g9(e, a) {
  const r = { ...a };
  for (const l in a) {
    const s = e[l], c = a[l];
    /^on[A-Z]/.test(l) ? s && c ? r[l] = (...d) => {
      c(...d), s(...d);
    } : s && (r[l] = s) : l === "style" ? r[l] = {
      ...s,
      ...c
    } : l === "className" && (r[l] = [s, c].filter(Boolean).join(" "));
  }
  return {
    ...e,
    ...r
  };
}
function y9(e) {
  let a = Object.getOwnPropertyDescriptor(e.props, "ref")?.get, r = a && "isReactWarning" in a && a.isReactWarning;
  return r ? e.ref : (a = Object.getOwnPropertyDescriptor(e, "ref")?.get, r = a && "isReactWarning" in a && a.isReactWarning, r ? e.props.ref : e.props.ref || e.ref);
}
var wy = al, Zr = /* @__PURE__ */ Zd(yy(), 1), Dt = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "span",
  "svg",
  "ul"
].reduce((e, a) => {
  const r = b.forwardRef((l, s) => {
    const { asChild: c, ...d } = l, h = c ? al : a;
    return typeof window < "u" && (window[/* @__PURE__ */ Symbol.for("radix-ui")] = !0), /* @__PURE__ */ (0, g.jsx)(h, {
      ...d,
      ref: s
    });
  });
  return r.displayName = `Primitive.${a}`, {
    ...e,
    [a]: r
  };
}, {});
function b9(e, a) {
  e && Zr.flushSync(() => e.dispatchEvent(a));
}
var _9 = "VisuallyHidden", Sy = b.forwardRef((e, a) => /* @__PURE__ */ (0, g.jsx)(Dt.span, {
  ...e,
  ref: a,
  style: {
    position: "absolute",
    border: 0,
    width: 1,
    height: 1,
    padding: 0,
    margin: -1,
    overflow: "hidden",
    clip: "rect(0, 0, 0, 0)",
    whiteSpace: "nowrap",
    wordWrap: "normal",
    ...e.style
  }
}));
Sy.displayName = _9;
var rh = Sy;
function w9(e, a) {
  const r = b.createContext(a), l = (c) => {
    const { children: d, ...h } = c, m = b.useMemo(() => h, Object.values(h));
    return /* @__PURE__ */ (0, g.jsx)(r.Provider, {
      value: m,
      children: d
    });
  };
  l.displayName = e + "Provider";
  function s(c) {
    const d = b.useContext(r);
    if (d) return d;
    if (a !== void 0) return a;
    throw new Error(`\`${c}\` must be used within \`${e}\``);
  }
  return [l, s];
}
function il(e, a = []) {
  let r = [];
  function l(c, d) {
    const h = b.createContext(d), m = r.length;
    r = [...r, d];
    const y = (_) => {
      const { scope: w, children: E, ...x } = _, C = w?.[e]?.[m] || h, T = b.useMemo(() => x, Object.values(x));
      return /* @__PURE__ */ (0, g.jsx)(C.Provider, {
        value: T,
        children: E
      });
    };
    y.displayName = c + "Provider";
    function p(_, w) {
      const E = w?.[e]?.[m] || h, x = b.useContext(E);
      if (x) return x;
      if (d !== void 0) return d;
      throw new Error(`\`${_}\` must be used within \`${c}\``);
    }
    return [y, p];
  }
  const s = () => {
    const c = r.map((d) => b.createContext(d));
    return function(h) {
      const m = h?.[e] || c;
      return b.useMemo(() => ({ [`__scope${e}`]: {
        ...h,
        [e]: m
      } }), [h, m]);
    };
  };
  return s.scopeName = e, [l, S9(s, ...a)];
}
function S9(...e) {
  const a = e[0];
  if (e.length === 1) return a;
  const r = () => {
    const l = e.map((s) => ({
      useScope: s(),
      scopeName: s.scopeName
    }));
    return function(c) {
      const d = l.reduce((h, { useScope: m, scopeName: y }) => {
        const p = m(c)[`__scope${y}`];
        return {
          ...h,
          ...p
        };
      }, {});
      return b.useMemo(() => ({ [`__scope${a.scopeName}`]: d }), [d]);
    };
  };
  return r.scopeName = a.scopeName, r;
}
function wt(e, a, { checkForDefaultPrevented: r = !0 } = {}) {
  return function(s) {
    if (e?.(s), r === !1 || !s.defaultPrevented) return a?.(s);
  };
}
function ei(e) {
  const a = b.useRef(e);
  return b.useEffect(() => {
    a.current = e;
  }), b.useMemo(() => (...r) => a.current?.(...r), []);
}
function uu({ prop: e, defaultProp: a, onChange: r = () => {
} }) {
  const [l, s] = E9({
    defaultProp: a,
    onChange: r
  }), c = e !== void 0, d = c ? e : l, h = ei(r);
  return [d, b.useCallback((m) => {
    if (c) {
      const y = typeof m == "function" ? m(e) : m;
      y !== e && h(y);
    } else s(m);
  }, [
    c,
    e,
    s,
    h
  ])];
}
function E9({ defaultProp: e, onChange: a }) {
  const r = b.useState(e), [l] = r, s = b.useRef(l), c = ei(a);
  return b.useEffect(() => {
    s.current !== l && (c(l), s.current = l);
  }, [
    l,
    s,
    c
  ]), r;
}
var Li = globalThis?.document ? b.useLayoutEffect : () => {
};
function T9(e, a) {
  return b.useReducer((r, l) => a[r][l] ?? r, e);
}
var oi = (e) => {
  const { present: a, children: r } = e, l = C9(a), s = typeof r == "function" ? r({ present: l.isPresent }) : b.Children.only(r), c = rn(l.ref, A9(s));
  return typeof r == "function" || l.isPresent ? b.cloneElement(s, { ref: c }) : null;
};
oi.displayName = "Presence";
function C9(e) {
  const [a, r] = b.useState(), l = b.useRef({}), s = b.useRef(e), c = b.useRef("none"), [d, h] = T9(e ? "mounted" : "unmounted", {
    mounted: {
      UNMOUNT: "unmounted",
      ANIMATION_OUT: "unmountSuspended"
    },
    unmountSuspended: {
      MOUNT: "mounted",
      ANIMATION_END: "unmounted"
    },
    unmounted: { MOUNT: "mounted" }
  });
  return b.useEffect(() => {
    const m = Ns(l.current);
    c.current = d === "mounted" ? m : "none";
  }, [d]), Li(() => {
    const m = l.current, y = s.current;
    if (y !== e) {
      const p = c.current, _ = Ns(m);
      e ? h("MOUNT") : _ === "none" || m?.display === "none" ? h("UNMOUNT") : h(y && p !== _ ? "ANIMATION_OUT" : "UNMOUNT"), s.current = e;
    }
  }, [e, h]), Li(() => {
    if (a) {
      let m;
      const y = a.ownerDocument.defaultView ?? window, p = (w) => {
        const E = Ns(l.current).includes(w.animationName);
        if (w.target === a && E && (h("ANIMATION_END"), !s.current)) {
          const x = a.style.animationFillMode;
          a.style.animationFillMode = "forwards", m = y.setTimeout(() => {
            a.style.animationFillMode === "forwards" && (a.style.animationFillMode = x);
          });
        }
      }, _ = (w) => {
        w.target === a && (c.current = Ns(l.current));
      };
      return a.addEventListener("animationstart", _), a.addEventListener("animationcancel", p), a.addEventListener("animationend", p), () => {
        y.clearTimeout(m), a.removeEventListener("animationstart", _), a.removeEventListener("animationcancel", p), a.removeEventListener("animationend", p);
      };
    } else h("ANIMATION_END");
  }, [a, h]), {
    isPresent: ["mounted", "unmountSuspended"].includes(d),
    ref: b.useCallback((m) => {
      m && (l.current = getComputedStyle(m)), r(m);
    }, [])
  };
}
function Ns(e) {
  return e?.animationName || "none";
}
function A9(e) {
  let a = Object.getOwnPropertyDescriptor(e.props, "ref")?.get, r = a && "isReactWarning" in a && a.isReactWarning;
  return r ? e.ref : (a = Object.getOwnPropertyDescriptor(e, "ref")?.get, r = a && "isReactWarning" in a && a.isReactWarning, r ? e.props.ref : e.props.ref || e.ref);
}
var x9 = b.useId || (() => {
}), O9 = 0;
function Go(e) {
  const [a, r] = b.useState(x9());
  return Li(() => {
    e || r((l) => l ?? String(O9++));
  }, [e]), e || (a ? `radix-${a}` : "");
}
function M9(e, a = globalThis?.document) {
  const r = ei(e);
  b.useEffect(() => {
    const l = (s) => {
      s.key === "Escape" && r(s);
    };
    return a.addEventListener("keydown", l, { capture: !0 }), () => a.removeEventListener("keydown", l, { capture: !0 });
  }, [r, a]);
}
var R9 = "DismissableLayer", Od = "dismissableLayer.update", N9 = "dismissableLayer.pointerDownOutside", D9 = "dismissableLayer.focusOutside", r1, Ey = b.createContext({
  layers: /* @__PURE__ */ new Set(),
  layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
  branches: /* @__PURE__ */ new Set()
}), cu = b.forwardRef((e, a) => {
  const { disableOutsidePointerEvents: r = !1, onEscapeKeyDown: l, onPointerDownOutside: s, onFocusOutside: c, onInteractOutside: d, onDismiss: h, ...m } = e, y = b.useContext(Ey), [p, _] = b.useState(null), w = p?.ownerDocument ?? globalThis?.document, [, E] = b.useState({}), x = rn(a, (Q) => _(Q)), C = Array.from(y.layers), [T] = [...y.layersWithOutsidePointerEventsDisabled].slice(-1), M = C.indexOf(T), D = p ? C.indexOf(p) : -1, j = y.layersWithOutsidePointerEventsDisabled.size > 0, H = D >= M, k = H9((Q) => {
    const K = Q.target, q = [...y.branches].some((F) => F.contains(K));
    !H || q || (s?.(Q), d?.(Q), Q.defaultPrevented || h?.());
  }, w), B = j9((Q) => {
    const K = Q.target;
    [...y.branches].some((q) => q.contains(K)) || (c?.(Q), d?.(Q), Q.defaultPrevented || h?.());
  }, w);
  return M9((Q) => {
    D === y.layers.size - 1 && (l?.(Q), !Q.defaultPrevented && h && (Q.preventDefault(), h()));
  }, w), b.useEffect(() => {
    if (p)
      return r && (y.layersWithOutsidePointerEventsDisabled.size === 0 && (r1 = w.body.style.pointerEvents, w.body.style.pointerEvents = "none"), y.layersWithOutsidePointerEventsDisabled.add(p)), y.layers.add(p), o1(), () => {
        r && y.layersWithOutsidePointerEventsDisabled.size === 1 && (w.body.style.pointerEvents = r1);
      };
  }, [
    p,
    w,
    r,
    y
  ]), b.useEffect(() => () => {
    p && (y.layers.delete(p), y.layersWithOutsidePointerEventsDisabled.delete(p), o1());
  }, [p, y]), b.useEffect(() => {
    const Q = () => E({});
    return document.addEventListener(Od, Q), () => document.removeEventListener(Od, Q);
  }, []), /* @__PURE__ */ (0, g.jsx)(Dt.div, {
    ...m,
    ref: x,
    style: {
      pointerEvents: j ? H ? "auto" : "none" : void 0,
      ...e.style
    },
    onFocusCapture: wt(e.onFocusCapture, B.onFocusCapture),
    onBlurCapture: wt(e.onBlurCapture, B.onBlurCapture),
    onPointerDownCapture: wt(e.onPointerDownCapture, k.onPointerDownCapture)
  });
});
cu.displayName = R9;
var z9 = "DismissableLayerBranch", L9 = b.forwardRef((e, a) => {
  const r = b.useContext(Ey), l = b.useRef(null), s = rn(a, l);
  return b.useEffect(() => {
    const c = l.current;
    if (c)
      return r.branches.add(c), () => {
        r.branches.delete(c);
      };
  }, [r.branches]), /* @__PURE__ */ (0, g.jsx)(Dt.div, {
    ...e,
    ref: s
  });
});
L9.displayName = z9;
function H9(e, a = globalThis?.document) {
  const r = ei(e), l = b.useRef(!1), s = b.useRef(() => {
  });
  return b.useEffect(() => {
    const c = (h) => {
      if (h.target && !l.current) {
        let m = function() {
          Ty(N9, r, y, { discrete: !0 });
        };
        const y = { originalEvent: h };
        h.pointerType === "touch" ? (a.removeEventListener("click", s.current), s.current = m, a.addEventListener("click", s.current, { once: !0 })) : m();
      } else a.removeEventListener("click", s.current);
      l.current = !1;
    }, d = window.setTimeout(() => {
      a.addEventListener("pointerdown", c);
    }, 0);
    return () => {
      window.clearTimeout(d), a.removeEventListener("pointerdown", c), a.removeEventListener("click", s.current);
    };
  }, [a, r]), { onPointerDownCapture: () => l.current = !0 };
}
function j9(e, a = globalThis?.document) {
  const r = ei(e), l = b.useRef(!1);
  return b.useEffect(() => {
    const s = (c) => {
      c.target && !l.current && Ty(D9, r, { originalEvent: c }, { discrete: !1 });
    };
    return a.addEventListener("focusin", s), () => a.removeEventListener("focusin", s);
  }, [a, r]), {
    onFocusCapture: () => l.current = !0,
    onBlurCapture: () => l.current = !1
  };
}
function o1() {
  const e = new CustomEvent(Od);
  document.dispatchEvent(e);
}
function Ty(e, a, r, { discrete: l }) {
  const s = r.originalEvent.target, c = new CustomEvent(e, {
    bubbles: !1,
    cancelable: !0,
    detail: r
  });
  a && s.addEventListener(e, a, { once: !0 }), l ? b9(s, c) : s.dispatchEvent(c);
}
var Qf = "focusScope.autoFocusOnMount", Kf = "focusScope.autoFocusOnUnmount", l1 = {
  bubbles: !1,
  cancelable: !0
}, B9 = "FocusScope", oh = b.forwardRef((e, a) => {
  const { loop: r = !1, trapped: l = !1, onMountAutoFocus: s, onUnmountAutoFocus: c, ...d } = e, [h, m] = b.useState(null), y = ei(s), p = ei(c), _ = b.useRef(null), w = rn(a, (C) => m(C)), E = b.useRef({
    paused: !1,
    pause() {
      this.paused = !0;
    },
    resume() {
      this.paused = !1;
    }
  }).current;
  b.useEffect(() => {
    if (l) {
      let C = function(j) {
        if (E.paused || !h) return;
        const H = j.target;
        h.contains(H) ? _.current = H : Ka(_.current, { select: !0 });
      }, T = function(j) {
        if (E.paused || !h) return;
        const H = j.relatedTarget;
        H !== null && (h.contains(H) || Ka(_.current, { select: !0 }));
      }, M = function(j) {
        if (document.activeElement === document.body)
          for (const H of j) H.removedNodes.length > 0 && Ka(h);
      };
      document.addEventListener("focusin", C), document.addEventListener("focusout", T);
      const D = new MutationObserver(M);
      return h && D.observe(h, {
        childList: !0,
        subtree: !0
      }), () => {
        document.removeEventListener("focusin", C), document.removeEventListener("focusout", T), D.disconnect();
      };
    }
  }, [
    l,
    h,
    E.paused
  ]), b.useEffect(() => {
    if (h) {
      u1.add(E);
      const C = document.activeElement;
      if (!h.contains(C)) {
        const T = new CustomEvent(Qf, l1);
        h.addEventListener(Qf, y), h.dispatchEvent(T), T.defaultPrevented || (U9(G9(Cy(h)), { select: !0 }), document.activeElement === C && Ka(h));
      }
      return () => {
        h.removeEventListener(Qf, y), setTimeout(() => {
          const T = new CustomEvent(Kf, l1);
          h.addEventListener(Kf, p), h.dispatchEvent(T), T.defaultPrevented || Ka(C ?? document.body, { select: !0 }), h.removeEventListener(Kf, p), u1.remove(E);
        }, 0);
      };
    }
  }, [
    h,
    y,
    p,
    E
  ]);
  const x = b.useCallback((C) => {
    if (!r && !l || E.paused) return;
    const T = C.key === "Tab" && !C.altKey && !C.ctrlKey && !C.metaKey, M = document.activeElement;
    if (T && M) {
      const D = C.currentTarget, [j, H] = k9(D);
      j && H ? !C.shiftKey && M === H ? (C.preventDefault(), r && Ka(j, { select: !0 })) : C.shiftKey && M === j && (C.preventDefault(), r && Ka(H, { select: !0 })) : M === D && C.preventDefault();
    }
  }, [
    r,
    l,
    E.paused
  ]);
  return /* @__PURE__ */ (0, g.jsx)(Dt.div, {
    tabIndex: -1,
    ...d,
    ref: w,
    onKeyDown: x
  });
});
oh.displayName = B9;
function U9(e, { select: a = !1 } = {}) {
  const r = document.activeElement;
  for (const l of e)
    if (Ka(l, { select: a }), document.activeElement !== r) return;
}
function k9(e) {
  const a = Cy(e);
  return [s1(a, e), s1(a.reverse(), e)];
}
function Cy(e) {
  const a = [], r = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, { acceptNode: (l) => {
    const s = l.tagName === "INPUT" && l.type === "hidden";
    return l.disabled || l.hidden || s ? NodeFilter.FILTER_SKIP : l.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
  } });
  for (; r.nextNode(); ) a.push(r.currentNode);
  return a;
}
function s1(e, a) {
  for (const r of e) if (!P9(r, { upTo: a })) return r;
}
function P9(e, { upTo: a }) {
  if (getComputedStyle(e).visibility === "hidden") return !0;
  for (; e; ) {
    if (a !== void 0 && e === a) return !1;
    if (getComputedStyle(e).display === "none") return !0;
    e = e.parentElement;
  }
  return !1;
}
function I9(e) {
  return e instanceof HTMLInputElement && "select" in e;
}
function Ka(e, { select: a = !1 } = {}) {
  if (e && e.focus) {
    const r = document.activeElement;
    e.focus({ preventScroll: !0 }), e !== r && I9(e) && a && e.select();
  }
}
var u1 = Z9();
function Z9() {
  let e = [];
  return {
    add(a) {
      const r = e[0];
      a !== r && r?.pause(), e = c1(e, a), e.unshift(a);
    },
    remove(a) {
      e = c1(e, a), e[0]?.resume();
    }
  };
}
function c1(e, a) {
  const r = [...e], l = r.indexOf(a);
  return l !== -1 && r.splice(l, 1), r;
}
function G9(e) {
  return e.filter((a) => a.tagName !== "A");
}
var V9 = "Portal", fu = b.forwardRef((e, a) => {
  const { container: r, ...l } = e, [s, c] = b.useState(!1);
  Li(() => c(!0), []);
  const d = r || s && globalThis?.document?.body;
  return d ? Zr.createPortal(/* @__PURE__ */ (0, g.jsx)(Dt.div, {
    ...l,
    ref: a
  }), d) : null;
});
fu.displayName = V9;
var Jf = 0;
function Ay() {
  b.useEffect(() => {
    const e = document.querySelectorAll("[data-radix-focus-guard]");
    return document.body.insertAdjacentElement("afterbegin", e[0] ?? f1()), document.body.insertAdjacentElement("beforeend", e[1] ?? f1()), Jf++, () => {
      Jf === 1 && document.querySelectorAll("[data-radix-focus-guard]").forEach((a) => a.remove()), Jf--;
    };
  }, []);
}
function f1() {
  const e = document.createElement("span");
  return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.outline = "none", e.style.opacity = "0", e.style.position = "fixed", e.style.pointerEvents = "none", e;
}
var Ps = "right-scroll-bar-position", Is = "width-before-scroll-bar", $9 = "with-scroll-bars-hidden", F9 = "--removed-body-scroll-bar-size";
function ed(e, a) {
  return typeof e == "function" ? e(a) : e && (e.current = a), e;
}
function q9(e, a) {
  var r = (0, b.useState)(function() {
    return {
      value: e,
      callback: a,
      facade: {
        get current() {
          return r.value;
        },
        set current(l) {
          var s = r.value;
          s !== l && (r.value = l, r.callback(l, s));
        }
      }
    };
  })[0];
  return r.callback = a, r.facade;
}
var X9 = typeof window < "u" ? b.useLayoutEffect : b.useEffect, d1 = /* @__PURE__ */ new WeakMap();
function Y9(e, a) {
  var r = q9(a || null, function(l) {
    return e.forEach(function(s) {
      return ed(s, l);
    });
  });
  return X9(function() {
    var l = d1.get(r);
    if (l) {
      var s = new Set(l), c = new Set(e), d = r.current;
      s.forEach(function(h) {
        c.has(h) || ed(h, null);
      }), c.forEach(function(h) {
        s.has(h) || ed(h, d);
      });
    }
    d1.set(r, e);
  }, [e]), r;
}
function W9(e) {
  return e;
}
function Q9(e, a) {
  a === void 0 && (a = W9);
  var r = [], l = !1;
  return {
    read: function() {
      if (l) throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      return r.length ? r[r.length - 1] : e;
    },
    useMedium: function(s) {
      var c = a(s, l);
      return r.push(c), function() {
        r = r.filter(function(d) {
          return d !== c;
        });
      };
    },
    assignSyncMedium: function(s) {
      for (l = !0; r.length; ) {
        var c = r;
        r = [], c.forEach(s);
      }
      r = {
        push: function(d) {
          return s(d);
        },
        filter: function() {
          return r;
        }
      };
    },
    assignMedium: function(s) {
      l = !0;
      var c = [];
      if (r.length) {
        var d = r;
        r = [], d.forEach(s), c = r;
      }
      var h = function() {
        var y = c;
        c = [], y.forEach(s);
      }, m = function() {
        return Promise.resolve().then(h);
      };
      m(), r = {
        push: function(y) {
          c.push(y), m();
        },
        filter: function(y) {
          return c = c.filter(y), r;
        }
      };
    }
  };
}
function K9(e) {
  e === void 0 && (e = {});
  var a = Q9(null);
  return a.options = de({
    async: !0,
    ssr: !1
  }, e), a;
}
var xy = function(e) {
  var a = e.sideCar, r = Ca(e, ["sideCar"]);
  if (!a) throw new Error("Sidecar: please provide `sideCar` property to import the right car");
  var l = a.read();
  if (!l) throw new Error("Sidecar medium not found");
  return b.createElement(l, de({}, r));
};
xy.isSideCarExport = !0;
function J9(e, a) {
  return e.useMedium(a), xy;
}
var Oy = K9(), td = function() {
}, du = b.forwardRef(function(e, a) {
  var r = b.useRef(null), l = b.useState({
    onScrollCapture: td,
    onWheelCapture: td,
    onTouchMoveCapture: td
  }), s = l[0], c = l[1], d = e.forwardProps, h = e.children, m = e.className, y = e.removeScrollBar, p = e.enabled, _ = e.shards, w = e.sideCar, E = e.noIsolation, x = e.inert, C = e.allowPinchZoom, T = e.as, M = T === void 0 ? "div" : T, D = e.gapMode, j = Ca(e, [
    "forwardProps",
    "children",
    "className",
    "removeScrollBar",
    "enabled",
    "shards",
    "sideCar",
    "noIsolation",
    "inert",
    "allowPinchZoom",
    "as",
    "gapMode"
  ]), H = w, k = Y9([r, a]), B = de(de({}, j), s);
  return b.createElement(b.Fragment, null, p && b.createElement(H, {
    sideCar: Oy,
    removeScrollBar: y,
    shards: _,
    noIsolation: E,
    inert: x,
    setCallbacks: c,
    allowPinchZoom: !!C,
    lockRef: r,
    gapMode: D
  }), d ? b.cloneElement(b.Children.only(h), de(de({}, B), { ref: k })) : b.createElement(M, de({}, B, {
    className: m,
    ref: k
  }), h));
});
du.defaultProps = {
  enabled: !0,
  removeScrollBar: !0,
  inert: !1
};
du.classNames = {
  fullWidth: Is,
  zeroRight: Ps
};
var h1, eA = function() {
  if (h1) return h1;
  if (typeof __webpack_nonce__ < "u") return __webpack_nonce__;
};
function tA() {
  if (!document) return null;
  var e = document.createElement("style");
  e.type = "text/css";
  var a = eA();
  return a && e.setAttribute("nonce", a), e;
}
function nA(e, a) {
  e.styleSheet ? e.styleSheet.cssText = a : e.appendChild(document.createTextNode(a));
}
function aA(e) {
  (document.head || document.getElementsByTagName("head")[0]).appendChild(e);
}
var iA = function() {
  var e = 0, a = null;
  return {
    add: function(r) {
      e == 0 && (a = tA()) && (nA(a, r), aA(a)), e++;
    },
    remove: function() {
      e--, !e && a && (a.parentNode && a.parentNode.removeChild(a), a = null);
    }
  };
}, rA = function() {
  var e = iA();
  return function(a, r) {
    b.useEffect(function() {
      return e.add(a), function() {
        e.remove();
      };
    }, [a && r]);
  };
}, My = function() {
  var e = rA(), a = function(r) {
    var l = r.styles, s = r.dynamic;
    return e(l, s), null;
  };
  return a;
}, oA = {
  left: 0,
  top: 0,
  right: 0,
  gap: 0
}, nd = function(e) {
  return parseInt(e || "", 10) || 0;
}, lA = function(e) {
  var a = window.getComputedStyle(document.body), r = a[e === "padding" ? "paddingLeft" : "marginLeft"], l = a[e === "padding" ? "paddingTop" : "marginTop"], s = a[e === "padding" ? "paddingRight" : "marginRight"];
  return [
    nd(r),
    nd(l),
    nd(s)
  ];
}, sA = function(e) {
  if (e === void 0 && (e = "margin"), typeof window > "u") return oA;
  var a = lA(e), r = document.documentElement.clientWidth, l = window.innerWidth;
  return {
    left: a[0],
    top: a[1],
    right: a[2],
    gap: Math.max(0, l - r + a[2] - a[0])
  };
}, uA = My(), Vo = "data-scroll-locked", cA = function(e, a, r, l) {
  var s = e.left, c = e.top, d = e.right, h = e.gap;
  return r === void 0 && (r = "margin"), `
  .`.concat($9, ` {
   overflow: hidden `).concat(l, `;
   padding-right: `).concat(h, "px ").concat(l, `;
  }
  body[`).concat(Vo, `] {
    overflow: hidden `).concat(l, `;
    overscroll-behavior: contain;
    `).concat([
    a && "position: relative ".concat(l, ";"),
    r === "margin" && `
    padding-left: `.concat(s, `px;
    padding-top: `).concat(c, `px;
    padding-right: `).concat(d, `px;
    margin-left:0;
    margin-top:0;
    margin-right: `).concat(h, "px ").concat(l, `;
    `),
    r === "padding" && "padding-right: ".concat(h, "px ").concat(l, ";")
  ].filter(Boolean).join(""), `
  }
  
  .`).concat(Ps, ` {
    right: `).concat(h, "px ").concat(l, `;
  }
  
  .`).concat(Is, ` {
    margin-right: `).concat(h, "px ").concat(l, `;
  }
  
  .`).concat(Ps, " .").concat(Ps, ` {
    right: 0 `).concat(l, `;
  }
  
  .`).concat(Is, " .").concat(Is, ` {
    margin-right: 0 `).concat(l, `;
  }
  
  body[`).concat(Vo, `] {
    `).concat(F9, ": ").concat(h, `px;
  }
`);
}, m1 = function() {
  var e = parseInt(document.body.getAttribute("data-scroll-locked") || "0", 10);
  return isFinite(e) ? e : 0;
}, fA = function() {
  b.useEffect(function() {
    return document.body.setAttribute(Vo, (m1() + 1).toString()), function() {
      var e = m1() - 1;
      e <= 0 ? document.body.removeAttribute(Vo) : document.body.setAttribute(Vo, e.toString());
    };
  }, []);
}, dA = function(e) {
  var a = e.noRelative, r = e.noImportant, l = e.gapMode, s = l === void 0 ? "margin" : l;
  fA();
  var c = b.useMemo(function() {
    return sA(s);
  }, [s]);
  return b.createElement(uA, { styles: cA(c, !a, s, r ? "" : "!important") });
}, Md = !1;
if (typeof window < "u") try {
  var Ds = Object.defineProperty({}, "passive", { get: function() {
    return Md = !0, !0;
  } });
  window.addEventListener("test", Ds, Ds), window.removeEventListener("test", Ds, Ds);
} catch {
  Md = !1;
}
var xr = Md ? { passive: !1 } : !1, hA = function(e) {
  return e.tagName === "TEXTAREA";
}, Ry = function(e, a) {
  if (!(e instanceof Element)) return !1;
  var r = window.getComputedStyle(e);
  return r[a] !== "hidden" && !(r.overflowY === r.overflowX && !hA(e) && r[a] === "visible");
}, mA = function(e) {
  return Ry(e, "overflowY");
}, pA = function(e) {
  return Ry(e, "overflowX");
}, p1 = function(e, a) {
  var r = a.ownerDocument, l = a;
  do {
    if (typeof ShadowRoot < "u" && l instanceof ShadowRoot && (l = l.host), Ny(e, l)) {
      var s = Dy(e, l);
      if (s[1] > s[2]) return !0;
    }
    l = l.parentNode;
  } while (l && l !== r.body);
  return !1;
}, vA = function(e) {
  return [
    e.scrollTop,
    e.scrollHeight,
    e.clientHeight
  ];
}, gA = function(e) {
  return [
    e.scrollLeft,
    e.scrollWidth,
    e.clientWidth
  ];
}, Ny = function(e, a) {
  return e === "v" ? mA(a) : pA(a);
}, Dy = function(e, a) {
  return e === "v" ? vA(a) : gA(a);
}, yA = function(e, a) {
  return e === "h" && a === "rtl" ? -1 : 1;
}, bA = function(e, a, r, l, s) {
  var c = yA(e, window.getComputedStyle(a).direction), d = c * l, h = r.target, m = a.contains(h), y = !1, p = d > 0, _ = 0, w = 0;
  do {
    var E = Dy(e, h), x = E[0], C = E[1] - E[2] - c * x;
    (x || C) && Ny(e, h) && (_ += C, w += x), h instanceof ShadowRoot ? h = h.host : h = h.parentNode;
  } while (!m && h !== document.body || m && (a.contains(h) || a === h));
  return (p && (s && Math.abs(_) < 1 || !s && d > _) || !p && (s && Math.abs(w) < 1 || !s && -d > w)) && (y = !0), y;
}, zs = function(e) {
  return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, v1 = function(e) {
  return [e.deltaX, e.deltaY];
}, g1 = function(e) {
  return e && "current" in e ? e.current : e;
}, _A = function(e, a) {
  return e[0] === a[0] && e[1] === a[1];
}, wA = function(e) {
  return `
  .block-interactivity-`.concat(e, ` {pointer-events: none;}
  .allow-interactivity-`).concat(e, ` {pointer-events: all;}
`);
}, SA = 0, Or = [];
function EA(e) {
  var a = b.useRef([]), r = b.useRef([0, 0]), l = b.useRef(), s = b.useState(SA++)[0], c = b.useState(My)[0], d = b.useRef(e);
  b.useEffect(function() {
    d.current = e;
  }, [e]), b.useEffect(function() {
    if (e.inert) {
      document.body.classList.add("block-interactivity-".concat(s));
      var C = Gn([e.lockRef.current], (e.shards || []).map(g1), !0).filter(Boolean);
      return C.forEach(function(T) {
        return T.classList.add("allow-interactivity-".concat(s));
      }), function() {
        document.body.classList.remove("block-interactivity-".concat(s)), C.forEach(function(T) {
          return T.classList.remove("allow-interactivity-".concat(s));
        });
      };
    }
  }, [
    e.inert,
    e.lockRef.current,
    e.shards
  ]);
  var h = b.useCallback(function(C, T) {
    if ("touches" in C && C.touches.length === 2 || C.type === "wheel" && C.ctrlKey) return !d.current.allowPinchZoom;
    var M = zs(C), D = r.current, j = "deltaX" in C ? C.deltaX : D[0] - M[0], H = "deltaY" in C ? C.deltaY : D[1] - M[1], k, B = C.target, Q = Math.abs(j) > Math.abs(H) ? "h" : "v";
    if ("touches" in C && Q === "h" && B.type === "range") return !1;
    var K = p1(Q, B);
    if (!K) return !0;
    if (K ? k = Q : (k = Q === "v" ? "h" : "v", K = p1(Q, B)), !K) return !1;
    if (!l.current && "changedTouches" in C && (j || H) && (l.current = k), !k) return !0;
    var q = l.current || k;
    return bA(q, T, C, q === "h" ? j : H, !0);
  }, []), m = b.useCallback(function(C) {
    var T = C;
    if (!(!Or.length || Or[Or.length - 1] !== c)) {
      var M = "deltaY" in T ? v1(T) : zs(T), D = a.current.filter(function(H) {
        return H.name === T.type && (H.target === T.target || T.target === H.shadowParent) && _A(H.delta, M);
      })[0];
      if (D && D.should) {
        T.cancelable && T.preventDefault();
        return;
      }
      if (!D) {
        var j = (d.current.shards || []).map(g1).filter(Boolean).filter(function(H) {
          return H.contains(T.target);
        });
        (j.length > 0 ? h(T, j[0]) : !d.current.noIsolation) && T.cancelable && T.preventDefault();
      }
    }
  }, []), y = b.useCallback(function(C, T, M, D) {
    var j = {
      name: C,
      delta: T,
      target: M,
      should: D,
      shadowParent: TA(M)
    };
    a.current.push(j), setTimeout(function() {
      a.current = a.current.filter(function(H) {
        return H !== j;
      });
    }, 1);
  }, []), p = b.useCallback(function(C) {
    r.current = zs(C), l.current = void 0;
  }, []), _ = b.useCallback(function(C) {
    y(C.type, v1(C), C.target, h(C, e.lockRef.current));
  }, []), w = b.useCallback(function(C) {
    y(C.type, zs(C), C.target, h(C, e.lockRef.current));
  }, []);
  b.useEffect(function() {
    return Or.push(c), e.setCallbacks({
      onScrollCapture: _,
      onWheelCapture: _,
      onTouchMoveCapture: w
    }), document.addEventListener("wheel", m, xr), document.addEventListener("touchmove", m, xr), document.addEventListener("touchstart", p, xr), function() {
      Or = Or.filter(function(C) {
        return C !== c;
      }), document.removeEventListener("wheel", m, xr), document.removeEventListener("touchmove", m, xr), document.removeEventListener("touchstart", p, xr);
    };
  }, []);
  var E = e.removeScrollBar, x = e.inert;
  return b.createElement(b.Fragment, null, x ? b.createElement(c, { styles: wA(s) }) : null, E ? b.createElement(dA, { gapMode: e.gapMode }) : null);
}
function TA(e) {
  for (var a = null; e !== null; )
    e instanceof ShadowRoot && (a = e.host, e = e.host), e = e.parentNode;
  return a;
}
var CA = J9(Oy, EA), lh = b.forwardRef(function(e, a) {
  return b.createElement(du, de({}, e, {
    ref: a,
    sideCar: CA
  }));
});
lh.classNames = du.classNames;
var AA = function(e) {
  return typeof document > "u" ? null : (Array.isArray(e) ? e[0] : e).ownerDocument.body;
}, Mr = /* @__PURE__ */ new WeakMap(), Ls = /* @__PURE__ */ new WeakMap(), Hs = {}, ad = 0, zy = function(e) {
  return e && (e.host || zy(e.parentNode));
}, xA = function(e, a) {
  return a.map(function(r) {
    if (e.contains(r)) return r;
    var l = zy(r);
    return l && e.contains(l) ? l : (console.error("aria-hidden", r, "in not contained inside", e, ". Doing nothing"), null);
  }).filter(function(r) {
    return !!r;
  });
}, OA = function(e, a, r, l) {
  var s = xA(a, Array.isArray(e) ? e : [e]);
  Hs[r] || (Hs[r] = /* @__PURE__ */ new WeakMap());
  var c = Hs[r], d = [], h = /* @__PURE__ */ new Set(), m = new Set(s), y = function(_) {
    !_ || h.has(_) || (h.add(_), y(_.parentNode));
  };
  s.forEach(y);
  var p = function(_) {
    !_ || m.has(_) || Array.prototype.forEach.call(_.children, function(w) {
      if (h.has(w)) p(w);
      else try {
        var E = w.getAttribute(l), x = E !== null && E !== "false", C = (Mr.get(w) || 0) + 1, T = (c.get(w) || 0) + 1;
        Mr.set(w, C), c.set(w, T), d.push(w), C === 1 && x && Ls.set(w, !0), T === 1 && w.setAttribute(r, "true"), x || w.setAttribute(l, "true");
      } catch (M) {
        console.error("aria-hidden: cannot operate on ", w, M);
      }
    });
  };
  return p(a), h.clear(), ad++, function() {
    d.forEach(function(_) {
      var w = Mr.get(_) - 1, E = c.get(_) - 1;
      Mr.set(_, w), c.set(_, E), w || (Ls.has(_) || _.removeAttribute(l), Ls.delete(_)), E || _.removeAttribute(r);
    }), ad--, ad || (Mr = /* @__PURE__ */ new WeakMap(), Mr = /* @__PURE__ */ new WeakMap(), Ls = /* @__PURE__ */ new WeakMap(), Hs = {});
  };
}, Ly = function(e, a, r) {
  r === void 0 && (r = "data-aria-hidden");
  var l = Array.from(Array.isArray(e) ? e : [e]), s = a || AA(e);
  return s ? (l.push.apply(l, Array.from(s.querySelectorAll("[aria-live]"))), OA(l, s, r, "aria-hidden")) : function() {
    return null;
  };
}, sh = "Dialog", [Hy, WM] = il(sh), [MA, qn] = Hy(sh), jy = (e) => {
  const { __scopeDialog: a, children: r, open: l, defaultOpen: s, onOpenChange: c, modal: d = !0 } = e, h = b.useRef(null), m = b.useRef(null), [y = !1, p] = uu({
    prop: l,
    defaultProp: s,
    onChange: c
  });
  return /* @__PURE__ */ (0, g.jsx)(MA, {
    scope: a,
    triggerRef: h,
    contentRef: m,
    contentId: Go(),
    titleId: Go(),
    descriptionId: Go(),
    open: y,
    onOpenChange: p,
    onOpenToggle: b.useCallback(() => p((_) => !_), [p]),
    modal: d,
    children: r
  });
};
jy.displayName = sh;
var By = "DialogTrigger", RA = b.forwardRef((e, a) => {
  const { __scopeDialog: r, ...l } = e, s = qn(By, r), c = rn(a, s.triggerRef);
  return /* @__PURE__ */ (0, g.jsx)(Dt.button, {
    type: "button",
    "aria-haspopup": "dialog",
    "aria-expanded": s.open,
    "aria-controls": s.contentId,
    "data-state": fh(s.open),
    ...l,
    ref: c,
    onClick: wt(e.onClick, s.onOpenToggle)
  });
});
RA.displayName = By;
var uh = "DialogPortal", [NA, Uy] = Hy(uh, { forceMount: void 0 }), DA = (e) => {
  const { __scopeDialog: a, forceMount: r, children: l, container: s } = e, c = qn(uh, a);
  return /* @__PURE__ */ (0, g.jsx)(NA, {
    scope: a,
    forceMount: r,
    children: b.Children.map(l, (d) => /* @__PURE__ */ (0, g.jsx)(oi, {
      present: r || c.open,
      children: /* @__PURE__ */ (0, g.jsx)(fu, {
        asChild: !0,
        container: s,
        children: d
      })
    }))
  });
};
DA.displayName = uh;
var Ys = "DialogOverlay", zA = b.forwardRef((e, a) => {
  const r = Uy(Ys, e.__scopeDialog), { forceMount: l = r.forceMount, ...s } = e, c = qn(Ys, e.__scopeDialog);
  return c.modal ? /* @__PURE__ */ (0, g.jsx)(oi, {
    present: l || c.open,
    children: /* @__PURE__ */ (0, g.jsx)(LA, {
      ...s,
      ref: a
    })
  }) : null;
});
zA.displayName = Ys;
var LA = b.forwardRef((e, a) => {
  const { __scopeDialog: r, ...l } = e, s = qn(Ys, r);
  return /* @__PURE__ */ (0, g.jsx)(lh, {
    as: al,
    allowPinchZoom: !0,
    shards: [s.contentRef],
    children: /* @__PURE__ */ (0, g.jsx)(Dt.div, {
      "data-state": fh(s.open),
      ...l,
      ref: a,
      style: {
        pointerEvents: "auto",
        ...l.style
      }
    })
  });
}), Hi = "DialogContent", ky = b.forwardRef((e, a) => {
  const r = Uy(Hi, e.__scopeDialog), { forceMount: l = r.forceMount, ...s } = e, c = qn(Hi, e.__scopeDialog);
  return /* @__PURE__ */ (0, g.jsx)(oi, {
    present: l || c.open,
    children: c.modal ? /* @__PURE__ */ (0, g.jsx)(HA, {
      ...s,
      ref: a
    }) : /* @__PURE__ */ (0, g.jsx)(jA, {
      ...s,
      ref: a
    })
  });
});
ky.displayName = Hi;
var HA = b.forwardRef((e, a) => {
  const r = qn(Hi, e.__scopeDialog), l = b.useRef(null), s = rn(a, r.contentRef, l);
  return b.useEffect(() => {
    const c = l.current;
    if (c) return Ly(c);
  }, []), /* @__PURE__ */ (0, g.jsx)(Py, {
    ...e,
    ref: s,
    trapFocus: r.open,
    disableOutsidePointerEvents: !0,
    onCloseAutoFocus: wt(e.onCloseAutoFocus, (c) => {
      c.preventDefault(), r.triggerRef.current?.focus();
    }),
    onPointerDownOutside: wt(e.onPointerDownOutside, (c) => {
      const d = c.detail.originalEvent, h = d.button === 0 && d.ctrlKey === !0;
      (d.button === 2 || h) && c.preventDefault();
    }),
    onFocusOutside: wt(e.onFocusOutside, (c) => c.preventDefault())
  });
}), jA = b.forwardRef((e, a) => {
  const r = qn(Hi, e.__scopeDialog), l = b.useRef(!1), s = b.useRef(!1);
  return /* @__PURE__ */ (0, g.jsx)(Py, {
    ...e,
    ref: a,
    trapFocus: !1,
    disableOutsidePointerEvents: !1,
    onCloseAutoFocus: (c) => {
      e.onCloseAutoFocus?.(c), c.defaultPrevented || (l.current || r.triggerRef.current?.focus(), c.preventDefault()), l.current = !1, s.current = !1;
    },
    onInteractOutside: (c) => {
      e.onInteractOutside?.(c), c.defaultPrevented || (l.current = !0, c.detail.originalEvent.type === "pointerdown" && (s.current = !0));
      const d = c.target;
      r.triggerRef.current?.contains(d) && c.preventDefault(), c.detail.originalEvent.type === "focusin" && s.current && c.preventDefault();
    }
  });
}), Py = b.forwardRef((e, a) => {
  const { __scopeDialog: r, trapFocus: l, onOpenAutoFocus: s, onCloseAutoFocus: c, ...d } = e, h = qn(Hi, r), m = b.useRef(null), y = rn(a, m);
  return Ay(), /* @__PURE__ */ (0, g.jsxs)(g.Fragment, { children: [/* @__PURE__ */ (0, g.jsx)(oh, {
    asChild: !0,
    loop: !0,
    trapped: l,
    onMountAutoFocus: s,
    onUnmountAutoFocus: c,
    children: /* @__PURE__ */ (0, g.jsx)(cu, {
      role: "dialog",
      id: h.contentId,
      "aria-describedby": h.descriptionId,
      "aria-labelledby": h.titleId,
      "data-state": fh(h.open),
      ...d,
      ref: y,
      onDismiss: () => h.onOpenChange(!1)
    })
  }), /* @__PURE__ */ (0, g.jsxs)(g.Fragment, { children: [/* @__PURE__ */ (0, g.jsx)(kA, { titleId: h.titleId }), /* @__PURE__ */ (0, g.jsx)(IA, {
    contentRef: m,
    descriptionId: h.descriptionId
  })] })] });
}), ch = "DialogTitle", Iy = b.forwardRef((e, a) => {
  const { __scopeDialog: r, ...l } = e, s = qn(ch, r);
  return /* @__PURE__ */ (0, g.jsx)(Dt.h2, {
    id: s.titleId,
    ...l,
    ref: a
  });
});
Iy.displayName = ch;
var Zy = "DialogDescription", BA = b.forwardRef((e, a) => {
  const { __scopeDialog: r, ...l } = e, s = qn(Zy, r);
  return /* @__PURE__ */ (0, g.jsx)(Dt.p, {
    id: s.descriptionId,
    ...l,
    ref: a
  });
});
BA.displayName = Zy;
var Gy = "DialogClose", UA = b.forwardRef((e, a) => {
  const { __scopeDialog: r, ...l } = e, s = qn(Gy, r);
  return /* @__PURE__ */ (0, g.jsx)(Dt.button, {
    type: "button",
    ...l,
    ref: a,
    onClick: wt(e.onClick, () => s.onOpenChange(!1))
  });
});
UA.displayName = Gy;
function fh(e) {
  return e ? "open" : "closed";
}
var Vy = "DialogTitleWarning", [QM, $y] = w9(Vy, {
  contentName: Hi,
  titleName: ch,
  docsSlug: "dialog"
}), kA = ({ titleId: e }) => {
  const a = $y(Vy), r = `\`${a.contentName}\` requires a \`${a.titleName}\` for the component to be accessible for screen reader users.

If you want to hide the \`${a.titleName}\`, you can wrap it with our VisuallyHidden component.

For more information, see https://radix-ui.com/primitives/docs/components/${a.docsSlug}`;
  return b.useEffect(() => {
    e && (document.getElementById(e) || console.error(r));
  }, [r, e]), null;
}, PA = "DialogDescriptionWarning", IA = ({ contentRef: e, descriptionId: a }) => {
  const r = `Warning: Missing \`Description\` or \`aria-describedby={undefined}\` for {${$y(PA).contentName}}.`;
  return b.useEffect(() => {
    const l = e.current?.getAttribute("aria-describedby");
    a && l && (document.getElementById(a) || console.warn(r));
  }, [
    r,
    e,
    a
  ]), null;
}, ZA = jy, GA = ky, Fy = Iy;
function VA(e) {
  const a = b.useRef({
    value: e,
    previous: e
  });
  return b.useMemo(() => (a.current.value !== e && (a.current.previous = a.current.value, a.current.value = e), a.current.previous), [e]);
}
function qy(e) {
  const [a, r] = b.useState(void 0);
  return Li(() => {
    if (e) {
      r({
        width: e.offsetWidth,
        height: e.offsetHeight
      });
      const l = new ResizeObserver((s) => {
        if (!Array.isArray(s) || !s.length) return;
        const c = s[0];
        let d, h;
        if ("borderBoxSize" in c) {
          const m = c.borderBoxSize, y = Array.isArray(m) ? m[0] : m;
          d = y.inlineSize, h = y.blockSize;
        } else
          d = e.offsetWidth, h = e.offsetHeight;
        r({
          width: d,
          height: h
        });
      });
      return l.observe(e, { box: "border-box" }), () => l.unobserve(e);
    } else r(void 0);
  }, [e]), a;
}
var $A = [
  "top",
  "right",
  "bottom",
  "left"
], ti = Math.min, pn = Math.max, Ws = Math.round, js = Math.floor, ta = (e) => ({
  x: e,
  y: e
}), FA = {
  left: "right",
  right: "left",
  bottom: "top",
  top: "bottom"
}, qA = {
  start: "end",
  end: "start"
};
function Rd(e, a, r) {
  return pn(e, ti(a, r));
}
function Aa(e, a) {
  return typeof e == "function" ? e(a) : e;
}
function xa(e) {
  return e.split("-")[0];
}
function Gr(e) {
  return e.split("-")[1];
}
function dh(e) {
  return e === "x" ? "y" : "x";
}
function hh(e) {
  return e === "y" ? "height" : "width";
}
var XA = /* @__PURE__ */ new Set(["top", "bottom"]);
function ea(e) {
  return XA.has(xa(e)) ? "y" : "x";
}
function mh(e) {
  return dh(ea(e));
}
function YA(e, a, r) {
  r === void 0 && (r = !1);
  const l = Gr(e), s = mh(e), c = hh(s);
  let d = s === "x" ? l === (r ? "end" : "start") ? "right" : "left" : l === "start" ? "bottom" : "top";
  return a.reference[c] > a.floating[c] && (d = Qs(d)), [d, Qs(d)];
}
function WA(e) {
  const a = Qs(e);
  return [
    Nd(e),
    a,
    Nd(a)
  ];
}
function Nd(e) {
  return e.replace(/start|end/g, (a) => qA[a]);
}
var y1 = ["left", "right"], b1 = ["right", "left"], QA = ["top", "bottom"], KA = ["bottom", "top"];
function JA(e, a, r) {
  switch (e) {
    case "top":
    case "bottom":
      return r ? a ? b1 : y1 : a ? y1 : b1;
    case "left":
    case "right":
      return a ? QA : KA;
    default:
      return [];
  }
}
function e6(e, a, r, l) {
  const s = Gr(e);
  let c = JA(xa(e), r === "start", l);
  return s && (c = c.map((d) => d + "-" + s), a && (c = c.concat(c.map(Nd)))), c;
}
function Qs(e) {
  return e.replace(/left|right|bottom|top/g, (a) => FA[a]);
}
function t6(e) {
  return {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    ...e
  };
}
function Xy(e) {
  return typeof e != "number" ? t6(e) : {
    top: e,
    right: e,
    bottom: e,
    left: e
  };
}
function Ks(e) {
  const { x: a, y: r, width: l, height: s } = e;
  return {
    width: l,
    height: s,
    top: r,
    left: a,
    right: a + l,
    bottom: r + s,
    x: a,
    y: r
  };
}
function _1(e, a, r) {
  let { reference: l, floating: s } = e;
  const c = ea(a), d = mh(a), h = hh(d), m = xa(a), y = c === "y", p = l.x + l.width / 2 - s.width / 2, _ = l.y + l.height / 2 - s.height / 2, w = l[h] / 2 - s[h] / 2;
  let E;
  switch (m) {
    case "top":
      E = {
        x: p,
        y: l.y - s.height
      };
      break;
    case "bottom":
      E = {
        x: p,
        y: l.y + l.height
      };
      break;
    case "right":
      E = {
        x: l.x + l.width,
        y: _
      };
      break;
    case "left":
      E = {
        x: l.x - s.width,
        y: _
      };
      break;
    default:
      E = {
        x: l.x,
        y: l.y
      };
  }
  switch (Gr(a)) {
    case "start":
      E[d] -= w * (r && y ? -1 : 1);
      break;
    case "end":
      E[d] += w * (r && y ? -1 : 1);
      break;
  }
  return E;
}
var n6 = async (e, a, r) => {
  const { placement: l = "bottom", strategy: s = "absolute", middleware: c = [], platform: d } = r, h = c.filter(Boolean), m = await (d.isRTL == null ? void 0 : d.isRTL(a));
  let y = await d.getElementRects({
    reference: e,
    floating: a,
    strategy: s
  }), { x: p, y: _ } = _1(y, l, m), w = l, E = {}, x = 0;
  for (let C = 0; C < h.length; C++) {
    const { name: T, fn: M } = h[C], { x: D, y: j, data: H, reset: k } = await M({
      x: p,
      y: _,
      initialPlacement: l,
      placement: w,
      strategy: s,
      middlewareData: E,
      rects: y,
      platform: d,
      elements: {
        reference: e,
        floating: a
      }
    });
    p = D ?? p, _ = j ?? _, E = {
      ...E,
      [T]: {
        ...E[T],
        ...H
      }
    }, k && x <= 50 && (x++, typeof k == "object" && (k.placement && (w = k.placement), k.rects && (y = k.rects === !0 ? await d.getElementRects({
      reference: e,
      floating: a,
      strategy: s
    }) : k.rects), { x: p, y: _ } = _1(y, w, m)), C = -1);
  }
  return {
    x: p,
    y: _,
    placement: w,
    strategy: s,
    middlewareData: E
  };
};
async function Qo(e, a) {
  var r;
  a === void 0 && (a = {});
  const { x: l, y: s, platform: c, rects: d, elements: h, strategy: m } = e, { boundary: y = "clippingAncestors", rootBoundary: p = "viewport", elementContext: _ = "floating", altBoundary: w = !1, padding: E = 0 } = Aa(a, e), x = Xy(E), C = h[w ? _ === "floating" ? "reference" : "floating" : _], T = Ks(await c.getClippingRect({
    element: (r = await (c.isElement == null ? void 0 : c.isElement(C))) == null || r ? C : C.contextElement || await (c.getDocumentElement == null ? void 0 : c.getDocumentElement(h.floating)),
    boundary: y,
    rootBoundary: p,
    strategy: m
  })), M = _ === "floating" ? {
    x: l,
    y: s,
    width: d.floating.width,
    height: d.floating.height
  } : d.reference, D = await (c.getOffsetParent == null ? void 0 : c.getOffsetParent(h.floating)), j = await (c.isElement == null ? void 0 : c.isElement(D)) ? await (c.getScale == null ? void 0 : c.getScale(D)) || {
    x: 1,
    y: 1
  } : {
    x: 1,
    y: 1
  }, H = Ks(c.convertOffsetParentRelativeRectToViewportRelativeRect ? await c.convertOffsetParentRelativeRectToViewportRelativeRect({
    elements: h,
    rect: M,
    offsetParent: D,
    strategy: m
  }) : M);
  return {
    top: (T.top - H.top + x.top) / j.y,
    bottom: (H.bottom - T.bottom + x.bottom) / j.y,
    left: (T.left - H.left + x.left) / j.x,
    right: (H.right - T.right + x.right) / j.x
  };
}
var a6 = (e) => ({
  name: "arrow",
  options: e,
  async fn(a) {
    const { x: r, y: l, placement: s, rects: c, platform: d, elements: h, middlewareData: m } = a, { element: y, padding: p = 0 } = Aa(e, a) || {};
    if (y == null) return {};
    const _ = Xy(p), w = {
      x: r,
      y: l
    }, E = mh(s), x = hh(E), C = await d.getDimensions(y), T = E === "y", M = T ? "top" : "left", D = T ? "bottom" : "right", j = T ? "clientHeight" : "clientWidth", H = c.reference[x] + c.reference[E] - w[E] - c.floating[x], k = w[E] - c.reference[E], B = await (d.getOffsetParent == null ? void 0 : d.getOffsetParent(y));
    let Q = B ? B[j] : 0;
    (!Q || !await (d.isElement == null ? void 0 : d.isElement(B))) && (Q = h.floating[j] || c.floating[x]);
    const K = H / 2 - k / 2, q = Q / 2 - C[x] / 2 - 1, F = ti(_[M], q), ee = ti(_[D], q), ce = F, V = Q - C[x] - ee, ie = Q / 2 - C[x] / 2 + K, se = Rd(ce, ie, V), L = !m.arrow && Gr(s) != null && ie !== se && c.reference[x] / 2 - (ie < ce ? F : ee) - C[x] / 2 < 0, A = L ? ie < ce ? ie - ce : ie - V : 0;
    return {
      [E]: w[E] + A,
      data: {
        [E]: se,
        centerOffset: ie - se - A,
        ...L && { alignmentOffset: A }
      },
      reset: L
    };
  }
}), i6 = function(e) {
  return e === void 0 && (e = {}), {
    name: "flip",
    options: e,
    async fn(a) {
      var r, l;
      const { placement: s, middlewareData: c, rects: d, initialPlacement: h, platform: m, elements: y } = a, { mainAxis: p = !0, crossAxis: _ = !0, fallbackPlacements: w, fallbackStrategy: E = "bestFit", fallbackAxisSideDirection: x = "none", flipAlignment: C = !0, ...T } = Aa(e, a);
      if ((r = c.arrow) != null && r.alignmentOffset) return {};
      const M = xa(s), D = ea(h), j = xa(h) === h, H = await (m.isRTL == null ? void 0 : m.isRTL(y.floating)), k = w || (j || !C ? [Qs(h)] : WA(h)), B = x !== "none";
      !w && B && k.push(...e6(h, C, x, H));
      const Q = [h, ...k], K = await Qo(a, T), q = [];
      let F = ((l = c.flip) == null ? void 0 : l.overflows) || [];
      if (p && q.push(K[M]), _) {
        const ie = YA(s, d, H);
        q.push(K[ie[0]], K[ie[1]]);
      }
      if (F = [...F, {
        placement: s,
        overflows: q
      }], !q.every((ie) => ie <= 0)) {
        var ee, ce;
        const ie = (((ee = c.flip) == null ? void 0 : ee.index) || 0) + 1, se = Q[ie];
        if (se && (!(_ === "alignment" && D !== ea(se)) || F.every((A) => ea(A.placement) === D ? A.overflows[0] > 0 : !0)))
          return {
            data: {
              index: ie,
              overflows: F
            },
            reset: { placement: se }
          };
        let L = (ce = F.filter((A) => A.overflows[0] <= 0).sort((A, N) => A.overflows[1] - N.overflows[1])[0]) == null ? void 0 : ce.placement;
        if (!L) switch (E) {
          case "bestFit": {
            var V;
            const A = (V = F.filter((N) => {
              if (B) {
                const te = ea(N.placement);
                return te === D || te === "y";
              }
              return !0;
            }).map((N) => [N.placement, N.overflows.filter((te) => te > 0).reduce((te, oe) => te + oe, 0)]).sort((N, te) => N[1] - te[1])[0]) == null ? void 0 : V[0];
            A && (L = A);
            break;
          }
          case "initialPlacement":
            L = h;
            break;
        }
        if (s !== L) return { reset: { placement: L } };
      }
      return {};
    }
  };
};
function w1(e, a) {
  return {
    top: e.top - a.height,
    right: e.right - a.width,
    bottom: e.bottom - a.height,
    left: e.left - a.width
  };
}
function S1(e) {
  return $A.some((a) => e[a] >= 0);
}
var r6 = function(e) {
  return e === void 0 && (e = {}), {
    name: "hide",
    options: e,
    async fn(a) {
      const { rects: r } = a, { strategy: l = "referenceHidden", ...s } = Aa(e, a);
      switch (l) {
        case "referenceHidden": {
          const c = w1(await Qo(a, {
            ...s,
            elementContext: "reference"
          }), r.reference);
          return { data: {
            referenceHiddenOffsets: c,
            referenceHidden: S1(c)
          } };
        }
        case "escaped": {
          const c = w1(await Qo(a, {
            ...s,
            altBoundary: !0
          }), r.floating);
          return { data: {
            escapedOffsets: c,
            escaped: S1(c)
          } };
        }
        default:
          return {};
      }
    }
  };
}, Yy = /* @__PURE__ */ new Set(["left", "top"]);
async function o6(e, a) {
  const { placement: r, platform: l, elements: s } = e, c = await (l.isRTL == null ? void 0 : l.isRTL(s.floating)), d = xa(r), h = Gr(r), m = ea(r) === "y", y = Yy.has(d) ? -1 : 1, p = c && m ? -1 : 1, _ = Aa(a, e);
  let { mainAxis: w, crossAxis: E, alignmentAxis: x } = typeof _ == "number" ? {
    mainAxis: _,
    crossAxis: 0,
    alignmentAxis: null
  } : {
    mainAxis: _.mainAxis || 0,
    crossAxis: _.crossAxis || 0,
    alignmentAxis: _.alignmentAxis
  };
  return h && typeof x == "number" && (E = h === "end" ? x * -1 : x), m ? {
    x: E * p,
    y: w * y
  } : {
    x: w * y,
    y: E * p
  };
}
var l6 = function(e) {
  return e === void 0 && (e = 0), {
    name: "offset",
    options: e,
    async fn(a) {
      var r, l;
      const { x: s, y: c, placement: d, middlewareData: h } = a, m = await o6(a, e);
      return d === ((r = h.offset) == null ? void 0 : r.placement) && (l = h.arrow) != null && l.alignmentOffset ? {} : {
        x: s + m.x,
        y: c + m.y,
        data: {
          ...m,
          placement: d
        }
      };
    }
  };
}, s6 = function(e) {
  return e === void 0 && (e = {}), {
    name: "shift",
    options: e,
    async fn(a) {
      const { x: r, y: l, placement: s } = a, { mainAxis: c = !0, crossAxis: d = !1, limiter: h = { fn: (T) => {
        let { x: M, y: D } = T;
        return {
          x: M,
          y: D
        };
      } }, ...m } = Aa(e, a), y = {
        x: r,
        y: l
      }, p = await Qo(a, m), _ = ea(xa(s)), w = dh(_);
      let E = y[w], x = y[_];
      if (c) {
        const T = w === "y" ? "top" : "left", M = w === "y" ? "bottom" : "right", D = E + p[T], j = E - p[M];
        E = Rd(D, E, j);
      }
      if (d) {
        const T = _ === "y" ? "top" : "left", M = _ === "y" ? "bottom" : "right", D = x + p[T], j = x - p[M];
        x = Rd(D, x, j);
      }
      const C = h.fn({
        ...a,
        [w]: E,
        [_]: x
      });
      return {
        ...C,
        data: {
          x: C.x - r,
          y: C.y - l,
          enabled: {
            [w]: c,
            [_]: d
          }
        }
      };
    }
  };
}, u6 = function(e) {
  return e === void 0 && (e = {}), {
    options: e,
    fn(a) {
      const { x: r, y: l, placement: s, rects: c, middlewareData: d } = a, { offset: h = 0, mainAxis: m = !0, crossAxis: y = !0 } = Aa(e, a), p = {
        x: r,
        y: l
      }, _ = ea(s), w = dh(_);
      let E = p[w], x = p[_];
      const C = Aa(h, a), T = typeof C == "number" ? {
        mainAxis: C,
        crossAxis: 0
      } : {
        mainAxis: 0,
        crossAxis: 0,
        ...C
      };
      if (m) {
        const j = w === "y" ? "height" : "width", H = c.reference[w] - c.floating[j] + T.mainAxis, k = c.reference[w] + c.reference[j] - T.mainAxis;
        E < H ? E = H : E > k && (E = k);
      }
      if (y) {
        var M, D;
        const j = w === "y" ? "width" : "height", H = Yy.has(xa(s)), k = c.reference[_] - c.floating[j] + (H && ((M = d.offset) == null ? void 0 : M[_]) || 0) + (H ? 0 : T.crossAxis), B = c.reference[_] + c.reference[j] + (H ? 0 : ((D = d.offset) == null ? void 0 : D[_]) || 0) - (H ? T.crossAxis : 0);
        x < k ? x = k : x > B && (x = B);
      }
      return {
        [w]: E,
        [_]: x
      };
    }
  };
}, c6 = function(e) {
  return e === void 0 && (e = {}), {
    name: "size",
    options: e,
    async fn(a) {
      var r, l;
      const { placement: s, rects: c, platform: d, elements: h } = a, { apply: m = () => {
      }, ...y } = Aa(e, a), p = await Qo(a, y), _ = xa(s), w = Gr(s), E = ea(s) === "y", { width: x, height: C } = c.floating;
      let T, M;
      _ === "top" || _ === "bottom" ? (T = _, M = w === (await (d.isRTL == null ? void 0 : d.isRTL(h.floating)) ? "start" : "end") ? "left" : "right") : (M = _, T = w === "end" ? "top" : "bottom");
      const D = C - p.top - p.bottom, j = x - p.left - p.right, H = ti(C - p[T], D), k = ti(x - p[M], j), B = !a.middlewareData.shift;
      let Q = H, K = k;
      if ((r = a.middlewareData.shift) != null && r.enabled.x && (K = j), (l = a.middlewareData.shift) != null && l.enabled.y && (Q = D), B && !w) {
        const F = pn(p.left, 0), ee = pn(p.right, 0), ce = pn(p.top, 0), V = pn(p.bottom, 0);
        E ? K = x - 2 * (F !== 0 || ee !== 0 ? F + ee : pn(p.left, p.right)) : Q = C - 2 * (ce !== 0 || V !== 0 ? ce + V : pn(p.top, p.bottom));
      }
      await m({
        ...a,
        availableWidth: K,
        availableHeight: Q
      });
      const q = await d.getDimensions(h.floating);
      return x !== q.width || C !== q.height ? { reset: { rects: !0 } } : {};
    }
  };
};
function hu() {
  return typeof window < "u";
}
function Vr(e) {
  return Wy(e) ? (e.nodeName || "").toLowerCase() : "#document";
}
function yn(e) {
  var a;
  return (e == null || (a = e.ownerDocument) == null ? void 0 : a.defaultView) || window;
}
function ia(e) {
  var a;
  return (a = (Wy(e) ? e.ownerDocument : e.document) || window.document) == null ? void 0 : a.documentElement;
}
function Wy(e) {
  return hu() ? e instanceof Node || e instanceof yn(e).Node : !1;
}
function $n(e) {
  return hu() ? e instanceof Element || e instanceof yn(e).Element : !1;
}
function aa(e) {
  return hu() ? e instanceof HTMLElement || e instanceof yn(e).HTMLElement : !1;
}
function E1(e) {
  return !hu() || typeof ShadowRoot > "u" ? !1 : e instanceof ShadowRoot || e instanceof yn(e).ShadowRoot;
}
var f6 = /* @__PURE__ */ new Set(["inline", "contents"]);
function rl(e) {
  const { overflow: a, overflowX: r, overflowY: l, display: s } = Fn(e);
  return /auto|scroll|overlay|hidden|clip/.test(a + l + r) && !f6.has(s);
}
var d6 = /* @__PURE__ */ new Set([
  "table",
  "td",
  "th"
]);
function h6(e) {
  return d6.has(Vr(e));
}
var m6 = [":popover-open", ":modal"];
function mu(e) {
  return m6.some((a) => {
    try {
      return e.matches(a);
    } catch {
      return !1;
    }
  });
}
var p6 = [
  "transform",
  "translate",
  "scale",
  "rotate",
  "perspective"
], v6 = [
  "transform",
  "translate",
  "scale",
  "rotate",
  "perspective",
  "filter"
], g6 = [
  "paint",
  "layout",
  "strict",
  "content"
];
function ph(e) {
  const a = vh(), r = $n(e) ? Fn(e) : e;
  return p6.some((l) => r[l] ? r[l] !== "none" : !1) || (r.containerType ? r.containerType !== "normal" : !1) || !a && (r.backdropFilter ? r.backdropFilter !== "none" : !1) || !a && (r.filter ? r.filter !== "none" : !1) || v6.some((l) => (r.willChange || "").includes(l)) || g6.some((l) => (r.contain || "").includes(l));
}
function y6(e) {
  let a = ni(e);
  for (; aa(a) && !jr(a); ) {
    if (ph(a)) return a;
    if (mu(a)) return null;
    a = ni(a);
  }
  return null;
}
function vh() {
  return typeof CSS > "u" || !CSS.supports ? !1 : CSS.supports("-webkit-backdrop-filter", "none");
}
var b6 = /* @__PURE__ */ new Set([
  "html",
  "body",
  "#document"
]);
function jr(e) {
  return b6.has(Vr(e));
}
function Fn(e) {
  return yn(e).getComputedStyle(e);
}
function pu(e) {
  return $n(e) ? {
    scrollLeft: e.scrollLeft,
    scrollTop: e.scrollTop
  } : {
    scrollLeft: e.scrollX,
    scrollTop: e.scrollY
  };
}
function ni(e) {
  if (Vr(e) === "html") return e;
  const a = e.assignedSlot || e.parentNode || E1(e) && e.host || ia(e);
  return E1(a) ? a.host : a;
}
function Qy(e) {
  const a = ni(e);
  return jr(a) ? e.ownerDocument ? e.ownerDocument.body : e.body : aa(a) && rl(a) ? a : Qy(a);
}
function Ko(e, a, r) {
  var l;
  a === void 0 && (a = []), r === void 0 && (r = !0);
  const s = Qy(e), c = s === ((l = e.ownerDocument) == null ? void 0 : l.body), d = yn(s);
  if (c) {
    const h = Dd(d);
    return a.concat(d, d.visualViewport || [], rl(s) ? s : [], h && r ? Ko(h) : []);
  }
  return a.concat(s, Ko(s, [], r));
}
function Dd(e) {
  return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null;
}
function Ky(e) {
  const a = Fn(e);
  let r = parseFloat(a.width) || 0, l = parseFloat(a.height) || 0;
  const s = aa(e), c = s ? e.offsetWidth : r, d = s ? e.offsetHeight : l, h = Ws(r) !== c || Ws(l) !== d;
  return h && (r = c, l = d), {
    width: r,
    height: l,
    $: h
  };
}
function gh(e) {
  return $n(e) ? e : e.contextElement;
}
function zr(e) {
  const a = gh(e);
  if (!aa(a)) return ta(1);
  const r = a.getBoundingClientRect(), { width: l, height: s, $: c } = Ky(a);
  let d = (c ? Ws(r.width) : r.width) / l, h = (c ? Ws(r.height) : r.height) / s;
  return (!d || !Number.isFinite(d)) && (d = 1), (!h || !Number.isFinite(h)) && (h = 1), {
    x: d,
    y: h
  };
}
var _6 = /* @__PURE__ */ ta(0);
function Jy(e) {
  const a = yn(e);
  return !vh() || !a.visualViewport ? _6 : {
    x: a.visualViewport.offsetLeft,
    y: a.visualViewport.offsetTop
  };
}
function w6(e, a, r) {
  return a === void 0 && (a = !1), !r || a && r !== yn(e) ? !1 : a;
}
function ji(e, a, r, l) {
  a === void 0 && (a = !1), r === void 0 && (r = !1);
  const s = e.getBoundingClientRect(), c = gh(e);
  let d = ta(1);
  a && (l ? $n(l) && (d = zr(l)) : d = zr(e));
  const h = w6(c, r, l) ? Jy(c) : ta(0);
  let m = (s.left + h.x) / d.x, y = (s.top + h.y) / d.y, p = s.width / d.x, _ = s.height / d.y;
  if (c) {
    const w = yn(c), E = l && $n(l) ? yn(l) : l;
    let x = w, C = Dd(x);
    for (; C && l && E !== x; ) {
      const T = zr(C), M = C.getBoundingClientRect(), D = Fn(C), j = M.left + (C.clientLeft + parseFloat(D.paddingLeft)) * T.x, H = M.top + (C.clientTop + parseFloat(D.paddingTop)) * T.y;
      m *= T.x, y *= T.y, p *= T.x, _ *= T.y, m += j, y += H, x = yn(C), C = Dd(x);
    }
  }
  return Ks({
    width: p,
    height: _,
    x: m,
    y
  });
}
function vu(e, a) {
  const r = pu(e).scrollLeft;
  return a ? a.left + r : ji(ia(e)).left + r;
}
function eb(e, a) {
  const r = e.getBoundingClientRect();
  return {
    x: r.left + a.scrollLeft - vu(e, r),
    y: r.top + a.scrollTop
  };
}
function S6(e) {
  let { elements: a, rect: r, offsetParent: l, strategy: s } = e;
  const c = s === "fixed", d = ia(l), h = a ? mu(a.floating) : !1;
  if (l === d || h && c) return r;
  let m = {
    scrollLeft: 0,
    scrollTop: 0
  }, y = ta(1);
  const p = ta(0), _ = aa(l);
  if ((_ || !_ && !c) && ((Vr(l) !== "body" || rl(d)) && (m = pu(l)), aa(l))) {
    const E = ji(l);
    y = zr(l), p.x = E.x + l.clientLeft, p.y = E.y + l.clientTop;
  }
  const w = d && !_ && !c ? eb(d, m) : ta(0);
  return {
    width: r.width * y.x,
    height: r.height * y.y,
    x: r.x * y.x - m.scrollLeft * y.x + p.x + w.x,
    y: r.y * y.y - m.scrollTop * y.y + p.y + w.y
  };
}
function E6(e) {
  return Array.from(e.getClientRects());
}
function T6(e) {
  const a = ia(e), r = pu(e), l = e.ownerDocument.body, s = pn(a.scrollWidth, a.clientWidth, l.scrollWidth, l.clientWidth), c = pn(a.scrollHeight, a.clientHeight, l.scrollHeight, l.clientHeight);
  let d = -r.scrollLeft + vu(e);
  const h = -r.scrollTop;
  return Fn(l).direction === "rtl" && (d += pn(a.clientWidth, l.clientWidth) - s), {
    width: s,
    height: c,
    x: d,
    y: h
  };
}
var T1 = 25;
function C6(e, a) {
  const r = yn(e), l = ia(e), s = r.visualViewport;
  let c = l.clientWidth, d = l.clientHeight, h = 0, m = 0;
  if (s) {
    c = s.width, d = s.height;
    const p = vh();
    (!p || p && a === "fixed") && (h = s.offsetLeft, m = s.offsetTop);
  }
  const y = vu(l);
  if (y <= 0) {
    const p = l.ownerDocument, _ = p.body, w = getComputedStyle(_), E = p.compatMode === "CSS1Compat" && parseFloat(w.marginLeft) + parseFloat(w.marginRight) || 0, x = Math.abs(l.clientWidth - _.clientWidth - E);
    x <= T1 && (c -= x);
  } else y <= T1 && (c += y);
  return {
    width: c,
    height: d,
    x: h,
    y: m
  };
}
var A6 = /* @__PURE__ */ new Set(["absolute", "fixed"]);
function x6(e, a) {
  const r = ji(e, !0, a === "fixed"), l = r.top + e.clientTop, s = r.left + e.clientLeft, c = aa(e) ? zr(e) : ta(1);
  return {
    width: e.clientWidth * c.x,
    height: e.clientHeight * c.y,
    x: s * c.x,
    y: l * c.y
  };
}
function C1(e, a, r) {
  let l;
  if (a === "viewport") l = C6(e, r);
  else if (a === "document") l = T6(ia(e));
  else if ($n(a)) l = x6(a, r);
  else {
    const s = Jy(e);
    l = {
      x: a.x - s.x,
      y: a.y - s.y,
      width: a.width,
      height: a.height
    };
  }
  return Ks(l);
}
function tb(e, a) {
  const r = ni(e);
  return r === a || !$n(r) || jr(r) ? !1 : Fn(r).position === "fixed" || tb(r, a);
}
function O6(e, a) {
  const r = a.get(e);
  if (r) return r;
  let l = Ko(e, [], !1).filter((h) => $n(h) && Vr(h) !== "body"), s = null;
  const c = Fn(e).position === "fixed";
  let d = c ? ni(e) : e;
  for (; $n(d) && !jr(d); ) {
    const h = Fn(d), m = ph(d);
    !m && h.position === "fixed" && (s = null), (c ? !m && !s : !m && h.position === "static" && s && A6.has(s.position) || rl(d) && !m && tb(e, d)) ? l = l.filter((y) => y !== d) : s = h, d = ni(d);
  }
  return a.set(e, l), l;
}
function M6(e) {
  let { element: a, boundary: r, rootBoundary: l, strategy: s } = e;
  const c = [...r === "clippingAncestors" ? mu(a) ? [] : O6(a, this._c) : [].concat(r), l], d = c[0], h = c.reduce((m, y) => {
    const p = C1(a, y, s);
    return m.top = pn(p.top, m.top), m.right = ti(p.right, m.right), m.bottom = ti(p.bottom, m.bottom), m.left = pn(p.left, m.left), m;
  }, C1(a, d, s));
  return {
    width: h.right - h.left,
    height: h.bottom - h.top,
    x: h.left,
    y: h.top
  };
}
function R6(e) {
  const { width: a, height: r } = Ky(e);
  return {
    width: a,
    height: r
  };
}
function N6(e, a, r) {
  const l = aa(a), s = ia(a), c = r === "fixed", d = ji(e, !0, c, a);
  let h = {
    scrollLeft: 0,
    scrollTop: 0
  };
  const m = ta(0);
  function y() {
    m.x = vu(s);
  }
  if (l || !l && !c)
    if ((Vr(a) !== "body" || rl(s)) && (h = pu(a)), l) {
      const _ = ji(a, !0, c, a);
      m.x = _.x + a.clientLeft, m.y = _.y + a.clientTop;
    } else s && y();
  c && !l && s && y();
  const p = s && !l && !c ? eb(s, h) : ta(0);
  return {
    x: d.left + h.scrollLeft - m.x - p.x,
    y: d.top + h.scrollTop - m.y - p.y,
    width: d.width,
    height: d.height
  };
}
function id(e) {
  return Fn(e).position === "static";
}
function A1(e, a) {
  if (!aa(e) || Fn(e).position === "fixed") return null;
  if (a) return a(e);
  let r = e.offsetParent;
  return ia(e) === r && (r = r.ownerDocument.body), r;
}
function nb(e, a) {
  const r = yn(e);
  if (mu(e)) return r;
  if (!aa(e)) {
    let s = ni(e);
    for (; s && !jr(s); ) {
      if ($n(s) && !id(s)) return s;
      s = ni(s);
    }
    return r;
  }
  let l = A1(e, a);
  for (; l && h6(l) && id(l); ) l = A1(l, a);
  return l && jr(l) && id(l) && !ph(l) ? r : l || y6(e) || r;
}
var D6 = async function(e) {
  const a = this.getOffsetParent || nb, r = this.getDimensions, l = await r(e.floating);
  return {
    reference: N6(e.reference, await a(e.floating), e.strategy),
    floating: {
      x: 0,
      y: 0,
      width: l.width,
      height: l.height
    }
  };
};
function z6(e) {
  return Fn(e).direction === "rtl";
}
var L6 = {
  convertOffsetParentRelativeRectToViewportRelativeRect: S6,
  getDocumentElement: ia,
  getClippingRect: M6,
  getOffsetParent: nb,
  getElementRects: D6,
  getClientRects: E6,
  getDimensions: R6,
  getScale: zr,
  isElement: $n,
  isRTL: z6
};
function ab(e, a) {
  return e.x === a.x && e.y === a.y && e.width === a.width && e.height === a.height;
}
function H6(e, a) {
  let r = null, l;
  const s = ia(e);
  function c() {
    var h;
    clearTimeout(l), (h = r) == null || h.disconnect(), r = null;
  }
  function d(h, m) {
    h === void 0 && (h = !1), m === void 0 && (m = 1), c();
    const y = e.getBoundingClientRect(), { left: p, top: _, width: w, height: E } = y;
    if (h || a(), !w || !E) return;
    const x = js(_), C = js(s.clientWidth - (p + w)), T = js(s.clientHeight - (_ + E)), M = js(p), D = {
      rootMargin: -x + "px " + -C + "px " + -T + "px " + -M + "px",
      threshold: pn(0, ti(1, m)) || 1
    };
    let j = !0;
    function H(k) {
      const B = k[0].intersectionRatio;
      if (B !== m) {
        if (!j) return d();
        B ? d(!1, B) : l = setTimeout(() => {
          d(!1, 1e-7);
        }, 1e3);
      }
      B === 1 && !ab(y, e.getBoundingClientRect()) && d(), j = !1;
    }
    try {
      r = new IntersectionObserver(H, {
        ...D,
        root: s.ownerDocument
      });
    } catch {
      r = new IntersectionObserver(H, D);
    }
    r.observe(e);
  }
  return d(!0), c;
}
function j6(e, a, r, l) {
  l === void 0 && (l = {});
  const { ancestorScroll: s = !0, ancestorResize: c = !0, elementResize: d = typeof ResizeObserver == "function", layoutShift: h = typeof IntersectionObserver == "function", animationFrame: m = !1 } = l, y = gh(e), p = s || c ? [...y ? Ko(y) : [], ...Ko(a)] : [];
  p.forEach((M) => {
    s && M.addEventListener("scroll", r, { passive: !0 }), c && M.addEventListener("resize", r);
  });
  const _ = y && h ? H6(y, r) : null;
  let w = -1, E = null;
  d && (E = new ResizeObserver((M) => {
    let [D] = M;
    D && D.target === y && E && (E.unobserve(a), cancelAnimationFrame(w), w = requestAnimationFrame(() => {
      var j;
      (j = E) == null || j.observe(a);
    })), r();
  }), y && !m && E.observe(y), E.observe(a));
  let x, C = m ? ji(e) : null;
  m && T();
  function T() {
    const M = ji(e);
    C && !ab(C, M) && r(), C = M, x = requestAnimationFrame(T);
  }
  return r(), () => {
    var M;
    p.forEach((D) => {
      s && D.removeEventListener("scroll", r), c && D.removeEventListener("resize", r);
    }), _?.(), (M = E) == null || M.disconnect(), E = null, m && cancelAnimationFrame(x);
  };
}
var B6 = l6, U6 = s6, k6 = i6, P6 = c6, I6 = r6, x1 = a6, Z6 = u6, G6 = (e, a, r) => {
  const l = /* @__PURE__ */ new Map(), s = {
    platform: L6,
    ...r
  }, c = {
    ...s.platform,
    _c: l
  };
  return n6(e, a, {
    ...s,
    platform: c
  });
}, Zs = typeof document < "u" ? b.useLayoutEffect : function() {
};
function Js(e, a) {
  if (e === a) return !0;
  if (typeof e != typeof a) return !1;
  if (typeof e == "function" && e.toString() === a.toString()) return !0;
  let r, l, s;
  if (e && a && typeof e == "object") {
    if (Array.isArray(e)) {
      if (r = e.length, r !== a.length) return !1;
      for (l = r; l-- !== 0; ) if (!Js(e[l], a[l])) return !1;
      return !0;
    }
    if (s = Object.keys(e), r = s.length, r !== Object.keys(a).length) return !1;
    for (l = r; l-- !== 0; ) if (!{}.hasOwnProperty.call(a, s[l])) return !1;
    for (l = r; l-- !== 0; ) {
      const c = s[l];
      if (!(c === "_owner" && e.$$typeof) && !Js(e[c], a[c]))
        return !1;
    }
    return !0;
  }
  return e !== e && a !== a;
}
function ib(e) {
  return typeof window > "u" ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function O1(e, a) {
  const r = ib(e);
  return Math.round(a * r) / r;
}
function rd(e) {
  const a = b.useRef(e);
  return Zs(() => {
    a.current = e;
  }), a;
}
function V6(e) {
  e === void 0 && (e = {});
  const { placement: a = "bottom", strategy: r = "absolute", middleware: l = [], platform: s, elements: { reference: c, floating: d } = {}, transform: h = !0, whileElementsMounted: m, open: y } = e, [p, _] = b.useState({
    x: 0,
    y: 0,
    strategy: r,
    placement: a,
    middlewareData: {},
    isPositioned: !1
  }), [w, E] = b.useState(l);
  Js(w, l) || E(l);
  const [x, C] = b.useState(null), [T, M] = b.useState(null), D = b.useCallback((N) => {
    N !== B.current && (B.current = N, C(N));
  }, []), j = b.useCallback((N) => {
    N !== Q.current && (Q.current = N, M(N));
  }, []), H = c || x, k = d || T, B = b.useRef(null), Q = b.useRef(null), K = b.useRef(p), q = m != null, F = rd(m), ee = rd(s), ce = rd(y), V = b.useCallback(() => {
    if (!B.current || !Q.current) return;
    const N = {
      placement: a,
      strategy: r,
      middleware: w
    };
    ee.current && (N.platform = ee.current), G6(B.current, Q.current, N).then((te) => {
      const oe = {
        ...te,
        isPositioned: ce.current !== !1
      };
      ie.current && !Js(K.current, oe) && (K.current = oe, Zr.flushSync(() => {
        _(oe);
      }));
    });
  }, [
    w,
    a,
    r,
    ee,
    ce
  ]);
  Zs(() => {
    y === !1 && K.current.isPositioned && (K.current.isPositioned = !1, _((N) => ({
      ...N,
      isPositioned: !1
    })));
  }, [y]);
  const ie = b.useRef(!1);
  Zs(() => (ie.current = !0, () => {
    ie.current = !1;
  }), []), Zs(() => {
    if (H && (B.current = H), k && (Q.current = k), H && k) {
      if (F.current) return F.current(H, k, V);
      V();
    }
  }, [
    H,
    k,
    V,
    F,
    q
  ]);
  const se = b.useMemo(() => ({
    reference: B,
    floating: Q,
    setReference: D,
    setFloating: j
  }), [D, j]), L = b.useMemo(() => ({
    reference: H,
    floating: k
  }), [H, k]), A = b.useMemo(() => {
    const N = {
      position: r,
      left: 0,
      top: 0
    };
    if (!L.floating) return N;
    const te = O1(L.floating, p.x), oe = O1(L.floating, p.y);
    return h ? {
      ...N,
      transform: "translate(" + te + "px, " + oe + "px)",
      ...ib(L.floating) >= 1.5 && { willChange: "transform" }
    } : {
      position: r,
      left: te,
      top: oe
    };
  }, [
    r,
    h,
    L.floating,
    p.x,
    p.y
  ]);
  return b.useMemo(() => ({
    ...p,
    update: V,
    refs: se,
    elements: L,
    floatingStyles: A
  }), [
    p,
    V,
    se,
    L,
    A
  ]);
}
var $6 = (e) => {
  function a(r) {
    return {}.hasOwnProperty.call(r, "current");
  }
  return {
    name: "arrow",
    options: e,
    fn(r) {
      const { element: l, padding: s } = typeof e == "function" ? e(r) : e;
      return l && a(l) ? l.current != null ? x1({
        element: l.current,
        padding: s
      }).fn(r) : {} : l ? x1({
        element: l,
        padding: s
      }).fn(r) : {};
    }
  };
}, F6 = (e, a) => ({
  ...B6(e),
  options: [e, a]
}), q6 = (e, a) => ({
  ...U6(e),
  options: [e, a]
}), X6 = (e, a) => ({
  ...Z6(e),
  options: [e, a]
}), Y6 = (e, a) => ({
  ...k6(e),
  options: [e, a]
}), W6 = (e, a) => ({
  ...P6(e),
  options: [e, a]
}), Q6 = (e, a) => ({
  ...I6(e),
  options: [e, a]
}), K6 = (e, a) => ({
  ...$6(e),
  options: [e, a]
}), J6 = "Arrow", rb = b.forwardRef((e, a) => {
  const { children: r, width: l = 10, height: s = 5, ...c } = e;
  return /* @__PURE__ */ (0, g.jsx)(Dt.svg, {
    ...c,
    ref: a,
    width: l,
    height: s,
    viewBox: "0 0 30 10",
    preserveAspectRatio: "none",
    children: e.asChild ? r : /* @__PURE__ */ (0, g.jsx)("polygon", { points: "0,0 30,0 15,10" })
  });
});
rb.displayName = J6;
var e5 = rb, yh = "Popper", [ob, gu] = il(yh), [t5, lb] = ob(yh), sb = (e) => {
  const { __scopePopper: a, children: r } = e, [l, s] = b.useState(null);
  return /* @__PURE__ */ (0, g.jsx)(t5, {
    scope: a,
    anchor: l,
    onAnchorChange: s,
    children: r
  });
};
sb.displayName = yh;
var ub = "PopperAnchor", cb = b.forwardRef((e, a) => {
  const { __scopePopper: r, virtualRef: l, ...s } = e, c = lb(ub, r), d = b.useRef(null), h = rn(a, d);
  return b.useEffect(() => {
    c.onAnchorChange(l?.current || d.current);
  }), l ? null : /* @__PURE__ */ (0, g.jsx)(Dt.div, {
    ...s,
    ref: h
  });
});
cb.displayName = ub;
var bh = "PopperContent", [n5, a5] = ob(bh), fb = b.forwardRef((e, a) => {
  const { __scopePopper: r, side: l = "bottom", sideOffset: s = 0, align: c = "center", alignOffset: d = 0, arrowPadding: h = 0, avoidCollisions: m = !0, collisionBoundary: y = [], collisionPadding: p = 0, sticky: _ = "partial", hideWhenDetached: w = !1, updatePositionStrategy: E = "optimized", onPlaced: x, ...C } = e, T = lb(bh, r), [M, D] = b.useState(null), j = rn(a, (_e) => D(_e)), [H, k] = b.useState(null), B = qy(H), Q = B?.width ?? 0, K = B?.height ?? 0, q = l + (c !== "center" ? "-" + c : ""), F = typeof p == "number" ? p : {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    ...p
  }, ee = Array.isArray(y) ? y : [y], ce = ee.length > 0, V = {
    padding: F,
    boundary: ee.filter(r5),
    altBoundary: ce
  }, { refs: ie, floatingStyles: se, placement: L, isPositioned: A, middlewareData: N } = V6({
    strategy: "fixed",
    placement: q,
    whileElementsMounted: (..._e) => j6(..._e, { animationFrame: E === "always" }),
    elements: { reference: T.anchor },
    middleware: [
      F6({
        mainAxis: s + K,
        alignmentAxis: d
      }),
      m && q6({
        mainAxis: !0,
        crossAxis: !1,
        limiter: _ === "partial" ? X6() : void 0,
        ...V
      }),
      m && Y6({ ...V }),
      W6({
        ...V,
        apply: ({ elements: _e, rects: ue, availableWidth: me, availableHeight: Te }) => {
          const { width: Ce, height: Oe } = ue.reference, qe = _e.floating.style;
          qe.setProperty("--radix-popper-available-width", `${me}px`), qe.setProperty("--radix-popper-available-height", `${Te}px`), qe.setProperty("--radix-popper-anchor-width", `${Ce}px`), qe.setProperty("--radix-popper-anchor-height", `${Oe}px`);
        }
      }),
      H && K6({
        element: H,
        padding: h
      }),
      o5({
        arrowWidth: Q,
        arrowHeight: K
      }),
      w && Q6({
        strategy: "referenceHidden",
        ...V
      })
    ]
  }), [te, oe] = mb(L), Ee = ei(x);
  Li(() => {
    A && Ee?.();
  }, [A, Ee]);
  const O = N.arrow?.x, $ = N.arrow?.y, re = N.arrow?.centerOffset !== 0, [le, ye] = b.useState();
  return Li(() => {
    M && ye(window.getComputedStyle(M).zIndex);
  }, [M]), /* @__PURE__ */ (0, g.jsx)("div", {
    ref: ie.setFloating,
    "data-radix-popper-content-wrapper": "",
    style: {
      ...se,
      transform: A ? se.transform : "translate(0, -200%)",
      minWidth: "max-content",
      zIndex: le,
      "--radix-popper-transform-origin": [N.transformOrigin?.x, N.transformOrigin?.y].join(" "),
      ...N.hide?.referenceHidden && {
        visibility: "hidden",
        pointerEvents: "none"
      }
    },
    dir: e.dir,
    children: /* @__PURE__ */ (0, g.jsx)(n5, {
      scope: r,
      placedSide: te,
      onArrowChange: k,
      arrowX: O,
      arrowY: $,
      shouldHideArrow: re,
      children: /* @__PURE__ */ (0, g.jsx)(Dt.div, {
        "data-side": te,
        "data-align": oe,
        ...C,
        ref: j,
        style: {
          ...C.style,
          animation: A ? void 0 : "none"
        }
      })
    })
  });
});
fb.displayName = bh;
var db = "PopperArrow", i5 = {
  top: "bottom",
  right: "left",
  bottom: "top",
  left: "right"
}, hb = b.forwardRef(function(a, r) {
  const { __scopePopper: l, ...s } = a, c = a5(db, l), d = i5[c.placedSide];
  return /* @__PURE__ */ (0, g.jsx)("span", {
    ref: c.onArrowChange,
    style: {
      position: "absolute",
      left: c.arrowX,
      top: c.arrowY,
      [d]: 0,
      transformOrigin: {
        top: "",
        right: "0 0",
        bottom: "center 0",
        left: "100% 0"
      }[c.placedSide],
      transform: {
        top: "translateY(100%)",
        right: "translateY(50%) rotate(90deg) translateX(-50%)",
        bottom: "rotate(180deg)",
        left: "translateY(50%) rotate(-90deg) translateX(50%)"
      }[c.placedSide],
      visibility: c.shouldHideArrow ? "hidden" : void 0
    },
    children: /* @__PURE__ */ (0, g.jsx)(e5, {
      ...s,
      ref: r,
      style: {
        ...s.style,
        display: "block"
      }
    })
  });
});
hb.displayName = db;
function r5(e) {
  return e !== null;
}
var o5 = (e) => ({
  name: "transformOrigin",
  options: e,
  fn(a) {
    const { placement: r, rects: l, middlewareData: s } = a, c = s.arrow?.centerOffset !== 0, d = c ? 0 : e.arrowWidth, h = c ? 0 : e.arrowHeight, [m, y] = mb(r), p = {
      start: "0%",
      center: "50%",
      end: "100%"
    }[y], _ = (s.arrow?.x ?? 0) + d / 2, w = (s.arrow?.y ?? 0) + h / 2;
    let E = "", x = "";
    return m === "bottom" ? (E = c ? p : `${_}px`, x = `${-h}px`) : m === "top" ? (E = c ? p : `${_}px`, x = `${l.floating.height + h}px`) : m === "right" ? (E = `${-h}px`, x = c ? p : `${w}px`) : m === "left" && (E = `${l.floating.width + h}px`, x = c ? p : `${w}px`), { data: {
      x: E,
      y: x
    } };
  }
});
function mb(e) {
  const [a, r = "center"] = e.split("-");
  return [a, r];
}
var pb = sb, _h = cb, vb = fb, gb = hb, wh = "Popover", [yb, KM] = il(wh, [gu]), ol = gu(), [l5, li] = yb(wh), bb = (e) => {
  const { __scopePopover: a, children: r, open: l, defaultOpen: s, onOpenChange: c, modal: d = !1 } = e, h = ol(a), m = b.useRef(null), [y, p] = b.useState(!1), [_ = !1, w] = uu({
    prop: l,
    defaultProp: s,
    onChange: c
  });
  return /* @__PURE__ */ (0, g.jsx)(pb, {
    ...h,
    children: /* @__PURE__ */ (0, g.jsx)(l5, {
      scope: a,
      contentId: Go(),
      triggerRef: m,
      open: _,
      onOpenChange: w,
      onOpenToggle: b.useCallback(() => w((E) => !E), [w]),
      hasCustomAnchor: y,
      onCustomAnchorAdd: b.useCallback(() => p(!0), []),
      onCustomAnchorRemove: b.useCallback(() => p(!1), []),
      modal: d,
      children: r
    })
  });
};
bb.displayName = wh;
var _b = "PopoverAnchor", wb = b.forwardRef((e, a) => {
  const { __scopePopover: r, ...l } = e, s = li(_b, r), c = ol(r), { onCustomAnchorAdd: d, onCustomAnchorRemove: h } = s;
  return b.useEffect(() => (d(), () => h()), [d, h]), /* @__PURE__ */ (0, g.jsx)(_h, {
    ...c,
    ...l,
    ref: a
  });
});
wb.displayName = _b;
var Sb = "PopoverTrigger", Eb = b.forwardRef((e, a) => {
  const { __scopePopover: r, ...l } = e, s = li(Sb, r), c = ol(r), d = rn(a, s.triggerRef), h = /* @__PURE__ */ (0, g.jsx)(Dt.button, {
    type: "button",
    "aria-haspopup": "dialog",
    "aria-expanded": s.open,
    "aria-controls": s.contentId,
    "data-state": Mb(s.open),
    ...l,
    ref: d,
    onClick: wt(e.onClick, s.onOpenToggle)
  });
  return s.hasCustomAnchor ? h : /* @__PURE__ */ (0, g.jsx)(_h, {
    asChild: !0,
    ...c,
    children: h
  });
});
Eb.displayName = Sb;
var Sh = "PopoverPortal", [s5, u5] = yb(Sh, { forceMount: void 0 }), Tb = (e) => {
  const { __scopePopover: a, forceMount: r, children: l, container: s } = e, c = li(Sh, a);
  return /* @__PURE__ */ (0, g.jsx)(s5, {
    scope: a,
    forceMount: r,
    children: /* @__PURE__ */ (0, g.jsx)(oi, {
      present: r || c.open,
      children: /* @__PURE__ */ (0, g.jsx)(fu, {
        asChild: !0,
        container: s,
        children: l
      })
    })
  });
};
Tb.displayName = Sh;
var Br = "PopoverContent", Cb = b.forwardRef((e, a) => {
  const r = u5(Br, e.__scopePopover), { forceMount: l = r.forceMount, ...s } = e, c = li(Br, e.__scopePopover);
  return /* @__PURE__ */ (0, g.jsx)(oi, {
    present: l || c.open,
    children: c.modal ? /* @__PURE__ */ (0, g.jsx)(c5, {
      ...s,
      ref: a
    }) : /* @__PURE__ */ (0, g.jsx)(f5, {
      ...s,
      ref: a
    })
  });
});
Cb.displayName = Br;
var c5 = b.forwardRef((e, a) => {
  const r = li(Br, e.__scopePopover), l = b.useRef(null), s = rn(a, l), c = b.useRef(!1);
  return b.useEffect(() => {
    const d = l.current;
    if (d) return Ly(d);
  }, []), /* @__PURE__ */ (0, g.jsx)(lh, {
    as: al,
    allowPinchZoom: !0,
    children: /* @__PURE__ */ (0, g.jsx)(Ab, {
      ...e,
      ref: s,
      trapFocus: r.open,
      disableOutsidePointerEvents: !0,
      onCloseAutoFocus: wt(e.onCloseAutoFocus, (d) => {
        d.preventDefault(), c.current || r.triggerRef.current?.focus();
      }),
      onPointerDownOutside: wt(e.onPointerDownOutside, (d) => {
        const h = d.detail.originalEvent, m = h.button === 0 && h.ctrlKey === !0;
        c.current = h.button === 2 || m;
      }, { checkForDefaultPrevented: !1 }),
      onFocusOutside: wt(e.onFocusOutside, (d) => d.preventDefault(), { checkForDefaultPrevented: !1 })
    })
  });
}), f5 = b.forwardRef((e, a) => {
  const r = li(Br, e.__scopePopover), l = b.useRef(!1), s = b.useRef(!1);
  return /* @__PURE__ */ (0, g.jsx)(Ab, {
    ...e,
    ref: a,
    trapFocus: !1,
    disableOutsidePointerEvents: !1,
    onCloseAutoFocus: (c) => {
      e.onCloseAutoFocus?.(c), c.defaultPrevented || (l.current || r.triggerRef.current?.focus(), c.preventDefault()), l.current = !1, s.current = !1;
    },
    onInteractOutside: (c) => {
      e.onInteractOutside?.(c), c.defaultPrevented || (l.current = !0, c.detail.originalEvent.type === "pointerdown" && (s.current = !0));
      const d = c.target;
      r.triggerRef.current?.contains(d) && c.preventDefault(), c.detail.originalEvent.type === "focusin" && s.current && c.preventDefault();
    }
  });
}), Ab = b.forwardRef((e, a) => {
  const { __scopePopover: r, trapFocus: l, onOpenAutoFocus: s, onCloseAutoFocus: c, disableOutsidePointerEvents: d, onEscapeKeyDown: h, onPointerDownOutside: m, onFocusOutside: y, onInteractOutside: p, ..._ } = e, w = li(Br, r), E = ol(r);
  return Ay(), /* @__PURE__ */ (0, g.jsx)(oh, {
    asChild: !0,
    loop: !0,
    trapped: l,
    onMountAutoFocus: s,
    onUnmountAutoFocus: c,
    children: /* @__PURE__ */ (0, g.jsx)(cu, {
      asChild: !0,
      disableOutsidePointerEvents: d,
      onInteractOutside: p,
      onEscapeKeyDown: h,
      onPointerDownOutside: m,
      onFocusOutside: y,
      onDismiss: () => w.onOpenChange(!1),
      children: /* @__PURE__ */ (0, g.jsx)(vb, {
        "data-state": Mb(w.open),
        role: "dialog",
        id: w.contentId,
        ...E,
        ..._,
        ref: a,
        style: {
          ..._.style,
          "--radix-popover-content-transform-origin": "var(--radix-popper-transform-origin)",
          "--radix-popover-content-available-width": "var(--radix-popper-available-width)",
          "--radix-popover-content-available-height": "var(--radix-popper-available-height)",
          "--radix-popover-trigger-width": "var(--radix-popper-anchor-width)",
          "--radix-popover-trigger-height": "var(--radix-popper-anchor-height)"
        }
      })
    })
  });
}), xb = "PopoverClose", Ob = b.forwardRef((e, a) => {
  const { __scopePopover: r, ...l } = e, s = li(xb, r);
  return /* @__PURE__ */ (0, g.jsx)(Dt.button, {
    type: "button",
    ...l,
    ref: a,
    onClick: wt(e.onClick, () => s.onOpenChange(!1))
  });
});
Ob.displayName = xb;
var d5 = "PopoverArrow", h5 = b.forwardRef((e, a) => {
  const { __scopePopover: r, ...l } = e, s = ol(r);
  return /* @__PURE__ */ (0, g.jsx)(gb, {
    ...s,
    ...l,
    ref: a
  });
});
h5.displayName = d5;
function Mb(e) {
  return e ? "open" : "closed";
}
var yu = bb, Eh = wb, Th = Eb, bu = Tb, _u = Cb, zd = Ob, Ch = "Switch", [m5, JM] = il(Ch), [p5, v5] = m5(Ch), Rb = b.forwardRef((e, a) => {
  const { __scopeSwitch: r, name: l, checked: s, defaultChecked: c, required: d, disabled: h, value: m = "on", onCheckedChange: y, form: p, ..._ } = e, [w, E] = b.useState(null), x = rn(a, (j) => E(j)), C = b.useRef(!1), T = w ? p || !!w.closest("form") : !0, [M = !1, D] = uu({
    prop: s,
    defaultProp: c,
    onChange: y
  });
  return /* @__PURE__ */ (0, g.jsxs)(p5, {
    scope: r,
    checked: M,
    disabled: h,
    children: [/* @__PURE__ */ (0, g.jsx)(Dt.button, {
      type: "button",
      role: "switch",
      "aria-checked": M,
      "aria-required": d,
      "data-state": zb(M),
      "data-disabled": h ? "" : void 0,
      disabled: h,
      value: m,
      ..._,
      ref: x,
      onClick: wt(e.onClick, (j) => {
        D((H) => !H), T && (C.current = j.isPropagationStopped(), C.current || j.stopPropagation());
      })
    }), T && /* @__PURE__ */ (0, g.jsx)(g5, {
      control: w,
      bubbles: !C.current,
      name: l,
      value: m,
      checked: M,
      required: d,
      disabled: h,
      form: p,
      style: { transform: "translateX(-100%)" }
    })]
  });
});
Rb.displayName = Ch;
var Nb = "SwitchThumb", Db = b.forwardRef((e, a) => {
  const { __scopeSwitch: r, ...l } = e, s = v5(Nb, r);
  return /* @__PURE__ */ (0, g.jsx)(Dt.span, {
    "data-state": zb(s.checked),
    "data-disabled": s.disabled ? "" : void 0,
    ...l,
    ref: a
  });
});
Db.displayName = Nb;
var g5 = (e) => {
  const { control: a, checked: r, bubbles: l = !0, ...s } = e, c = b.useRef(null), d = VA(r), h = qy(a);
  return b.useEffect(() => {
    const m = c.current, y = window.HTMLInputElement.prototype, p = Object.getOwnPropertyDescriptor(y, "checked").set;
    if (d !== r && p) {
      const _ = new Event("click", { bubbles: l });
      p.call(m, r), m.dispatchEvent(_);
    }
  }, [
    d,
    r,
    l
  ]), /* @__PURE__ */ (0, g.jsx)("input", {
    type: "checkbox",
    "aria-hidden": !0,
    defaultChecked: r,
    ...s,
    tabIndex: -1,
    ref: c,
    style: {
      ...e.style,
      ...h,
      position: "absolute",
      pointerEvents: "none",
      opacity: 0,
      margin: 0
    }
  });
};
function zb(e) {
  return e ? "checked" : "unchecked";
}
var y5 = Rb, b5 = Db, [wu, eR] = il("Tooltip", [gu]), Su = gu(), Lb = "TooltipProvider", _5 = 700, Ld = "tooltip.open", [w5, Ah] = wu(Lb), Hb = (e) => {
  const { __scopeTooltip: a, delayDuration: r = _5, skipDelayDuration: l = 300, disableHoverableContent: s = !1, children: c } = e, [d, h] = b.useState(!0), m = b.useRef(!1), y = b.useRef(0);
  return b.useEffect(() => {
    const p = y.current;
    return () => window.clearTimeout(p);
  }, []), /* @__PURE__ */ (0, g.jsx)(w5, {
    scope: a,
    isOpenDelayed: d,
    delayDuration: r,
    onOpen: b.useCallback(() => {
      window.clearTimeout(y.current), h(!1);
    }, []),
    onClose: b.useCallback(() => {
      window.clearTimeout(y.current), y.current = window.setTimeout(() => h(!0), l);
    }, [l]),
    isPointerInTransitRef: m,
    onPointerInTransitChange: b.useCallback((p) => {
      m.current = p;
    }, []),
    disableHoverableContent: s,
    children: c
  });
};
Hb.displayName = Lb;
var Eu = "Tooltip", [S5, ll] = wu(Eu), jb = (e) => {
  const { __scopeTooltip: a, children: r, open: l, defaultOpen: s = !1, onOpenChange: c, disableHoverableContent: d, delayDuration: h } = e, m = Ah(Eu, e.__scopeTooltip), y = Su(a), [p, _] = b.useState(null), w = Go(), E = b.useRef(0), x = d ?? m.disableHoverableContent, C = h ?? m.delayDuration, T = b.useRef(!1), [M = !1, D] = uu({
    prop: l,
    defaultProp: s,
    onChange: (Q) => {
      Q ? (m.onOpen(), document.dispatchEvent(new CustomEvent(Ld))) : m.onClose(), c?.(Q);
    }
  }), j = b.useMemo(() => M ? T.current ? "delayed-open" : "instant-open" : "closed", [M]), H = b.useCallback(() => {
    window.clearTimeout(E.current), E.current = 0, T.current = !1, D(!0);
  }, [D]), k = b.useCallback(() => {
    window.clearTimeout(E.current), E.current = 0, D(!1);
  }, [D]), B = b.useCallback(() => {
    window.clearTimeout(E.current), E.current = window.setTimeout(() => {
      T.current = !0, D(!0), E.current = 0;
    }, C);
  }, [C, D]);
  return b.useEffect(() => () => {
    E.current && (window.clearTimeout(E.current), E.current = 0);
  }, []), /* @__PURE__ */ (0, g.jsx)(pb, {
    ...y,
    children: /* @__PURE__ */ (0, g.jsx)(S5, {
      scope: a,
      contentId: w,
      open: M,
      stateAttribute: j,
      trigger: p,
      onTriggerChange: _,
      onTriggerEnter: b.useCallback(() => {
        m.isOpenDelayed ? B() : H();
      }, [
        m.isOpenDelayed,
        B,
        H
      ]),
      onTriggerLeave: b.useCallback(() => {
        x ? k() : (window.clearTimeout(E.current), E.current = 0);
      }, [k, x]),
      onOpen: H,
      onClose: k,
      disableHoverableContent: x,
      children: r
    })
  });
};
jb.displayName = Eu;
var Hd = "TooltipTrigger", Bb = b.forwardRef((e, a) => {
  const { __scopeTooltip: r, ...l } = e, s = ll(Hd, r), c = Ah(Hd, r), d = Su(r), h = rn(a, b.useRef(null), s.onTriggerChange), m = b.useRef(!1), y = b.useRef(!1), p = b.useCallback(() => m.current = !1, []);
  return b.useEffect(() => () => document.removeEventListener("pointerup", p), [p]), /* @__PURE__ */ (0, g.jsx)(_h, {
    asChild: !0,
    ...d,
    children: /* @__PURE__ */ (0, g.jsx)(Dt.button, {
      "aria-describedby": s.open ? s.contentId : void 0,
      "data-state": s.stateAttribute,
      ...l,
      ref: h,
      onPointerMove: wt(e.onPointerMove, (_) => {
        _.pointerType !== "touch" && !y.current && !c.isPointerInTransitRef.current && (s.onTriggerEnter(), y.current = !0);
      }),
      onPointerLeave: wt(e.onPointerLeave, () => {
        s.onTriggerLeave(), y.current = !1;
      }),
      onPointerDown: wt(e.onPointerDown, () => {
        m.current = !0, document.addEventListener("pointerup", p, { once: !0 });
      }),
      onFocus: wt(e.onFocus, () => {
        m.current || s.onOpen();
      }),
      onBlur: wt(e.onBlur, s.onClose),
      onClick: wt(e.onClick, s.onClose)
    })
  });
});
Bb.displayName = Hd;
var xh = "TooltipPortal", [E5, T5] = wu(xh, { forceMount: void 0 }), Ub = (e) => {
  const { __scopeTooltip: a, forceMount: r, children: l, container: s } = e, c = ll(xh, a);
  return /* @__PURE__ */ (0, g.jsx)(E5, {
    scope: a,
    forceMount: r,
    children: /* @__PURE__ */ (0, g.jsx)(oi, {
      present: r || c.open,
      children: /* @__PURE__ */ (0, g.jsx)(fu, {
        asChild: !0,
        container: s,
        children: l
      })
    })
  });
};
Ub.displayName = xh;
var Ur = "TooltipContent", kb = b.forwardRef((e, a) => {
  const r = T5(Ur, e.__scopeTooltip), { forceMount: l = r.forceMount, side: s = "top", ...c } = e, d = ll(Ur, e.__scopeTooltip);
  return /* @__PURE__ */ (0, g.jsx)(oi, {
    present: l || d.open,
    children: d.disableHoverableContent ? /* @__PURE__ */ (0, g.jsx)(Pb, {
      side: s,
      ...c,
      ref: a
    }) : /* @__PURE__ */ (0, g.jsx)(C5, {
      side: s,
      ...c,
      ref: a
    })
  });
}), C5 = b.forwardRef((e, a) => {
  const r = ll(Ur, e.__scopeTooltip), l = Ah(Ur, e.__scopeTooltip), s = b.useRef(null), c = rn(a, s), [d, h] = b.useState(null), { trigger: m, onClose: y } = r, p = s.current, { onPointerInTransitChange: _ } = l, w = b.useCallback(() => {
    h(null), _(!1);
  }, [_]), E = b.useCallback((x, C) => {
    const T = x.currentTarget, M = {
      x: x.clientX,
      y: x.clientY
    }, D = R5(M, M5(M, T.getBoundingClientRect())), j = N5(C.getBoundingClientRect());
    h(z5([...D, ...j])), _(!0);
  }, [_]);
  return b.useEffect(() => () => w(), [w]), b.useEffect(() => {
    if (m && p) {
      const x = (T) => E(T, p), C = (T) => E(T, m);
      return m.addEventListener("pointerleave", x), p.addEventListener("pointerleave", C), () => {
        m.removeEventListener("pointerleave", x), p.removeEventListener("pointerleave", C);
      };
    }
  }, [
    m,
    p,
    E,
    w
  ]), b.useEffect(() => {
    if (d) {
      const x = (C) => {
        const T = C.target, M = {
          x: C.clientX,
          y: C.clientY
        }, D = m?.contains(T) || p?.contains(T), j = !D5(M, d);
        D ? w() : j && (w(), y());
      };
      return document.addEventListener("pointermove", x), () => document.removeEventListener("pointermove", x);
    }
  }, [
    m,
    p,
    d,
    y,
    w
  ]), /* @__PURE__ */ (0, g.jsx)(Pb, {
    ...e,
    ref: c
  });
}), [A5, x5] = wu(Eu, { isInside: !1 }), Pb = b.forwardRef((e, a) => {
  const { __scopeTooltip: r, children: l, "aria-label": s, onEscapeKeyDown: c, onPointerDownOutside: d, ...h } = e, m = ll(Ur, r), y = Su(r), { onClose: p } = m;
  return b.useEffect(() => (document.addEventListener(Ld, p), () => document.removeEventListener(Ld, p)), [p]), b.useEffect(() => {
    if (m.trigger) {
      const _ = (w) => {
        w.target?.contains(m.trigger) && p();
      };
      return window.addEventListener("scroll", _, { capture: !0 }), () => window.removeEventListener("scroll", _, { capture: !0 });
    }
  }, [m.trigger, p]), /* @__PURE__ */ (0, g.jsx)(cu, {
    asChild: !0,
    disableOutsidePointerEvents: !1,
    onEscapeKeyDown: c,
    onPointerDownOutside: d,
    onFocusOutside: (_) => _.preventDefault(),
    onDismiss: p,
    children: /* @__PURE__ */ (0, g.jsxs)(vb, {
      "data-state": m.stateAttribute,
      ...y,
      ...h,
      ref: a,
      style: {
        ...h.style,
        "--radix-tooltip-content-transform-origin": "var(--radix-popper-transform-origin)",
        "--radix-tooltip-content-available-width": "var(--radix-popper-available-width)",
        "--radix-tooltip-content-available-height": "var(--radix-popper-available-height)",
        "--radix-tooltip-trigger-width": "var(--radix-popper-anchor-width)",
        "--radix-tooltip-trigger-height": "var(--radix-popper-anchor-height)"
      },
      children: [/* @__PURE__ */ (0, g.jsx)(_y, { children: l }), /* @__PURE__ */ (0, g.jsx)(A5, {
        scope: r,
        isInside: !0,
        children: /* @__PURE__ */ (0, g.jsx)(rh, {
          id: m.contentId,
          role: "tooltip",
          children: s || l
        })
      })]
    })
  });
});
kb.displayName = Ur;
var Ib = "TooltipArrow", O5 = b.forwardRef((e, a) => {
  const { __scopeTooltip: r, ...l } = e, s = Su(r);
  return x5(Ib, r).isInside ? null : /* @__PURE__ */ (0, g.jsx)(gb, {
    ...s,
    ...l,
    ref: a
  });
});
O5.displayName = Ib;
function M5(e, a) {
  const r = Math.abs(a.top - e.y), l = Math.abs(a.bottom - e.y), s = Math.abs(a.right - e.x), c = Math.abs(a.left - e.x);
  switch (Math.min(r, l, s, c)) {
    case c:
      return "left";
    case s:
      return "right";
    case r:
      return "top";
    case l:
      return "bottom";
    default:
      throw new Error("unreachable");
  }
}
function R5(e, a, r = 5) {
  const l = [];
  switch (a) {
    case "top":
      l.push({
        x: e.x - r,
        y: e.y + r
      }, {
        x: e.x + r,
        y: e.y + r
      });
      break;
    case "bottom":
      l.push({
        x: e.x - r,
        y: e.y - r
      }, {
        x: e.x + r,
        y: e.y - r
      });
      break;
    case "left":
      l.push({
        x: e.x + r,
        y: e.y - r
      }, {
        x: e.x + r,
        y: e.y + r
      });
      break;
    case "right":
      l.push({
        x: e.x - r,
        y: e.y - r
      }, {
        x: e.x - r,
        y: e.y + r
      });
      break;
  }
  return l;
}
function N5(e) {
  const { top: a, right: r, bottom: l, left: s } = e;
  return [
    {
      x: s,
      y: a
    },
    {
      x: r,
      y: a
    },
    {
      x: r,
      y: l
    },
    {
      x: s,
      y: l
    }
  ];
}
function D5(e, a) {
  const { x: r, y: l } = e;
  let s = !1;
  for (let c = 0, d = a.length - 1; c < a.length; d = c++) {
    const h = a[c].x, m = a[c].y, y = a[d].x, p = a[d].y;
    m > l != p > l && r < (y - h) * (l - m) / (p - m) + h && (s = !s);
  }
  return s;
}
function z5(e) {
  const a = e.slice();
  return a.sort((r, l) => r.x < l.x ? -1 : r.x > l.x ? 1 : r.y < l.y ? -1 : r.y > l.y ? 1 : 0), L5(a);
}
function L5(e) {
  if (e.length <= 1) return e.slice();
  const a = [];
  for (let l = 0; l < e.length; l++) {
    const s = e[l];
    for (; a.length >= 2; ) {
      const c = a[a.length - 1], d = a[a.length - 2];
      if ((c.x - d.x) * (s.y - d.y) >= (c.y - d.y) * (s.x - d.x)) a.pop();
      else break;
    }
    a.push(s);
  }
  a.pop();
  const r = [];
  for (let l = e.length - 1; l >= 0; l--) {
    const s = e[l];
    for (; r.length >= 2; ) {
      const c = r[r.length - 1], d = r[r.length - 2];
      if ((c.x - d.x) * (s.y - d.y) >= (c.y - d.y) * (s.x - d.x)) r.pop();
      else break;
    }
    r.push(s);
  }
  return r.pop(), a.length === 1 && r.length === 1 && a[0].x === r[0].x && a[0].y === r[0].y ? a : a.concat(r);
}
var H5 = Hb, j5 = jb, Zb = Bb, B5 = Ub, U5 = kb;
function Gs(e) {
  const a = (0, b.useRef)(e);
  return a.current = e, a;
}
var kr = [], Bs = !1, M1 = (e) => {
  if (e.key === "Escape") {
    const [a] = kr;
    a && (e.preventDefault(), a.callback.current?.());
  }
}, Gb = () => {
  kr.length > 0 && !Bs ? (document.body.addEventListener("keydown", M1), Bs = !0) : kr.length === 0 && Bs && (document.body.removeEventListener("keydown", M1), Bs = !1);
}, k5 = (e) => {
  kr.unshift(e), Gb();
}, P5 = ({ id: e }) => {
  kr = kr.filter((a) => a.id !== e), Gb();
}, I5 = (e, a) => {
  const r = (0, b.useId)(), l = Gs(a);
  (0, b.useEffect)(() => {
    if (!e) return;
    const s = {
      id: r,
      callback: l
    };
    return k5(s), () => P5(s);
  }, [
    r,
    e,
    l
  ]);
}, Z5 = (e) => {
  e.preventDefault();
}, Vb = (0, b.createContext)(void 0);
function $b({ children: e, container: a }) {
  return /* @__PURE__ */ (0, g.jsx)(Vb.Provider, {
    value: a,
    children: e
  });
}
function sl() {
  return (0, b.useContext)(Vb);
}
var G5 = "_Tooltip_arpo7_1", V5 = "_TriggerDecorator_arpo7_86", Fb = {
  Tooltip: G5,
  "scale-in": "_scale-in_arpo7_1",
  "scale-out": "_scale-out_arpo7_1",
  TriggerDecorator: V5
}, Vn = (e) => {
  const { ref: a, portalContainer: r, onDismiss: l, onOpenChange: s, onContentPointerEnter: c, onContentPointerLeave: d, children: h, content: m, forceOpen: y = m === null ? !1 : void 0, maxWidth: p = 300, openDelay: _ = 150, interactive: w = !1, compact: E = !1, preventUnintentionalClickToClose: x, align: C, alignOffset: T = 0, side: M, sideOffset: D = 5, gutterSize: j = "md", contentClassName: H, onPointerDown: k, onClick: B, ...Q } = e, [K, q] = (0, b.useState)(!1), [F, ee] = (0, b.useState)(!1);
  (0, b.useEffect)(() => {
    if (!F) return;
    const se = window.setTimeout(() => ee(!1), 400);
    return () => window.clearTimeout(se);
  }, [F]);
  const ce = y ?? K, V = (se) => {
    s?.(se), typeof y != "boolean" && (q(se), x && ee(se));
  }, ie = (se) => {
    x && F && (se.preventDefault(), se.stopPropagation());
  };
  return /* @__PURE__ */ (0, g.jsxs)(qb, {
    onDismiss: l,
    open: ce,
    delayDuration: _,
    onOpenChange: V,
    disableHoverableContent: !w,
    children: [/* @__PURE__ */ (0, g.jsx)(Zb, {
      asChild: !0,
      children: /* @__PURE__ */ (0, g.jsx)(wy, {
        ...Q,
        ref: a,
        onPointerDown: (se) => {
          ie(se), k?.(se);
        },
        onClick: (se) => {
          ie(se), B?.(se);
        },
        children: h
      })
    }), /* @__PURE__ */ (0, g.jsx)(Xb, {
      portalContainer: r,
      maxWidth: p,
      compact: E,
      align: C,
      alignOffset: T,
      side: M,
      sideOffset: D,
      gutterSize: j,
      className: H,
      onPointerEnter: c,
      onPointerLeave: d,
      children: m
    })]
  });
}, qb = ({ onDismiss: e, children: a, open: r, onOpenChange: l, ...s }) => (I5(r, () => {
  l(!1), e?.();
}), /* @__PURE__ */ (0, g.jsx)(H5, { children: /* @__PURE__ */ (0, g.jsx)(j5, {
  open: r,
  onOpenChange: l,
  ...s,
  children: a
}) })), Xb = ({ children: e, portalContainer: a, maxWidth: r = 300, compact: l = !1, clickable: s = void 0, alignOffset: c = 0, sideOffset: d = 5, gutterSize: h = "md", className: m, style: y, ...p }) => {
  const _ = sl();
  return /* @__PURE__ */ (0, g.jsx)(B5, {
    container: a ?? _,
    children: /* @__PURE__ */ (0, g.jsx)(U5, {
      ...p,
      className: Be(Fb.Tooltip, m),
      "data-compact": l,
      "data-clickable": s,
      "data-gutter-size": h,
      alignOffset: c,
      sideOffset: d,
      collisionPadding: 15,
      hideWhenDetached: !0,
      style: {
        ...y,
        maxWidth: r
      },
      onEscapeKeyDown: Z5,
      children: e
    })
  });
}, $5 = ({ children: e, asChild: a = !0, ...r }) => /* @__PURE__ */ (0, g.jsx)(Zb, {
  asChild: a,
  ...r,
  children: e
}), F5 = (e) => {
  const { children: a, className: r, focusable: l = !0, ref: s, ...c } = e, d = typeof a == "string";
  return /* @__PURE__ */ (0, g.jsx)(wy, {
    ref: s,
    ...c,
    className: Be(Fb.TriggerDecorator, r),
    tabIndex: l ? 0 : void 0,
    children: d ? /* @__PURE__ */ (0, g.jsx)("span", { children: a }) : a
  });
};
Vn.Root = qb;
Vn.Content = Xb;
Vn.Trigger = $5;
Vn.TriggerDecorator = F5;
var q5 = "_Layout_1a5g1_1", X5 = "_TransitionItem_1a5g1_34", R1 = {
  Layout: q5,
  TransitionItem: X5
};
function Y5(e) {
  const { as: a = "span", children: r, transitionClassName: l, insertMethod: s, className: c, hideOverflow: d = !1, preventInitialTransition: h = !0, disableAnimations: m, itemAnchor: y = "start", dimension: p = "height", enterFromSize: _, resizeContents: w = !1 } = e, E = (0, b.useRef)(null), x = (0, b.useRef)(null), C = (0, b.useRef)(null), T = (0, b.useRef)(null), { enterTotalDuration: M, exitTotalDuration: D, variables: j } = J5(e), H = (F) => {
    const ee = E.current;
    if (!ee) return;
    w ? (delete ee.dataset.resizeContents, C.current = p === "width" ? F.clientWidth : F.clientHeight, ee.dataset.resizeContents = "") : C.current = null;
    const ce = T.current !== null && Date.now() - T.current < 50, V = x.current !== null;
    if (x.current = F, ee.dataset.direction = ce || V ? "move" : "in", ce || (ee.dataset.interrupted = String(!!ee.style[p])), _ !== void 0) {
      const ie = ee.style.transition;
      ee.style.transition = "none", ee.style[p] = `${_}px`, ee.offsetWidth, ee.style.transition = ie;
    } else ee.style[p] = `${ee.getBoundingClientRect()[p]}px`;
  }, k = (F) => {
    const ee = E.current;
    if (!ee || x.current !== F) return;
    const ce = C.current ?? (p === "width" ? F.clientWidth : F.clientHeight);
    ee.style[p] = `${ce}px`;
  }, B = (F) => {
    const ee = E.current;
    qs(() => {
      ee && x.current === F && (delete ee.dataset.resizeContents, ee.style[p] = "");
    });
  }, Q = (F) => {
    const ee = E.current, ce = !x.current || x.current === F;
    !ee || !ce || (delete ee.dataset.resizeContents, x.current = null, T.current = Date.now(), ee.dataset.direction = "out", ee.dataset.interrupted = String(!!ee.style[p]), ee.style[p] = `${ee.getBoundingClientRect()[p]}px`);
  }, K = () => {
    const F = E.current;
    F && !x.current && (F.style[p] = "0");
  }, q = () => {
    qs(() => {
      const F = E.current;
      F && !x.current && (F.style[p] = "");
    });
  };
  return /* @__PURE__ */ (0, g.jsx)(a, {
    ref: E,
    className: Be(R1.Layout, c),
    style: j,
    "data-item-anchor": y,
    "data-clip": d,
    "data-dimension": p,
    children: /* @__PURE__ */ (0, g.jsx)(Wo, {
      as: a,
      className: Be(R1.TransitionItem, l),
      insertMethod: s,
      enterDuration: M,
      exitDuration: D,
      preventInitialTransition: h,
      disableAnimations: m,
      onEnter: H,
      onEnterActive: k,
      onEnterComplete: B,
      onExit: Q,
      onExitActive: K,
      onExitComplete: q,
      children: r
    })
  });
}
var od = 300, W5 = 300, Q5 = 100, K5 = 200;
function J5({ initial: e, enter: a, exit: r, forceCompositeLayer: l, layoutEnter: s, layoutExit: c, layoutMove: d }) {
  const h = Yf(e), m = Yf(a), y = Yf(r), p = [
    h,
    m,
    y
  ].some((B) => B !== "none"), _ = a?.duration ?? W5, w = r?.duration ?? K5, E = a?.delay ?? Q5, x = r?.delay ?? 0, C = s?.duration ?? od, T = c?.duration ?? od, M = d?.duration ?? od, D = s?.delay ?? 0, j = c?.delay ?? 0, H = d?.delay ?? 0, k = K4({
    "tg-will-change": l ? "transform, opacity" : "auto",
    "tg-enter-opacity": qf(a?.opacity ?? 1),
    "tg-enter-transform": m,
    "tg-enter-filter": Wf(a),
    "tg-enter-duration": Qn(_),
    "tg-enter-delay": Qn(E),
    "tg-enter-timing-function": a?.timingFunction ?? (p ? "var(--cubic-enter)" : "ease"),
    "tg-exit-opacity": qf(r?.opacity ?? 0),
    "tg-exit-transform": y,
    "tg-exit-filter": Wf(r),
    "tg-exit-duration": Qn(w),
    "tg-exit-delay": Qn(x),
    "tg-exit-timing-function": r?.timingFunction ?? (p ? "var(--cubic-exit)" : "ease"),
    "tg-initial-opacity": qf(e?.opacity ?? r?.opacity ?? 0),
    "tg-initial-transform": h === "none" ? y : h,
    "tg-initial-filter": Wf(e ?? r),
    "tg-layout-enter-duration": Qn(C),
    "tg-layout-enter-delay": Qn(D),
    "tg-layout-enter-timing-function": s?.timingFunction ?? "var(--cubic-move)",
    "tg-layout-exit-duration": Qn(T),
    "tg-layout-exit-delay": Qn(j),
    "tg-layout-exit-timing-function": c?.timingFunction ?? "var(--cubic-move)",
    "tg-layout-move-duration": Qn(M),
    "tg-layout-move-delay": Qn(H),
    "tg-layout-move-timing-function": d?.timingFunction ?? "var(--cubic-move)"
  });
  return {
    enterTotalDuration: Math.max(E + _, D + C, H + M),
    exitTotalDuration: Math.max(x + w, j + T, H + M),
    variables: k
  };
}
var e8 = "_Theme_1ewnz_2", t8 = "_Portal_1ewnz_35", n8 = "_Tooltip_1ewnz_41", a8 = "_SharingTooltip_1ewnz_51", i8 = "_HideHint_1ewnz_58", r8 = "_SharingHint_1ewnz_68", o8 = "_HideHintContent_1ewnz_74", l8 = "_HideHintText_1ewnz_80", s8 = "_Shortcut_1ewnz_85", Ft = {
  Theme: e8,
  Portal: t8,
  Tooltip: n8,
  SharingTooltip: a8,
  HideHint: i8,
  SharingHint: r8,
  HideHintContent: o8,
  HideHintText: l8,
  Shortcut: s8
}, u8 = "_Widget_1oafq_1", c8 = "_LandingShadow_1oafq_46", f8 = "_WidgetEntrance_1oafq_56", d8 = "_WidgetExit_1oafq_69", h8 = "_Shell_1oafq_82", m8 = "_ToolbarPanel_1oafq_115", p8 = "_ShellControls_1oafq_120", v8 = "_Launcher_1oafq_130", g8 = "_LauncherRow_1oafq_153", y8 = "_LauncherLabel_1oafq_157", b8 = "_CornerTarget_1oafq_167", _8 = "_Panel_1oafq_203", w8 = "_LogoButton_1oafq_203", S8 = "_ShellContent_1oafq_248", E8 = "_ShellLayout_1oafq_252", T8 = "_LauncherLogo_1oafq_325", C8 = "_blossomEntrance_1oafq_1", A8 = "_Composer_1oafq_361", x8 = "_Textarea_1oafq_377", O8 = "_ComposerFooter_1oafq_415", M8 = "_ComposerTooltip_1oafq_420", R8 = "_ComposerArrow_1oafq_426", N8 = "_SendButton_1oafq_439", D8 = "_LauncherDismissButton_1oafq_494", z8 = "_SharingClose_1oafq_596", je = {
  Widget: u8,
  LandingShadow: c8,
  WidgetEntrance: f8,
  WidgetExit: d8,
  Shell: h8,
  ToolbarPanel: m8,
  ShellControls: p8,
  Launcher: v8,
  LauncherRow: g8,
  LauncherLabel: y8,
  CornerTarget: b8,
  Panel: _8,
  LogoButton: w8,
  ShellContent: S8,
  ShellLayout: E8,
  LauncherLogo: T8,
  blossomEntrance: C8,
  Composer: A8,
  Textarea: x8,
  ComposerFooter: O8,
  ComposerTooltip: M8,
  ComposerArrow: R8,
  SendButton: N8,
  LauncherDismissButton: D8,
  SharingClose: z8
};
function Yb({ storage: e, reducedMotion: a = !1, initiallyHidden: r = !1 } = {}) {
  const l = su(e);
  return qd()((s, c) => {
    const d = (h) => {
      s((m) => {
        const y = h(m.state);
        return y === m.state ? m : {
          state: y,
          showHideHint: (y.view === "hiding" || y.view === "hidden") && m.showHideHint,
          showLogoEntrance: y.view === "launcher" && m.showLogoEntrance
        };
      });
    };
    return {
      state: {
        view: r ? "hidden" : "launcher",
        draft: ""
      },
      composerMode: "edit",
      corner: l.read(qt.editorWidgetCorner),
      hasInteracted: l.read(qt.editorWidgetInteracted),
      hasSeenHideHint: l.read(qt.editorWidgetHideHintSeen),
      showHideHint: !1,
      showLogoEntrance: !r && !a,
      actions: {
        setCorner: (h) => {
          c().corner !== h && s({ corner: h }), l.write(qt.editorWidgetCorner, h);
        },
        markInteracted: () => {
          c().hasInteracted || (s({ hasInteracted: !0 }), l.write(qt.editorWidgetInteracted, !0));
        },
        markHideHintSeen: () => {
          const h = c();
          h.hasSeenHideHint || !h.showHideHint || h.state.view !== "hidden" || (s({ hasSeenHideHint: !0 }), l.write(qt.editorWidgetHideHintSeen, !0));
        },
        finishLogoEntrance: () => {
          c().showLogoEntrance && s({ showLogoEntrance: !1 });
        },
        open: (h = "edit") => s((m) => m.state.view === "launcher" ? {
          state: {
            ...m.state,
            view: "composer"
          },
          composerMode: h,
          showHideHint: !1,
          showLogoEntrance: !1
        } : m),
        collapse: () => d((h) => h.view === "composer" ? {
          ...h,
          view: "launcher"
        } : h),
        changeDraft: (h) => d((m) => m.view === "composer" ? {
          ...m,
          draft: h
        } : m),
        hide: () => s((h) => {
          const { state: m } = h;
          return m.view !== "launcher" && m.view !== "composer" ? h : {
            state: {
              ...m,
              view: "hiding"
            },
            showHideHint: !h.hasSeenHideHint,
            showLogoEntrance: !1
          };
        }),
        dismiss: () => d((h) => h.view === "launcher" || h.view === "composer" ? {
          ...h,
          view: "dismissed"
        } : h),
        finishHide: () => d((h) => h.view === "hiding" ? {
          ...h,
          view: "hidden"
        } : h),
        restoreHidden: () => d((h) => h.view === "hiding" || h.view === "hidden" ? {
          view: "launcher",
          draft: h.draft
        } : h),
        beginHandoff: ({ allowEmpty: h = !1 } = {}) => {
          const { state: m } = c();
          return m.view !== "composer" || !h && !m.draft.trim() ? null : (s({ state: {
            view: "handoff",
            request: m.draft
          } }), m.draft);
        },
        finishHandoff: () => d((h) => h.view === "handoff" ? {
          view: "launcher",
          draft: h.request
        } : h)
      }
    };
  });
}
var L8 = 1e3, N1 = 3e3, H8 = 480, j8 = 1500, B8 = 2e3, U8 = 150;
function k8(e, a, r, l = !1) {
  const [s, c] = (0, b.useState)(e && a ? "away" : "tucked"), [d, h] = (0, b.useState)(!1), [m, y] = (0, b.useState)(!1), [p, _] = (0, b.useState)(!1), [w, E] = (0, b.useState)(e && a), [x, C] = (0, b.useState)(!1), [T, M] = (0, b.useState)(!1), D = (0, b.useRef)(!0), j = (0, b.useRef)(e && a), H = d || p;
  return (0, b.useEffect)(() => {
    if (!e) {
      C(!1), M(!1);
      return;
    }
    if (T) return;
    if (x) {
      if (d || m) return;
      const B = window.setTimeout(() => C(!1), U8);
      return () => window.clearTimeout(B);
    }
    if (!d) return;
    const k = window.setTimeout(() => C(!0), B8);
    return () => window.clearTimeout(k);
  }, [
    e,
    d,
    m,
    x,
    T
  ]), (0, b.useEffect)(() => {
    if (!e) {
      D.current = !0, j.current = !1, c("tucked"), h(!1), y(!1), _(!1), E(!1);
      return;
    }
    if (H) {
      j.current = !1, D.current = !1, E(!0), c("expanded");
      return;
    }
    if (m || j.current || (c("tucked"), !a)) return;
    if (r) {
      if (D.current = !1, l) {
        const B = window.setTimeout(() => c("away"), N1);
        return () => window.clearTimeout(B);
      }
      c("away");
      return;
    }
    const k = [];
    return D.current ? k.push(window.setTimeout(() => {
      D.current = !1, c("expanded"), k.push(window.setTimeout(() => c("away"), H8));
    }, l ? N1 : L8)) : k.push(window.setTimeout(() => c("away"), j8)), () => k.forEach((B) => window.clearTimeout(B));
  }, [
    e,
    a,
    H,
    m,
    r,
    l
  ]), {
    phase: s,
    quiet: w,
    hoverHintVisible: x,
    hintDismissed: T,
    dismissHint: () => {
      M(!0), C(!1), y(!1);
    },
    hintHandlers: {
      onContentPointerEnter: (k) => {
        k.pointerType !== "touch" && y(!0);
      },
      onContentPointerLeave: () => y(!1)
    },
    targetHandlers: {
      onPointerEnter: (k) => {
        k.pointerType !== "touch" && (M(!1), h(!0));
      },
      onPointerLeave: () => h(!1),
      onFocus: () => _(!0),
      onBlur: () => _(!1)
    }
  };
}
var P8 = [
  "bottom-center",
  "top-left",
  "top-right",
  "bottom-left",
  "bottom-right"
], I8 = 1.25;
function Oh(e, a) {
  return {
    x: e === "bottom-center" ? (a.left + a.right) / 2 : e.endsWith("left") ? a.left : a.right,
    y: e.startsWith("top") ? a.top : a.bottom
  };
}
function Wb(e, a) {
  let r = "bottom-center", l = 1 / 0;
  for (const s of P8) {
    const c = Oh(s, a), d = s === "bottom-center" ? I8 : 1, h = Math.hypot(e.x - c.x, e.y - c.y) / d;
    h < l && (r = s, l = h);
  }
  return r;
}
var Z8 = 100, D1 = 200, G8 = 0.6;
function z1(e, a, r, l, s = []) {
  const c = s.at(-1), d = c && s.find((h) => c.time - h.time <= Z8);
  if (d && c && c.time > d.time) {
    const h = c.time - d.time, m = (c.x - d.x) / h, y = (c.y - d.y) / h;
    Math.hypot(m, y) >= G8 && (e = Math.max(0, Math.min(r, e + m * D1)), a = Math.max(0, Math.min(l, a + y * D1)));
  }
  return a < l / 2 ? e < r / 2 ? "top-left" : "top-right" : Wb({
    x: e,
    y: a
  }, {
    left: 0,
    top: 0,
    right: r,
    bottom: l
  });
}
var V8 = 5, $8 = 520, F8 = 12, q8 = 20, X8 = 137, Y8 = 36, Po = 32, L1 = 280, W8 = 20;
function Q8({ corner: e, onCornerChange: a, onInteract: r, anchorSharingClose: l = !1, preserveChildClickTargets: s = !1, enableMomentum: c = !1 }) {
  const [d, h] = (0, b.useState)(null), [m, y] = (0, b.useState)(null), [p, _] = (0, b.useState)(null), [w, E] = (0, b.useState)(!1), [x, C] = (0, b.useState)({
    width: X8,
    height: Y8,
    viewportWidth: window.innerWidth,
    viewportHeight: window.innerHeight
  }), T = (0, b.useRef)(null), M = (0, b.useRef)(null), D = (0, b.useRef)(!1), j = x.viewportWidth <= $8 ? F8 : q8;
  (0, b.useLayoutEffect)(() => {
    function L() {
      const N = m?.getBoundingClientRect();
      C((te) => {
        const oe = {
          width: N?.width ?? te.width,
          height: N?.height ?? te.height,
          viewportWidth: window.innerWidth,
          viewportHeight: window.innerHeight
        };
        return oe.width === te.width && oe.height === te.height && oe.viewportWidth === te.viewportWidth && oe.viewportHeight === te.viewportHeight ? te : oe;
      });
    }
    L();
    const A = new ResizeObserver(() => (0, Zr.flushSync)(L));
    return m && A.observe(m), window.addEventListener("resize", L), () => {
      A.disconnect(), window.removeEventListener("resize", L);
    };
  }, [m]), (0, b.useLayoutEffect)(() => () => {
    M.current !== null && window.clearTimeout(M.current);
  }, []);
  function H() {
    M.current !== null && window.clearTimeout(M.current), E(!0), M.current = window.setTimeout(() => {
      M.current = null, E(!1);
    }, L1 + W8);
  }
  function k(L) {
    return Oh(L, {
      left: j,
      top: j,
      right: Math.max(j, x.viewportWidth - x.width - j),
      bottom: Math.max(j, x.viewportHeight - x.height - j)
    });
  }
  function B(L) {
    if (L.pointerType === "touch" || L.button !== 0 || !L.isPrimary || T.current) return;
    const A = d?.getBoundingClientRect();
    A && (D.current = !1, M.current !== null && window.clearTimeout(M.current), M.current = null, E(!1), T.current = {
      pointerId: L.pointerId,
      x: L.clientX,
      y: L.clientY,
      start: {
        x: A.x,
        y: A.y
      },
      moved: !1,
      samples: [{
        x: L.clientX,
        y: L.clientY,
        time: L.timeStamp
      }]
    }, (s && L.target instanceof Element ? L.target : L.currentTarget).setPointerCapture(L.pointerId));
  }
  function Q(L) {
    const A = T.current;
    if (!A || A.pointerId !== L.pointerId) return;
    A.samples.push({
      x: L.clientX,
      y: L.clientY,
      time: L.timeStamp
    }), A.samples.length > 12 && A.samples.shift();
    const N = L.clientX - A.x, te = L.clientY - A.y;
    !A.moved && Math.hypot(N, te) < V8 || (A.moved || (s && L.currentTarget.setPointerCapture(L.pointerId), r()), A.moved = !0, _(K(A, L)));
  }
  function K(L, A) {
    return {
      x: Math.max(0, Math.min(L.start.x + A.clientX - L.x, x.viewportWidth - x.width)),
      y: Math.max(0, Math.min(L.start.y + A.clientY - L.y, x.viewportHeight - x.height))
    };
  }
  function q(L) {
    const A = T.current;
    if (!(!A || A.pointerId !== L.pointerId)) {
      if (T.current = null, D.current = A.moved, A.moved) {
        const N = K(A, L);
        a(z1(N.x + x.width / 2, N.y + x.height / 2, x.viewportWidth, x.viewportHeight, c ? [...A.samples, {
          x: L.clientX,
          y: L.clientY,
          time: L.timeStamp
        }] : void 0)), H(), _(null);
      }
      L.currentTarget.hasPointerCapture(L.pointerId) && L.currentTarget.releasePointerCapture(L.pointerId);
    }
  }
  function F(L) {
    !T.current || T.current.pointerId !== L.pointerId || (D.current = T.current.moved, T.current = null, H(), _(null), L.currentTarget.hasPointerCapture(L.pointerId) && L.currentTarget.releasePointerCapture(L.pointerId));
  }
  function ee(L) {
    D.current && L.detail !== 0 && (L.preventDefault(), L.stopPropagation()), D.current = !1;
  }
  function ce(L) {
    if (L.altKey || L.ctrlKey || L.metaKey || L.shiftKey || T.current) return;
    let A;
    switch (L.key) {
      case "ArrowLeft":
        A = e.startsWith("top") ? "top-left" : e === "bottom-right" ? "bottom-center" : "bottom-left";
        break;
      case "ArrowRight":
        A = e.startsWith("top") ? "top-right" : e === "bottom-left" ? "bottom-center" : "bottom-right";
        break;
      case "ArrowUp":
        A = e.endsWith("left") ? "top-left" : "top-right";
        break;
      case "ArrowDown":
        A = e === "bottom-center" ? e : e.endsWith("left") ? "bottom-left" : "bottom-right";
        break;
      default:
        return;
    }
    L.preventDefault(), r(), a(A), H();
  }
  const V = p ?? k(e), ie = k(p ? z1(p.x + x.width / 2, p.y + x.height / 2, x.viewportWidth, x.viewportHeight) : e), se = e === "bottom-center" ? x.viewportWidth / 2 - Po : e.endsWith("left") ? -Po : x.viewportWidth - Po;
  return {
    widgetRef: h,
    contentRef: y,
    snapping: w,
    dragging: p !== null,
    style: {
      left: V.x,
      top: V.y,
      ...l && e.endsWith("right") && {
        left: "auto",
        right: j
      },
      ...l && e === "bottom-center" && {
        left: "50%",
        translate: "-50% 0"
      },
      "--widget-snap-duration": `${L1}ms`,
      "--widget-surface-width": `${x.width}px`,
      "--widget-surface-height": `${x.height}px`,
      "--corner-x-direction": e === "bottom-center" ? 0 : e.endsWith("left") ? -1 : 1,
      "--corner-y-direction": e.startsWith("top") ? -1 : 1,
      "--tuck-x": `${se - V.x}px`,
      "--tuck-y": `${(e.startsWith("top") ? -Po : x.viewportHeight - Po) - V.y}px`
    },
    shadowStyle: {
      left: ie.x,
      top: ie.y,
      width: x.width,
      height: x.height
    },
    dragHandlers: {
      onPointerDown: B,
      onPointerMove: Q,
      onPointerUp: q,
      onPointerCancel: F,
      onLostPointerCapture(L) {
        (!s || L.target === L.currentTarget) && F(L);
      },
      onClickCapture: ee,
      onKeyDown: ce
    }
  };
}
var Qb = "(prefers-reduced-motion: reduce)";
function K8(e) {
  const a = window.matchMedia(Qb);
  return a.addEventListener("change", e), () => a.removeEventListener("change", e);
}
function J8() {
  return window.matchMedia(Qb).matches;
}
function Kb() {
  return (0, b.useSyncExternalStore)(K8, J8);
}
var Jb = "(hover: hover) and (pointer: fine)";
function ex(e) {
  const a = window.matchMedia(Jb);
  return a.addEventListener("change", e), () => a.removeEventListener("change", e);
}
function tx() {
  return window.matchMedia(Jb).matches;
}
function nx() {
  return (0, b.useSyncExternalStore)(ex, tx);
}
function ax(e) {
  return /* @__PURE__ */ (0, g.jsx)("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    ...e,
    children: /* @__PURE__ */ (0, g.jsx)("path", { d: "M12 3C12.2652 3 12.5196 3.10536 12.7071 3.29289L19.7071 10.2929C20.0976 10.6834 20.0976 11.3166 19.7071 11.7071C19.3166 12.0976 18.6834 12.0976 18.2929 11.7071L13 6.41421V20C13 20.5523 12.5523 21 12 21C11.4477 21 11 20.5523 11 20V6.41422L5.70711 11.7071C5.31658 12.0976 4.68342 12.0976 4.29289 11.7071C3.90237 11.3166 3.90237 10.6834 4.29289 10.2929L11.2929 3.29289C11.4804 3.10536 11.7348 3 12 3Z" })
  });
}
function ai(e) {
  return /* @__PURE__ */ (0, g.jsx)("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    ...e,
    children: /* @__PURE__ */ (0, g.jsx)("path", {
      fillRule: "evenodd",
      d: "M5.636 5.636a1 1 0 0 1 1.414 0l4.95 4.95 4.95-4.95a1 1 0 0 1 1.414 1.414L13.414 12l4.95 4.95a1 1 0 0 1-1.414 1.414L12 13.414l-4.95 4.95a1 1 0 0 1-1.414-1.414l4.95-4.95-4.95-4.95a1 1 0 0 1 0-1.414Z",
      clipRule: "evenodd"
    })
  });
}
function ix({ accountId: e, chatgptOrigin: a, projectId: r }) {
  const l = new URL(r ? `/sites/${encodeURIComponent(r)}/edit` : "/sites", a);
  return r && e && l.searchParams.set("account_id", e), l;
}
function H1({ accountId: e, chatgptOrigin: a, projectId: r }) {
  if (!r) return null;
  const l = new URL(`/sites/${encodeURIComponent(r)}/settings`, a);
  return e && l.searchParams.set("account_id", e), l;
}
function Pr(e, a) {
  return a === null ? e : `[${e.replaceAll(`\r
`, " ").replaceAll("\r", " ").replaceAll(`
`, " ").replaceAll("\\", "\\\\").replaceAll("[", "\\[").replaceAll("](", "]\\(").replaceAll("]", "\\]")}](sites-project://${encodeURIComponent(a)})`;
}
function Tu({ accountId: e, chatgptOrigin: a, query: r, editContext: l }) {
  const s = new URL("/", a);
  return e && s.searchParams.set("account_id", e), l?.chatgpt_conversation_id && s.searchParams.set("resume_conversation_id", l.chatgpt_conversation_id), s.searchParams.set("surface", "work"), s.searchParams.set("prompt", r), s.searchParams.set("promptSource", "codex-app"), s.searchParams.set("site_edit_source", "widget"), s;
}
function jd({ accountId: e, browserUrl: a, chatgptOrigin: r, query: l, isDefaultPrompt: s = !1, projectId: c, editContext: d }) {
  if (c) {
    const m = ix({
      accountId: e,
      chatgptOrigin: r,
      projectId: c
    });
    return d?.chatgpt_conversation_id && m.searchParams.set("conversation_id", d.chatgpt_conversation_id), d?.codex_thread_id && m.searchParams.set("codex_thread_id", d.codex_thread_id), s || m.searchParams.set("prompt", l), m.searchParams.set("browser_url", a), m;
  }
  const h = new URL("/codex/open-app", r);
  return h.searchParams.set("app_brand", "chatgpt"), h.searchParams.set("fallback", "work"), e && h.searchParams.set("account_id", e), d?.codex_thread_id && h.searchParams.set("codex_thread_id", d.codex_thread_id), d?.chatgpt_conversation_id && h.searchParams.set("chatgpt_conversation_id", d.chatgpt_conversation_id), h.searchParams.set("q", l), h.searchParams.set("browserUrl", a), h;
}
function e_(e) {
  const [a, r] = (0, b.useState)(null);
  return (0, b.useLayoutEffect)(() => {
    if (!a) return;
    let l = 0;
    const s = () => {
      cancelAnimationFrame(l), l = requestAnimationFrame(() => {
        const d = e.current?.getBoundingClientRect();
        if (!d) return;
        const h = a.getBoundingClientRect();
        a.style.setProperty("--closed-top", `${d.top - h.top}px`), a.style.setProperty("--closed-left", `${d.left - h.left}px`), a.style.setProperty("--closed-right", `${h.right - d.right}px`), a.style.setProperty("--closed-bottom", `${h.bottom - d.bottom}px`), a.hasAttribute("data-mobile-widget-positioned") || (getComputedStyle(a, "::before").inset, a.dataset.mobileWidgetPositioned = "");
      });
    }, c = new ResizeObserver(s);
    return c.observe(a), e.current && c.observe(e.current), s(), window.addEventListener("resize", s), window.visualViewport?.addEventListener("resize", s), window.visualViewport?.addEventListener("scroll", s), () => {
      cancelAnimationFrame(l), c.disconnect(), window.removeEventListener("resize", s), window.visualViewport?.removeEventListener("resize", s), window.visualViewport?.removeEventListener("scroll", s);
    };
  }, [a, e]), {
    menuRef: r,
    menuMounted: a !== null
  };
}
var j1 = 52, Io = 12, rx = 5, B1 = 280;
function t_(e, a) {
  const r = (0, b.useRef)(null), [l] = (0, b.useState)(su), [s, c] = (0, b.useState)(() => l.read(qt.editorWidgetMobileAnchor)), [d, h] = (0, b.useState)(null), [m, y] = (0, b.useState)(!1), p = (0, b.useRef)(null), [_, w] = (0, b.useState)({
    left: Io,
    top: Io,
    right: window.innerWidth - Io,
    bottom: window.innerHeight - j1 - Io
  }), [E, x] = (0, b.useState)(!1), [C, T] = (0, b.useState)(!1), M = (0, b.useRef)(null), D = (0, b.useRef)(!1), j = (0, b.useRef)(!1);
  (0, b.useLayoutEffect)(() => () => {
    p.current !== null && window.clearTimeout(p.current);
  }, []);
  function H() {
    p.current !== null && window.clearTimeout(p.current), y(!0), p.current = window.setTimeout(() => {
      p.current = null, y(!1);
    }, B1 + 20);
  }
  const k = (0, b.useCallback)(() => {
    const q = window.visualViewport, F = r.current ? getComputedStyle(r.current) : null, ee = (A) => Math.max(Io, parseFloat(F?.getPropertyValue(`--safe-${A}`) ?? "0") || 0), ce = (q?.offsetLeft ?? 0) + ee("left"), V = (q?.offsetTop ?? 0) + ee("top"), ie = r.current?.offsetWidth ?? 0, se = r.current?.offsetHeight ?? j1, L = {
      left: ce,
      top: V,
      right: Math.max(ce, (q?.offsetLeft ?? 0) + (q?.width ?? window.innerWidth) - ie - ee("right")),
      bottom: Math.max(V, (q?.offsetTop ?? 0) + (q?.height ?? window.innerHeight) - se - ee("bottom"))
    };
    w((A) => A.left === L.left && A.top === L.top && A.right === L.right && A.bottom === L.bottom ? A : L);
  }, []);
  (0, b.useLayoutEffect)(k), (0, b.useLayoutEffect)(() => {
    const q = new ResizeObserver(k);
    return r.current && q.observe(r.current), window.addEventListener("resize", k), window.visualViewport?.addEventListener("resize", k), window.visualViewport?.addEventListener("scroll", k), () => {
      q.disconnect(), window.removeEventListener("resize", k), window.visualViewport?.removeEventListener("resize", k), window.visualViewport?.removeEventListener("scroll", k);
    };
  }, [k]);
  function B(q) {
    return {
      x: Math.max(_.left, Math.min(q.x, _.right)),
      y: Math.max(_.top, Math.min(q.y, _.bottom))
    };
  }
  const Q = B(d ?? Oh(s, _));
  function K(q, F = !1) {
    const ee = M.current;
    if (!(!ee || ee.id !== q.pointerId)) {
      if (M.current = null, j.current = !F && !ee.moved && q.pointerType === "touch", D.current = F || ee.moved || j.current, !F && ee.moved) {
        const ce = Wb(B({
          x: ee.start.x + q.clientX - ee.pointer.x,
          y: ee.start.y + q.clientY - ee.pointer.y
        }), _);
        c(ce), l.write(qt.editorWidgetMobileAnchor, ce);
      }
      ee.moved && H(), h(null), x(!1), T(!1), q.currentTarget.hasPointerCapture(q.pointerId) && q.currentTarget.releasePointerCapture(q.pointerId);
    }
  }
  return {
    ref: r,
    anchor: s,
    style: {
      left: Q.x,
      top: Q.y,
      "--widget-snap-duration": `${B1}ms`
    },
    dragging: E,
    pressed: C,
    snapping: m,
    dragHandlers: {
      onPointerDown(q) {
        if (!q.isPrimary || q.button !== 0 || M.current) return;
        const F = r.current?.getBoundingClientRect(), ee = F ? {
          x: F.x,
          y: F.y
        } : Q;
        p.current !== null && window.clearTimeout(p.current), p.current = null, y(!1), T(!0), h(ee), D.current = !1, j.current = !1, M.current = {
          id: q.pointerId,
          pointer: {
            x: q.clientX,
            y: q.clientY
          },
          start: ee,
          moved: !1
        }, q.target instanceof Element && q.target.setPointerCapture(q.pointerId);
      },
      onPointerMove(q) {
        const F = M.current;
        if (!F || F.id !== q.pointerId) return;
        const ee = q.clientX - F.pointer.x, ce = q.clientY - F.pointer.y;
        !F.moved && Math.hypot(ee, ce) < rx || (F.moved || (q.currentTarget.setPointerCapture(q.pointerId), e()), F.moved = !0, x(!0), h(B({
          x: F.start.x + ee,
          y: F.start.y + ce
        })));
      },
      onPointerUp: (q) => K(q),
      onPointerCancel: (q) => K(q, !0),
      onLostPointerCapture(q) {
        q.target === q.currentTarget && K(q, !0);
      },
      onTouchEnd(q) {
        q.cancelable && q.preventDefault(), j.current && (j.current = !1, a(q));
      },
      onClickCapture(q) {
        D.current && q.detail !== 0 && (q.preventDefault(), q.stopPropagation()), D.current = !1;
      }
    }
  };
}
function n_(e) {
  return /* @__PURE__ */ (0, g.jsx)("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    ...e,
    children: /* @__PURE__ */ (0, g.jsx)("path", { d: "M3 12a2 2 0 1 1 4 0 2 2 0 0 1-4 0Zm7 0a2 2 0 1 1 4 0 2 2 0 0 1-4 0Zm7 0a2 2 0 1 1 4 0 2 2 0 0 1-4 0Z" })
  });
}
function a_(e) {
  return /* @__PURE__ */ (0, g.jsxs)("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    ...e,
    children: [/* @__PURE__ */ (0, g.jsx)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M2.29285 2.29289C2.68337 1.90237 3.31654 1.90237 3.70706 2.29289L21.7071 20.2929C22.0976 20.6834 22.0976 21.3166 21.7071 21.7071C21.3165 22.0976 20.6834 22.0976 20.2928 21.7071L17.7784 19.1927C16.2039 20.2404 14.274 21 12 21C8.84578 21 6.36056 19.541 4.55854 17.8792C2.76156 16.222 1.58474 14.312 1.01229 13.2562C0.585014 12.4681 0.585717 11.5305 1.01263 10.7432C1.59034 9.67778 2.79199 7.72646 4.63582 6.05008L2.29285 3.70711C1.90232 3.31658 1.90232 2.68342 2.29285 2.29289ZM6.05186 7.46612C4.40718 8.93862 3.30712 10.7074 2.77079 11.6965C2.66592 11.8899 2.66602 12.1102 2.77049 12.3029C3.28862 13.2585 4.34187 14.9588 5.9144 16.4089C7.48191 17.8545 9.50568 19 12 19C13.6494 19 15.0899 18.5001 16.3303 17.7445L14.396 15.8102C12.6574 16.9057 10.3323 16.6963 8.81797 15.182C7.30363 13.6676 7.09422 11.3425 8.18971 9.60397L6.05186 7.46612ZM9.67217 11.0864L12.9135 14.3278C12.0164 14.6793 10.9571 14.4927 10.2322 13.7678C9.50728 13.0429 9.32061 11.9836 9.67217 11.0864Z"
    }), /* @__PURE__ */ (0, g.jsx)("path", { d: "M10.2233 5.19987C10.7835 5.07151 11.3752 5 12 5C14.4942 5 16.518 6.1455 18.0855 7.59105C19.6581 9.04124 20.7113 10.7415 21.2294 11.6971C21.3334 11.8889 21.3338 12.1105 21.2284 12.3047C20.9449 12.8276 20.496 13.5829 19.8836 14.4005C19.5525 14.8426 19.6425 15.4693 20.0845 15.8004C20.5265 16.1315 21.1533 16.0415 21.4844 15.5995C22.1677 14.6872 22.6678 13.8459 22.9865 13.2582C23.4131 12.4717 23.4154 11.5327 22.9876 10.7438C22.4152 9.68799 21.2384 7.77798 19.4414 6.1208C17.6394 4.45899 15.1541 3 12 3C11.221 3 10.4794 3.08934 9.77657 3.25041C9.23825 3.37379 8.90186 3.9102 9.02523 4.44853C9.1486 4.98686 9.68502 5.32325 10.2233 5.19987Z" })]
  });
}
function Mh(e) {
  return /* @__PURE__ */ (0, g.jsx)("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    ...e,
    children: /* @__PURE__ */ (0, g.jsx)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M13.2929 4.29291C15.0641 2.52167 17.9359 2.52167 19.7071 4.2929C21.4784 6.06414 21.4784 8.93588 19.7071 10.7071L18.7073 11.7069L11.6135 18.8007C10.8766 19.5376 9.92793 20.0258 8.89999 20.1971L4.16441 20.9864C3.84585 21.0395 3.52127 20.9355 3.29291 20.7071C3.06454 20.4788 2.96053 20.1542 3.01362 19.8356L3.80288 15.1C3.9742 14.0721 4.46243 13.1234 5.19932 12.3865L13.2929 4.29291ZM13 7.41422L6.61353 13.8007C6.1714 14.2428 5.87846 14.8121 5.77567 15.4288L5.21656 18.7835L8.57119 18.2244C9.18795 18.1216 9.75719 17.8286 10.1993 17.3865L16.5858 11L13 7.41422ZM18 9.5858L14.4142 6.00001L14.7071 5.70712C15.6973 4.71693 17.3027 4.71693 18.2929 5.70712C19.2831 6.69731 19.2831 8.30272 18.2929 9.29291L18 9.5858Z"
    })
  });
}
var ox = "_Widget_1lfcb_1", lx = "_Launcher_1lfcb_27", sx = "_Action_1lfcb_28", ux = "_EditAction_1lfcb_29", cx = "_MoreAction_1lfcb_30", fx = "_Menu_1lfcb_39", dx = "_Actions_1lfcb_204", vn = {
  Widget: ox,
  Launcher: lx,
  Action: sx,
  EditAction: ux,
  MoreAction: cx,
  Menu: fx,
  "menu-exit": "_menu-exit_1lfcb_1",
  Actions: dx
};
function hx({ accountId: e, config: a, chatgptOrigin: r, projectId: l, siteTitle: s }) {
  const c = sl(), [d, h] = (0, b.useState)(!1), [m, y] = (0, b.useState)(a.hidden), [p] = (0, b.useState)(nh), _ = (0, b.useRef)(!1), w = (0, b.useRef)(!1), E = t_(() => h(!1), (M) => {
    M.target instanceof Element && M.target.closest("button, a")?.click();
  }), { menuRef: x, menuMounted: C } = e_(E.ref);
  if ((0, b.useEffect)(() => {
    m || _.current || (_.current = !0, At("editor_widget_shown"));
  }, [m]), m) return null;
  const T = Tu({
    accountId: e,
    chatgptOrigin: r,
    editContext: a.edit_context,
    query: `${Pr(s, l)} `
  }).toString();
  return /* @__PURE__ */ (0, g.jsxs)(yu, {
    open: d,
    onOpenChange: h,
    children: [(0, Zr.createPortal)(/* @__PURE__ */ (0, g.jsx)(mx, {
      position: E,
      open: d,
      menuMounted: C,
      openedByPointer: w,
      editUrl: T
    }), c ?? document.body), /* @__PURE__ */ (0, g.jsx)(bu, {
      container: c,
      children: /* @__PURE__ */ (0, g.jsx)(px, {
        ref: x,
        anchor: E.anchor,
        open: d,
        openedByPointer: w,
        editUrl: T,
        onEdit: () => h(!1),
        onHide: () => {
          h(!1), y(!0), p(!0), At("editor_widget_hidden");
        }
      })
    })]
  });
}
function mx({ position: e, open: a, menuMounted: r, openedByPointer: l, editUrl: s }) {
  const c = Fe(), d = c.formatMessage(Ye.editorWidgetMobileMenu);
  return /* @__PURE__ */ (0, g.jsx)(Eh, {
    asChild: !0,
    children: /* @__PURE__ */ (0, g.jsx)("div", {
      ref: e.ref,
      className: Be(je.Widget, vn.Widget),
      style: e.style,
      "data-mobile-widget-dragging": e.dragging ? "" : void 0,
      "data-mobile-widget-pressed": e.pressed ? "" : void 0,
      "data-mobile-widget-snapping": e.snapping ? "" : void 0,
      "data-mobile-widget-menu-open": a ? "" : void 0,
      "data-mobile-widget-menu-mounted": r ? "" : void 0,
      dir: Oa(c.locale),
      lang: c.locale,
      children: /* @__PURE__ */ (0, g.jsxs)("div", {
        className: vn.Launcher,
        role: "group",
        "aria-label": d,
        inert: a,
        onPointerDownCapture: () => {
          l.current = !0;
        },
        onKeyDown: () => {
          l.current = !1;
        },
        ...e.dragHandlers,
        children: [
          /* @__PURE__ */ (0, g.jsx)(ih, {
            src: th,
            alt: "",
            width: 24,
            height: 24
          }),
          /* @__PURE__ */ (0, g.jsx)(i_, {
            className: vn.EditAction,
            href: s
          }),
          /* @__PURE__ */ (0, g.jsx)(Th, {
            asChild: !0,
            children: /* @__PURE__ */ (0, g.jsx)("button", {
              type: "button",
              className: vn.MoreAction,
              "aria-label": d,
              title: d,
              children: /* @__PURE__ */ (0, g.jsx)(n_, {
                "aria-hidden": "true",
                focusable: "false"
              })
            })
          })
        ]
      })
    })
  });
}
function px({ ref: e, anchor: a, open: r, openedByPointer: l, editUrl: s, onEdit: c, onHide: d }) {
  const h = Fe(), m = Oa(h.locale);
  return /* @__PURE__ */ (0, g.jsx)(_u, {
    ref: e,
    className: Be(je.Widget, vn.Menu),
    side: a.startsWith("top") ? "bottom" : "top",
    align: a === "bottom-center" ? "center" : a.endsWith("left") !== (m === "rtl") ? "start" : "end",
    sideOffset: -52,
    collisionPadding: 16,
    updatePositionStrategy: "always",
    inert: !r,
    onOpenAutoFocus: (y) => {
      y.preventDefault(), y.target instanceof HTMLElement && (l.current ? y.target : y.target.querySelector("a, button") ?? y.target).focus({ preventScroll: !0 }), l.current = !1;
    },
    "aria-label": h.formatMessage(Ye.editorWidgetMobileMenu),
    dir: m,
    lang: h.locale,
    children: /* @__PURE__ */ (0, g.jsxs)("div", {
      className: vn.Actions,
      children: [
        /* @__PURE__ */ (0, g.jsx)(i_, {
          className: vn.Action,
          href: s,
          onClick: c,
          showIcon: !0
        }),
        /* @__PURE__ */ (0, g.jsxs)("button", {
          type: "button",
          className: vn.Action,
          onClick: d,
          children: [/* @__PURE__ */ (0, g.jsx)(a_, {
            "aria-hidden": "true",
            focusable: "false"
          }), h.formatMessage(Ye.editorWidgetHideAction)]
        }),
        /* @__PURE__ */ (0, g.jsx)(zd, {
          asChild: !0,
          children: /* @__PURE__ */ (0, g.jsxs)("button", {
            type: "button",
            className: vn.Action,
            children: [/* @__PURE__ */ (0, g.jsx)(ai, {
              "aria-hidden": "true",
              focusable: "false"
            }), h.formatMessage(Ye.editorWidgetMobileClose)]
          })
        })
      ]
    })
  });
}
function i_({ className: e, href: a, onClick: r, showIcon: l = !1 }) {
  const s = Fe();
  return /* @__PURE__ */ (0, g.jsxs)("a", {
    className: e,
    href: a,
    target: "_blank",
    rel: "noopener noreferrer",
    draggable: !1,
    onClick: () => {
      r?.(), At("editor_widget_open_in_chatgpt_clicked");
    },
    children: [l && /* @__PURE__ */ (0, g.jsx)(Mh, {
      "aria-hidden": "true",
      focusable: "false"
    }), s.formatMessage(Ye.editorWidgetLaunchAction)]
  });
}
var ne = {
  removeRecipient: {
    id: "sites.dispatch.widget.toolbar.remove_recipient",
    defaultMessage: "Remove {name}",
    description: "Remove a selected recipient from an unsent Site invitation."
  },
  inviteRole: {
    id: "sites.dispatch.widget.toolbar.invite_role",
    defaultMessage: "Role for selected recipients",
    description: "Accessible label for the role selector inside the invitation input."
  },
  commitInvites: {
    id: "sites.dispatch.widget.toolbar.commit_invites",
    defaultMessage: "Invite",
    description: "Save pending sharing changes and invite all selected recipients."
  },
  save: {
    id: "sites.dispatch.widget.toolbar.save",
    defaultMessage: "Save",
    description: "Commit pending Site sharing and remix settings."
  },
  cancel: {
    id: "sites.dispatch.widget.toolbar.cancel",
    defaultMessage: "Cancel",
    description: "Close Site sharing and discard unsaved changes."
  },
  advanced: {
    id: "sites.dispatch.widget.toolbar.advanced",
    defaultMessage: "Advanced",
    description: "Open the Site owner's advanced sharing settings."
  },
  advancedSettings: {
    id: "sites.dispatch.widget.toolbar.advanced_settings",
    defaultMessage: "Advanced settings",
    description: "Title of the advanced Site sharing panel."
  },
  back: {
    id: "sites.dispatch.widget.toolbar.back",
    defaultMessage: "Back",
    description: "Return to the sharing panel, preserving unsaved changes."
  },
  remixWorkspace: {
    id: "sites.dispatch.widget.toolbar.remix_workspace",
    defaultMessage: "Let viewers in {workspace} remix",
    description: "Owner setting allowing workspace viewers to remix this Site."
  },
  remixViewers: {
    id: "sites.dispatch.widget.toolbar.remix_viewers",
    defaultMessage: "Let viewers remix",
    description: "Owner remix setting when no workspace name is available."
  },
  remixInfo: {
    id: "sites.dispatch.widget.toolbar.remix_info",
    defaultMessage: "About remixing",
    description: "Accessible label for the remix explanation tooltip."
  },
  remixExplanation: {
    id: "sites.dispatch.widget.toolbar.remix_explanation",
    defaultMessage: "Remixing lets viewers in your workspace make their own version of this site. Only the code is copied; your site’s data isn’t included.",
    description: "Explains what workspace viewers can copy when remixing a Site."
  },
  viewerRemixDescription: {
    id: "sites.dispatch.widget.toolbar.viewerRemixDescription",
    defaultMessage: "Use and remix",
    description: "Viewer role description for workspace members when site remixing is enabled."
  },
  viewerMixedRemixDescription: {
    id: "sites.dispatch.widget.toolbar.viewerMixedRemixDescription",
    defaultMessage: "Use this site. {workspace} members can also remix.",
    description: "Viewer role description for mixed workspace and external recipients when site remixing is enabled."
  },
  editorWorkspaceOnlyDescription: {
    id: "sites.dispatch.widget.toolbar.editorWorkspaceOnlyDescription",
    defaultMessage: "Only workspace members can be editors",
    description: "Reason Editor is disabled when recipients include external visitors or tenant groups."
  },
  viewerDescriptionShort: {
    id: "sites.dispatch.widget.toolbar.viewer_description_short",
    defaultMessage: "View and use the site",
    description: "Description for the viewerDescription sharing option."
  },
  editorDescriptionShort: {
    id: "sites.dispatch.widget.toolbar.editor_description_short",
    defaultMessage: "Edit and publish",
    description: "Description for the editorDescription sharing option."
  },
  openChatGPT: {
    id: "sites.dispatch.widget.toolbar.open_chatgpt",
    defaultMessage: "Open ChatGPT",
    description: "Tooltip and accessible label for opening an empty Edit or Remix composer in ChatGPT."
  },
  remixOpenPrompt: {
    id: "sites.dispatch.widget.toolbar.remix_open_prompt",
    defaultMessage: "Remix {site}",
    description: "Editable prefill when opening ChatGPT from an empty remix composer. site is the complete Site reference."
  },
  privateHint: {
    id: "sites.dispatch.widget.toolbar.private_hint_status",
    defaultMessage: "This site is private.",
    description: "Access statement in a first-use tooltip. A separate sharing action appears below it."
  },
  invitedHint: {
    id: "sites.dispatch.widget.toolbar.invited_hint_status",
    defaultMessage: "Only invited people can view.",
    description: "Access statement for a Site shared with invited people or groups. A separate manage-access action appears below it."
  },
  workspaceHint: {
    id: "sites.dispatch.widget.toolbar.workspace_hint_status",
    defaultMessage: "Everyone in {workspace} can view.",
    description: "Workspace-wide access statement in a tooltip. A separate manage-access action appears below it."
  },
  publicHint: {
    id: "sites.dispatch.widget.toolbar.public_hint_status",
    defaultMessage: "Anyone with the link can view.",
    description: "Public access statement in a tooltip. A separate manage-access action appears below it."
  },
  shareHintAction: {
    id: "sites.dispatch.widget.toolbar.share_hint_action",
    defaultMessage: "Click to share.",
    description: "Second line of a sharing tooltip, below a standalone private-access statement. Describes clicking the toolbar's sharing button."
  },
  manageHintAction: {
    id: "sites.dispatch.widget.toolbar.manage_hint_action",
    defaultMessage: "Click to manage.",
    description: "Second line of a sharing tooltip, below a standalone access statement. Describes clicking the toolbar button to manage Site access."
  },
  remixComposerPlaceholder: {
    id: "sites.dispatch.widget.toolbar.remix_composer_placeholder",
    defaultMessage: "Describe your remix",
    description: "Placeholder and accessible label for the Site remix composer."
  },
  publicDescription: {
    id: "sites.dispatch.widget.toolbar.publicDescription",
    defaultMessage: "Anyone on the internet with the link can view",
    description: "Description for the publicDescription sharing option."
  },
  workspaceDescription: {
    id: "sites.dispatch.widget.toolbar.workspaceDescription",
    defaultMessage: "Workspace members with the link can view",
    description: "Description for the workspaceDescription sharing option."
  },
  privateDescription: {
    id: "sites.dispatch.widget.toolbar.privateDescription",
    defaultMessage: "You and people you’ve added can view",
    description: "Description for the privateDescription sharing option."
  },
  viewerDescription: {
    id: "sites.dispatch.widget.toolbar.viewerDescription",
    defaultMessage: "View and use the site.",
    description: "Description for the viewerDescription sharing option."
  },
  editorDescription: {
    id: "sites.dispatch.widget.toolbar.editorDescription",
    defaultMessage: "Edit the site and publish updates. Access, download, change, or delete its data.",
    description: "Description for the editorDescription sharing option."
  },
  admins: {
    id: "sites.dispatch.widget.toolbar.admins",
    defaultMessage: "Admins only",
    description: "Legacy Site access limited to owners and workspace administrators."
  },
  menu: {
    id: "sites.dispatch.widget.toolbar.menu",
    defaultMessage: "Toolbar menu",
    description: "Open toolbar actions."
  },
  role: {
    id: "sites.dispatch.widget.toolbar.role",
    defaultMessage: "Access for {name}",
    description: "Accessible name for a sharing role selector."
  },
  label: {
    id: "sites.dispatch.widget.toolbar.label",
    defaultMessage: "Site toolbar",
    description: "Accessible name of the Site sharing toolbar."
  },
  private: {
    id: "sites.dispatch.widget.toolbar.private",
    defaultMessage: "Private",
    description: "Toolbar label for a Site shared only with its owner."
  },
  public: {
    id: "sites.dispatch.widget.toolbar.public",
    defaultMessage: "Public",
    description: "Toolbar label for a publicly accessible Site."
  },
  workspace: {
    id: "sites.dispatch.widget.toolbar.workspace",
    defaultMessage: "Workspace",
    description: "Fallback label for workspace-wide Site access."
  },
  people: {
    id: "sites.dispatch.widget.toolbar.people",
    defaultMessage: "{count, plural, one {# person} other {# people}}",
    description: "Number of people explicitly allowed to access a Site, including its owner."
  },
  inviteOnly: {
    id: "sites.dispatch.widget.toolbar.invite_only",
    defaultMessage: "Invite only",
    description: "Site shared with access groups, whose membership can overlap."
  },
  share: {
    id: "sites.dispatch.widget.toolbar.share",
    defaultMessage: "Share",
    description: "Open the Site sharing dialog."
  },
  manageAccess: {
    id: "sites.dispatch.widget.toolbar.manageAccess",
    defaultMessage: "Manage access",
    description: "Short shortcut label in the published Site toolbar for owners who can open the Site’s sharing settings."
  },
  title: {
    id: "sites.dispatch.widget.toolbar.title",
    defaultMessage: "Share ‘{title}’",
    description: "Site sharing dialog heading."
  },
  edit: {
    id: "sites.dispatch.widget.toolbar.edit",
    defaultMessage: "Edit this site",
    description: "Open this Site in ChatGPT for editing."
  },
  remix: {
    id: "sites.dispatch.widget.toolbar.remix",
    defaultMessage: "Remix",
    description: "Start a new ChatGPT conversation to remix the Site."
  },
  settings: {
    id: "sites.dispatch.widget.toolbar.settings",
    defaultMessage: "Settings",
    description: "Owner-only Site toolbar menu item. Opens this Site's settings page on ChatGPT web in a new tab. Short label beside a gear icon."
  },
  hide: {
    id: "sites.dispatch.widget.toolbar.hide",
    defaultMessage: "Hide toolbar",
    description: "Hide the Site toolbar."
  },
  close: {
    id: "sites.dispatch.widget.toolbar.close",
    defaultMessage: "Close",
    description: "Close the current toolbar menu or sharing dialog."
  },
  search: {
    id: "sites.dispatch.widget.toolbar.add_people_or_teams",
    defaultMessage: "Add people or teams",
    description: "Invite input placeholder and accessible label for finding people or teams to share a Site with."
  },
  linkAccess: {
    id: "sites.dispatch.widget.toolbar.link_access",
    defaultMessage: "Link access",
    description: "Heading for who can open the Site link."
  },
  invited: {
    id: "sites.dispatch.widget.toolbar.invited",
    defaultMessage: "Only invited people",
    description: "Restricted Site link access option."
  },
  anyone: {
    id: "sites.dispatch.widget.toolbar.anyone",
    defaultMessage: "Anyone with the link",
    description: "Public Site link access option."
  },
  everyone: {
    id: "sites.dispatch.widget.toolbar.everyone",
    defaultMessage: "Everyone in {workspace}",
    description: "Workspace-wide Site link access option."
  },
  who: {
    id: "sites.dispatch.widget.toolbar.who",
    defaultMessage: "Who has access",
    description: "Heading for people and groups with Site access."
  },
  owner: {
    id: "sites.dispatch.widget.toolbar.owner",
    defaultMessage: "Owner",
    description: "Non-editable Site owner role."
  },
  viewer: {
    id: "sites.dispatch.widget.toolbar.viewer",
    defaultMessage: "Viewer",
    description: "Role that can view a Site."
  },
  editor: {
    id: "sites.dispatch.widget.toolbar.editor",
    defaultMessage: "Editor",
    description: "Role that can edit a Site."
  },
  remove: {
    id: "sites.dispatch.widget.toolbar.remove",
    defaultMessage: "Remove access",
    description: "Remove a person or group from Site sharing."
  },
  requestEditAccess: {
    id: "sites.dispatch.widget.toolbar.request_edit_access",
    defaultMessage: "Request edit access",
    description: "Button in the sharing dialog that asks the site owner to grant editing permission."
  },
  editRequested: {
    id: "sites.dispatch.widget.toolbar.edit_requested",
    defaultMessage: "Requested",
    description: "Disabled button label after the viewer has sent a request to edit this site."
  },
  requestEditError: {
    id: "sites.dispatch.widget.toolbar.request_edit_error",
    defaultMessage: "Couldn’t send your request. Please try again.",
    description: "Shown when a viewer’s request to edit a site could not be sent."
  },
  copy: {
    id: "sites.dispatch.widget.toolbar.copy",
    defaultMessage: "Copy link",
    description: "Copy the canonical Site URL."
  },
  copied: {
    id: "sites.dispatch.widget.toolbar.copied",
    defaultMessage: "Copied",
    description: "Confirmation that the Site URL was copied."
  },
  shareSignInTitleOwner: {
    id: "sites.dispatch.widget.toolbar.share.sign_in.title.owner",
    defaultMessage: "Log in to manage access",
    description: "Short title of the Site sharing dialog shown to a Site owner who needs to log in to ChatGPT to manage who can access the Site."
  },
  shareSignInTitleViewer: {
    id: "sites.dispatch.widget.toolbar.share.sign_in.title.viewer",
    defaultMessage: "Log in to view access",
    description: "Short title of the Site sharing dialog shown to a non-owner who needs to log in to ChatGPT to see the Site’s sharing settings."
  },
  shareSignIn: {
    id: "sites.dispatch.widget.toolbar.share.sign_in",
    defaultMessage: "You can open this site’s sharing settings once you’re logged in to ChatGPT.",
    description: "Instruction in the Site sharing dialog when ChatGPT sign-in is required."
  },
  shareContinue: {
    id: "sites.dispatch.widget.toolbar.share.continue",
    defaultMessage: "Continue to ChatGPT",
    description: "Button in the Site sharing dialog that opens ChatGPT sign-in in another tab."
  },
  shareWaiting: {
    id: "sites.dispatch.widget.toolbar.share.waiting",
    defaultMessage: "Finish your ChatGPT login in the new tab.",
    description: "Status in the original Site sharing dialog while the user signs into ChatGPT."
  },
  shareRetry: {
    id: "sites.dispatch.widget.toolbar.share.retry",
    defaultMessage: "Try again",
    description: "Button that starts a new sign-in attempt from the waiting Site sharing dialog."
  },
  shareLoading: {
    id: "sites.dispatch.widget.toolbar.share.loading",
    defaultMessage: "Loading sharing settings…",
    description: "Accessible name of the spinner while the Site sharing dialog retrieves permissions."
  },
  shareLoadErrorTitle: {
    id: "sites.dispatch.widget.toolbar.share.load_error_title",
    defaultMessage: "Something went wrong",
    description: "Short heading in the Site sharing notice when sharing settings could not load."
  },
  shareLoadError: {
    id: "sites.dispatch.widget.toolbar.share.load_error",
    defaultMessage: "We couldn’t load sharing settings for this site.",
    description: "Error in the Site sharing dialog when permissions could not be retrieved."
  },
  shareOpenSettings: {
    id: "sites.dispatch.widget.toolbar.share.open_settings",
    defaultMessage: "Open in ChatGPT",
    description: "Short button label in the Site sharing error notice. Opens this Site’s sharing dialog in ChatGPT."
  },
  error: {
    id: "sites.dispatch.widget.toolbar.error",
    defaultMessage: "Couldn’t update sharing. Please try again.",
    description: "A Site sharing save failed."
  },
  interactionRequired: {
    id: "sites.dispatch.widget.toolbar.interaction_required",
    defaultMessage: "Keep the sharing dialog fully visible, then try again.",
    description: "A sharing change was blocked because the dialog was not visibly receiving a user action."
  },
  searchError: {
    id: "sites.dispatch.widget.toolbar.search_error",
    defaultMessage: "Couldn’t search. Please try again.",
    description: "Site sharing directory search failed."
  },
  peopleSearchUnavailable: {
    id: "sites.dispatch.widget.toolbar.people_search_unavailable",
    defaultMessage: "People search is unavailable",
    description: "Shown when people search is unavailable and there are no suggestions to show."
  },
  noResults: {
    id: "sites.dispatch.widget.toolbar.no_results",
    defaultMessage: "No matching people or groups",
    description: "Empty Site sharing search results."
  },
  invite: {
    id: "sites.dispatch.widget.toolbar.invite",
    defaultMessage: "Invite {email}",
    description: "Invite a new external visitor by email."
  },
  searching: {
    id: "sites.dispatch.widget.toolbar.searching",
    defaultMessage: "Searching…",
    description: "Site sharing search is running."
  },
  saving: {
    id: "sites.dispatch.widget.toolbar.saving",
    defaultMessage: "Saving…",
    description: "Site sharing update is running."
  },
  more: {
    id: "sites.dispatch.widget.toolbar.more",
    defaultMessage: "Type more to narrow your search",
    description: "More sharing search results exist than fit in the list."
  },
  members: {
    id: "sites.dispatch.widget.toolbar.members",
    defaultMessage: "{count, plural, one {# member} other {# members}}",
    description: "Number of members of a Site access group."
  },
  copyError: {
    id: "sites.dispatch.widget.toolbar.copy_error",
    defaultMessage: "Couldn’t copy the link. Please try again.",
    description: "Clipboard copy failed."
  },
  remixPrompt: {
    id: "sites.dispatch.widget.toolbar.remix_prompt",
    defaultMessage: "Remix {site} into a new site.",
    description: "New ChatGPT conversation prompt for remixing an existing Site reference."
  }
}, r_ = (e) => /* @__PURE__ */ (0, g.jsx)("svg", {
  width: "1em",
  height: "1em",
  viewBox: "0 0 24 24",
  fill: "currentColor",
  ...e,
  children: /* @__PURE__ */ (0, g.jsx)("path", {
    fillRule: "evenodd",
    d: "M12 4a4 4 0 0 0-4 4h8a4 4 0 0 0-4-4Zm-6 6a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-8a1 1 0 0 0-1-1H6Zm0-2a6 6 0 1 1 12 0 3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3v-8a3 3 0 0 1 3-3Zm4 6a2 2 0 1 1 3 1.732V17a1 1 0 1 1-2 0v-1.268A2 2 0 0 1 10 14Z",
    clipRule: "evenodd"
  })
}), o_ = (e) => /* @__PURE__ */ (0, g.jsx)("svg", {
  width: "1em",
  height: "1em",
  viewBox: "0 0 24 24",
  fill: "currentColor",
  ...e,
  children: /* @__PURE__ */ (0, g.jsx)("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12ZM11.9851 4.00291C11.9744 4.00615 11.953 4.01416 11.921 4.03356C11.7908 4.11248 11.5742 4.32444 11.325 4.77696C11.0839 5.21453 10.8521 5.8046 10.6514 6.53263C10.3148 7.75315 10.0844 9.29169 10.019 11H13.981C13.9156 9.29169 13.6852 7.75315 13.3486 6.53263C13.1479 5.8046 12.9161 5.21453 12.675 4.77696C12.4258 4.32444 12.2092 4.11248 12.079 4.03356C12.047 4.01416 12.0256 4.00615 12.0149 4.00291C12.0067 4.00046 12.001 4.00006 11.9996 4C11.9982 4.00006 11.9933 4.00046 11.9851 4.00291ZM8.01766 11C8.08396 9.13314 8.33431 7.41167 8.72334 6.00094C8.87366 5.45584 9.04762 4.94639 9.24523 4.48694C6.48462 5.49946 4.43722 7.9901 4.06189 11H8.01766ZM4.06189 13H8.01766C8.09487 15.1737 8.42177 17.1555 8.93 18.6802C9.02641 18.9694 9.13134 19.2483 9.24522 19.5131C6.48461 18.5005 4.43722 16.0099 4.06189 13ZM10.019 13C10.0955 14.9972 10.3973 16.7574 10.8274 18.0477C11.0794 18.8038 11.3575 19.3436 11.6177 19.6737C11.7455 19.8359 11.8494 19.9225 11.9186 19.9649C11.9515 19.9852 11.9736 19.9935 11.9847 19.9969C11.9948 20 11.9999 20 11.9999 20C11.9999 20 12.0049 20.0001 12.0153 19.9969C12.0264 19.9935 12.0485 19.9852 12.0814 19.9649C12.1506 19.9225 12.2545 19.8359 12.3823 19.6737C12.6425 19.3436 12.9206 18.8038 13.1726 18.0477C13.6027 16.7574 13.9045 14.9972 13.981 13H10.019ZM15.9823 13C15.9051 15.1737 15.5782 17.1555 15.07 18.6802C14.9736 18.9694 14.8687 19.2483 14.7548 19.5131C17.5154 18.5005 19.5628 16.0099 19.9381 13H15.9823ZM19.9381 11C19.5628 7.99009 17.5154 5.49946 14.7548 4.48694C14.9524 4.94639 15.1263 5.45584 15.2767 6.00094C15.6657 7.41167 15.916 9.13314 15.9823 11H19.9381Z"
  })
}), vx = (e) => /* @__PURE__ */ (0, g.jsx)("svg", {
  width: "1em",
  height: "1em",
  viewBox: "0 0 24 24",
  fill: "currentColor",
  ...e,
  children: /* @__PURE__ */ (0, g.jsx)("path", {
    fillRule: "evenodd",
    d: "M7.5 5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5ZM3 7.5a4.5 4.5 0 1 1 9 0 4.5 4.5 0 0 1-9 0ZM17 6a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm-4 2a4 4 0 1 1 8 0 4 4 0 0 1-8 0Zm-8.96 8.247C3.137 17.048 2.5 18.271 2.5 20a1 1 0 1 1-2 0c0-2.271.862-4.049 2.21-5.248C4.042 13.57 5.788 13 7.5 13s3.459.57 4.79 1.752c1.348 1.2 2.21 2.977 2.21 5.248a1 1 0 1 1-2 0c0-1.729-.638-2.952-1.54-3.753C10.042 15.43 8.788 15 7.5 15s-2.541.43-3.46 1.247Zm15.757-.607c-1.009-.638-2.338-.807-3.526-.472a1 1 0 0 1-.542-1.925c1.695-.478 3.616-.255 5.136.706 1.558.984 2.635 2.707 2.635 5.051a1 1 0 1 1-2 0c0-1.665-.732-2.746-1.703-3.36Z",
    clipRule: "evenodd"
  })
}), l_ = (e) => /* @__PURE__ */ (0, g.jsx)("svg", {
  width: "1em",
  height: "1em",
  viewBox: "0 0 24 24",
  fill: "currentColor",
  ...e,
  children: /* @__PURE__ */ (0, g.jsx)("path", {
    d: "M3 6C3 4.34315 4.34315 3 6 3H12C13.6569 3 15 4.34315 15 6V7H18C19.6569 7 21 8.34315 21 10V19H22C22.5523 19 23 19.4477 23 20C23 20.5523 22.5523 21 22 21H2C1.44772 21 1 20.5523 1 20C1 19.4477 1.44772 19 2 19H3V6ZM5 19H8V17C8 16.4477 8.44772 16 9 16C9.55228 16 10 16.4477 10 17V19H13V6C13 5.44772 12.5523 5 12 5H6C5.44772 5 5 5.44772 5 6V19ZM15 19H19V10C19 9.44772 18.5523 9 18 9H15V19Z",
    fill: "currentColor"
  })
}), gx = (e) => /* @__PURE__ */ (0, g.jsx)("svg", {
  width: "1em",
  height: "1em",
  viewBox: "0 0 24 24",
  fill: "currentColor",
  ...e,
  children: /* @__PURE__ */ (0, g.jsx)("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12ZM16.0015 18.9289C14.8244 19.6101 13.4577 20 12 20C7.58172 20 4 16.4183 4 12C4 9.23858 6.23858 7 9 7C11.7614 7 14 9.23858 14 12C14 12.5523 14.4477 13 15 13C15.5523 13 16 12.5523 16 12C16 8.13401 12.866 5 9 5C8.65998 5 8.32561 5.02424 7.99855 5.0711C9.17557 4.3899 10.5423 4 12 4C16.4183 4 20 7.58172 20 12C20 14.7614 17.7614 17 15 17C12.2386 17 10 14.7614 10 12C10 11.4477 9.55228 11 9 11C8.44772 11 8 11.4477 8 12C8 15.866 11.134 19 15 19C15.34 19 15.6744 18.9758 16.0015 18.9289Z",
    fill: "currentColor"
  })
}), yx = (e) => /* @__PURE__ */ (0, g.jsx)("svg", {
  width: "1em",
  height: "1em",
  viewBox: "0 0 24 24",
  fill: "currentColor",
  ...e,
  children: /* @__PURE__ */ (0, g.jsx)("path", {
    d: "M11.2929 3.29289C11.6834 2.90237 12.3166 2.90237 12.7071 3.29289L16.7071 7.29289C17.0976 7.68342 17.0976 8.31658 16.7071 8.70711C16.3166 9.09763 15.6834 9.09763 15.2929 8.70711L13 6.41421V15C13 15.5523 12.5523 16 12 16C11.4477 16 11 15.5523 11 15V6.41421L8.70711 8.70711C8.31658 9.09763 7.68342 9.09763 7.29289 8.70711C6.90237 8.31658 6.90237 7.68342 7.29289 7.29289L11.2929 3.29289ZM4 14C4.55229 14 5 14.4477 5 15V15.2C5 16.0566 5.00078 16.6389 5.03755 17.089C5.07337 17.5274 5.1383 17.7516 5.21799 17.908C5.40973 18.2843 5.7157 18.5903 6.09202 18.782C6.24842 18.8617 6.47262 18.9266 6.91104 18.9624C7.36113 18.9992 7.94342 19 8.8 19H15.2C16.0566 19 16.6389 18.9992 17.089 18.9624C17.5274 18.9266 17.7516 18.8617 17.908 18.782C18.2843 18.5903 18.5903 18.2843 18.782 17.908C18.8617 17.7516 18.9266 17.5274 18.9624 17.089C18.9992 16.6389 19 16.0566 19 15.2V15C19 14.4477 19.4477 14 20 14C20.5523 14 21 14.4477 21 15V15.2413C21 16.0463 21 16.7106 20.9558 17.2518C20.9099 17.8139 20.8113 18.3306 20.564 18.816C20.1805 19.5686 19.5686 20.1805 18.816 20.564C18.3306 20.8113 17.8139 20.9099 17.2518 20.9558C16.7106 21 16.0463 21 15.2413 21H8.75868C7.95372 21 7.28936 21 6.74817 20.9558C6.18608 20.9099 5.66937 20.8113 5.18404 20.564C4.43139 20.1805 3.81947 19.5686 3.43597 18.816C3.18868 18.3306 3.09012 17.8139 3.04419 17.2518C2.99998 16.7106 2.99999 16.0463 3 15.2413L3 15C3 14.4477 3.44772 14 4 14Z",
    fill: "currentColor"
  })
}), s_ = (e) => /* @__PURE__ */ (0, g.jsxs)("svg", {
  width: "1em",
  height: "1em",
  viewBox: "0 0 24 24",
  fill: "currentColor",
  ...e,
  children: [/* @__PURE__ */ (0, g.jsx)("path", {
    fillRule: "evenodd",
    d: "M11.568 3.5a1 1 0 0 0-.863.494l-.811 1.381A3.001 3.001 0 0 1 7.33 6.856l-1.596.013a1 1 0 0 0-.858.501l-.439.761a1 1 0 0 0-.004.992l.792 1.4a3 3 0 0 1 0 2.954l-.792 1.4a1 1 0 0 0 .004.992l.439.76a1 1 0 0 0 .858.502l1.596.013a3 3 0 0 1 2.564 1.48l.811 1.382a1 1 0 0 0 .863.494h.87a1 1 0 0 0 .862-.494l.812-1.381a3.001 3.001 0 0 1 2.563-1.481l1.596-.013a1 1 0 0 0 .86-.501l.438-.761a1 1 0 0 0 .004-.992l-.793-1.4a3 3 0 0 1 0-2.954l.793-1.4a1 1 0 0 0-.004-.992l-.439-.76a1 1 0 0 0-.858-.502l-1.597-.013a3 3 0 0 1-2.563-1.48L13.3 3.993a1 1 0 0 0-.862-.494h-.87ZM8.98 2.981A3.001 3.001 0 0 1 11.568 1.5h.87c1.064 0 2.049.564 2.588 1.481l.811 1.382a1 1 0 0 0 .855.494l1.596.013a3 3 0 0 1 2.575 1.502l.44.76a3 3 0 0 1 .011 2.975l-.792 1.4a1 1 0 0 0 0 .985l.792 1.401a3 3 0 0 1-.012 2.974l-.439.761a3.001 3.001 0 0 1-2.575 1.503l-1.597.012a1 1 0 0 0-.854.494l-.811 1.382a3.001 3.001 0 0 1-2.588 1.481h-.87a3.001 3.001 0 0 1-2.588-1.481l-.811-1.382a1 1 0 0 0-.855-.494l-1.596-.012a3.001 3.001 0 0 1-2.576-1.503l-.438-.76a3 3 0 0 1-.013-2.975l.793-1.4a1 1 0 0 0 0-.985l-.793-1.4a3 3 0 0 1 .013-2.975l.438-.761A3.001 3.001 0 0 1 5.718 4.87l1.596-.013a1 1 0 0 0 .855-.494l.81-1.382Z",
    clipRule: "evenodd"
  }), /* @__PURE__ */ (0, g.jsx)("path", {
    fillRule: "evenodd",
    d: "M12.003 10.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3ZM8.502 12a3.5 3.5 0 1 1 7 .001 3.5 3.5 0 0 1-7-.001Z",
    clipRule: "evenodd"
  })]
}), bx = "_Launcher_6xtjb_1", _x = "_Logo_6xtjb_32", wx = "_Divider_6xtjb_38", Sx = "_Shortcut_6xtjb_45", Ex = "_More_6xtjb_46", Tx = "_Ghost_6xtjb_50", Cx = "_Label_6xtjb_84", Ax = "_Menu_6xtjb_91", xx = "_MenuActions_6xtjb_104", Ox = "_MenuDivider_6xtjb_107", Mx = "_MenuAction_6xtjb_104", bt = {
  Launcher: bx,
  Logo: _x,
  Divider: wx,
  Shortcut: Sx,
  More: Ex,
  Ghost: Tx,
  Label: Cx,
  Menu: Ax,
  MenuActions: xx,
  MenuDivider: Ox,
  MenuAction: Mx
};
function Rx({ children: e, summary: a, enabled: r, anchor: l, onDismiss: s }) {
  const { formatMessage: c } = Fe();
  function d() {
    switch (a.icon) {
      case "lock":
        return c(ne.privateHint);
      case "globe":
        return c(ne.publicHint);
      case "building":
        return c(ne.workspaceHint, { workspace: a.label });
      default:
        return c(ne.invitedHint);
    }
  }
  return /* @__PURE__ */ (0, g.jsx)(Vn, {
    content: /* @__PURE__ */ (0, g.jsxs)("span", {
      className: Ft.SharingHint,
      dir: "auto",
      children: [
        /* @__PURE__ */ (0, g.jsx)("span", { children: d() }),
        " ",
        /* @__PURE__ */ (0, g.jsx)("span", { children: c(a.icon === "lock" ? ne.shareHintAction : ne.manageHintAction) })
      ]
    }),
    contentClassName: Be(Ft.Tooltip, Ft.SharingTooltip),
    forceOpen: r ? void 0 : !1,
    interactive: !0,
    maxWidth: "min(300px, calc(100vw - 30px))",
    side: l.startsWith("top") ? "bottom" : "top",
    sideOffset: 12,
    onDismiss: s,
    children: e
  });
}
var Nx = {
  lock: r_,
  globe: o_,
  people: vx,
  building: l_
};
function Dx(e, a) {
  return e === "bottom-center" ? "center" : e.endsWith("left") !== (a === "rtl") ? "start" : "end";
}
function zx({ toolbar: e, onHide: a, onCompose: r }) {
  const { formatMessage: l } = Fe(), s = dy(e.currentUserRole, "editor"), c = s || e.remixEnabled !== !1;
  return /* @__PURE__ */ (0, g.jsxs)(g.Fragment, { children: [
    ["edit", "remix"].map((d) => {
      if (d === "edit" && !s || d === "remix" && !c) return null;
      const h = /* @__PURE__ */ (0, g.jsxs)(g.Fragment, { children: [d === "edit" ? /* @__PURE__ */ (0, g.jsx)(Mh, {}) : /* @__PURE__ */ (0, g.jsx)(gx, {
        "aria-hidden": "true",
        focusable: "false"
      }), l(ne[d])] });
      return /* @__PURE__ */ (0, g.jsx)(ft, {
        variant: "ghost",
        color: "secondary",
        className: Be(bt.Ghost, bt.MenuAction),
        onClick: () => r(d),
        children: h
      }, d);
    }),
    e.currentUserRole === "owner" && e.settingsUrl && /* @__PURE__ */ (0, g.jsx)(zd, {
      asChild: !0,
      children: /* @__PURE__ */ (0, g.jsxs)(ah, {
        variant: "ghost",
        color: "secondary",
        className: Be(bt.Ghost, bt.MenuAction),
        href: e.settingsUrl,
        target: "_blank",
        rel: "noopener noreferrer",
        children: [/* @__PURE__ */ (0, g.jsx)(s_, {
          "aria-hidden": "true",
          focusable: "false"
        }), l(ne.settings)]
      })
    }),
    c && /* @__PURE__ */ (0, g.jsx)("hr", { className: bt.MenuDivider }),
    /* @__PURE__ */ (0, g.jsxs)(ft, {
      variant: "ghost",
      color: "secondary",
      className: Be(bt.Ghost, bt.MenuAction),
      onClick: a,
      children: [/* @__PURE__ */ (0, g.jsx)(a_, {}), l(ne.hide)]
    }),
    /* @__PURE__ */ (0, g.jsx)(zd, {
      asChild: !0,
      children: /* @__PURE__ */ (0, g.jsxs)(ft, {
        variant: "ghost",
        color: "secondary",
        className: Be(bt.Ghost, bt.MenuAction),
        children: [/* @__PURE__ */ (0, g.jsx)(ai, {}), l(ne.close)]
      })
    })
  ] });
}
function u_({ toolbar: e, mobileLayout: a = !1, launcherRef: r, corner: l, dragHandlers: s, onHide: c, onCompose: d, showLogoEntrance: h, finishLogoEntrance: m, showSharingHint: y, onDismissHint: p }) {
  const { formatMessage: _ } = Fe(), w = Oa(Fe().locale), E = dy(e.currentUserRole, "editor"), x = sl(), C = (0, b.useRef)(null), T = (0, b.useRef)(null), M = (0, b.useRef)(!1), D = (0, b.useRef)(!1), [j, H] = (0, b.useState)(!1), [k, B] = (0, b.useState)(!1), { menuRef: Q, menuMounted: K } = e_(C);
  (0, b.useLayoutEffect)(() => {
    !K && D.current && (D.current = !1, c());
  }, [K, c]);
  const q = (0, b.useRef)(null), F = (0, b.useCallback)((ie) => {
    q.current = ie, Q(ie);
  }, [Q]), ee = () => {
    At("toolbar_share_clicked"), M.current = !0, H(k), B(!1), e.openSharing(T.current);
  };
  function ce(ie, se) {
    ie === "edit" && !E || (At(ie === "edit" ? "toolbar_edit_clicked" : "toolbar_remix_clicked"), M.current = !0, H(k && !a), B(!1), d(ie, se));
  }
  const V = /* @__PURE__ */ (0, g.jsx)("span", {
    className: Be(je.LauncherLogo, bt.Logo),
    "data-entering": h ? "" : void 0,
    children: /* @__PURE__ */ (0, g.jsx)(ih, {
      src: th,
      alt: "OpenAI",
      width: 16,
      height: 16,
      onAnimationEnd: m
    })
  });
  return /* @__PURE__ */ (0, g.jsxs)(yu, {
    open: k,
    onOpenChange: (ie) => {
      ie && !k && (H(!1), M.current = !1, At("toolbar_menu_opened")), B(ie);
    },
    children: [/* @__PURE__ */ (0, g.jsx)(Eh, {
      asChild: !0,
      children: /* @__PURE__ */ (0, g.jsxs)("div", {
        ref: C,
        className: Be(bt.Launcher, a && vn.Launcher),
        "data-mobile": a ? "" : void 0,
        "data-toolbar-menu-mounted": K ? "" : void 0,
        "data-menu-open": k || j || D.current ? "" : void 0,
        inert: k,
        role: "toolbar",
        "aria-label": _(ne.label),
        ...s,
        onDragStart: (ie) => ie.preventDefault(),
        children: [
          V,
          /* @__PURE__ */ (0, g.jsx)("span", {
            className: bt.Divider,
            "aria-hidden": "true"
          }),
          /* @__PURE__ */ (0, g.jsx)(Lx, {
            toolbar: e,
            showSharingHint: y && !k && !j,
            corner: l,
            onDismissHint: p,
            buttonRef: (ie) => {
              T.current = ie, r(ie);
            },
            ariaKeyshortcuts: s && !a ? "ArrowUp ArrowDown ArrowLeft ArrowRight" : void 0,
            onClick: ee
          }),
          /* @__PURE__ */ (0, g.jsx)("span", {
            className: bt.Divider,
            "aria-hidden": "true"
          }),
          /* @__PURE__ */ (0, g.jsx)(Th, {
            asChild: !0,
            children: /* @__PURE__ */ (0, g.jsx)(ft, {
              variant: "ghost",
              color: "secondary",
              pill: !0,
              uniform: !0,
              className: Be(bt.Ghost, bt.More),
              "aria-label": _(ne.menu),
              children: /* @__PURE__ */ (0, g.jsx)(n_, {})
            })
          })
        ]
      })
    }), !j && !D.current && /* @__PURE__ */ (0, g.jsx)(bu, {
      container: x,
      children: /* @__PURE__ */ (0, g.jsx)(_u, {
        ref: F,
        className: Be(je.Widget, vn.Menu, bt.Menu),
        "data-mobile": a ? "" : void 0,
        side: l.startsWith("top") ? "bottom" : "top",
        align: Dx(l, w),
        sideOffset: -36,
        collisionPadding: 16,
        updatePositionStrategy: "always",
        inert: !k,
        onOpenAutoFocus: (ie) => {
          ie.preventDefault(), ie.target instanceof HTMLElement && (a ? ie.target : ie.target.querySelector("a, button"))?.focus({ preventScroll: !0 });
        },
        onCloseAutoFocus: (ie) => {
          M.current && ie.preventDefault(), M.current = !1;
        },
        "aria-label": _(ne.menu),
        children: /* @__PURE__ */ (0, g.jsx)("div", {
          className: Be(vn.Actions, bt.MenuActions),
          children: /* @__PURE__ */ (0, g.jsx)(zx, {
            toolbar: e,
            onHide: () => {
              M.current = !0, D.current = !0, B(!1);
            },
            onCompose: (ie) => {
              const se = q.current?.getBoundingClientRect().width;
              se !== void 0 && ce(ie, se);
            }
          })
        })
      })
    })]
  });
}
function Lx({ toolbar: e, buttonRef: a, onClick: r, ariaKeyshortcuts: l, showSharingHint: s, corner: c, onDismissHint: d }) {
  const h = Fe(), m = e.summary ? Nx[e.summary.icon] : yx, y = /* @__PURE__ */ (0, g.jsxs)(ft, {
    variant: "ghost",
    color: "secondary",
    pill: !0,
    ref: a,
    className: Be(bt.Ghost, bt.Shortcut),
    type: "button",
    "data-toolbar-sharing-trigger": "",
    "aria-haspopup": "dialog",
    "aria-keyshortcuts": l,
    onClick: r,
    children: [/* @__PURE__ */ (0, g.jsx)(m, {
      "aria-hidden": "true",
      focusable: "false"
    }), /* @__PURE__ */ (0, g.jsx)("span", {
      className: bt.Label,
      children: e.summary?.label ?? h.formatMessage(ne.share)
    })]
  });
  return !e.summary || e.hideSharingHint || e.currentUserRole === "viewer" ? y : /* @__PURE__ */ (0, g.jsx)(Rx, {
    summary: e.summary,
    enabled: s,
    anchor: c,
    onDismiss: d,
    children: y
  });
}
var Hx = "_Widget_lanvw_1", jx = "_CloseButton_lanvw_7", U1 = {
  Widget: Hx,
  CloseButton: jx
};
function Bx({ toolbar: e, config: a, accountId: r, chatgptOrigin: l, projectId: s, siteTitle: c }) {
  const d = Fe(), h = sl(), m = Kb(), [y] = (0, b.useState)(() => Yb({
    reducedMotion: m,
    initiallyHidden: a.hidden
  })), { state: p, showLogoEntrance: _, actions: w } = au(y), E = p.view === "hidden" || p.view === "dismissed";
  (0, b.useEffect)(() => {
    (m || e.sharingOpen) && w.finishLogoEntrance();
  }, [
    w,
    m,
    e.sharingOpen
  ]);
  const [x] = (0, b.useState)(nh), C = (0, b.useRef)(!1), T = t_(() => {
  }, (D) => {
    D.target instanceof Element && D.target.closest("button, a")?.click();
  });
  (0, b.useEffect)(() => {
    E || C.current || (C.current = !0, At("toolbar_shown"));
  }, [E]);
  function M(D) {
    const j = Tu({
      accountId: r,
      chatgptOrigin: l,
      query: d.formatMessage(D === "remix" ? ne.remixOpenPrompt : Ye.invitationBannerEditPrompt, { site: Pr(c, s) }),
      editContext: D === "edit" ? a.edit_context : void 0
    });
    window.open(j.toString(), "_blank", "noopener,noreferrer"), At(D === "edit" ? "toolbar_edit_submitted" : "toolbar_remix_submitted");
  }
  return E ? null : (0, Zr.createPortal)(/* @__PURE__ */ (0, g.jsx)("div", {
    ref: T.ref,
    className: Be(je.Widget, vn.Widget, U1.Widget),
    style: T.style,
    "data-corner": T.anchor,
    "data-mobile-widget-dragging": T.dragging ? "" : void 0,
    "data-mobile-widget-snapping": T.snapping ? "" : void 0,
    dir: Oa(d.locale),
    lang: d.locale,
    children: /* @__PURE__ */ (0, g.jsx)(Wo, {
      as: "div",
      className: je.WidgetEntrance,
      disableAnimations: m,
      enterDuration: 180,
      preventInitialTransition: !1,
      children: /* @__PURE__ */ (0, g.jsx)("div", { children: e.sharingOpen ? /* @__PURE__ */ (0, g.jsxs)(ft, {
        variant: "ghost",
        color: "secondary",
        pill: !0,
        className: U1.CloseButton,
        "data-toolbar-sharing-close": !0,
        onClick: e.closeSharing,
        children: [/* @__PURE__ */ (0, g.jsx)(ai, { "aria-hidden": "true" }), d.formatMessage(ne.close)]
      }) : /* @__PURE__ */ (0, g.jsx)(u_, {
        mobileLayout: !0,
        toolbar: e,
        launcherRef: () => {
        },
        corner: T.anchor,
        dragHandlers: T.dragHandlers,
        showLogoEntrance: _,
        finishLogoEntrance: w.finishLogoEntrance,
        showSharingHint: !1,
        onDismissHint: () => {
        },
        onCompose: M,
        onHide: () => {
          w.dismiss(), x(!0), At("toolbar_hidden");
        }
      }) }, "mobile-toolbar")
    })
  }), h ?? document.body);
}
var Ux = "_RemixTooltip_6yzd8_1", kx = "_remixTooltipFadeIn_6yzd8_1", Px = "_CloseButton_6yzd8_68", k1 = {
  RemixTooltip: Ux,
  remixTooltipFadeIn: kx,
  CloseButton: Px
}, ld = {
  remixTooltipTitle: {
    id: "sites.dispatch.widget.toolbar.remix_tooltip.title",
    defaultMessage: "Remix this site",
    description: "Title of a one-time tooltip above the published Site's remix composer."
  },
  remixTooltipBody: {
    id: "sites.dispatch.widget.toolbar.remix_tooltip.body",
    defaultMessage: "Describe your changes, then continue in ChatGPT to create your own version.",
    description: "Instructions shown to someone opening the remix composer on a published Site for the first time. Remixing creates a personal version of the Site."
  },
  remixTooltipClose: {
    id: "sites.dispatch.widget.toolbar.remix_tooltip.close",
    defaultMessage: "Dismiss remix tooltip",
    description: "Accessible label for the close button on the one-time Site remix tooltip. The remix composer stays open."
  }
};
function Ix({ onDismiss: e }) {
  const a = Fe();
  return /* @__PURE__ */ (0, g.jsxs)("aside", {
    className: k1.RemixTooltip,
    children: [/* @__PURE__ */ (0, g.jsxs)("div", {
      role: "status",
      children: [/* @__PURE__ */ (0, g.jsx)("strong", { children: /* @__PURE__ */ (0, g.jsx)(Ja, { ...ld.remixTooltipTitle }) }), /* @__PURE__ */ (0, g.jsx)("p", { children: /* @__PURE__ */ (0, g.jsx)(Ja, { ...ld.remixTooltipBody }) })]
    }), /* @__PURE__ */ (0, g.jsx)(ft, {
      className: k1.CloseButton,
      variant: "ghost",
      uniform: !0,
      "aria-label": a.formatMessage(ld.remixTooltipClose),
      onClick: e,
      children: /* @__PURE__ */ (0, g.jsx)(ai, { "aria-hidden": "true" })
    })]
  });
}
var sd = "cubic-bezier(0.2, 1.25, 0.3, 1)", P1 = 360, I1 = 280, Zx = 1e3, Gx = 180, Vx = 100, $x = 200, Fx = 80, qx = 140, Xx = 120, Z1 = 0, G1 = 160, ud = 290, Rh = 12, V1 = Rh + 4, $1 = 8, Yx = 280, Wx = 52, Qx = -8, Kx = -12;
function Jx(e) {
  return e.key === "Escape" && !e.defaultPrevented && !e.repeat && !e.isComposing && e.keyCode !== 229;
}
function e7(e) {
  return !(e.defaultPrevented || e.repeat || e.isComposing || e.code !== "KeyM" || !e.altKey || e.ctrlKey || e.metaKey || e.shiftKey || e.getModifierState("AltGraph") || document.designMode === "on" || e.composedPath().some((a) => a instanceof HTMLElement && (a.isContentEditable || a.matches('input, textarea, select, [role="textbox"], [role="searchbox"], [role="combobox"], [role="spinbutton"]'))));
}
function c_(e) {
  return Xs() ? e.toolbar ? /* @__PURE__ */ (0, g.jsx)(Bx, {
    ...e,
    toolbar: e.toolbar
  }) : /* @__PURE__ */ (0, g.jsx)(hx, { ...e }) : /* @__PURE__ */ (0, g.jsx)(n7, { ...e });
}
function t7({ toolbar: e, opensChatGPT: a, suppressTooltip: r, disabled: l, tooltipSide: s }) {
  const c = Fe().formatMessage(a ? ne.openChatGPT : Ye.editorWidgetSendAction), d = /* @__PURE__ */ (0, g.jsx)(ft, {
    className: je.SendButton,
    color: "primary",
    variant: "solid",
    size: "lg",
    iconSize: "lg",
    pill: !0,
    uniform: !0,
    type: "submit",
    onMouseDown: (h) => {
      h.button === 0 && h.preventDefault();
    },
    "aria-label": c,
    disabled: l,
    children: /* @__PURE__ */ (0, g.jsx)(ax, {
      className: e ? je.ComposerArrow : void 0,
      "data-open": a ? "" : void 0,
      "aria-hidden": "true",
      focusable: "false"
    })
  });
  return e ? /* @__PURE__ */ (0, g.jsx)(Vn, {
    content: a && !r ? c : null,
    contentClassName: Be(Ft.Tooltip, je.ComposerTooltip),
    side: s,
    sideOffset: Rh + $1,
    align: "end",
    alignOffset: -$1,
    children: d
  }) : d;
}
function n7({ config: e, accountId: a, chatgptOrigin: r, projectId: l, siteTitle: s, toolbar: c }) {
  const d = Fe(), h = (0, b.useRef)(null), m = (0, b.useRef)(null), y = (0, b.useRef)(null), p = (0, b.useRef)(!1), _ = (0, b.useRef)(!1), w = Kb(), E = nx(), [x] = (0, b.useState)(() => Yb({
    reducedMotion: w,
    initiallyHidden: e.hidden
  })), [C] = (0, b.useState)(nh), { state: T, composerMode: M, actions: D, corner: j, hasInteracted: H, showHideHint: k, showLogoEntrance: B } = au(x), Q = j === "bottom-center" ? "center" : j.endsWith("left") ? "start" : "end", [K, q] = (0, b.useState)(), F = T.view === "composer", ee = !!c, ce = (0, b.useRef)(!1), [V, ie] = (0, b.useState)(!1), se = F && V, L = (0, b.useCallback)(() => {
    ie(!1), h.current?.focus({ preventScroll: !0 });
  }, []);
  (0, b.useLayoutEffect)(() => {
    if (!ee || F || w) return;
    const ve = m.current?.querySelector(`.${je.ShellLayout}`), Ot = ve?.querySelector(`.${je.Composer}`);
    if (!ve || !Ot) return;
    const Ut = Ot.getBoundingClientRect().height, kt = getComputedStyle(ve).minHeight;
    ve.style.height = kt;
    const Fr = ve.animate([{ height: `${Ut}px` }, { height: kt }], {
      delay: Z1,
      duration: G1,
      easing: "ease-in-out",
      fill: "backwards"
    });
    return () => {
      Fr.cancel(), ve.style.height = "";
    };
  }, [
    F,
    ee,
    w
  ]);
  const A = F && !c ? Vx : 0, N = F ? P1 : I1, te = T.view === "hiding", oe = te || T.view === "hidden", Ee = T.view !== "handoff" && T.view !== "dismissed" && (E || !oe), O = E && oe, $ = !E || H, re = k8(O, T.view === "hidden", w, k), le = O && T.view === "hidden" && !re.hintDismissed && (re.hoverHintVisible || k && !re.quiet && re.phase !== "away"), { widgetRef: ye, contentRef: _e, style: ue, dragging: me, dragHandlers: Te, snapping: Ce, shadowStyle: Oe } = Q8({
    corner: j,
    onCornerChange: D.setCorner,
    onInteract: D.markInteracted,
    anchorSharingClose: c?.anchorSharingClose ?? !1,
    preserveChildClickTargets: !!c,
    enableMomentum: !!c
  }), qe = T.view === "handoff" ? "" : T.draft, dt = !!c && !qe.trim(), St = jd({
    accountId: a,
    projectId: l,
    browserUrl: window.location.href,
    chatgptOrigin: r,
    query: d.formatMessage(Ye.editorWidgetDefaultEditPrompt, { site: Pr(s, l) }),
    isDefaultPrompt: !0,
    editContext: e.edit_context
  });
  (0, b.useEffect)(() => {
    le && D.markHideHintSeen();
  }, [le, D]), (0, b.useEffect)(() => {
    !Ee || oe || _.current || (_.current = !0, At(c ? "toolbar_shown" : "editor_widget_shown"));
  }, [
    Ee,
    oe,
    c
  ]), (0, b.useEffect)(() => {
    if (T.view !== "handoff") return;
    const ve = window.setTimeout(D.finishHandoff, Zx);
    return () => window.clearTimeout(ve);
  }, [T.view, D]);
  const rt = (0, b.useCallback)(() => {
    const ve = y.current;
    !p.current || !ve || ve.closest("[inert]") || (p.current = !1, ve.focus({ preventScroll: !0 }));
  }, []), on = (0, b.useCallback)((ve) => {
    y.current = ve, rt();
  }, [rt]);
  (0, b.useLayoutEffect)(() => {
    w && (te && D.finishHide(), D.finishLogoEntrance());
  }, [
    te,
    w,
    D
  ]), (0, b.useEffect)(() => {
    T.view === "launcher" && rt();
  }, [T.view, rt]);
  const Xt = (0, b.useCallback)(() => {
    p.current = !0, D.restoreHidden(), C(!1), At(c ? "toolbar_restored" : "editor_widget_restored");
  }, [
    D,
    C,
    c
  ]);
  (0, b.useEffect)(() => {
    if (!O) return;
    function ve(Ot) {
      e7(Ot) && (Ot.preventDefault(), Xt());
    }
    return window.addEventListener("keydown", ve), () => window.removeEventListener("keydown", ve);
  }, [O, Xt]);
  function jn(ve) {
    se || ve.relatedTarget instanceof Node && ve.currentTarget.contains(ve.relatedTarget) || D.collapse();
  }
  function _n(ve) {
    if (!(!F || !Jx(ve.nativeEvent))) {
      if (ve.preventDefault(), ve.stopPropagation(), se) {
        L();
        return;
      }
      p.current = !0, D.collapse();
    }
  }
  function wn() {
    C(!0), E ? D.hide() : D.dismiss(), At(c ? "toolbar_hidden" : "editor_widget_hidden");
  }
  function Bn(ve) {
    ve.preventDefault();
    const Ot = D.beginHandoff({ allowEmpty: !!c });
    if (Ot === null) return;
    At(c ? M === "remix" ? "toolbar_remix_submitted" : "toolbar_edit_submitted" : "editor_widget_edit_request_submitted");
    const Ut = Pi(Ot.trim());
    Ut.searchParams.set("site_edit_source", "widget");
    try {
      window.open(Ut.toString(), "_blank", "noopener,noreferrer");
    } catch {
    }
  }
  function Pi(ve) {
    const Ot = Pr(s, l), Ut = d.formatMessage(Ye.invitationBannerEditPrompt, { site: Ot });
    if (c && !ve) {
      const kt = M === "remix";
      return Tu({
        accountId: a,
        chatgptOrigin: r,
        query: kt ? d.formatMessage(ne.remixOpenPrompt, { site: Ot }) : Ut,
        editContext: kt ? void 0 : e.edit_context
      });
    }
    if (c && M === "remix") {
      const kt = new URL(c.remixUrl);
      return kt.searchParams.set("prompt", `${kt.searchParams.get("prompt")}

${ve}`), kt;
    }
    return jd({
      accountId: a,
      projectId: l,
      browserUrl: window.location.href,
      chatgptOrigin: r,
      query: `${Ut}

${ve}`,
      editContext: e.edit_context
    });
  }
  function $r() {
    return !F && c ? Z1 + G1 : F ? c ? 0 : $x : Fx;
  }
  function xt() {
    return F ? /* @__PURE__ */ (0, g.jsxs)("form", {
      className: je.Composer,
      onSubmit: Bn,
      children: [/* @__PURE__ */ (0, g.jsx)(d9, {
        textareaRef: h,
        className: je.Textarea,
        autoFocus: !0,
        "aria-label": d.formatMessage(c && M === "remix" ? ne.remixComposerPlaceholder : Ye.editorWidgetComposerLabel),
        placeholder: d.formatMessage(c && M === "remix" ? ne.remixComposerPlaceholder : Ye.editorWidgetComposerPlaceholder),
        value: qe,
        onKeyDown: (ve) => {
          ve.stopPropagation(), _n(ve);
        },
        onKeyUp: (ve) => ve.stopPropagation(),
        onKeyPress: (ve) => ve.stopPropagation(),
        onChange: (ve) => D.changeDraft(ve.target.value)
      }), /* @__PURE__ */ (0, g.jsx)("div", {
        className: je.ComposerFooter,
        children: /* @__PURE__ */ (0, g.jsx)(t7, {
          toolbar: ee,
          opensChatGPT: dt,
          suppressTooltip: se,
          disabled: !c && !qe.trim(),
          tooltipSide: j.startsWith("top") ? "bottom" : "top"
        })
      })]
    }, "composer") : c?.sharingOpen ? /* @__PURE__ */ (0, g.jsxs)("button", {
      "data-toolbar-sharing-close": !0,
      ref: on,
      className: Be(je.Launcher, je.SharingClose),
      onClick: c.closeSharing,
      children: [/* @__PURE__ */ (0, g.jsx)(ai, { "aria-hidden": "true" }), d.formatMessage(ne.close)]
    }, "sharing-close") : c ? /* @__PURE__ */ (0, g.jsx)(u_, {
      toolbar: c,
      launcherRef: on,
      corner: j,
      showSharingHint: !H && !oe && !me,
      onDismissHint: D.markInteracted,
      dragHandlers: E ? Te : void 0,
      onHide: wn,
      onCompose: (ve, Ot) => {
        q(Math.max(Ot, 200));
        const Ut = ve === "remix" && e.remix_tooltip_hidden === !1 && !ce.current;
        ie(Ut), D.open(ve), Ut && (ce.current = !0, G4());
      },
      showLogoEntrance: B,
      finishLogoEntrance: D.finishLogoEntrance
    }, "launcher") : /* @__PURE__ */ (0, g.jsxs)("div", {
      className: je.LauncherRow,
      children: [/* @__PURE__ */ (0, g.jsx)(Vn, {
        contentClassName: Ft.Tooltip,
        maxWidth: ud,
        content: $ ? null : d.formatMessage(Ye.editorWidgetOpenAction),
        sideOffset: V1,
        children: /* @__PURE__ */ (0, g.jsx)(ah, {
          className: je.LogoButton,
          href: St.toString(),
          target: "_blank",
          rel: "noopener noreferrer",
          onClick: () => At("editor_widget_open_in_chatgpt_clicked"),
          variant: "ghost",
          size: "lg",
          pill: !0,
          uniform: !0,
          "aria-label": d.formatMessage(Ye.editorWidgetOpenAction),
          children: /* @__PURE__ */ (0, g.jsx)("span", {
            className: je.LauncherLogo,
            "data-entering": B ? "" : void 0,
            "aria-hidden": "true",
            children: /* @__PURE__ */ (0, g.jsx)(ih, {
              src: th,
              alt: "",
              width: 18,
              height: 18,
              onAnimationEnd: D.finishLogoEntrance
            })
          })
        })
      }), /* @__PURE__ */ (0, g.jsx)(Vn, {
        contentClassName: Ft.Tooltip,
        maxWidth: ud,
        content: $ || me ? null : d.formatMessage(Ye.editorWidgetLaunchTooltip),
        sideOffset: Rh,
        children: /* @__PURE__ */ (0, g.jsx)("button", {
          ref: on,
          className: je.Launcher,
          type: "button",
          "aria-expanded": "false",
          "aria-keyshortcuts": E ? "ArrowUp ArrowDown ArrowLeft ArrowRight" : void 0,
          ...E ? Te : {},
          "aria-label": d.formatMessage(Ye.editorWidgetLaunchAction),
          onClick: () => {
            D.open(), At("editor_widget_composer_opened");
          },
          children: /* @__PURE__ */ (0, g.jsx)("span", {
            className: je.LauncherLabel,
            children: /* @__PURE__ */ (0, g.jsx)(Ja, { ...Ye.editorWidgetLaunchAction })
          })
        })
      })]
    }, "launcher");
  }
  return /* @__PURE__ */ (0, g.jsxs)(g.Fragment, { children: [me && !c && /* @__PURE__ */ (0, g.jsx)("div", {
    className: je.LandingShadow,
    style: Oe,
    "aria-hidden": "true"
  }), /* @__PURE__ */ (0, g.jsx)(Wo, {
    as: "div",
    className: je.WidgetExit,
    disableAnimations: w,
    exitDuration: 0,
    onExit: (ve) => {
      ve.inert = !0;
    },
    onEnter: (ve) => {
      ve.inert = !1, rt();
    },
    children: Ee && /* @__PURE__ */ (0, g.jsxs)("div", {
      ref: ye,
      className: je.Widget,
      style: ue,
      "data-sharing-open": c?.anchorSharingClose ? "" : void 0,
      "data-dragging": me ? "" : void 0,
      "data-snapping": Ce ? "" : void 0,
      "data-corner": j,
      "data-tucked": oe ? "" : void 0,
      "data-peek-phase": oe ? re.phase : void 0,
      "data-quiet-tuck": re.quiet ? "" : void 0,
      dir: Oa(d.locale),
      lang: d.locale,
      onBlur: jn,
      onClickCapture: D.markInteracted,
      onPointerDownCapture: c ? D.markInteracted : void 0,
      onKeyDownCapture: c ? D.markInteracted : void 0,
      onKeyDown: _n,
      children: [/* @__PURE__ */ (0, g.jsx)(Wo, {
        as: "div",
        className: je.WidgetEntrance,
        disableAnimations: w,
        enterDuration: Gx,
        preventInitialTransition: oe,
        children: /* @__PURE__ */ (0, g.jsx)("div", {
          ref: m,
          className: Be(je.Panel, c && je.ToolbarPanel),
          "data-expanded": F ? "" : void 0,
          children: /* @__PURE__ */ (0, g.jsxs)("div", {
            className: je.Shell,
            onTransitionEnd: (ve) => {
              ve.target === ve.currentTarget && ve.propertyName === "transform" && !ve.pseudoElement && D.finishHide();
            },
            children: [/* @__PURE__ */ (0, g.jsxs)("div", {
              ref: _e,
              className: je.ShellControls,
              inert: oe,
              children: [/* @__PURE__ */ (0, g.jsx)(Y5, {
                as: "div",
                className: je.ShellLayout,
                disableAnimations: w,
                transitionClassName: je.ShellContent,
                dimension: "width",
                enterFromSize: F ? K : void 0,
                resizeContents: !!(c && F),
                itemAnchor: Q,
                hideOverflow: !0,
                initial: { opacity: 0 },
                enter: {
                  opacity: 1,
                  delay: $r(),
                  duration: qx
                },
                exit: {
                  opacity: 0,
                  duration: Xx
                },
                layoutEnter: {
                  delay: A,
                  duration: P1,
                  timingFunction: sd
                },
                layoutExit: {
                  duration: I1,
                  timingFunction: sd
                },
                layoutMove: {
                  delay: A,
                  duration: N,
                  timingFunction: sd
                },
                children: xt()
              }), !c && /* @__PURE__ */ (0, g.jsx)(Vn, {
                contentClassName: Ft.Tooltip,
                maxWidth: ud,
                content: F || $ ? null : d.formatMessage(Ye.editorWidgetHideAction),
                sideOffset: V1,
                children: /* @__PURE__ */ (0, g.jsx)(ft, {
                  className: je.LauncherDismissButton,
                  variant: "ghost",
                  size: "lg",
                  pill: !0,
                  uniform: !0,
                  "aria-hidden": F,
                  tabIndex: F ? -1 : 0,
                  "aria-label": d.formatMessage(Ye.editorWidgetHideAction),
                  onClick: wn,
                  children: /* @__PURE__ */ (0, g.jsx)(ai, {
                    "aria-hidden": "true",
                    focusable: "false"
                  })
                })
              })]
            }), se && /* @__PURE__ */ (0, g.jsx)(Ix, { onDismiss: L })]
          })
        }, "panel")
      }), O && /* @__PURE__ */ (0, g.jsx)(Vn, {
        contentClassName: Be(Ft.Tooltip, Ft.HideHint),
        forceOpen: le,
        onDismiss: re.dismissHint,
        interactive: !0,
        ...re.hintHandlers,
        side: j.startsWith("top") ? "bottom" : "top",
        align: Q,
        alignOffset: j === "bottom-center" ? 0 : Wx,
        sideOffset: j.startsWith("top") ? Qx : Kx,
        maxWidth: Yx,
        content: /* @__PURE__ */ (0, g.jsxs)("span", {
          className: Ft.HideHintContent,
          children: [/* @__PURE__ */ (0, g.jsx)("span", {
            className: Ft.HideHintText,
            children: /* @__PURE__ */ (0, g.jsx)(Ja, { ...j === "bottom-center" ? Ye.editorWidgetHideHintBottomCenter : Ye.editorWidgetHideHint })
          }), /* @__PURE__ */ (0, g.jsxs)("span", {
            className: Ft.Shortcut,
            children: [/* @__PURE__ */ (0, g.jsx)("kbd", { children: c9() ? "⌥" : "Alt" }), /* @__PURE__ */ (0, g.jsx)("kbd", { children: "M" })]
          })]
        }),
        children: /* @__PURE__ */ (0, g.jsx)("button", {
          className: je.CornerTarget,
          type: "button",
          "aria-label": d.formatMessage(Ye.editorWidgetRestoreAction),
          "aria-keyshortcuts": "Alt+M",
          ...re.targetHandlers,
          onClick: Xt
        })
      })]
    }, "widget")
  })] });
}
var a7 = "_Banner_1iivt_1", i7 = "_Content_1iivt_34", r7 = "_Message_1iivt_42", o7 = "_OwnerName_1iivt_50", l7 = "_Actions_1iivt_54", s7 = "_EditLink_1iivt_62", u7 = "_DismissButton_1iivt_63", Mi = {
  Banner: a7,
  Content: i7,
  Message: r7,
  OwnerName: o7,
  Actions: l7,
  EditLink: s7,
  DismissButton: u7
}, c7 = "/_internal/sites_widget/invitation-banner/dismiss";
function F1(e) {
  const a = e.currentTarget, r = a.offsetWidth;
  let l = 0.985;
  r <= 80 ? l = 0.96 : r <= 150 ? l = 0.97 : r <= 220 ? l = 0.98 : r > 600 && (l = 0.995), a.style.setProperty("--scale", l.toString());
}
function f7({ editContext: e, accountId: a, chatgptOrigin: r, ownerName: l, projectId: s, siteTitle: c, onDismiss: d }) {
  const h = Fe();
  (0, b.useEffect)(() => {
    At("editor_invite_banner_shown");
  }, []);
  const m = jd({
    editContext: e,
    accountId: a,
    projectId: s,
    browserUrl: window.location.href,
    chatgptOrigin: r,
    query: h.formatMessage(Ye.invitationBannerEditPrompt, { site: Pr(c, s) }),
    isDefaultPrompt: !0
  });
  function y() {
    At("editor_invite_banner_dismissed"), d(), fetch(c7, {
      method: "POST",
      credentials: "same-origin"
    }).catch(() => {
    });
  }
  function p(_) {
    At("editor_invite_banner_edit_with_chat_clicked");
    const w = new URL(_.currentTarget.href);
    w.searchParams.has("browser_url") && w.searchParams.set("browser_url", window.location.href), _.currentTarget.href = w.toString();
  }
  return /* @__PURE__ */ (0, g.jsx)("aside", {
    className: Mi.Banner,
    "aria-label": h.formatMessage(Ye.invitationBannerLabel),
    dir: Oa(h.locale),
    lang: h.locale,
    children: /* @__PURE__ */ (0, g.jsxs)("div", {
      className: Mi.Content,
      children: [/* @__PURE__ */ (0, g.jsx)("div", {
        className: Mi.Message,
        children: l ? /* @__PURE__ */ (0, g.jsx)(Ja, {
          ...Ye.invitationBannerMessageWithOwner,
          values: {
            ownerName: l,
            strong: (_) => /* @__PURE__ */ (0, g.jsx)("strong", {
              className: Mi.OwnerName,
              children: _
            })
          }
        }) : /* @__PURE__ */ (0, g.jsx)(Ja, { ...Ye.invitationBannerMessage })
      }), /* @__PURE__ */ (0, g.jsxs)("div", {
        className: Mi.Actions,
        children: [/* @__PURE__ */ (0, g.jsxs)("a", {
          className: Mi.EditLink,
          href: m.toString(),
          target: "_blank",
          rel: "noopener noreferrer",
          onClick: p,
          onPointerEnter: F1,
          children: [/* @__PURE__ */ (0, g.jsx)(Mh, {
            "aria-hidden": "true",
            focusable: "false"
          }), /* @__PURE__ */ (0, g.jsx)(Ja, { ...Ye.invitationBannerEditAction })]
        }), /* @__PURE__ */ (0, g.jsx)("button", {
          className: Mi.DismissButton,
          type: "button",
          "aria-label": h.formatMessage(Ye.invitationBannerDismissAction),
          onPointerEnter: F1,
          onClick: y,
          children: /* @__PURE__ */ (0, g.jsx)(ai, {
            "aria-hidden": "true",
            focusable: "false"
          })
        })]
      })]
    })
  });
}
var d7 = "codex-browser-sidebar-comments-root";
function Bd() {
  return document.getElementById(d7) !== null;
}
var h7 = /* @__PURE__ */ bn(((e) => {
  function a(L, A) {
    var N = L.length;
    L.push(A);
    e: for (; 0 < N; ) {
      var te = N - 1 >>> 1, oe = L[te];
      if (0 < s(oe, A)) L[te] = A, L[N] = oe, N = te;
      else break e;
    }
  }
  function r(L) {
    return L.length === 0 ? null : L[0];
  }
  function l(L) {
    if (L.length === 0) return null;
    var A = L[0], N = L.pop();
    if (N !== A) {
      L[0] = N;
      e: for (var te = 0, oe = L.length, Ee = oe >>> 1; te < Ee; ) {
        var O = 2 * (te + 1) - 1, $ = L[O], re = O + 1, le = L[re];
        if (0 > s($, N)) re < oe && 0 > s(le, $) ? (L[te] = le, L[re] = N, te = re) : (L[te] = $, L[O] = N, te = O);
        else if (re < oe && 0 > s(le, N)) L[te] = le, L[re] = N, te = re;
        else break e;
      }
    }
    return A;
  }
  function s(L, A) {
    var N = L.sortIndex - A.sortIndex;
    return N !== 0 ? N : L.id - A.id;
  }
  if (e.unstable_now = void 0, typeof performance == "object" && typeof performance.now == "function") {
    var c = performance;
    e.unstable_now = function() {
      return c.now();
    };
  } else {
    var d = Date, h = d.now();
    e.unstable_now = function() {
      return d.now() - h;
    };
  }
  var m = [], y = [], p = 1, _ = null, w = 3, E = !1, x = !1, C = !1, T = !1, M = typeof setTimeout == "function" ? setTimeout : null, D = typeof clearTimeout == "function" ? clearTimeout : null, j = typeof setImmediate < "u" ? setImmediate : null;
  function H(L) {
    for (var A = r(y); A !== null; ) {
      if (A.callback === null) l(y);
      else if (A.startTime <= L) l(y), A.sortIndex = A.expirationTime, a(m, A);
      else break;
      A = r(y);
    }
  }
  function k(L) {
    if (C = !1, H(L), !x) if (r(m) !== null) x = !0, B || (B = !0, ce());
    else {
      var A = r(y);
      A !== null && se(k, A.startTime - L);
    }
  }
  var B = !1, Q = -1, K = 5, q = -1;
  function F() {
    return T ? !0 : !(e.unstable_now() - q < K);
  }
  function ee() {
    if (T = !1, B) {
      var L = e.unstable_now();
      q = L;
      var A = !0;
      try {
        e: {
          x = !1, C && (C = !1, D(Q), Q = -1), E = !0;
          var N = w;
          try {
            t: {
              for (H(L), _ = r(m); _ !== null && !(_.expirationTime > L && F()); ) {
                var te = _.callback;
                if (typeof te == "function") {
                  _.callback = null, w = _.priorityLevel;
                  var oe = te(_.expirationTime <= L);
                  if (L = e.unstable_now(), typeof oe == "function") {
                    _.callback = oe, H(L), A = !0;
                    break t;
                  }
                  _ === r(m) && l(m), H(L);
                } else l(m);
                _ = r(m);
              }
              if (_ !== null) A = !0;
              else {
                var Ee = r(y);
                Ee !== null && se(k, Ee.startTime - L), A = !1;
              }
            }
            break e;
          } finally {
            _ = null, w = N, E = !1;
          }
          A = void 0;
        }
      } finally {
        A ? ce() : B = !1;
      }
    }
  }
  var ce;
  if (typeof j == "function") ce = function() {
    j(ee);
  };
  else if (typeof MessageChannel < "u") {
    var V = new MessageChannel(), ie = V.port2;
    V.port1.onmessage = ee, ce = function() {
      ie.postMessage(null);
    };
  } else ce = function() {
    M(ee, 0);
  };
  function se(L, A) {
    Q = M(function() {
      L(e.unstable_now());
    }, A);
  }
  e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(L) {
    L.callback = null;
  }, e.unstable_forceFrameRate = function(L) {
    0 > L || 125 < L ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : K = 0 < L ? Math.floor(1e3 / L) : 5;
  }, e.unstable_getCurrentPriorityLevel = function() {
    return w;
  }, e.unstable_next = function(L) {
    switch (w) {
      case 1:
      case 2:
      case 3:
        var A = 3;
        break;
      default:
        A = w;
    }
    var N = w;
    w = A;
    try {
      return L();
    } finally {
      w = N;
    }
  }, e.unstable_requestPaint = function() {
    T = !0;
  }, e.unstable_runWithPriority = function(L, A) {
    switch (L) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
        break;
      default:
        L = 3;
    }
    var N = w;
    w = L;
    try {
      return A();
    } finally {
      w = N;
    }
  }, e.unstable_scheduleCallback = function(L, A, N) {
    var te = e.unstable_now();
    switch (typeof N == "object" && N !== null ? (N = N.delay, N = typeof N == "number" && 0 < N ? te + N : te) : N = te, L) {
      case 1:
        var oe = -1;
        break;
      case 2:
        oe = 250;
        break;
      case 5:
        oe = 1073741823;
        break;
      case 4:
        oe = 1e4;
        break;
      default:
        oe = 5e3;
    }
    return oe = N + oe, L = {
      id: p++,
      callback: A,
      priorityLevel: L,
      startTime: N,
      expirationTime: oe,
      sortIndex: -1
    }, N > te ? (L.sortIndex = N, a(y, L), r(m) === null && L === r(y) && (C ? (D(Q), Q = -1) : C = !0, se(k, N - te))) : (L.sortIndex = oe, a(m, L), x || E || (x = !0, B || (B = !0, ce()))), L;
  }, e.unstable_shouldYield = F, e.unstable_wrapCallback = function(L) {
    var A = w;
    return function() {
      var N = w;
      w = A;
      try {
        return L.apply(this, arguments);
      } finally {
        w = N;
      }
    };
  };
})), m7 = /* @__PURE__ */ bn(((e, a) => {
  a.exports = h7();
})), p7 = /* @__PURE__ */ bn(((e) => {
  var a = m7(), r = Gd(), l = yy();
  function s(t) {
    var n = "https://react.dev/errors/" + t;
    if (1 < arguments.length) {
      n += "?args[]=" + encodeURIComponent(arguments[1]);
      for (var i = 2; i < arguments.length; i++) n += "&args[]=" + encodeURIComponent(arguments[i]);
    }
    return "Minified React error #" + t + "; visit " + n + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  function c(t) {
    return !(!t || t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11);
  }
  function d(t) {
    var n = t, i = t;
    if (t.alternate) for (; n.return; ) n = n.return;
    else {
      t = n;
      do
        n = t, (n.flags & 4098) !== 0 && (i = n.return), t = n.return;
      while (t);
    }
    return n.tag === 3 ? i : null;
  }
  function h(t) {
    if (t.tag === 13) {
      var n = t.memoizedState;
      if (n === null && (t = t.alternate, t !== null && (n = t.memoizedState)), n !== null) return n.dehydrated;
    }
    return null;
  }
  function m(t) {
    if (t.tag === 31) {
      var n = t.memoizedState;
      if (n === null && (t = t.alternate, t !== null && (n = t.memoizedState)), n !== null) return n.dehydrated;
    }
    return null;
  }
  function y(t) {
    if (d(t) !== t) throw Error(s(188));
  }
  function p(t) {
    var n = t.alternate;
    if (!n) {
      if (n = d(t), n === null) throw Error(s(188));
      return n !== t ? null : t;
    }
    for (var i = t, o = n; ; ) {
      var u = i.return;
      if (u === null) break;
      var f = u.alternate;
      if (f === null) {
        if (o = u.return, o !== null) {
          i = o;
          continue;
        }
        break;
      }
      if (u.child === f.child) {
        for (f = u.child; f; ) {
          if (f === i) return y(u), t;
          if (f === o) return y(u), n;
          f = f.sibling;
        }
        throw Error(s(188));
      }
      if (i.return !== o.return) i = u, o = f;
      else {
        for (var v = !1, S = u.child; S; ) {
          if (S === i) {
            v = !0, i = u, o = f;
            break;
          }
          if (S === o) {
            v = !0, o = u, i = f;
            break;
          }
          S = S.sibling;
        }
        if (!v) {
          for (S = f.child; S; ) {
            if (S === i) {
              v = !0, i = f, o = u;
              break;
            }
            if (S === o) {
              v = !0, o = f, i = u;
              break;
            }
            S = S.sibling;
          }
          if (!v) throw Error(s(189));
        }
      }
      if (i.alternate !== o) throw Error(s(190));
    }
    if (i.tag !== 3) throw Error(s(188));
    return i.stateNode.current === i ? t : n;
  }
  function _(t) {
    var n = t.tag;
    if (n === 5 || n === 26 || n === 27 || n === 6) return t;
    for (t = t.child; t !== null; ) {
      if (n = _(t), n !== null) return n;
      t = t.sibling;
    }
    return null;
  }
  var w = Object.assign, E = /* @__PURE__ */ Symbol.for("react.element"), x = /* @__PURE__ */ Symbol.for("react.transitional.element"), C = /* @__PURE__ */ Symbol.for("react.portal"), T = /* @__PURE__ */ Symbol.for("react.fragment"), M = /* @__PURE__ */ Symbol.for("react.strict_mode"), D = /* @__PURE__ */ Symbol.for("react.profiler"), j = /* @__PURE__ */ Symbol.for("react.consumer"), H = /* @__PURE__ */ Symbol.for("react.context"), k = /* @__PURE__ */ Symbol.for("react.forward_ref"), B = /* @__PURE__ */ Symbol.for("react.suspense"), Q = /* @__PURE__ */ Symbol.for("react.suspense_list"), K = /* @__PURE__ */ Symbol.for("react.memo"), q = /* @__PURE__ */ Symbol.for("react.lazy"), F = /* @__PURE__ */ Symbol.for("react.activity"), ee = /* @__PURE__ */ Symbol.for("react.memo_cache_sentinel"), ce = Symbol.iterator;
  function V(t) {
    return t === null || typeof t != "object" ? null : (t = ce && t[ce] || t["@@iterator"], typeof t == "function" ? t : null);
  }
  var ie = /* @__PURE__ */ Symbol.for("react.client.reference");
  function se(t) {
    if (t == null) return null;
    if (typeof t == "function") return t.$$typeof === ie ? null : t.displayName || t.name || null;
    if (typeof t == "string") return t;
    switch (t) {
      case T:
        return "Fragment";
      case D:
        return "Profiler";
      case M:
        return "StrictMode";
      case B:
        return "Suspense";
      case Q:
        return "SuspenseList";
      case F:
        return "Activity";
    }
    if (typeof t == "object") switch (t.$$typeof) {
      case C:
        return "Portal";
      case H:
        return t.displayName || "Context";
      case j:
        return (t._context.displayName || "Context") + ".Consumer";
      case k:
        var n = t.render;
        return t = t.displayName, t || (t = n.displayName || n.name || "", t = t !== "" ? "ForwardRef(" + t + ")" : "ForwardRef"), t;
      case K:
        return n = t.displayName || null, n !== null ? n : se(t.type) || "Memo";
      case q:
        n = t._payload, t = t._init;
        try {
          return se(t(n));
        } catch {
        }
    }
    return null;
  }
  var L = Array.isArray, A = r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, N = l.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, te = {
    pending: !1,
    data: null,
    method: null,
    action: null
  }, oe = [], Ee = -1;
  function O(t) {
    return { current: t };
  }
  function $(t) {
    0 > Ee || (t.current = oe[Ee], oe[Ee] = null, Ee--);
  }
  function re(t, n) {
    Ee++, oe[Ee] = t.current, t.current = n;
  }
  var le = O(null), ye = O(null), _e = O(null), ue = O(null);
  function me(t, n) {
    switch (re(_e, n), re(ye, t), re(le, null), n.nodeType) {
      case 9:
      case 11:
        t = (t = n.documentElement) && (t = t.namespaceURI) ? Fv(t) : 0;
        break;
      default:
        if (t = n.tagName, n = n.namespaceURI) n = Fv(n), t = qv(n, t);
        else switch (t) {
          case "svg":
            t = 1;
            break;
          case "math":
            t = 2;
            break;
          default:
            t = 0;
        }
    }
    $(le), re(le, t);
  }
  function Te() {
    $(le), $(ye), $(_e);
  }
  function Ce(t) {
    t.memoizedState !== null && re(ue, t);
    var n = le.current, i = qv(n, t.type);
    n !== i && (re(ye, t), re(le, i));
  }
  function Oe(t) {
    ye.current === t && ($(le), $(ye)), ue.current === t && ($(ue), jo._currentValue = te);
  }
  var qe, dt;
  function St(t) {
    if (qe === void 0) try {
      throw Error();
    } catch (i) {
      var n = i.stack.trim().match(/\n( *(at )?)/);
      qe = n && n[1] || "", dt = -1 < i.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < i.stack.indexOf("@") ? "@unknown:0:0" : "";
    }
    return `
` + qe + t + dt;
  }
  var rt = !1;
  function on(t, n) {
    if (!t || rt) return "";
    rt = !0;
    var i = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      var o = { DetermineComponentFrameRoot: function() {
        try {
          if (n) {
            var J = function() {
              throw Error();
            };
            if (Object.defineProperty(J.prototype, "props", { set: function() {
              throw Error();
            } }), typeof Reflect == "object" && Reflect.construct) {
              try {
                Reflect.construct(J, []);
              } catch (G) {
                var Z = G;
              }
              Reflect.construct(t, [], J);
            } else {
              try {
                J.call();
              } catch (G) {
                Z = G;
              }
              t.call(J.prototype);
            }
          } else {
            try {
              throw Error();
            } catch (G) {
              Z = G;
            }
            (J = t()) && typeof J.catch == "function" && J.catch(function() {
            });
          }
        } catch (G) {
          if (G && Z && typeof G.stack == "string") return [G.stack, Z.stack];
        }
        return [null, null];
      } };
      o.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
      var u = Object.getOwnPropertyDescriptor(o.DetermineComponentFrameRoot, "name");
      u && u.configurable && Object.defineProperty(o.DetermineComponentFrameRoot, "name", { value: "DetermineComponentFrameRoot" });
      var f = o.DetermineComponentFrameRoot(), v = f[0], S = f[1];
      if (v && S) {
        var R = v.split(`
`), I = S.split(`
`);
        for (u = o = 0; o < R.length && !R[o].includes("DetermineComponentFrameRoot"); ) o++;
        for (; u < I.length && !I[u].includes("DetermineComponentFrameRoot"); ) u++;
        if (o === R.length || u === I.length) for (o = R.length - 1, u = I.length - 1; 1 <= o && 0 <= u && R[o] !== I[u]; ) u--;
        for (; 1 <= o && 0 <= u; o--, u--) if (R[o] !== I[u]) {
          if (o !== 1 || u !== 1) do
            if (o--, u--, 0 > u || R[o] !== I[u]) {
              var X = `
` + R[o].replace(" at new ", " at ");
              return t.displayName && X.includes("<anonymous>") && (X = X.replace("<anonymous>", t.displayName)), X;
            }
          while (1 <= o && 0 <= u);
          break;
        }
      }
    } finally {
      rt = !1, Error.prepareStackTrace = i;
    }
    return (i = t ? t.displayName || t.name : "") ? St(i) : "";
  }
  function Xt(t, n) {
    switch (t.tag) {
      case 26:
      case 27:
      case 5:
        return St(t.type);
      case 16:
        return St("Lazy");
      case 13:
        return t.child !== n && n !== null ? St("Suspense Fallback") : St("Suspense");
      case 19:
        return St("SuspenseList");
      case 0:
      case 15:
        return on(t.type, !1);
      case 11:
        return on(t.type.render, !1);
      case 1:
        return on(t.type, !0);
      case 31:
        return St("Activity");
      default:
        return "";
    }
  }
  function jn(t) {
    try {
      var n = "", i = null;
      do
        n += Xt(t, i), i = t, t = t.return;
      while (t);
      return n;
    } catch (o) {
      return `
Error generating stack: ` + o.message + `
` + o.stack;
    }
  }
  var _n = Object.prototype.hasOwnProperty, wn = a.unstable_scheduleCallback, Bn = a.unstable_cancelCallback, Pi = a.unstable_shouldYield, $r = a.unstable_requestPaint, xt = a.unstable_now, ve = a.unstable_getCurrentPriorityLevel, Ot = a.unstable_ImmediatePriority, Ut = a.unstable_UserBlockingPriority, kt = a.unstable_NormalPriority, Fr = a.unstable_LowPriority, ul = a.unstable_IdlePriority, cl = a.log, Au = a.unstable_setDisableYieldValue, si = null, Zt = null;
  function Un(t) {
    if (typeof cl == "function" && Au(t), Zt && typeof Zt.setStrictMode == "function") try {
      Zt.setStrictMode(si, t);
    } catch {
    }
  }
  var ae = Math.clz32 ? Math.clz32 : Mt, Se = Math.log, Qe = Math.LN2;
  function Mt(t) {
    return t >>>= 0, t === 0 ? 32 : 31 - (Se(t) / Qe | 0) | 0;
  }
  var ht = 256, Et = 262144, mt = 4194304;
  function Tt(t) {
    var n = t & 42;
    if (n !== 0) return n;
    switch (t & -t) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
        return 64;
      case 128:
        return 128;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
        return t & 261888;
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t & 3932160;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return t & 62914560;
      case 67108864:
        return 67108864;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 0;
      default:
        return t;
    }
  }
  function ln(t, n, i) {
    var o = t.pendingLanes;
    if (o === 0) return 0;
    var u = 0, f = t.suspendedLanes, v = t.pingedLanes;
    t = t.warmLanes;
    var S = o & 134217727;
    return S !== 0 ? (o = S & ~f, o !== 0 ? u = Tt(o) : (v &= S, v !== 0 ? u = Tt(v) : i || (i = S & ~t, i !== 0 && (u = Tt(i))))) : (S = o & ~f, S !== 0 ? u = Tt(S) : v !== 0 ? u = Tt(v) : i || (i = o & ~t, i !== 0 && (u = Tt(i)))), u === 0 ? 0 : n !== 0 && n !== u && (n & f) === 0 && (f = u & -u, i = n & -n, f >= i || f === 32 && (i & 4194048) !== 0) ? n : u;
  }
  function Ma(t, n) {
    return (t.pendingLanes & ~(t.suspendedLanes & ~t.pingedLanes) & n) === 0;
  }
  function xu(t, n) {
    switch (t) {
      case 1:
      case 2:
      case 4:
      case 8:
      case 64:
        return n + 250;
      case 16:
      case 32:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return n + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return -1;
      case 67108864:
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function fl() {
    var t = mt;
    return mt <<= 1, (mt & 62914560) === 0 && (mt = 4194304), t;
  }
  function qr(t) {
    for (var n = [], i = 0; 31 > i; i++) n.push(t);
    return n;
  }
  function Ii(t, n) {
    t.pendingLanes |= n, n !== 268435456 && (t.suspendedLanes = 0, t.pingedLanes = 0, t.warmLanes = 0);
  }
  function Ou(t, n, i, o, u, f) {
    var v = t.pendingLanes;
    t.pendingLanes = i, t.suspendedLanes = 0, t.pingedLanes = 0, t.warmLanes = 0, t.expiredLanes &= i, t.entangledLanes &= i, t.errorRecoveryDisabledLanes &= i, t.shellSuspendCounter = 0;
    var S = t.entanglements, R = t.expirationTimes, I = t.hiddenUpdates;
    for (i = v & ~i; 0 < i; ) {
      var X = 31 - ae(i), J = 1 << X;
      S[X] = 0, R[X] = -1;
      var Z = I[X];
      if (Z !== null) for (I[X] = null, X = 0; X < Z.length; X++) {
        var G = Z[X];
        G !== null && (G.lane &= -536870913);
      }
      i &= ~J;
    }
    o !== 0 && Xr(t, o, 0), f !== 0 && u === 0 && t.tag !== 0 && (t.suspendedLanes |= f & ~(v & ~n));
  }
  function Xr(t, n, i) {
    t.pendingLanes |= n, t.suspendedLanes &= ~n;
    var o = 31 - ae(n);
    t.entangledLanes |= n, t.entanglements[o] = t.entanglements[o] | 1073741824 | i & 261930;
  }
  function dl(t, n) {
    var i = t.entangledLanes |= n;
    for (t = t.entanglements; i; ) {
      var o = 31 - ae(i), u = 1 << o;
      u & n | t[o] & n && (t[o] |= n), i &= ~u;
    }
  }
  function Nh(t, n) {
    var i = n & -n;
    return i = (i & 42) !== 0 ? 1 : Dh(i), (i & (t.suspendedLanes | n)) !== 0 ? 0 : i;
  }
  function Dh(t) {
    switch (t) {
      case 2:
        t = 1;
        break;
      case 8:
        t = 4;
        break;
      case 32:
        t = 16;
        break;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        t = 128;
        break;
      case 268435456:
        t = 134217728;
        break;
      default:
        t = 0;
    }
    return t;
  }
  function Mu(t) {
    return t &= -t, 2 < t ? 8 < t ? (t & 134217727) !== 0 ? 32 : 268435456 : 8 : 2;
  }
  function zh() {
    var t = N.p;
    return t !== 0 ? t : (t = window.event, t === void 0 ? 32 : m0(t.type));
  }
  function Lh(t, n) {
    var i = N.p;
    try {
      return N.p = t, n();
    } finally {
      N.p = i;
    }
  }
  var Ra = Math.random().toString(36).slice(2), zt = "__reactFiber$" + Ra, Yt = "__reactProps$" + Ra, Yr = "__reactContainer$" + Ra, Ru = "__reactEvents$" + Ra, C_ = "__reactListeners$" + Ra, A_ = "__reactHandles$" + Ra, Hh = "__reactResources$" + Ra, Wr = "__reactMarker$" + Ra;
  function Nu(t) {
    delete t[zt], delete t[Yt], delete t[Ru], delete t[C_], delete t[A_];
  }
  function Zi(t) {
    var n = t[zt];
    if (n) return n;
    for (var i = t.parentNode; i; ) {
      if (n = i[Yr] || i[zt]) {
        if (i = n.alternate, n.child !== null || i !== null && i.child !== null) for (t = e0(t); t !== null; ) {
          if (i = t[zt]) return i;
          t = e0(t);
        }
        return n;
      }
      t = i, i = t.parentNode;
    }
    return null;
  }
  function Gi(t) {
    if (t = t[zt] || t[Yr]) {
      var n = t.tag;
      if (n === 5 || n === 6 || n === 13 || n === 31 || n === 26 || n === 27 || n === 3) return t;
    }
    return null;
  }
  function Qr(t) {
    var n = t.tag;
    if (n === 5 || n === 26 || n === 27 || n === 6) return t.stateNode;
    throw Error(s(33));
  }
  function Vi(t) {
    var n = t[Hh];
    return n || (n = t[Hh] = {
      hoistableStyles: /* @__PURE__ */ new Map(),
      hoistableScripts: /* @__PURE__ */ new Map()
    }), n;
  }
  function Rt(t) {
    t[Wr] = !0;
  }
  var jh = /* @__PURE__ */ new Set(), Bh = {};
  function ui(t, n) {
    $i(t, n), $i(t + "Capture", n);
  }
  function $i(t, n) {
    for (Bh[t] = n, t = 0; t < n.length; t++) jh.add(n[t]);
  }
  var x_ = RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"), Uh = {}, kh = {};
  function O_(t) {
    return _n.call(kh, t) ? !0 : _n.call(Uh, t) ? !1 : x_.test(t) ? kh[t] = !0 : (Uh[t] = !0, !1);
  }
  function hl(t, n, i) {
    if (O_(n)) if (i === null) t.removeAttribute(n);
    else {
      switch (typeof i) {
        case "undefined":
        case "function":
        case "symbol":
          t.removeAttribute(n);
          return;
        case "boolean":
          var o = n.toLowerCase().slice(0, 5);
          if (o !== "data-" && o !== "aria-") {
            t.removeAttribute(n);
            return;
          }
      }
      t.setAttribute(n, "" + i);
    }
  }
  function ml(t, n, i) {
    if (i === null) t.removeAttribute(n);
    else {
      switch (typeof i) {
        case "undefined":
        case "function":
        case "symbol":
        case "boolean":
          t.removeAttribute(n);
          return;
      }
      t.setAttribute(n, "" + i);
    }
  }
  function ra(t, n, i, o) {
    if (o === null) t.removeAttribute(i);
    else {
      switch (typeof o) {
        case "undefined":
        case "function":
        case "symbol":
        case "boolean":
          t.removeAttribute(i);
          return;
      }
      t.setAttributeNS(n, i, "" + o);
    }
  }
  function Sn(t) {
    switch (typeof t) {
      case "bigint":
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return t;
      case "object":
        return t;
      default:
        return "";
    }
  }
  function Ph(t) {
    var n = t.type;
    return (t = t.nodeName) && t.toLowerCase() === "input" && (n === "checkbox" || n === "radio");
  }
  function M_(t, n, i) {
    var o = Object.getOwnPropertyDescriptor(t.constructor.prototype, n);
    if (!t.hasOwnProperty(n) && typeof o < "u" && typeof o.get == "function" && typeof o.set == "function") {
      var u = o.get, f = o.set;
      return Object.defineProperty(t, n, {
        configurable: !0,
        get: function() {
          return u.call(this);
        },
        set: function(v) {
          i = "" + v, f.call(this, v);
        }
      }), Object.defineProperty(t, n, { enumerable: o.enumerable }), {
        getValue: function() {
          return i;
        },
        setValue: function(v) {
          i = "" + v;
        },
        stopTracking: function() {
          t._valueTracker = null, delete t[n];
        }
      };
    }
  }
  function Du(t) {
    if (!t._valueTracker) {
      var n = Ph(t) ? "checked" : "value";
      t._valueTracker = M_(t, n, "" + t[n]);
    }
  }
  function Ih(t) {
    if (!t) return !1;
    var n = t._valueTracker;
    if (!n) return !0;
    var i = n.getValue(), o = "";
    return t && (o = Ph(t) ? t.checked ? "true" : "false" : t.value), t = o, t !== i ? (n.setValue(t), !0) : !1;
  }
  function pl(t) {
    if (t = t || (typeof document < "u" ? document : void 0), typeof t > "u") return null;
    try {
      return t.activeElement || t.body;
    } catch {
      return t.body;
    }
  }
  var R_ = /[\n"\\]/g;
  function En(t) {
    return t.replace(R_, function(n) {
      return "\\" + n.charCodeAt(0).toString(16) + " ";
    });
  }
  function zu(t, n, i, o, u, f, v, S) {
    t.name = "", v != null && typeof v != "function" && typeof v != "symbol" && typeof v != "boolean" ? t.type = v : t.removeAttribute("type"), n != null ? v === "number" ? (n === 0 && t.value === "" || t.value != n) && (t.value = "" + Sn(n)) : t.value !== "" + Sn(n) && (t.value = "" + Sn(n)) : v !== "submit" && v !== "reset" || t.removeAttribute("value"), n != null ? Lu(t, v, Sn(n)) : i != null ? Lu(t, v, Sn(i)) : o != null && t.removeAttribute("value"), u == null && f != null && (t.defaultChecked = !!f), u != null && (t.checked = u && typeof u != "function" && typeof u != "symbol"), S != null && typeof S != "function" && typeof S != "symbol" && typeof S != "boolean" ? t.name = "" + Sn(S) : t.removeAttribute("name");
  }
  function Zh(t, n, i, o, u, f, v, S) {
    if (f != null && typeof f != "function" && typeof f != "symbol" && typeof f != "boolean" && (t.type = f), n != null || i != null) {
      if (!(f !== "submit" && f !== "reset" || n != null)) {
        Du(t);
        return;
      }
      i = i != null ? "" + Sn(i) : "", n = n != null ? "" + Sn(n) : i, S || n === t.value || (t.value = n), t.defaultValue = n;
    }
    o = o ?? u, o = typeof o != "function" && typeof o != "symbol" && !!o, t.checked = S ? t.checked : !!o, t.defaultChecked = !!o, v != null && typeof v != "function" && typeof v != "symbol" && typeof v != "boolean" && (t.name = v), Du(t);
  }
  function Lu(t, n, i) {
    n === "number" && pl(t.ownerDocument) === t || t.defaultValue === "" + i || (t.defaultValue = "" + i);
  }
  function Fi(t, n, i, o) {
    if (t = t.options, n) {
      n = {};
      for (var u = 0; u < i.length; u++) n["$" + i[u]] = !0;
      for (i = 0; i < t.length; i++) u = n.hasOwnProperty("$" + t[i].value), t[i].selected !== u && (t[i].selected = u), u && o && (t[i].defaultSelected = !0);
    } else {
      for (i = "" + Sn(i), n = null, u = 0; u < t.length; u++) {
        if (t[u].value === i) {
          t[u].selected = !0, o && (t[u].defaultSelected = !0);
          return;
        }
        n !== null || t[u].disabled || (n = t[u]);
      }
      n !== null && (n.selected = !0);
    }
  }
  function Gh(t, n, i) {
    if (n != null && (n = "" + Sn(n), n !== t.value && (t.value = n), i == null)) {
      t.defaultValue !== n && (t.defaultValue = n);
      return;
    }
    t.defaultValue = i != null ? "" + Sn(i) : "";
  }
  function Vh(t, n, i, o) {
    if (n == null) {
      if (o != null) {
        if (i != null) throw Error(s(92));
        if (L(o)) {
          if (1 < o.length) throw Error(s(93));
          o = o[0];
        }
        i = o;
      }
      i ??= "", n = i;
    }
    i = Sn(n), t.defaultValue = i, o = t.textContent, o === i && o !== "" && o !== null && (t.value = o), Du(t);
  }
  function qi(t, n) {
    if (n) {
      var i = t.firstChild;
      if (i && i === t.lastChild && i.nodeType === 3) {
        i.nodeValue = n;
        return;
      }
    }
    t.textContent = n;
  }
  var N_ = new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));
  function $h(t, n, i) {
    var o = n.indexOf("--") === 0;
    i == null || typeof i == "boolean" || i === "" ? o ? t.setProperty(n, "") : n === "float" ? t.cssFloat = "" : t[n] = "" : o ? t.setProperty(n, i) : typeof i != "number" || i === 0 || N_.has(n) ? n === "float" ? t.cssFloat = i : t[n] = ("" + i).trim() : t[n] = i + "px";
  }
  function Fh(t, n, i) {
    if (n != null && typeof n != "object") throw Error(s(62));
    if (t = t.style, i != null) {
      for (var o in i) !i.hasOwnProperty(o) || n != null && n.hasOwnProperty(o) || (o.indexOf("--") === 0 ? t.setProperty(o, "") : o === "float" ? t.cssFloat = "" : t[o] = "");
      for (var u in n) o = n[u], n.hasOwnProperty(u) && i[u] !== o && $h(t, u, o);
    } else for (var f in n) n.hasOwnProperty(f) && $h(t, f, n[f]);
  }
  function Hu(t) {
    if (t.indexOf("-") === -1) return !1;
    switch (t) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var D_ = /* @__PURE__ */ new Map([
    ["acceptCharset", "accept-charset"],
    ["htmlFor", "for"],
    ["httpEquiv", "http-equiv"],
    ["crossOrigin", "crossorigin"],
    ["accentHeight", "accent-height"],
    ["alignmentBaseline", "alignment-baseline"],
    ["arabicForm", "arabic-form"],
    ["baselineShift", "baseline-shift"],
    ["capHeight", "cap-height"],
    ["clipPath", "clip-path"],
    ["clipRule", "clip-rule"],
    ["colorInterpolation", "color-interpolation"],
    ["colorInterpolationFilters", "color-interpolation-filters"],
    ["colorProfile", "color-profile"],
    ["colorRendering", "color-rendering"],
    ["dominantBaseline", "dominant-baseline"],
    ["enableBackground", "enable-background"],
    ["fillOpacity", "fill-opacity"],
    ["fillRule", "fill-rule"],
    ["floodColor", "flood-color"],
    ["floodOpacity", "flood-opacity"],
    ["fontFamily", "font-family"],
    ["fontSize", "font-size"],
    ["fontSizeAdjust", "font-size-adjust"],
    ["fontStretch", "font-stretch"],
    ["fontStyle", "font-style"],
    ["fontVariant", "font-variant"],
    ["fontWeight", "font-weight"],
    ["glyphName", "glyph-name"],
    ["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
    ["glyphOrientationVertical", "glyph-orientation-vertical"],
    ["horizAdvX", "horiz-adv-x"],
    ["horizOriginX", "horiz-origin-x"],
    ["imageRendering", "image-rendering"],
    ["letterSpacing", "letter-spacing"],
    ["lightingColor", "lighting-color"],
    ["markerEnd", "marker-end"],
    ["markerMid", "marker-mid"],
    ["markerStart", "marker-start"],
    ["overlinePosition", "overline-position"],
    ["overlineThickness", "overline-thickness"],
    ["paintOrder", "paint-order"],
    ["panose-1", "panose-1"],
    ["pointerEvents", "pointer-events"],
    ["renderingIntent", "rendering-intent"],
    ["shapeRendering", "shape-rendering"],
    ["stopColor", "stop-color"],
    ["stopOpacity", "stop-opacity"],
    ["strikethroughPosition", "strikethrough-position"],
    ["strikethroughThickness", "strikethrough-thickness"],
    ["strokeDasharray", "stroke-dasharray"],
    ["strokeDashoffset", "stroke-dashoffset"],
    ["strokeLinecap", "stroke-linecap"],
    ["strokeLinejoin", "stroke-linejoin"],
    ["strokeMiterlimit", "stroke-miterlimit"],
    ["strokeOpacity", "stroke-opacity"],
    ["strokeWidth", "stroke-width"],
    ["textAnchor", "text-anchor"],
    ["textDecoration", "text-decoration"],
    ["textRendering", "text-rendering"],
    ["transformOrigin", "transform-origin"],
    ["underlinePosition", "underline-position"],
    ["underlineThickness", "underline-thickness"],
    ["unicodeBidi", "unicode-bidi"],
    ["unicodeRange", "unicode-range"],
    ["unitsPerEm", "units-per-em"],
    ["vAlphabetic", "v-alphabetic"],
    ["vHanging", "v-hanging"],
    ["vIdeographic", "v-ideographic"],
    ["vMathematical", "v-mathematical"],
    ["vectorEffect", "vector-effect"],
    ["vertAdvY", "vert-adv-y"],
    ["vertOriginX", "vert-origin-x"],
    ["vertOriginY", "vert-origin-y"],
    ["wordSpacing", "word-spacing"],
    ["writingMode", "writing-mode"],
    ["xmlnsXlink", "xmlns:xlink"],
    ["xHeight", "x-height"]
  ]), z_ = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
  function vl(t) {
    return z_.test("" + t) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : t;
  }
  function oa() {
  }
  var ju = null;
  function Bu(t) {
    return t = t.target || t.srcElement || window, t.correspondingUseElement && (t = t.correspondingUseElement), t.nodeType === 3 ? t.parentNode : t;
  }
  var Xi = null, Yi = null;
  function qh(t) {
    var n = Gi(t);
    if (n && (t = n.stateNode)) {
      var i = t[Yt] || null;
      e: switch (t = n.stateNode, n.type) {
        case "input":
          if (zu(t, i.value, i.defaultValue, i.defaultValue, i.checked, i.defaultChecked, i.type, i.name), n = i.name, i.type === "radio" && n != null) {
            for (i = t; i.parentNode; ) i = i.parentNode;
            for (i = i.querySelectorAll('input[name="' + En("" + n) + '"][type="radio"]'), n = 0; n < i.length; n++) {
              var o = i[n];
              if (o !== t && o.form === t.form) {
                var u = o[Yt] || null;
                if (!u) throw Error(s(90));
                zu(o, u.value, u.defaultValue, u.defaultValue, u.checked, u.defaultChecked, u.type, u.name);
              }
            }
            for (n = 0; n < i.length; n++) o = i[n], o.form === t.form && Ih(o);
          }
          break e;
        case "textarea":
          Gh(t, i.value, i.defaultValue);
          break e;
        case "select":
          n = i.value, n != null && Fi(t, !!i.multiple, n, !1);
      }
    }
  }
  var Uu = !1;
  function Xh(t, n, i) {
    if (Uu) return t(n, i);
    Uu = !0;
    try {
      return t(n);
    } finally {
      if (Uu = !1, (Xi !== null || Yi !== null) && (as(), Xi && (n = Xi, t = Yi, Yi = Xi = null, qh(n), t)))
        for (n = 0; n < t.length; n++) qh(t[n]);
    }
  }
  function Kr(t, n) {
    var i = t.stateNode;
    if (i === null) return null;
    var o = i[Yt] || null;
    if (o === null) return null;
    i = o[n];
    e: switch (n) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        (o = !o.disabled) || (t = t.type, o = !(t === "button" || t === "input" || t === "select" || t === "textarea")), t = !o;
        break e;
      default:
        t = !1;
    }
    if (t) return null;
    if (i && typeof i != "function") throw Error(s(231, n, typeof i));
    return i;
  }
  var la = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), ku = !1;
  if (la) try {
    var Jr = {};
    Object.defineProperty(Jr, "passive", { get: function() {
      ku = !0;
    } }), window.addEventListener("test", Jr, Jr), window.removeEventListener("test", Jr, Jr);
  } catch {
    ku = !1;
  }
  var Na = null, Pu = null, gl = null;
  function Yh() {
    if (gl) return gl;
    var t, n = Pu, i = n.length, o, u = "value" in Na ? Na.value : Na.textContent, f = u.length;
    for (t = 0; t < i && n[t] === u[t]; t++) ;
    var v = i - t;
    for (o = 1; o <= v && n[i - o] === u[f - o]; o++) ;
    return gl = u.slice(t, 1 < o ? 1 - o : void 0);
  }
  function yl(t) {
    var n = t.keyCode;
    return "charCode" in t ? (t = t.charCode, t === 0 && n === 13 && (t = 13)) : t = n, t === 10 && (t = 13), 32 <= t || t === 13 ? t : 0;
  }
  function bl() {
    return !0;
  }
  function Wh() {
    return !1;
  }
  function Wt(t) {
    function n(i, o, u, f, v) {
      this._reactName = i, this._targetInst = u, this.type = o, this.nativeEvent = f, this.target = v, this.currentTarget = null;
      for (var S in t) t.hasOwnProperty(S) && (i = t[S], this[S] = i ? i(f) : f[S]);
      return this.isDefaultPrevented = (f.defaultPrevented != null ? f.defaultPrevented : f.returnValue === !1) ? bl : Wh, this.isPropagationStopped = Wh, this;
    }
    return w(n.prototype, {
      preventDefault: function() {
        this.defaultPrevented = !0;
        var i = this.nativeEvent;
        i && (i.preventDefault ? i.preventDefault() : typeof i.returnValue != "unknown" && (i.returnValue = !1), this.isDefaultPrevented = bl);
      },
      stopPropagation: function() {
        var i = this.nativeEvent;
        i && (i.stopPropagation ? i.stopPropagation() : typeof i.cancelBubble != "unknown" && (i.cancelBubble = !0), this.isPropagationStopped = bl);
      },
      persist: function() {
      },
      isPersistent: bl
    }), n;
  }
  var ci = {
    eventPhase: 0,
    bubbles: 0,
    cancelable: 0,
    timeStamp: function(t) {
      return t.timeStamp || Date.now();
    },
    defaultPrevented: 0,
    isTrusted: 0
  }, _l = Wt(ci), eo = w({}, ci, {
    view: 0,
    detail: 0
  }), L_ = Wt(eo), Iu, Zu, to, wl = w({}, eo, {
    screenX: 0,
    screenY: 0,
    clientX: 0,
    clientY: 0,
    pageX: 0,
    pageY: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    getModifierState: Vu,
    button: 0,
    buttons: 0,
    relatedTarget: function(t) {
      return t.relatedTarget === void 0 ? t.fromElement === t.srcElement ? t.toElement : t.fromElement : t.relatedTarget;
    },
    movementX: function(t) {
      return "movementX" in t ? t.movementX : (t !== to && (to && t.type === "mousemove" ? (Iu = t.screenX - to.screenX, Zu = t.screenY - to.screenY) : Zu = Iu = 0, to = t), Iu);
    },
    movementY: function(t) {
      return "movementY" in t ? t.movementY : Zu;
    }
  }), Qh = Wt(wl), H_ = Wt(w({}, wl, { dataTransfer: 0 })), Gu = Wt(w({}, eo, { relatedTarget: 0 })), j_ = Wt(w({}, ci, {
    animationName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  })), B_ = Wt(w({}, ci, { clipboardData: function(t) {
    return "clipboardData" in t ? t.clipboardData : window.clipboardData;
  } })), Kh = Wt(w({}, ci, { data: 0 })), U_ = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified"
  }, k_ = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta"
  }, P_ = {
    Alt: "altKey",
    Control: "ctrlKey",
    Meta: "metaKey",
    Shift: "shiftKey"
  };
  function I_(t) {
    var n = this.nativeEvent;
    return n.getModifierState ? n.getModifierState(t) : (t = P_[t]) ? !!n[t] : !1;
  }
  function Vu() {
    return I_;
  }
  var Z_ = Wt(w({}, eo, {
    key: function(t) {
      if (t.key) {
        var n = U_[t.key] || t.key;
        if (n !== "Unidentified") return n;
      }
      return t.type === "keypress" ? (t = yl(t), t === 13 ? "Enter" : String.fromCharCode(t)) : t.type === "keydown" || t.type === "keyup" ? k_[t.keyCode] || "Unidentified" : "";
    },
    code: 0,
    location: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    repeat: 0,
    locale: 0,
    getModifierState: Vu,
    charCode: function(t) {
      return t.type === "keypress" ? yl(t) : 0;
    },
    keyCode: function(t) {
      return t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0;
    },
    which: function(t) {
      return t.type === "keypress" ? yl(t) : t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0;
    }
  })), Jh = Wt(w({}, wl, {
    pointerId: 0,
    width: 0,
    height: 0,
    pressure: 0,
    tangentialPressure: 0,
    tiltX: 0,
    tiltY: 0,
    twist: 0,
    pointerType: 0,
    isPrimary: 0
  })), G_ = Wt(w({}, eo, {
    touches: 0,
    targetTouches: 0,
    changedTouches: 0,
    altKey: 0,
    metaKey: 0,
    ctrlKey: 0,
    shiftKey: 0,
    getModifierState: Vu
  })), V_ = Wt(w({}, ci, {
    propertyName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  })), $_ = Wt(w({}, wl, {
    deltaX: function(t) {
      return "deltaX" in t ? t.deltaX : "wheelDeltaX" in t ? -t.wheelDeltaX : 0;
    },
    deltaY: function(t) {
      return "deltaY" in t ? t.deltaY : "wheelDeltaY" in t ? -t.wheelDeltaY : "wheelDelta" in t ? -t.wheelDelta : 0;
    },
    deltaZ: 0,
    deltaMode: 0
  })), F_ = Wt(w({}, ci, {
    newState: 0,
    oldState: 0
  })), q_ = [
    9,
    13,
    27,
    32
  ], $u = la && "CompositionEvent" in window, no = null;
  la && "documentMode" in document && (no = document.documentMode);
  var X_ = la && "TextEvent" in window && !no, em = la && (!$u || no && 8 < no && 11 >= no), tm = " ", nm = !1;
  function am(t, n) {
    switch (t) {
      case "keyup":
        return q_.indexOf(n.keyCode) !== -1;
      case "keydown":
        return n.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function im(t) {
    return t = t.detail, typeof t == "object" && "data" in t ? t.data : null;
  }
  var Wi = !1;
  function Y_(t, n) {
    switch (t) {
      case "compositionend":
        return im(n);
      case "keypress":
        return n.which !== 32 ? null : (nm = !0, tm);
      case "textInput":
        return t = n.data, t === tm && nm ? null : t;
      default:
        return null;
    }
  }
  function W_(t, n) {
    if (Wi) return t === "compositionend" || !$u && am(t, n) ? (t = Yh(), gl = Pu = Na = null, Wi = !1, t) : null;
    switch (t) {
      case "paste":
        return null;
      case "keypress":
        if (!(n.ctrlKey || n.altKey || n.metaKey) || n.ctrlKey && n.altKey) {
          if (n.char && 1 < n.char.length) return n.char;
          if (n.which) return String.fromCharCode(n.which);
        }
        return null;
      case "compositionend":
        return em && n.locale !== "ko" ? null : n.data;
      default:
        return null;
    }
  }
  var Q_ = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0
  };
  function rm(t) {
    var n = t && t.nodeName && t.nodeName.toLowerCase();
    return n === "input" ? !!Q_[t.type] : n === "textarea";
  }
  function om(t, n, i, o) {
    Xi ? Yi ? Yi.push(o) : Yi = [o] : Xi = o, n = cs(n, "onChange"), 0 < n.length && (i = new _l("onChange", "change", null, i, o), t.push({
      event: i,
      listeners: n
    }));
  }
  var ao = null, io = null;
  function K_(t) {
    kv(t, 0);
  }
  function Sl(t) {
    if (Ih(Qr(t))) return t;
  }
  function lm(t, n) {
    if (t === "change") return n;
  }
  var sm = !1;
  if (la) {
    var Fu;
    if (la) {
      var qu = "oninput" in document;
      if (!qu) {
        var um = document.createElement("div");
        um.setAttribute("oninput", "return;"), qu = typeof um.oninput == "function";
      }
      Fu = qu;
    } else Fu = !1;
    sm = Fu && (!document.documentMode || 9 < document.documentMode);
  }
  function cm() {
    ao && (ao.detachEvent("onpropertychange", fm), io = ao = null);
  }
  function fm(t) {
    if (t.propertyName === "value" && Sl(io)) {
      var n = [];
      om(n, io, t, Bu(t)), Xh(K_, n);
    }
  }
  function J_(t, n, i) {
    t === "focusin" ? (cm(), ao = n, io = i, ao.attachEvent("onpropertychange", fm)) : t === "focusout" && cm();
  }
  function e2(t) {
    if (t === "selectionchange" || t === "keyup" || t === "keydown") return Sl(io);
  }
  function t2(t, n) {
    if (t === "click") return Sl(n);
  }
  function n2(t, n) {
    if (t === "input" || t === "change") return Sl(n);
  }
  function a2(t, n) {
    return t === n && (t !== 0 || 1 / t === 1 / n) || t !== t && n !== n;
  }
  var sn = typeof Object.is == "function" ? Object.is : a2;
  function ro(t, n) {
    if (sn(t, n)) return !0;
    if (typeof t != "object" || t === null || typeof n != "object" || n === null) return !1;
    var i = Object.keys(t), o = Object.keys(n);
    if (i.length !== o.length) return !1;
    for (o = 0; o < i.length; o++) {
      var u = i[o];
      if (!_n.call(n, u) || !sn(t[u], n[u])) return !1;
    }
    return !0;
  }
  function dm(t) {
    for (; t && t.firstChild; ) t = t.firstChild;
    return t;
  }
  function hm(t, n) {
    var i = dm(t);
    t = 0;
    for (var o; i; ) {
      if (i.nodeType === 3) {
        if (o = t + i.textContent.length, t <= n && o >= n) return {
          node: i,
          offset: n - t
        };
        t = o;
      }
      e: {
        for (; i; ) {
          if (i.nextSibling) {
            i = i.nextSibling;
            break e;
          }
          i = i.parentNode;
        }
        i = void 0;
      }
      i = dm(i);
    }
  }
  function mm(t, n) {
    return t && n ? t === n ? !0 : t && t.nodeType === 3 ? !1 : n && n.nodeType === 3 ? mm(t, n.parentNode) : "contains" in t ? t.contains(n) : t.compareDocumentPosition ? !!(t.compareDocumentPosition(n) & 16) : !1 : !1;
  }
  function pm(t) {
    t = t != null && t.ownerDocument != null && t.ownerDocument.defaultView != null ? t.ownerDocument.defaultView : window;
    for (var n = pl(t.document); n instanceof t.HTMLIFrameElement; ) {
      try {
        var i = typeof n.contentWindow.location.href == "string";
      } catch {
        i = !1;
      }
      if (i) t = n.contentWindow;
      else break;
      n = pl(t.document);
    }
    return n;
  }
  function Xu(t) {
    var n = t && t.nodeName && t.nodeName.toLowerCase();
    return n && (n === "input" && (t.type === "text" || t.type === "search" || t.type === "tel" || t.type === "url" || t.type === "password") || n === "textarea" || t.contentEditable === "true");
  }
  var i2 = la && "documentMode" in document && 11 >= document.documentMode, Qi = null, Yu = null, oo = null, Wu = !1;
  function vm(t, n, i) {
    var o = i.window === i ? i.document : i.nodeType === 9 ? i : i.ownerDocument;
    Wu || Qi == null || Qi !== pl(o) || (o = Qi, "selectionStart" in o && Xu(o) ? o = {
      start: o.selectionStart,
      end: o.selectionEnd
    } : (o = (o.ownerDocument && o.ownerDocument.defaultView || window).getSelection(), o = {
      anchorNode: o.anchorNode,
      anchorOffset: o.anchorOffset,
      focusNode: o.focusNode,
      focusOffset: o.focusOffset
    }), oo && ro(oo, o) || (oo = o, o = cs(Yu, "onSelect"), 0 < o.length && (n = new _l("onSelect", "select", null, n, i), t.push({
      event: n,
      listeners: o
    }), n.target = Qi)));
  }
  function fi(t, n) {
    var i = {};
    return i[t.toLowerCase()] = n.toLowerCase(), i["Webkit" + t] = "webkit" + n, i["Moz" + t] = "moz" + n, i;
  }
  var Ki = {
    animationend: fi("Animation", "AnimationEnd"),
    animationiteration: fi("Animation", "AnimationIteration"),
    animationstart: fi("Animation", "AnimationStart"),
    transitionrun: fi("Transition", "TransitionRun"),
    transitionstart: fi("Transition", "TransitionStart"),
    transitioncancel: fi("Transition", "TransitionCancel"),
    transitionend: fi("Transition", "TransitionEnd")
  }, Qu = {}, gm = {};
  la && (gm = document.createElement("div").style, "AnimationEvent" in window || (delete Ki.animationend.animation, delete Ki.animationiteration.animation, delete Ki.animationstart.animation), "TransitionEvent" in window || delete Ki.transitionend.transition);
  function di(t) {
    if (Qu[t]) return Qu[t];
    if (!Ki[t]) return t;
    var n = Ki[t], i;
    for (i in n) if (n.hasOwnProperty(i) && i in gm) return Qu[t] = n[i];
    return t;
  }
  var ym = di("animationend"), bm = di("animationiteration"), _m = di("animationstart"), r2 = di("transitionrun"), o2 = di("transitionstart"), l2 = di("transitioncancel"), wm = di("transitionend"), Sm = /* @__PURE__ */ new Map(), Ku = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
  Ku.push("scrollEnd");
  function kn(t, n) {
    Sm.set(t, n), ui(n, [t]);
  }
  var El = typeof reportError == "function" ? reportError : function(t) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var n = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof t == "object" && t !== null && typeof t.message == "string" ? String(t.message) : String(t),
        error: t
      });
      if (!window.dispatchEvent(n)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", t);
      return;
    }
    console.error(t);
  }, Tn = [], Ji = 0, Ju = 0;
  function Tl() {
    for (var t = Ji, n = Ju = Ji = 0; n < t; ) {
      var i = Tn[n];
      Tn[n++] = null;
      var o = Tn[n];
      Tn[n++] = null;
      var u = Tn[n];
      Tn[n++] = null;
      var f = Tn[n];
      if (Tn[n++] = null, o !== null && u !== null) {
        var v = o.pending;
        v === null ? u.next = u : (u.next = v.next, v.next = u), o.pending = u;
      }
      f !== 0 && Em(i, u, f);
    }
  }
  function Cl(t, n, i, o) {
    Tn[Ji++] = t, Tn[Ji++] = n, Tn[Ji++] = i, Tn[Ji++] = o, Ju |= o, t.lanes |= o, t = t.alternate, t !== null && (t.lanes |= o);
  }
  function ec(t, n, i, o) {
    return Cl(t, n, i, o), Al(t);
  }
  function hi(t, n) {
    return Cl(t, null, null, n), Al(t);
  }
  function Em(t, n, i) {
    t.lanes |= i;
    var o = t.alternate;
    o !== null && (o.lanes |= i);
    for (var u = !1, f = t.return; f !== null; ) f.childLanes |= i, o = f.alternate, o !== null && (o.childLanes |= i), f.tag === 22 && (t = f.stateNode, t === null || t._visibility & 1 || (u = !0)), t = f, f = f.return;
    return t.tag === 3 ? (f = t.stateNode, u && n !== null && (u = 31 - ae(i), t = f.hiddenUpdates, o = t[u], o === null ? t[u] = [n] : o.push(n), n.lane = i | 536870912), f) : null;
  }
  function Al(t) {
    if (50 < Mo) throw Mo = 0, cf = null, Error(s(185));
    for (var n = t.return; n !== null; ) t = n, n = t.return;
    return t.tag === 3 ? t.stateNode : null;
  }
  var er = {};
  function s2(t, n, i, o) {
    this.tag = t, this.key = i, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = n, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = o, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
  }
  function un(t, n, i, o) {
    return new s2(t, n, i, o);
  }
  function tc(t) {
    return t = t.prototype, !(!t || !t.isReactComponent);
  }
  function sa(t, n) {
    var i = t.alternate;
    return i === null ? (i = un(t.tag, n, t.key, t.mode), i.elementType = t.elementType, i.type = t.type, i.stateNode = t.stateNode, i.alternate = t, t.alternate = i) : (i.pendingProps = n, i.type = t.type, i.flags = 0, i.subtreeFlags = 0, i.deletions = null), i.flags = t.flags & 65011712, i.childLanes = t.childLanes, i.lanes = t.lanes, i.child = t.child, i.memoizedProps = t.memoizedProps, i.memoizedState = t.memoizedState, i.updateQueue = t.updateQueue, n = t.dependencies, i.dependencies = n === null ? null : {
      lanes: n.lanes,
      firstContext: n.firstContext
    }, i.sibling = t.sibling, i.index = t.index, i.ref = t.ref, i.refCleanup = t.refCleanup, i;
  }
  function Tm(t, n) {
    t.flags &= 65011714;
    var i = t.alternate;
    return i === null ? (t.childLanes = 0, t.lanes = n, t.child = null, t.subtreeFlags = 0, t.memoizedProps = null, t.memoizedState = null, t.updateQueue = null, t.dependencies = null, t.stateNode = null) : (t.childLanes = i.childLanes, t.lanes = i.lanes, t.child = i.child, t.subtreeFlags = 0, t.deletions = null, t.memoizedProps = i.memoizedProps, t.memoizedState = i.memoizedState, t.updateQueue = i.updateQueue, t.type = i.type, n = i.dependencies, t.dependencies = n === null ? null : {
      lanes: n.lanes,
      firstContext: n.firstContext
    }), t;
  }
  function xl(t, n, i, o, u, f) {
    var v = 0;
    if (o = t, typeof t == "function") tc(t) && (v = 1);
    else if (typeof t == "string") v = mw(t, i, le.current) ? 26 : t === "html" || t === "head" || t === "body" ? 27 : 5;
    else e: switch (t) {
      case F:
        return t = un(31, i, n, u), t.elementType = F, t.lanes = f, t;
      case T:
        return mi(i.children, u, f, n);
      case M:
        v = 8, u |= 24;
        break;
      case D:
        return t = un(12, i, n, u | 2), t.elementType = D, t.lanes = f, t;
      case B:
        return t = un(13, i, n, u), t.elementType = B, t.lanes = f, t;
      case Q:
        return t = un(19, i, n, u), t.elementType = Q, t.lanes = f, t;
      default:
        if (typeof t == "object" && t !== null) switch (t.$$typeof) {
          case H:
            v = 10;
            break e;
          case j:
            v = 9;
            break e;
          case k:
            v = 11;
            break e;
          case K:
            v = 14;
            break e;
          case q:
            v = 16, o = null;
            break e;
        }
        v = 29, i = Error(s(130, t === null ? "null" : typeof t, "")), o = null;
    }
    return n = un(v, i, n, u), n.elementType = t, n.type = o, n.lanes = f, n;
  }
  function mi(t, n, i, o) {
    return t = un(7, t, o, n), t.lanes = i, t;
  }
  function nc(t, n, i) {
    return t = un(6, t, null, n), t.lanes = i, t;
  }
  function Cm(t) {
    var n = un(18, null, null, 0);
    return n.stateNode = t, n;
  }
  function ac(t, n, i) {
    return n = un(4, t.children !== null ? t.children : [], t.key, n), n.lanes = i, n.stateNode = {
      containerInfo: t.containerInfo,
      pendingChildren: null,
      implementation: t.implementation
    }, n;
  }
  var Am = /* @__PURE__ */ new WeakMap();
  function Cn(t, n) {
    if (typeof t == "object" && t !== null) {
      var i = Am.get(t);
      return i !== void 0 ? i : (n = {
        value: t,
        source: n,
        stack: jn(n)
      }, Am.set(t, n), n);
    }
    return {
      value: t,
      source: n,
      stack: jn(n)
    };
  }
  var tr = [], nr = 0, Ol = null, lo = 0, An = [], xn = 0, Da = null, Xn = 1, Yn = "";
  function ua(t, n) {
    tr[nr++] = lo, tr[nr++] = Ol, Ol = t, lo = n;
  }
  function xm(t, n, i) {
    An[xn++] = Xn, An[xn++] = Yn, An[xn++] = Da, Da = t;
    var o = Xn;
    t = Yn;
    var u = 32 - ae(o) - 1;
    o &= ~(1 << u), i += 1;
    var f = 32 - ae(n) + u;
    if (30 < f) {
      var v = u - u % 5;
      f = (o & (1 << v) - 1).toString(32), o >>= v, u -= v, Xn = 1 << 32 - ae(n) + u | i << u | o, Yn = f + t;
    } else Xn = 1 << f | i << u | o, Yn = t;
  }
  function ic(t) {
    t.return !== null && (ua(t, 1), xm(t, 1, 0));
  }
  function rc(t) {
    for (; t === Ol; ) Ol = tr[--nr], tr[nr] = null, lo = tr[--nr], tr[nr] = null;
    for (; t === Da; ) Da = An[--xn], An[xn] = null, Yn = An[--xn], An[xn] = null, Xn = An[--xn], An[xn] = null;
  }
  function Om(t, n) {
    An[xn++] = Xn, An[xn++] = Yn, An[xn++] = Da, Xn = n.id, Yn = n.overflow, Da = t;
  }
  var Lt = null, Ke = null, ze = !1, za = null, On = !1, oc = Error(s(519));
  function La(t) {
    throw so(Cn(Error(s(418, 1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? "text" : "HTML", "")), t)), oc;
  }
  function Mm(t) {
    var n = t.stateNode, i = t.type, o = t.memoizedProps;
    switch (n[zt] = t, n[Yt] = o, i) {
      case "dialog":
        Re("cancel", n), Re("close", n);
        break;
      case "iframe":
      case "object":
      case "embed":
        Re("load", n);
        break;
      case "video":
      case "audio":
        for (i = 0; i < No.length; i++) Re(No[i], n);
        break;
      case "source":
        Re("error", n);
        break;
      case "img":
      case "image":
      case "link":
        Re("error", n), Re("load", n);
        break;
      case "details":
        Re("toggle", n);
        break;
      case "input":
        Re("invalid", n), Zh(n, o.value, o.defaultValue, o.checked, o.defaultChecked, o.type, o.name, !0);
        break;
      case "select":
        Re("invalid", n);
        break;
      case "textarea":
        Re("invalid", n), Vh(n, o.value, o.defaultValue, o.children);
    }
    i = o.children, typeof i != "string" && typeof i != "number" && typeof i != "bigint" || n.textContent === "" + i || o.suppressHydrationWarning === !0 || Vv(n.textContent, i) ? (o.popover != null && (Re("beforetoggle", n), Re("toggle", n)), o.onScroll != null && Re("scroll", n), o.onScrollEnd != null && Re("scrollend", n), o.onClick != null && (n.onclick = oa), n = !0) : n = !1, n || La(t, !0);
  }
  function Rm(t) {
    for (Lt = t.return; Lt; ) switch (Lt.tag) {
      case 5:
      case 31:
      case 13:
        On = !1;
        return;
      case 27:
      case 3:
        On = !0;
        return;
      default:
        Lt = Lt.return;
    }
  }
  function ar(t) {
    if (t !== Lt) return !1;
    if (!ze) return Rm(t), ze = !0, !1;
    var n = t.tag, i;
    if ((i = n !== 3 && n !== 27) && ((i = n === 5) && (i = t.type, i = !(i !== "form" && i !== "button") || Tf(t.type, t.memoizedProps)), i = !i), i && Ke && La(t), Rm(t), n === 13) {
      if (t = t.memoizedState, t = t !== null ? t.dehydrated : null, !t) throw Error(s(317));
      Ke = Jv(t);
    } else if (n === 31) {
      if (t = t.memoizedState, t = t !== null ? t.dehydrated : null, !t) throw Error(s(317));
      Ke = Jv(t);
    } else n === 27 ? (n = Ke, Fa(t.type) ? (t = Mf, Mf = null, Ke = t) : Ke = n) : Ke = Lt ? Nn(t.stateNode.nextSibling) : null;
    return !0;
  }
  function pi() {
    Ke = Lt = null, ze = !1;
  }
  function lc() {
    var t = za;
    return t !== null && (en === null ? en = t : en.push.apply(en, t), za = null), t;
  }
  function so(t) {
    za === null ? za = [t] : za.push(t);
  }
  var sc = O(null), vi = null, ca = null;
  function Ha(t, n, i) {
    re(sc, n._currentValue), n._currentValue = i;
  }
  function fa(t) {
    t._currentValue = sc.current, $(sc);
  }
  function uc(t, n, i) {
    for (; t !== null; ) {
      var o = t.alternate;
      if ((t.childLanes & n) !== n ? (t.childLanes |= n, o !== null && (o.childLanes |= n)) : o !== null && (o.childLanes & n) !== n && (o.childLanes |= n), t === i) break;
      t = t.return;
    }
  }
  function cc(t, n, i, o) {
    var u = t.child;
    for (u !== null && (u.return = t); u !== null; ) {
      var f = u.dependencies;
      if (f !== null) {
        var v = u.child;
        f = f.firstContext;
        e: for (; f !== null; ) {
          var S = f;
          f = u;
          for (var R = 0; R < n.length; R++) if (S.context === n[R]) {
            f.lanes |= i, S = f.alternate, S !== null && (S.lanes |= i), uc(f.return, i, t), o || (v = null);
            break e;
          }
          f = S.next;
        }
      } else if (u.tag === 18) {
        if (v = u.return, v === null) throw Error(s(341));
        v.lanes |= i, f = v.alternate, f !== null && (f.lanes |= i), uc(v, i, t), v = null;
      } else v = u.child;
      if (v !== null) v.return = u;
      else for (v = u; v !== null; ) {
        if (v === t) {
          v = null;
          break;
        }
        if (u = v.sibling, u !== null) {
          u.return = v.return, v = u;
          break;
        }
        v = v.return;
      }
      u = v;
    }
  }
  function ir(t, n, i, o) {
    t = null;
    for (var u = n, f = !1; u !== null; ) {
      if (!f) {
        if ((u.flags & 524288) !== 0) f = !0;
        else if ((u.flags & 262144) !== 0) break;
      }
      if (u.tag === 10) {
        var v = u.alternate;
        if (v === null) throw Error(s(387));
        if (v = v.memoizedProps, v !== null) {
          var S = u.type;
          sn(u.pendingProps.value, v.value) || (t !== null ? t.push(S) : t = [S]);
        }
      } else if (u === ue.current) {
        if (v = u.alternate, v === null) throw Error(s(387));
        v.memoizedState.memoizedState !== u.memoizedState.memoizedState && (t !== null ? t.push(jo) : t = [jo]);
      }
      u = u.return;
    }
    t !== null && cc(n, t, i, o), n.flags |= 262144;
  }
  function Ml(t) {
    for (t = t.firstContext; t !== null; ) {
      if (!sn(t.context._currentValue, t.memoizedValue)) return !0;
      t = t.next;
    }
    return !1;
  }
  function gi(t) {
    vi = t, ca = null, t = t.dependencies, t !== null && (t.firstContext = null);
  }
  function Ht(t) {
    return Nm(vi, t);
  }
  function Rl(t, n) {
    return vi === null && gi(t), Nm(t, n);
  }
  function Nm(t, n) {
    var i = n._currentValue;
    if (n = {
      context: n,
      memoizedValue: i,
      next: null
    }, ca === null) {
      if (t === null) throw Error(s(308));
      ca = n, t.dependencies = {
        lanes: 0,
        firstContext: n
      }, t.flags |= 524288;
    } else ca = ca.next = n;
    return i;
  }
  var u2 = typeof AbortController < "u" ? AbortController : function() {
    var t = [], n = this.signal = {
      aborted: !1,
      addEventListener: function(i, o) {
        t.push(o);
      }
    };
    this.abort = function() {
      n.aborted = !0, t.forEach(function(i) {
        return i();
      });
    };
  }, c2 = a.unstable_scheduleCallback, f2 = a.unstable_NormalPriority, pt = {
    $$typeof: H,
    Consumer: null,
    Provider: null,
    _currentValue: null,
    _currentValue2: null,
    _threadCount: 0
  };
  function fc() {
    return {
      controller: new u2(),
      data: /* @__PURE__ */ new Map(),
      refCount: 0
    };
  }
  function uo(t) {
    t.refCount--, t.refCount === 0 && c2(f2, function() {
      t.controller.abort();
    });
  }
  var co = null, dc = 0, rr = 0, or = null;
  function d2(t, n) {
    if (co === null) {
      var i = co = [];
      dc = 0, rr = vf(), or = {
        status: "pending",
        value: void 0,
        then: function(o) {
          i.push(o);
        }
      };
    }
    return dc++, n.then(Dm, Dm), n;
  }
  function Dm() {
    if (--dc === 0 && co !== null) {
      or !== null && (or.status = "fulfilled");
      var t = co;
      co = null, rr = 0, or = null;
      for (var n = 0; n < t.length; n++) (0, t[n])();
    }
  }
  function h2(t, n) {
    var i = [], o = {
      status: "pending",
      value: null,
      reason: null,
      then: function(u) {
        i.push(u);
      }
    };
    return t.then(function() {
      o.status = "fulfilled", o.value = n;
      for (var u = 0; u < i.length; u++) (0, i[u])(n);
    }, function(u) {
      for (o.status = "rejected", o.reason = u, u = 0; u < i.length; u++) (0, i[u])(void 0);
    }), o;
  }
  var zm = A.S;
  A.S = function(t, n) {
    hv = xt(), typeof n == "object" && n !== null && typeof n.then == "function" && d2(t, n), zm !== null && zm(t, n);
  };
  var yi = O(null);
  function hc() {
    var t = yi.current;
    return t !== null ? t : Xe.pooledCache;
  }
  function Nl(t, n) {
    n === null ? re(yi, yi.current) : re(yi, n.pool);
  }
  function Lm() {
    var t = hc();
    return t === null ? null : {
      parent: pt._currentValue,
      pool: t
    };
  }
  var lr = Error(s(460)), mc = Error(s(474)), Dl = Error(s(542)), zl = { then: function() {
  } };
  function Hm(t) {
    return t = t.status, t === "fulfilled" || t === "rejected";
  }
  function jm(t, n, i) {
    switch (i = t[i], i === void 0 ? t.push(n) : i !== n && (n.then(oa, oa), n = i), n.status) {
      case "fulfilled":
        return n.value;
      case "rejected":
        throw t = n.reason, Um(t), t;
      default:
        if (typeof n.status == "string") n.then(oa, oa);
        else {
          if (t = Xe, t !== null && 100 < t.shellSuspendCounter) throw Error(s(482));
          t = n, t.status = "pending", t.then(function(o) {
            if (n.status === "pending") {
              var u = n;
              u.status = "fulfilled", u.value = o;
            }
          }, function(o) {
            if (n.status === "pending") {
              var u = n;
              u.status = "rejected", u.reason = o;
            }
          });
        }
        switch (n.status) {
          case "fulfilled":
            return n.value;
          case "rejected":
            throw t = n.reason, Um(t), t;
        }
        throw _i = n, lr;
    }
  }
  function bi(t) {
    try {
      var n = t._init;
      return n(t._payload);
    } catch (i) {
      throw i !== null && typeof i == "object" && typeof i.then == "function" ? (_i = i, lr) : i;
    }
  }
  var _i = null;
  function Bm() {
    if (_i === null) throw Error(s(459));
    var t = _i;
    return _i = null, t;
  }
  function Um(t) {
    if (t === lr || t === Dl) throw Error(s(483));
  }
  var sr = null, fo = 0;
  function Ll(t) {
    var n = fo;
    return fo += 1, sr === null && (sr = []), jm(sr, t, n);
  }
  function ho(t, n) {
    n = n.props.ref, t.ref = n !== void 0 ? n : null;
  }
  function Hl(t, n) {
    throw n.$$typeof === E ? Error(s(525)) : (t = Object.prototype.toString.call(n), Error(s(31, t === "[object Object]" ? "object with keys {" + Object.keys(n).join(", ") + "}" : t)));
  }
  function km(t) {
    function n(U, z) {
      if (t) {
        var P = U.deletions;
        P === null ? (U.deletions = [z], U.flags |= 16) : P.push(z);
      }
    }
    function i(U, z) {
      if (!t) return null;
      for (; z !== null; ) n(U, z), z = z.sibling;
      return null;
    }
    function o(U) {
      for (var z = /* @__PURE__ */ new Map(); U !== null; ) U.key !== null ? z.set(U.key, U) : z.set(U.index, U), U = U.sibling;
      return z;
    }
    function u(U, z) {
      return U = sa(U, z), U.index = 0, U.sibling = null, U;
    }
    function f(U, z, P) {
      return U.index = P, t ? (P = U.alternate, P !== null ? (P = P.index, P < z ? (U.flags |= 67108866, z) : P) : (U.flags |= 67108866, z)) : (U.flags |= 1048576, z);
    }
    function v(U) {
      return t && U.alternate === null && (U.flags |= 67108866), U;
    }
    function S(U, z, P, W) {
      return z === null || z.tag !== 6 ? (z = nc(P, U.mode, W), z.return = U, z) : (z = u(z, P), z.return = U, z);
    }
    function R(U, z, P, W) {
      var be = P.type;
      return be === T ? X(U, z, P.props.children, W, P.key) : z !== null && (z.elementType === be || typeof be == "object" && be !== null && be.$$typeof === q && bi(be) === z.type) ? (z = u(z, P.props), ho(z, P), z.return = U, z) : (z = xl(P.type, P.key, P.props, null, U.mode, W), ho(z, P), z.return = U, z);
    }
    function I(U, z, P, W) {
      return z === null || z.tag !== 4 || z.stateNode.containerInfo !== P.containerInfo || z.stateNode.implementation !== P.implementation ? (z = ac(P, U.mode, W), z.return = U, z) : (z = u(z, P.children || []), z.return = U, z);
    }
    function X(U, z, P, W, be) {
      return z === null || z.tag !== 7 ? (z = mi(P, U.mode, W, be), z.return = U, z) : (z = u(z, P), z.return = U, z);
    }
    function J(U, z, P) {
      if (typeof z == "string" && z !== "" || typeof z == "number" || typeof z == "bigint") return z = nc("" + z, U.mode, P), z.return = U, z;
      if (typeof z == "object" && z !== null) {
        switch (z.$$typeof) {
          case x:
            return P = xl(z.type, z.key, z.props, null, U.mode, P), ho(P, z), P.return = U, P;
          case C:
            return z = ac(z, U.mode, P), z.return = U, z;
          case q:
            return z = bi(z), J(U, z, P);
        }
        if (L(z) || V(z)) return z = mi(z, U.mode, P, null), z.return = U, z;
        if (typeof z.then == "function") return J(U, Ll(z), P);
        if (z.$$typeof === H) return J(U, Rl(U, z), P);
        Hl(U, z);
      }
      return null;
    }
    function Z(U, z, P, W) {
      var be = z !== null ? z.key : null;
      if (typeof P == "string" && P !== "" || typeof P == "number" || typeof P == "bigint") return be !== null ? null : S(U, z, "" + P, W);
      if (typeof P == "object" && P !== null) {
        switch (P.$$typeof) {
          case x:
            return P.key === be ? R(U, z, P, W) : null;
          case C:
            return P.key === be ? I(U, z, P, W) : null;
          case q:
            return P = bi(P), Z(U, z, P, W);
        }
        if (L(P) || V(P)) return be !== null ? null : X(U, z, P, W, null);
        if (typeof P.then == "function") return Z(U, z, Ll(P), W);
        if (P.$$typeof === H) return Z(U, z, Rl(U, P), W);
        Hl(U, P);
      }
      return null;
    }
    function G(U, z, P, W, be) {
      if (typeof W == "string" && W !== "" || typeof W == "number" || typeof W == "bigint") return U = U.get(P) || null, S(z, U, "" + W, be);
      if (typeof W == "object" && W !== null) {
        switch (W.$$typeof) {
          case x:
            return U = U.get(W.key === null ? P : W.key) || null, R(z, U, W, be);
          case C:
            return U = U.get(W.key === null ? P : W.key) || null, I(z, U, W, be);
          case q:
            return W = bi(W), G(U, z, P, W, be);
        }
        if (L(W) || V(W)) return U = U.get(P) || null, X(z, U, W, be, null);
        if (typeof W.then == "function") return G(U, z, P, Ll(W), be);
        if (W.$$typeof === H) return G(U, z, P, Rl(z, W), be);
        Hl(z, W);
      }
      return null;
    }
    function he(U, z, P, W) {
      for (var be = null, Ue = null, pe = z, xe = z = 0, De = null; pe !== null && xe < P.length; xe++) {
        pe.index > xe ? (De = pe, pe = null) : De = pe.sibling;
        var ke = Z(U, pe, P[xe], W);
        if (ke === null) {
          pe === null && (pe = De);
          break;
        }
        t && pe && ke.alternate === null && n(U, pe), z = f(ke, z, xe), Ue === null ? be = ke : Ue.sibling = ke, Ue = ke, pe = De;
      }
      if (xe === P.length) return i(U, pe), ze && ua(U, xe), be;
      if (pe === null) {
        for (; xe < P.length; xe++) pe = J(U, P[xe], W), pe !== null && (z = f(pe, z, xe), Ue === null ? be = pe : Ue.sibling = pe, Ue = pe);
        return ze && ua(U, xe), be;
      }
      for (pe = o(pe); xe < P.length; xe++) De = G(pe, U, xe, P[xe], W), De !== null && (t && De.alternate !== null && pe.delete(De.key === null ? xe : De.key), z = f(De, z, xe), Ue === null ? be = De : Ue.sibling = De, Ue = De);
      return t && pe.forEach(function(Qa) {
        return n(U, Qa);
      }), ze && ua(U, xe), be;
    }
    function we(U, z, P, W) {
      if (P == null) throw Error(s(151));
      for (var be = null, Ue = null, pe = z, xe = z = 0, De = null, ke = P.next(); pe !== null && !ke.done; xe++, ke = P.next()) {
        pe.index > xe ? (De = pe, pe = null) : De = pe.sibling;
        var Qa = Z(U, pe, ke.value, W);
        if (Qa === null) {
          pe === null && (pe = De);
          break;
        }
        t && pe && Qa.alternate === null && n(U, pe), z = f(Qa, z, xe), Ue === null ? be = Qa : Ue.sibling = Qa, Ue = Qa, pe = De;
      }
      if (ke.done) return i(U, pe), ze && ua(U, xe), be;
      if (pe === null) {
        for (; !ke.done; xe++, ke = P.next()) ke = J(U, ke.value, W), ke !== null && (z = f(ke, z, xe), Ue === null ? be = ke : Ue.sibling = ke, Ue = ke);
        return ze && ua(U, xe), be;
      }
      for (pe = o(pe); !ke.done; xe++, ke = P.next()) ke = G(pe, U, xe, ke.value, W), ke !== null && (t && ke.alternate !== null && pe.delete(ke.key === null ? xe : ke.key), z = f(ke, z, xe), Ue === null ? be = ke : Ue.sibling = ke, Ue = ke);
      return t && pe.forEach(function(Ow) {
        return n(U, Ow);
      }), ze && ua(U, xe), be;
    }
    function $e(U, z, P, W) {
      if (typeof P == "object" && P !== null && P.type === T && P.key === null && (P = P.props.children), typeof P == "object" && P !== null) {
        switch (P.$$typeof) {
          case x:
            e: {
              for (var be = P.key; z !== null; ) {
                if (z.key === be) {
                  if (be = P.type, be === T) {
                    if (z.tag === 7) {
                      i(U, z.sibling), W = u(z, P.props.children), W.return = U, U = W;
                      break e;
                    }
                  } else if (z.elementType === be || typeof be == "object" && be !== null && be.$$typeof === q && bi(be) === z.type) {
                    i(U, z.sibling), W = u(z, P.props), ho(W, P), W.return = U, U = W;
                    break e;
                  }
                  i(U, z);
                  break;
                } else n(U, z);
                z = z.sibling;
              }
              P.type === T ? (W = mi(P.props.children, U.mode, W, P.key), W.return = U, U = W) : (W = xl(P.type, P.key, P.props, null, U.mode, W), ho(W, P), W.return = U, U = W);
            }
            return v(U);
          case C:
            e: {
              for (be = P.key; z !== null; ) {
                if (z.key === be) if (z.tag === 4 && z.stateNode.containerInfo === P.containerInfo && z.stateNode.implementation === P.implementation) {
                  i(U, z.sibling), W = u(z, P.children || []), W.return = U, U = W;
                  break e;
                } else {
                  i(U, z);
                  break;
                }
                else n(U, z);
                z = z.sibling;
              }
              W = ac(P, U.mode, W), W.return = U, U = W;
            }
            return v(U);
          case q:
            return P = bi(P), $e(U, z, P, W);
        }
        if (L(P)) return he(U, z, P, W);
        if (V(P)) {
          if (be = V(P), typeof be != "function") throw Error(s(150));
          return P = be.call(P), we(U, z, P, W);
        }
        if (typeof P.then == "function") return $e(U, z, Ll(P), W);
        if (P.$$typeof === H) return $e(U, z, Rl(U, P), W);
        Hl(U, P);
      }
      return typeof P == "string" && P !== "" || typeof P == "number" || typeof P == "bigint" ? (P = "" + P, z !== null && z.tag === 6 ? (i(U, z.sibling), W = u(z, P), W.return = U, U = W) : (i(U, z), W = nc(P, U.mode, W), W.return = U, U = W), v(U)) : i(U, z);
    }
    return function(U, z, P, W) {
      try {
        fo = 0;
        var be = $e(U, z, P, W);
        return sr = null, be;
      } catch (pe) {
        if (pe === lr || pe === Dl) throw pe;
        var Ue = un(29, pe, null, U.mode);
        return Ue.lanes = W, Ue.return = U, Ue;
      }
    };
  }
  var wi = km(!0), Pm = km(!1), ja = !1;
  function pc(t) {
    t.updateQueue = {
      baseState: t.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: {
        pending: null,
        lanes: 0,
        hiddenCallbacks: null
      },
      callbacks: null
    };
  }
  function vc(t, n) {
    t = t.updateQueue, n.updateQueue === t && (n.updateQueue = {
      baseState: t.baseState,
      firstBaseUpdate: t.firstBaseUpdate,
      lastBaseUpdate: t.lastBaseUpdate,
      shared: t.shared,
      callbacks: null
    });
  }
  function Si(t) {
    return {
      lane: t,
      tag: 0,
      payload: null,
      callback: null,
      next: null
    };
  }
  function Ei(t, n, i) {
    var o = t.updateQueue;
    if (o === null) return null;
    if (o = o.shared, (Pe & 2) !== 0) {
      var u = o.pending;
      return u === null ? n.next = n : (n.next = u.next, u.next = n), o.pending = n, n = Al(t), Em(t, null, i), n;
    }
    return Cl(t, o, n, i), Al(t);
  }
  function mo(t, n, i) {
    if (n = n.updateQueue, n !== null && (n = n.shared, (i & 4194048) !== 0)) {
      var o = n.lanes;
      o &= t.pendingLanes, i |= o, n.lanes = i, dl(t, i);
    }
  }
  function gc(t, n) {
    var i = t.updateQueue, o = t.alternate;
    if (o !== null && (o = o.updateQueue, i === o)) {
      var u = null, f = null;
      if (i = i.firstBaseUpdate, i !== null) {
        do {
          var v = {
            lane: i.lane,
            tag: i.tag,
            payload: i.payload,
            callback: null,
            next: null
          };
          f === null ? u = f = v : f = f.next = v, i = i.next;
        } while (i !== null);
        f === null ? u = f = n : f = f.next = n;
      } else u = f = n;
      i = {
        baseState: o.baseState,
        firstBaseUpdate: u,
        lastBaseUpdate: f,
        shared: o.shared,
        callbacks: o.callbacks
      }, t.updateQueue = i;
      return;
    }
    t = i.lastBaseUpdate, t === null ? i.firstBaseUpdate = n : t.next = n, i.lastBaseUpdate = n;
  }
  var yc = !1;
  function po() {
    if (yc) {
      var t = or;
      if (t !== null) throw t;
    }
  }
  function vo(t, n, i, o) {
    yc = !1;
    var u = t.updateQueue;
    ja = !1;
    var f = u.firstBaseUpdate, v = u.lastBaseUpdate, S = u.shared.pending;
    if (S !== null) {
      u.shared.pending = null;
      var R = S, I = R.next;
      R.next = null, v === null ? f = I : v.next = I, v = R;
      var X = t.alternate;
      X !== null && (X = X.updateQueue, S = X.lastBaseUpdate, S !== v && (S === null ? X.firstBaseUpdate = I : S.next = I, X.lastBaseUpdate = R));
    }
    if (f !== null) {
      var J = u.baseState;
      v = 0, X = I = R = null, S = f;
      do {
        var Z = S.lane & -536870913, G = Z !== S.lane;
        if (G ? (Ne & Z) === Z : (o & Z) === Z) {
          Z !== 0 && Z === rr && (yc = !0), X !== null && (X = X.next = {
            lane: 0,
            tag: S.tag,
            payload: S.payload,
            callback: null,
            next: null
          });
          e: {
            var he = t, we = S;
            Z = n;
            var $e = i;
            switch (we.tag) {
              case 1:
                if (he = we.payload, typeof he == "function") {
                  J = he.call($e, J, Z);
                  break e;
                }
                J = he;
                break e;
              case 3:
                he.flags = he.flags & -65537 | 128;
              case 0:
                if (he = we.payload, Z = typeof he == "function" ? he.call($e, J, Z) : he, Z == null) break e;
                J = w({}, J, Z);
                break e;
              case 2:
                ja = !0;
            }
          }
          Z = S.callback, Z !== null && (t.flags |= 64, G && (t.flags |= 8192), G = u.callbacks, G === null ? u.callbacks = [Z] : G.push(Z));
        } else G = {
          lane: Z,
          tag: S.tag,
          payload: S.payload,
          callback: S.callback,
          next: null
        }, X === null ? (I = X = G, R = J) : X = X.next = G, v |= Z;
        if (S = S.next, S === null) {
          if (S = u.shared.pending, S === null) break;
          G = S, S = G.next, G.next = null, u.lastBaseUpdate = G, u.shared.pending = null;
        }
      } while (!0);
      X === null && (R = J), u.baseState = R, u.firstBaseUpdate = I, u.lastBaseUpdate = X, f === null && (u.shared.lanes = 0), Ia |= v, t.lanes = v, t.memoizedState = J;
    }
  }
  function Im(t, n) {
    if (typeof t != "function") throw Error(s(191, t));
    t.call(n);
  }
  function Zm(t, n) {
    var i = t.callbacks;
    if (i !== null) for (t.callbacks = null, t = 0; t < i.length; t++) Im(i[t], n);
  }
  var ur = O(null), jl = O(0);
  function Gm(t, n) {
    t = _a, re(jl, t), re(ur, n), _a = t | n.baseLanes;
  }
  function bc() {
    re(jl, _a), re(ur, ur.current);
  }
  function _c() {
    _a = jl.current, $(ur), $(jl);
  }
  var cn = O(null), Mn = null;
  function Ba(t) {
    var n = t.alternate;
    re(ut, ut.current & 1), re(cn, t), Mn === null && (n === null || ur.current !== null || n.memoizedState !== null) && (Mn = t);
  }
  function wc(t) {
    re(ut, ut.current), re(cn, t), Mn === null && (Mn = t);
  }
  function Vm(t) {
    t.tag === 22 ? (re(ut, ut.current), re(cn, t), Mn === null && (Mn = t)) : Ua(t);
  }
  function Ua() {
    re(ut, ut.current), re(cn, cn.current);
  }
  function fn(t) {
    $(cn), Mn === t && (Mn = null), $(ut);
  }
  var ut = O(0);
  function Bl(t) {
    for (var n = t; n !== null; ) {
      if (n.tag === 13) {
        var i = n.memoizedState;
        if (i !== null && (i = i.dehydrated, i === null || xf(i) || Of(i))) return n;
      } else if (n.tag === 19 && (n.memoizedProps.revealOrder === "forwards" || n.memoizedProps.revealOrder === "backwards" || n.memoizedProps.revealOrder === "unstable_legacy-backwards" || n.memoizedProps.revealOrder === "together")) {
        if ((n.flags & 128) !== 0) return n;
      } else if (n.child !== null) {
        n.child.return = n, n = n.child;
        continue;
      }
      if (n === t) break;
      for (; n.sibling === null; ) {
        if (n.return === null || n.return === t) return null;
        n = n.return;
      }
      n.sibling.return = n.return, n = n.sibling;
    }
    return null;
  }
  var da = 0, Ae = null, Ge = null, vt = null, Ul = !1, cr = !1, Ti = !1, kl = 0, go = 0, fr = null, m2 = 0;
  function ot() {
    throw Error(s(321));
  }
  function Sc(t, n) {
    if (n === null) return !1;
    for (var i = 0; i < n.length && i < t.length; i++) if (!sn(t[i], n[i])) return !1;
    return !0;
  }
  function Ec(t, n, i, o, u, f) {
    return da = f, Ae = n, n.memoizedState = null, n.updateQueue = null, n.lanes = 0, A.H = t === null || t.memoizedState === null ? xp : Uc, Ti = !1, f = i(o, u), Ti = !1, cr && (f = Fm(n, i, o, u)), $m(t), f;
  }
  function $m(t) {
    A.H = _o;
    var n = Ge !== null && Ge.next !== null;
    if (da = 0, vt = Ge = Ae = null, Ul = !1, go = 0, fr = null, n) throw Error(s(300));
    t === null || gt || (t = t.dependencies, t !== null && Ml(t) && (gt = !0));
  }
  function Fm(t, n, i, o) {
    Ae = t;
    var u = 0;
    do {
      if (cr && (fr = null), go = 0, cr = !1, 25 <= u) throw Error(s(301));
      if (u += 1, vt = Ge = null, t.updateQueue != null) {
        var f = t.updateQueue;
        f.lastEffect = null, f.events = null, f.stores = null, f.memoCache != null && (f.memoCache.index = 0);
      }
      A.H = Op, f = n(i, o);
    } while (cr);
    return f;
  }
  function p2() {
    var t = A.H, n = t.useState()[0];
    return n = typeof n.then == "function" ? yo(n) : n, t = t.useState()[0], (Ge !== null ? Ge.memoizedState : null) !== t && (Ae.flags |= 1024), n;
  }
  function Tc() {
    var t = kl !== 0;
    return kl = 0, t;
  }
  function Cc(t, n, i) {
    n.updateQueue = t.updateQueue, n.flags &= -2053, t.lanes &= ~i;
  }
  function Ac(t) {
    if (Ul) {
      for (t = t.memoizedState; t !== null; ) {
        var n = t.queue;
        n !== null && (n.pending = null), t = t.next;
      }
      Ul = !1;
    }
    da = 0, vt = Ge = Ae = null, cr = !1, go = kl = 0, fr = null;
  }
  function Gt() {
    var t = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null
    };
    return vt === null ? Ae.memoizedState = vt = t : vt = vt.next = t, vt;
  }
  function ct() {
    if (Ge === null) {
      var t = Ae.alternate;
      t = t !== null ? t.memoizedState : null;
    } else t = Ge.next;
    var n = vt === null ? Ae.memoizedState : vt.next;
    if (n !== null) vt = n, Ge = t;
    else {
      if (t === null)
        throw Ae.alternate === null ? Error(s(467)) : Error(s(310));
      Ge = t, t = {
        memoizedState: Ge.memoizedState,
        baseState: Ge.baseState,
        baseQueue: Ge.baseQueue,
        queue: Ge.queue,
        next: null
      }, vt === null ? Ae.memoizedState = vt = t : vt = vt.next = t;
    }
    return vt;
  }
  function Pl() {
    return {
      lastEffect: null,
      events: null,
      stores: null,
      memoCache: null
    };
  }
  function yo(t) {
    var n = go;
    return go += 1, fr === null && (fr = []), t = jm(fr, t, n), n = Ae, (vt === null ? n.memoizedState : vt.next) === null && (n = n.alternate, A.H = n === null || n.memoizedState === null ? xp : Uc), t;
  }
  function Il(t) {
    if (t !== null && typeof t == "object") {
      if (typeof t.then == "function") return yo(t);
      if (t.$$typeof === H) return Ht(t);
    }
    throw Error(s(438, String(t)));
  }
  function xc(t) {
    var n = null, i = Ae.updateQueue;
    if (i !== null && (n = i.memoCache), n == null) {
      var o = Ae.alternate;
      o !== null && (o = o.updateQueue, o !== null && (o = o.memoCache, o != null && (n = {
        data: o.data.map(function(u) {
          return u.slice();
        }),
        index: 0
      })));
    }
    if (n ??= {
      data: [],
      index: 0
    }, i === null && (i = Pl(), Ae.updateQueue = i), i.memoCache = n, i = n.data[n.index], i === void 0) for (i = n.data[n.index] = Array(t), o = 0; o < t; o++) i[o] = ee;
    return n.index++, i;
  }
  function ha(t, n) {
    return typeof n == "function" ? n(t) : n;
  }
  function Zl(t) {
    return Oc(ct(), Ge, t);
  }
  function Oc(t, n, i) {
    var o = t.queue;
    if (o === null) throw Error(s(311));
    o.lastRenderedReducer = i;
    var u = t.baseQueue, f = o.pending;
    if (f !== null) {
      if (u !== null) {
        var v = u.next;
        u.next = f.next, f.next = v;
      }
      n.baseQueue = u = f, o.pending = null;
    }
    if (f = t.baseState, u === null) t.memoizedState = f;
    else {
      n = u.next;
      var S = v = null, R = null, I = n, X = !1;
      do {
        var J = I.lane & -536870913;
        if (J !== I.lane ? (Ne & J) === J : (da & J) === J) {
          var Z = I.revertLane;
          if (Z === 0) R !== null && (R = R.next = {
            lane: 0,
            revertLane: 0,
            gesture: null,
            action: I.action,
            hasEagerState: I.hasEagerState,
            eagerState: I.eagerState,
            next: null
          }), J === rr && (X = !0);
          else if ((da & Z) === Z) {
            I = I.next, Z === rr && (X = !0);
            continue;
          } else J = {
            lane: 0,
            revertLane: I.revertLane,
            gesture: null,
            action: I.action,
            hasEagerState: I.hasEagerState,
            eagerState: I.eagerState,
            next: null
          }, R === null ? (S = R = J, v = f) : R = R.next = J, Ae.lanes |= Z, Ia |= Z;
          J = I.action, Ti && i(f, J), f = I.hasEagerState ? I.eagerState : i(f, J);
        } else Z = {
          lane: J,
          revertLane: I.revertLane,
          gesture: I.gesture,
          action: I.action,
          hasEagerState: I.hasEagerState,
          eagerState: I.eagerState,
          next: null
        }, R === null ? (S = R = Z, v = f) : R = R.next = Z, Ae.lanes |= J, Ia |= J;
        I = I.next;
      } while (I !== null && I !== n);
      if (R === null ? v = f : R.next = S, !sn(f, t.memoizedState) && (gt = !0, X && (i = or, i !== null))) throw i;
      t.memoizedState = f, t.baseState = v, t.baseQueue = R, o.lastRenderedState = f;
    }
    return u === null && (o.lanes = 0), [t.memoizedState, o.dispatch];
  }
  function Mc(t) {
    var n = ct(), i = n.queue;
    if (i === null) throw Error(s(311));
    i.lastRenderedReducer = t;
    var o = i.dispatch, u = i.pending, f = n.memoizedState;
    if (u !== null) {
      i.pending = null;
      var v = u = u.next;
      do
        f = t(f, v.action), v = v.next;
      while (v !== u);
      sn(f, n.memoizedState) || (gt = !0), n.memoizedState = f, n.baseQueue === null && (n.baseState = f), i.lastRenderedState = f;
    }
    return [f, o];
  }
  function qm(t, n, i) {
    var o = Ae, u = ct(), f = ze;
    if (f) {
      if (i === void 0) throw Error(s(407));
      i = i();
    } else i = n();
    var v = !sn((Ge || u).memoizedState, i);
    if (v && (u.memoizedState = i, gt = !0), u = u.queue, Dc(Wm.bind(null, o, u, t), [t]), u.getSnapshot !== n || v || vt !== null && vt.memoizedState.tag & 1) {
      if (o.flags |= 2048, dr(9, { destroy: void 0 }, Ym.bind(null, o, u, i, n), null), Xe === null) throw Error(s(349));
      f || (da & 127) !== 0 || Xm(o, n, i);
    }
    return i;
  }
  function Xm(t, n, i) {
    t.flags |= 16384, t = {
      getSnapshot: n,
      value: i
    }, n = Ae.updateQueue, n === null ? (n = Pl(), Ae.updateQueue = n, n.stores = [t]) : (i = n.stores, i === null ? n.stores = [t] : i.push(t));
  }
  function Ym(t, n, i, o) {
    n.value = i, n.getSnapshot = o, Qm(n) && Km(t);
  }
  function Wm(t, n, i) {
    return i(function() {
      Qm(n) && Km(t);
    });
  }
  function Qm(t) {
    var n = t.getSnapshot;
    t = t.value;
    try {
      var i = n();
      return !sn(t, i);
    } catch {
      return !0;
    }
  }
  function Km(t) {
    var n = hi(t, 2);
    n !== null && tn(n, t, 2);
  }
  function Rc(t) {
    var n = Gt();
    if (typeof t == "function") {
      var i = t;
      if (t = i(), Ti) {
        Un(!0);
        try {
          i();
        } finally {
          Un(!1);
        }
      }
    }
    return n.memoizedState = n.baseState = t, n.queue = {
      pending: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: ha,
      lastRenderedState: t
    }, n;
  }
  function Jm(t, n, i, o) {
    return t.baseState = i, Oc(t, Ge, typeof o == "function" ? o : ha);
  }
  function v2(t, n, i, o, u) {
    if ($l(t)) throw Error(s(485));
    if (t = n.action, t !== null) {
      var f = {
        payload: u,
        action: t,
        next: null,
        isTransition: !0,
        status: "pending",
        value: null,
        reason: null,
        listeners: [],
        then: function(v) {
          f.listeners.push(v);
        }
      };
      A.T !== null ? i(!0) : f.isTransition = !1, o(f), i = n.pending, i === null ? (f.next = n.pending = f, ep(n, f)) : (f.next = i.next, n.pending = i.next = f);
    }
  }
  function ep(t, n) {
    var i = n.action, o = n.payload, u = t.state;
    if (n.isTransition) {
      var f = A.T, v = {};
      A.T = v;
      try {
        var S = i(u, o), R = A.S;
        R !== null && R(v, S), tp(t, n, S);
      } catch (I) {
        Nc(t, n, I);
      } finally {
        f !== null && v.types !== null && (f.types = v.types), A.T = f;
      }
    } else try {
      f = i(u, o), tp(t, n, f);
    } catch (I) {
      Nc(t, n, I);
    }
  }
  function tp(t, n, i) {
    i !== null && typeof i == "object" && typeof i.then == "function" ? i.then(function(o) {
      np(t, n, o);
    }, function(o) {
      return Nc(t, n, o);
    }) : np(t, n, i);
  }
  function np(t, n, i) {
    n.status = "fulfilled", n.value = i, ap(n), t.state = i, n = t.pending, n !== null && (i = n.next, i === n ? t.pending = null : (i = i.next, n.next = i, ep(t, i)));
  }
  function Nc(t, n, i) {
    var o = t.pending;
    if (t.pending = null, o !== null) {
      o = o.next;
      do
        n.status = "rejected", n.reason = i, ap(n), n = n.next;
      while (n !== o);
    }
    t.action = null;
  }
  function ap(t) {
    t = t.listeners;
    for (var n = 0; n < t.length; n++) (0, t[n])();
  }
  function ip(t, n) {
    return n;
  }
  function rp(t, n) {
    if (ze) {
      var i = Xe.formState;
      if (i !== null) {
        e: {
          var o = Ae;
          if (ze) {
            if (Ke) {
              t: {
                for (var u = Ke, f = On; u.nodeType !== 8; ) {
                  if (!f) {
                    u = null;
                    break t;
                  }
                  if (u = Nn(u.nextSibling), u === null) {
                    u = null;
                    break t;
                  }
                }
                f = u.data, u = f === "F!" || f === "F" ? u : null;
              }
              if (u) {
                Ke = Nn(u.nextSibling), o = u.data === "F!";
                break e;
              }
            }
            La(o);
          }
          o = !1;
        }
        o && (n = i[0]);
      }
    }
    return i = Gt(), i.memoizedState = i.baseState = n, o = {
      pending: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: ip,
      lastRenderedState: n
    }, i.queue = o, i = Tp.bind(null, Ae, o), o.dispatch = i, o = Rc(!1), f = Bc.bind(null, Ae, !1, o.queue), o = Gt(), u = {
      state: n,
      dispatch: null,
      action: t,
      pending: null
    }, o.queue = u, i = v2.bind(null, Ae, u, f, i), u.dispatch = i, o.memoizedState = t, [
      n,
      i,
      !1
    ];
  }
  function op(t) {
    return lp(ct(), Ge, t);
  }
  function lp(t, n, i) {
    if (n = Oc(t, n, ip)[0], t = Zl(ha)[0], typeof n == "object" && n !== null && typeof n.then == "function") try {
      var o = yo(n);
    } catch (v) {
      throw v === lr ? Dl : v;
    }
    else o = n;
    n = ct();
    var u = n.queue, f = u.dispatch;
    return i !== n.memoizedState && (Ae.flags |= 2048, dr(9, { destroy: void 0 }, g2.bind(null, u, i), null)), [
      o,
      f,
      t
    ];
  }
  function g2(t, n) {
    t.action = n;
  }
  function sp(t) {
    var n = ct(), i = Ge;
    if (i !== null) return lp(n, i, t);
    ct(), n = n.memoizedState, i = ct();
    var o = i.queue.dispatch;
    return i.memoizedState = t, [
      n,
      o,
      !1
    ];
  }
  function dr(t, n, i, o) {
    return t = {
      tag: t,
      create: i,
      deps: o,
      inst: n,
      next: null
    }, n = Ae.updateQueue, n === null && (n = Pl(), Ae.updateQueue = n), i = n.lastEffect, i === null ? n.lastEffect = t.next = t : (o = i.next, i.next = t, t.next = o, n.lastEffect = t), t;
  }
  function up() {
    return ct().memoizedState;
  }
  function Gl(t, n, i, o) {
    var u = Gt();
    Ae.flags |= t, u.memoizedState = dr(1 | n, { destroy: void 0 }, i, o === void 0 ? null : o);
  }
  function Vl(t, n, i, o) {
    var u = ct();
    o = o === void 0 ? null : o;
    var f = u.memoizedState.inst;
    Ge !== null && o !== null && Sc(o, Ge.memoizedState.deps) ? u.memoizedState = dr(n, f, i, o) : (Ae.flags |= t, u.memoizedState = dr(1 | n, f, i, o));
  }
  function cp(t, n) {
    Gl(8390656, 8, t, n);
  }
  function Dc(t, n) {
    Vl(2048, 8, t, n);
  }
  function y2(t) {
    Ae.flags |= 4;
    var n = Ae.updateQueue;
    if (n === null) n = Pl(), Ae.updateQueue = n, n.events = [t];
    else {
      var i = n.events;
      i === null ? n.events = [t] : i.push(t);
    }
  }
  function fp(t) {
    var n = ct().memoizedState;
    return y2({
      ref: n,
      nextImpl: t
    }), function() {
      if ((Pe & 2) !== 0) throw Error(s(440));
      return n.impl.apply(void 0, arguments);
    };
  }
  function dp(t, n) {
    return Vl(4, 2, t, n);
  }
  function hp(t, n) {
    return Vl(4, 4, t, n);
  }
  function mp(t, n) {
    if (typeof n == "function") {
      t = t();
      var i = n(t);
      return function() {
        typeof i == "function" ? i() : n(null);
      };
    }
    if (n != null) return t = t(), n.current = t, function() {
      n.current = null;
    };
  }
  function pp(t, n, i) {
    i = i != null ? i.concat([t]) : null, Vl(4, 4, mp.bind(null, n, t), i);
  }
  function zc() {
  }
  function vp(t, n) {
    var i = ct();
    n = n === void 0 ? null : n;
    var o = i.memoizedState;
    return n !== null && Sc(n, o[1]) ? o[0] : (i.memoizedState = [t, n], t);
  }
  function gp(t, n) {
    var i = ct();
    n = n === void 0 ? null : n;
    var o = i.memoizedState;
    if (n !== null && Sc(n, o[1])) return o[0];
    if (o = t(), Ti) {
      Un(!0);
      try {
        t();
      } finally {
        Un(!1);
      }
    }
    return i.memoizedState = [o, n], o;
  }
  function Lc(t, n, i) {
    return i === void 0 || (da & 1073741824) !== 0 && (Ne & 261930) === 0 ? t.memoizedState = n : (t.memoizedState = i, t = pv(), Ae.lanes |= t, Ia |= t, i);
  }
  function yp(t, n, i, o) {
    return sn(i, n) ? i : ur.current !== null ? (t = Lc(t, i, o), sn(t, n) || (gt = !0), t) : (da & 42) === 0 || (da & 1073741824) !== 0 && (Ne & 261930) === 0 ? (gt = !0, t.memoizedState = i) : (t = pv(), Ae.lanes |= t, Ia |= t, n);
  }
  function bp(t, n, i, o, u) {
    var f = N.p;
    N.p = f !== 0 && 8 > f ? f : 8;
    var v = A.T, S = {};
    A.T = S, Bc(t, !1, n, i);
    try {
      var R = u(), I = A.S;
      I !== null && I(S, R), R !== null && typeof R == "object" && typeof R.then == "function" ? bo(t, n, h2(R, o), Rn(t)) : bo(t, n, o, Rn(t));
    } catch (X) {
      bo(t, n, {
        then: function() {
        },
        status: "rejected",
        reason: X
      }, Rn());
    } finally {
      N.p = f, v !== null && S.types !== null && (v.types = S.types), A.T = v;
    }
  }
  function b2() {
  }
  function Hc(t, n, i, o) {
    if (t.tag !== 5) throw Error(s(476));
    var u = _p(t).queue;
    bp(t, u, n, te, i === null ? b2 : function() {
      return wp(t), i(o);
    });
  }
  function _p(t) {
    var n = t.memoizedState;
    if (n !== null) return n;
    n = {
      memoizedState: te,
      baseState: te,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: ha,
        lastRenderedState: te
      },
      next: null
    };
    var i = {};
    return n.next = {
      memoizedState: i,
      baseState: i,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: ha,
        lastRenderedState: i
      },
      next: null
    }, t.memoizedState = n, t = t.alternate, t !== null && (t.memoizedState = n), n;
  }
  function wp(t) {
    var n = _p(t);
    n.next === null && (n = t.alternate.memoizedState), bo(t, n.next.queue, {}, Rn());
  }
  function jc() {
    return Ht(jo);
  }
  function Sp() {
    return ct().memoizedState;
  }
  function Ep() {
    return ct().memoizedState;
  }
  function _2(t) {
    for (var n = t.return; n !== null; ) {
      switch (n.tag) {
        case 24:
        case 3:
          var i = Rn();
          t = Si(i);
          var o = Ei(n, t, i);
          o !== null && (tn(o, n, i), mo(o, n, i)), n = { cache: fc() }, t.payload = n;
          return;
      }
      n = n.return;
    }
  }
  function w2(t, n, i) {
    var o = Rn();
    i = {
      lane: o,
      revertLane: 0,
      gesture: null,
      action: i,
      hasEagerState: !1,
      eagerState: null,
      next: null
    }, $l(t) ? Cp(n, i) : (i = ec(t, n, i, o), i !== null && (tn(i, t, o), Ap(i, n, o)));
  }
  function Tp(t, n, i) {
    bo(t, n, i, Rn());
  }
  function bo(t, n, i, o) {
    var u = {
      lane: o,
      revertLane: 0,
      gesture: null,
      action: i,
      hasEagerState: !1,
      eagerState: null,
      next: null
    };
    if ($l(t)) Cp(n, u);
    else {
      var f = t.alternate;
      if (t.lanes === 0 && (f === null || f.lanes === 0) && (f = n.lastRenderedReducer, f !== null)) try {
        var v = n.lastRenderedState, S = f(v, i);
        if (u.hasEagerState = !0, u.eagerState = S, sn(S, v)) return Cl(t, n, u, 0), Xe === null && Tl(), !1;
      } catch {
      }
      if (i = ec(t, n, u, o), i !== null) return tn(i, t, o), Ap(i, n, o), !0;
    }
    return !1;
  }
  function Bc(t, n, i, o) {
    if (o = {
      lane: 2,
      revertLane: vf(),
      gesture: null,
      action: o,
      hasEagerState: !1,
      eagerState: null,
      next: null
    }, $l(t)) {
      if (n) throw Error(s(479));
    } else n = ec(t, i, o, 2), n !== null && tn(n, t, 2);
  }
  function $l(t) {
    var n = t.alternate;
    return t === Ae || n !== null && n === Ae;
  }
  function Cp(t, n) {
    cr = Ul = !0;
    var i = t.pending;
    i === null ? n.next = n : (n.next = i.next, i.next = n), t.pending = n;
  }
  function Ap(t, n, i) {
    if ((i & 4194048) !== 0) {
      var o = n.lanes;
      o &= t.pendingLanes, i |= o, n.lanes = i, dl(t, i);
    }
  }
  var _o = {
    readContext: Ht,
    use: Il,
    useCallback: ot,
    useContext: ot,
    useEffect: ot,
    useImperativeHandle: ot,
    useLayoutEffect: ot,
    useInsertionEffect: ot,
    useMemo: ot,
    useReducer: ot,
    useRef: ot,
    useState: ot,
    useDebugValue: ot,
    useDeferredValue: ot,
    useTransition: ot,
    useSyncExternalStore: ot,
    useId: ot,
    useHostTransitionStatus: ot,
    useFormState: ot,
    useActionState: ot,
    useOptimistic: ot,
    useMemoCache: ot,
    useCacheRefresh: ot
  };
  _o.useEffectEvent = ot;
  var xp = {
    readContext: Ht,
    use: Il,
    useCallback: function(t, n) {
      return Gt().memoizedState = [t, n === void 0 ? null : n], t;
    },
    useContext: Ht,
    useEffect: cp,
    useImperativeHandle: function(t, n, i) {
      i = i != null ? i.concat([t]) : null, Gl(4194308, 4, mp.bind(null, n, t), i);
    },
    useLayoutEffect: function(t, n) {
      return Gl(4194308, 4, t, n);
    },
    useInsertionEffect: function(t, n) {
      Gl(4, 2, t, n);
    },
    useMemo: function(t, n) {
      var i = Gt();
      n = n === void 0 ? null : n;
      var o = t();
      if (Ti) {
        Un(!0);
        try {
          t();
        } finally {
          Un(!1);
        }
      }
      return i.memoizedState = [o, n], o;
    },
    useReducer: function(t, n, i) {
      var o = Gt();
      if (i !== void 0) {
        var u = i(n);
        if (Ti) {
          Un(!0);
          try {
            i(n);
          } finally {
            Un(!1);
          }
        }
      } else u = n;
      return o.memoizedState = o.baseState = u, t = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: t,
        lastRenderedState: u
      }, o.queue = t, t = t.dispatch = w2.bind(null, Ae, t), [o.memoizedState, t];
    },
    useRef: function(t) {
      var n = Gt();
      return t = { current: t }, n.memoizedState = t;
    },
    useState: function(t) {
      t = Rc(t);
      var n = t.queue, i = Tp.bind(null, Ae, n);
      return n.dispatch = i, [t.memoizedState, i];
    },
    useDebugValue: zc,
    useDeferredValue: function(t, n) {
      return Lc(Gt(), t, n);
    },
    useTransition: function() {
      var t = Rc(!1);
      return t = bp.bind(null, Ae, t.queue, !0, !1), Gt().memoizedState = t, [!1, t];
    },
    useSyncExternalStore: function(t, n, i) {
      var o = Ae, u = Gt();
      if (ze) {
        if (i === void 0) throw Error(s(407));
        i = i();
      } else {
        if (i = n(), Xe === null) throw Error(s(349));
        (Ne & 127) !== 0 || Xm(o, n, i);
      }
      u.memoizedState = i;
      var f = {
        value: i,
        getSnapshot: n
      };
      return u.queue = f, cp(Wm.bind(null, o, f, t), [t]), o.flags |= 2048, dr(9, { destroy: void 0 }, Ym.bind(null, o, f, i, n), null), i;
    },
    useId: function() {
      var t = Gt(), n = Xe.identifierPrefix;
      if (ze) {
        var i = Yn, o = Xn;
        i = (o & ~(1 << 32 - ae(o) - 1)).toString(32) + i, n = "_" + n + "R_" + i, i = kl++, 0 < i && (n += "H" + i.toString(32)), n += "_";
      } else i = m2++, n = "_" + n + "r_" + i.toString(32) + "_";
      return t.memoizedState = n;
    },
    useHostTransitionStatus: jc,
    useFormState: rp,
    useActionState: rp,
    useOptimistic: function(t) {
      var n = Gt();
      n.memoizedState = n.baseState = t;
      var i = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: null,
        lastRenderedState: null
      };
      return n.queue = i, n = Bc.bind(null, Ae, !0, i), i.dispatch = n, [t, n];
    },
    useMemoCache: xc,
    useCacheRefresh: function() {
      return Gt().memoizedState = _2.bind(null, Ae);
    },
    useEffectEvent: function(t) {
      var n = Gt(), i = { impl: t };
      return n.memoizedState = i, function() {
        if ((Pe & 2) !== 0) throw Error(s(440));
        return i.impl.apply(void 0, arguments);
      };
    }
  }, Uc = {
    readContext: Ht,
    use: Il,
    useCallback: vp,
    useContext: Ht,
    useEffect: Dc,
    useImperativeHandle: pp,
    useInsertionEffect: dp,
    useLayoutEffect: hp,
    useMemo: gp,
    useReducer: Zl,
    useRef: up,
    useState: function() {
      return Zl(ha);
    },
    useDebugValue: zc,
    useDeferredValue: function(t, n) {
      return yp(ct(), Ge.memoizedState, t, n);
    },
    useTransition: function() {
      var t = Zl(ha)[0], n = ct().memoizedState;
      return [typeof t == "boolean" ? t : yo(t), n];
    },
    useSyncExternalStore: qm,
    useId: Sp,
    useHostTransitionStatus: jc,
    useFormState: op,
    useActionState: op,
    useOptimistic: function(t, n) {
      return Jm(ct(), Ge, t, n);
    },
    useMemoCache: xc,
    useCacheRefresh: Ep
  };
  Uc.useEffectEvent = fp;
  var Op = {
    readContext: Ht,
    use: Il,
    useCallback: vp,
    useContext: Ht,
    useEffect: Dc,
    useImperativeHandle: pp,
    useInsertionEffect: dp,
    useLayoutEffect: hp,
    useMemo: gp,
    useReducer: Mc,
    useRef: up,
    useState: function() {
      return Mc(ha);
    },
    useDebugValue: zc,
    useDeferredValue: function(t, n) {
      var i = ct();
      return Ge === null ? Lc(i, t, n) : yp(i, Ge.memoizedState, t, n);
    },
    useTransition: function() {
      var t = Mc(ha)[0], n = ct().memoizedState;
      return [typeof t == "boolean" ? t : yo(t), n];
    },
    useSyncExternalStore: qm,
    useId: Sp,
    useHostTransitionStatus: jc,
    useFormState: sp,
    useActionState: sp,
    useOptimistic: function(t, n) {
      var i = ct();
      return Ge !== null ? Jm(i, Ge, t, n) : (i.baseState = t, [t, i.queue.dispatch]);
    },
    useMemoCache: xc,
    useCacheRefresh: Ep
  };
  Op.useEffectEvent = fp;
  function kc(t, n, i, o) {
    n = t.memoizedState, i = i(o, n), i = i == null ? n : w({}, n, i), t.memoizedState = i, t.lanes === 0 && (t.updateQueue.baseState = i);
  }
  var Pc = {
    enqueueSetState: function(t, n, i) {
      t = t._reactInternals;
      var o = Rn(), u = Si(o);
      u.payload = n, i != null && (u.callback = i), n = Ei(t, u, o), n !== null && (tn(n, t, o), mo(n, t, o));
    },
    enqueueReplaceState: function(t, n, i) {
      t = t._reactInternals;
      var o = Rn(), u = Si(o);
      u.tag = 1, u.payload = n, i != null && (u.callback = i), n = Ei(t, u, o), n !== null && (tn(n, t, o), mo(n, t, o));
    },
    enqueueForceUpdate: function(t, n) {
      t = t._reactInternals;
      var i = Rn(), o = Si(i);
      o.tag = 2, n != null && (o.callback = n), n = Ei(t, o, i), n !== null && (tn(n, t, i), mo(n, t, i));
    }
  };
  function Mp(t, n, i, o, u, f, v) {
    return t = t.stateNode, typeof t.shouldComponentUpdate == "function" ? t.shouldComponentUpdate(o, f, v) : n.prototype && n.prototype.isPureReactComponent ? !ro(i, o) || !ro(u, f) : !0;
  }
  function Rp(t, n, i, o) {
    t = n.state, typeof n.componentWillReceiveProps == "function" && n.componentWillReceiveProps(i, o), typeof n.UNSAFE_componentWillReceiveProps == "function" && n.UNSAFE_componentWillReceiveProps(i, o), n.state !== t && Pc.enqueueReplaceState(n, n.state, null);
  }
  function Ci(t, n) {
    var i = n;
    if ("ref" in n) {
      i = {};
      for (var o in n) o !== "ref" && (i[o] = n[o]);
    }
    if (t = t.defaultProps) {
      i === n && (i = w({}, i));
      for (var u in t) i[u] === void 0 && (i[u] = t[u]);
    }
    return i;
  }
  function S2(t) {
    El(t);
  }
  function E2(t) {
    console.error(t);
  }
  function T2(t) {
    El(t);
  }
  function Fl(t, n) {
    try {
      var i = t.onUncaughtError;
      i(n.value, { componentStack: n.stack });
    } catch (o) {
      setTimeout(function() {
        throw o;
      });
    }
  }
  function Np(t, n, i) {
    try {
      var o = t.onCaughtError;
      o(i.value, {
        componentStack: i.stack,
        errorBoundary: n.tag === 1 ? n.stateNode : null
      });
    } catch (u) {
      setTimeout(function() {
        throw u;
      });
    }
  }
  function Ic(t, n, i) {
    return i = Si(i), i.tag = 3, i.payload = { element: null }, i.callback = function() {
      Fl(t, n);
    }, i;
  }
  function Dp(t) {
    return t = Si(t), t.tag = 3, t;
  }
  function zp(t, n, i, o) {
    var u = i.type.getDerivedStateFromError;
    if (typeof u == "function") {
      var f = o.value;
      t.payload = function() {
        return u(f);
      }, t.callback = function() {
        Np(n, i, o);
      };
    }
    var v = i.stateNode;
    v !== null && typeof v.componentDidCatch == "function" && (t.callback = function() {
      Np(n, i, o), typeof u != "function" && (Za === null ? Za = /* @__PURE__ */ new Set([this]) : Za.add(this));
      var S = o.stack;
      this.componentDidCatch(o.value, { componentStack: S !== null ? S : "" });
    });
  }
  function C2(t, n, i, o, u) {
    if (i.flags |= 32768, o !== null && typeof o == "object" && typeof o.then == "function") {
      if (n = i.alternate, n !== null && ir(n, i, u, !0), i = cn.current, i !== null) {
        switch (i.tag) {
          case 31:
          case 13:
            return Mn === null ? is() : i.alternate === null && lt === 0 && (lt = 3), i.flags &= -257, i.flags |= 65536, i.lanes = u, o === zl ? i.flags |= 16384 : (n = i.updateQueue, n === null ? i.updateQueue = /* @__PURE__ */ new Set([o]) : n.add(o), hf(t, o, u)), !1;
          case 22:
            return i.flags |= 65536, o === zl ? i.flags |= 16384 : (n = i.updateQueue, n === null ? (n = {
              transitions: null,
              markerInstances: null,
              retryQueue: /* @__PURE__ */ new Set([o])
            }, i.updateQueue = n) : (i = n.retryQueue, i === null ? n.retryQueue = /* @__PURE__ */ new Set([o]) : i.add(o)), hf(t, o, u)), !1;
        }
        throw Error(s(435, i.tag));
      }
      return hf(t, o, u), is(), !1;
    }
    if (ze) return n = cn.current, n !== null ? ((n.flags & 65536) === 0 && (n.flags |= 256), n.flags |= 65536, n.lanes = u, o !== oc && (t = Error(s(422), { cause: o }), so(Cn(t, i)))) : (o !== oc && (n = Error(s(423), { cause: o }), so(Cn(n, i))), t = t.current.alternate, t.flags |= 65536, u &= -u, t.lanes |= u, o = Cn(o, i), u = Ic(t.stateNode, o, u), gc(t, u), lt !== 4 && (lt = 2)), !1;
    var f = Error(s(520), { cause: o });
    if (f = Cn(f, i), Oo === null ? Oo = [f] : Oo.push(f), lt !== 4 && (lt = 2), n === null) return !0;
    o = Cn(o, i), i = n;
    do {
      switch (i.tag) {
        case 3:
          return i.flags |= 65536, t = u & -u, i.lanes |= t, t = Ic(i.stateNode, o, t), gc(i, t), !1;
        case 1:
          if (n = i.type, f = i.stateNode, (i.flags & 128) === 0 && (typeof n.getDerivedStateFromError == "function" || f !== null && typeof f.componentDidCatch == "function" && (Za === null || !Za.has(f)))) return i.flags |= 65536, u &= -u, i.lanes |= u, u = Dp(u), zp(u, t, i, o), gc(i, u), !1;
      }
      i = i.return;
    } while (i !== null);
    return !1;
  }
  var Zc = Error(s(461)), gt = !1;
  function jt(t, n, i, o) {
    n.child = t === null ? Pm(n, null, i, o) : wi(n, t.child, i, o);
  }
  function Lp(t, n, i, o, u) {
    i = i.render;
    var f = n.ref;
    if ("ref" in o) {
      var v = {};
      for (var S in o) S !== "ref" && (v[S] = o[S]);
    } else v = o;
    return gi(n), o = Ec(t, n, i, v, f, u), S = Tc(), t !== null && !gt ? (Cc(t, n, u), ma(t, n, u)) : (ze && S && ic(n), n.flags |= 1, jt(t, n, o, u), n.child);
  }
  function Hp(t, n, i, o, u) {
    if (t === null) {
      var f = i.type;
      return typeof f == "function" && !tc(f) && f.defaultProps === void 0 && i.compare === null ? (n.tag = 15, n.type = f, jp(t, n, f, o, u)) : (t = xl(i.type, null, o, n, n.mode, u), t.ref = n.ref, t.return = n, n.child = t);
    }
    if (f = t.child, !Wc(t, u)) {
      var v = f.memoizedProps;
      if (i = i.compare, i = i !== null ? i : ro, i(v, o) && t.ref === n.ref) return ma(t, n, u);
    }
    return n.flags |= 1, t = sa(f, o), t.ref = n.ref, t.return = n, n.child = t;
  }
  function jp(t, n, i, o, u) {
    if (t !== null) {
      var f = t.memoizedProps;
      if (ro(f, o) && t.ref === n.ref) if (gt = !1, n.pendingProps = o = f, Wc(t, u)) (t.flags & 131072) !== 0 && (gt = !0);
      else return n.lanes = t.lanes, ma(t, n, u);
    }
    return Gc(t, n, i, o, u);
  }
  function Bp(t, n, i, o) {
    var u = o.children, f = t !== null ? t.memoizedState : null;
    if (t === null && n.stateNode === null && (n.stateNode = {
      _visibility: 1,
      _pendingMarkers: null,
      _retryCache: null,
      _transitions: null
    }), o.mode === "hidden") {
      if ((n.flags & 128) !== 0) {
        if (f = f !== null ? f.baseLanes | i : i, t !== null) {
          for (o = n.child = t.child, u = 0; o !== null; ) u = u | o.lanes | o.childLanes, o = o.sibling;
          o = u & ~f;
        } else o = 0, n.child = null;
        return Up(t, n, f, i, o);
      }
      if ((i & 536870912) !== 0) n.memoizedState = {
        baseLanes: 0,
        cachePool: null
      }, t !== null && Nl(n, f !== null ? f.cachePool : null), f !== null ? Gm(n, f) : bc(), Vm(n);
      else return o = n.lanes = 536870912, Up(t, n, f !== null ? f.baseLanes | i : i, i, o);
    } else f !== null ? (Nl(n, f.cachePool), Gm(n, f), Ua(n), n.memoizedState = null) : (t !== null && Nl(n, null), bc(), Ua(n));
    return jt(t, n, u, i), n.child;
  }
  function wo(t, n) {
    return t !== null && t.tag === 22 || n.stateNode !== null || (n.stateNode = {
      _visibility: 1,
      _pendingMarkers: null,
      _retryCache: null,
      _transitions: null
    }), n.sibling;
  }
  function Up(t, n, i, o, u) {
    var f = hc();
    return f = f === null ? null : {
      parent: pt._currentValue,
      pool: f
    }, n.memoizedState = {
      baseLanes: i,
      cachePool: f
    }, t !== null && Nl(n, null), bc(), Vm(n), t !== null && ir(t, n, o, !0), n.childLanes = u, null;
  }
  function ql(t, n) {
    return n = Yl({
      mode: n.mode,
      children: n.children
    }, t.mode), n.ref = t.ref, t.child = n, n.return = t, n;
  }
  function kp(t, n, i) {
    return wi(n, t.child, null, i), t = ql(n, n.pendingProps), t.flags |= 2, fn(n), n.memoizedState = null, t;
  }
  function A2(t, n, i) {
    var o = n.pendingProps, u = (n.flags & 128) !== 0;
    if (n.flags &= -129, t === null) {
      if (ze) {
        if (o.mode === "hidden") return t = ql(n, o), n.lanes = 536870912, wo(null, t);
        if (wc(n), (t = Ke) ? (t = Kv(t, On), t = t !== null && t.data === "&" ? t : null, t !== null && (n.memoizedState = {
          dehydrated: t,
          treeContext: Da !== null ? {
            id: Xn,
            overflow: Yn
          } : null,
          retryLane: 536870912,
          hydrationErrors: null
        }, i = Cm(t), i.return = n, n.child = i, Lt = n, Ke = null)) : t = null, t === null) throw La(n);
        return n.lanes = 536870912, null;
      }
      return ql(n, o);
    }
    var f = t.memoizedState;
    if (f !== null) {
      var v = f.dehydrated;
      if (wc(n), u) if (n.flags & 256) n.flags &= -257, n = kp(t, n, i);
      else if (n.memoizedState !== null) n.child = t.child, n.flags |= 128, n = null;
      else throw Error(s(558));
      else if (gt || ir(t, n, i, !1), u = (i & t.childLanes) !== 0, gt || u) {
        if (o = Xe, o !== null && (v = Nh(o, i), v !== 0 && v !== f.retryLane)) throw f.retryLane = v, hi(t, v), tn(o, t, v), Zc;
        is(), n = kp(t, n, i);
      } else t = f.treeContext, Ke = Nn(v.nextSibling), Lt = n, ze = !0, za = null, On = !1, t !== null && Om(n, t), n = ql(n, o), n.flags |= 4096;
      return n;
    }
    return t = sa(t.child, {
      mode: o.mode,
      children: o.children
    }), t.ref = n.ref, n.child = t, t.return = n, t;
  }
  function Xl(t, n) {
    var i = n.ref;
    if (i === null) t !== null && t.ref !== null && (n.flags |= 4194816);
    else {
      if (typeof i != "function" && typeof i != "object") throw Error(s(284));
      (t === null || t.ref !== i) && (n.flags |= 4194816);
    }
  }
  function Gc(t, n, i, o, u) {
    return gi(n), i = Ec(t, n, i, o, void 0, u), o = Tc(), t !== null && !gt ? (Cc(t, n, u), ma(t, n, u)) : (ze && o && ic(n), n.flags |= 1, jt(t, n, i, u), n.child);
  }
  function Pp(t, n, i, o, u, f) {
    return gi(n), n.updateQueue = null, i = Fm(n, o, i, u), $m(t), o = Tc(), t !== null && !gt ? (Cc(t, n, f), ma(t, n, f)) : (ze && o && ic(n), n.flags |= 1, jt(t, n, i, f), n.child);
  }
  function Ip(t, n, i, o, u) {
    if (gi(n), n.stateNode === null) {
      var f = er, v = i.contextType;
      typeof v == "object" && v !== null && (f = Ht(v)), f = new i(o, f), n.memoizedState = f.state !== null && f.state !== void 0 ? f.state : null, f.updater = Pc, n.stateNode = f, f._reactInternals = n, f = n.stateNode, f.props = o, f.state = n.memoizedState, f.refs = {}, pc(n), v = i.contextType, f.context = typeof v == "object" && v !== null ? Ht(v) : er, f.state = n.memoizedState, v = i.getDerivedStateFromProps, typeof v == "function" && (kc(n, i, v, o), f.state = n.memoizedState), typeof i.getDerivedStateFromProps == "function" || typeof f.getSnapshotBeforeUpdate == "function" || typeof f.UNSAFE_componentWillMount != "function" && typeof f.componentWillMount != "function" || (v = f.state, typeof f.componentWillMount == "function" && f.componentWillMount(), typeof f.UNSAFE_componentWillMount == "function" && f.UNSAFE_componentWillMount(), v !== f.state && Pc.enqueueReplaceState(f, f.state, null), vo(n, o, f, u), po(), f.state = n.memoizedState), typeof f.componentDidMount == "function" && (n.flags |= 4194308), o = !0;
    } else if (t === null) {
      f = n.stateNode;
      var S = n.memoizedProps, R = Ci(i, S);
      f.props = R;
      var I = f.context, X = i.contextType;
      v = er, typeof X == "object" && X !== null && (v = Ht(X));
      var J = i.getDerivedStateFromProps;
      X = typeof J == "function" || typeof f.getSnapshotBeforeUpdate == "function", S = n.pendingProps !== S, X || typeof f.UNSAFE_componentWillReceiveProps != "function" && typeof f.componentWillReceiveProps != "function" || (S || I !== v) && Rp(n, f, o, v), ja = !1;
      var Z = n.memoizedState;
      f.state = Z, vo(n, o, f, u), po(), I = n.memoizedState, S || Z !== I || ja ? (typeof J == "function" && (kc(n, i, J, o), I = n.memoizedState), (R = ja || Mp(n, i, R, o, Z, I, v)) ? (X || typeof f.UNSAFE_componentWillMount != "function" && typeof f.componentWillMount != "function" || (typeof f.componentWillMount == "function" && f.componentWillMount(), typeof f.UNSAFE_componentWillMount == "function" && f.UNSAFE_componentWillMount()), typeof f.componentDidMount == "function" && (n.flags |= 4194308)) : (typeof f.componentDidMount == "function" && (n.flags |= 4194308), n.memoizedProps = o, n.memoizedState = I), f.props = o, f.state = I, f.context = v, o = R) : (typeof f.componentDidMount == "function" && (n.flags |= 4194308), o = !1);
    } else {
      f = n.stateNode, vc(t, n), v = n.memoizedProps, X = Ci(i, v), f.props = X, J = n.pendingProps, Z = f.context, I = i.contextType, R = er, typeof I == "object" && I !== null && (R = Ht(I)), S = i.getDerivedStateFromProps, (I = typeof S == "function" || typeof f.getSnapshotBeforeUpdate == "function") || typeof f.UNSAFE_componentWillReceiveProps != "function" && typeof f.componentWillReceiveProps != "function" || (v !== J || Z !== R) && Rp(n, f, o, R), ja = !1, Z = n.memoizedState, f.state = Z, vo(n, o, f, u), po();
      var G = n.memoizedState;
      v !== J || Z !== G || ja || t !== null && t.dependencies !== null && Ml(t.dependencies) ? (typeof S == "function" && (kc(n, i, S, o), G = n.memoizedState), (X = ja || Mp(n, i, X, o, Z, G, R) || t !== null && t.dependencies !== null && Ml(t.dependencies)) ? (I || typeof f.UNSAFE_componentWillUpdate != "function" && typeof f.componentWillUpdate != "function" || (typeof f.componentWillUpdate == "function" && f.componentWillUpdate(o, G, R), typeof f.UNSAFE_componentWillUpdate == "function" && f.UNSAFE_componentWillUpdate(o, G, R)), typeof f.componentDidUpdate == "function" && (n.flags |= 4), typeof f.getSnapshotBeforeUpdate == "function" && (n.flags |= 1024)) : (typeof f.componentDidUpdate != "function" || v === t.memoizedProps && Z === t.memoizedState || (n.flags |= 4), typeof f.getSnapshotBeforeUpdate != "function" || v === t.memoizedProps && Z === t.memoizedState || (n.flags |= 1024), n.memoizedProps = o, n.memoizedState = G), f.props = o, f.state = G, f.context = R, o = X) : (typeof f.componentDidUpdate != "function" || v === t.memoizedProps && Z === t.memoizedState || (n.flags |= 4), typeof f.getSnapshotBeforeUpdate != "function" || v === t.memoizedProps && Z === t.memoizedState || (n.flags |= 1024), o = !1);
    }
    return f = o, Xl(t, n), o = (n.flags & 128) !== 0, f || o ? (f = n.stateNode, i = o && typeof i.getDerivedStateFromError != "function" ? null : f.render(), n.flags |= 1, t !== null && o ? (n.child = wi(n, t.child, null, u), n.child = wi(n, null, i, u)) : jt(t, n, i, u), n.memoizedState = f.state, t = n.child) : t = ma(t, n, u), t;
  }
  function Zp(t, n, i, o) {
    return pi(), n.flags |= 256, jt(t, n, i, o), n.child;
  }
  var Vc = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0,
    hydrationErrors: null
  };
  function $c(t) {
    return {
      baseLanes: t,
      cachePool: Lm()
    };
  }
  function Fc(t, n, i) {
    return t = t !== null ? t.childLanes & ~i : 0, n && (t |= hn), t;
  }
  function Gp(t, n, i) {
    var o = n.pendingProps, u = !1, f = (n.flags & 128) !== 0, v;
    if ((v = f) || (v = t !== null && t.memoizedState === null ? !1 : (ut.current & 2) !== 0), v && (u = !0, n.flags &= -129), v = (n.flags & 32) !== 0, n.flags &= -33, t === null) {
      if (ze) {
        if (u ? Ba(n) : Ua(n), (t = Ke) ? (t = Kv(t, On), t = t !== null && t.data !== "&" ? t : null, t !== null && (n.memoizedState = {
          dehydrated: t,
          treeContext: Da !== null ? {
            id: Xn,
            overflow: Yn
          } : null,
          retryLane: 536870912,
          hydrationErrors: null
        }, i = Cm(t), i.return = n, n.child = i, Lt = n, Ke = null)) : t = null, t === null) throw La(n);
        return Of(t) ? n.lanes = 32 : n.lanes = 536870912, null;
      }
      var S = o.children;
      return o = o.fallback, u ? (Ua(n), u = n.mode, S = Yl({
        mode: "hidden",
        children: S
      }, u), o = mi(o, u, i, null), S.return = n, o.return = n, S.sibling = o, n.child = S, o = n.child, o.memoizedState = $c(i), o.childLanes = Fc(t, v, i), n.memoizedState = Vc, wo(null, o)) : (Ba(n), qc(n, S));
    }
    var R = t.memoizedState;
    if (R !== null && (S = R.dehydrated, S !== null)) {
      if (f) n.flags & 256 ? (Ba(n), n.flags &= -257, n = Xc(t, n, i)) : n.memoizedState !== null ? (Ua(n), n.child = t.child, n.flags |= 128, n = null) : (Ua(n), S = o.fallback, u = n.mode, o = Yl({
        mode: "visible",
        children: o.children
      }, u), S = mi(S, u, i, null), S.flags |= 2, o.return = n, S.return = n, o.sibling = S, n.child = o, wi(n, t.child, null, i), o = n.child, o.memoizedState = $c(i), o.childLanes = Fc(t, v, i), n.memoizedState = Vc, n = wo(null, o));
      else if (Ba(n), Of(S)) {
        if (v = S.nextSibling && S.nextSibling.dataset, v) var I = v.dgst;
        v = I, o = Error(s(419)), o.stack = "", o.digest = v, so({
          value: o,
          source: null,
          stack: null
        }), n = Xc(t, n, i);
      } else if (gt || ir(t, n, i, !1), v = (i & t.childLanes) !== 0, gt || v) {
        if (v = Xe, v !== null && (o = Nh(v, i), o !== 0 && o !== R.retryLane)) throw R.retryLane = o, hi(t, o), tn(v, t, o), Zc;
        xf(S) || is(), n = Xc(t, n, i);
      } else xf(S) ? (n.flags |= 192, n.child = t.child, n = null) : (t = R.treeContext, Ke = Nn(S.nextSibling), Lt = n, ze = !0, za = null, On = !1, t !== null && Om(n, t), n = qc(n, o.children), n.flags |= 4096);
      return n;
    }
    return u ? (Ua(n), S = o.fallback, u = n.mode, R = t.child, I = R.sibling, o = sa(R, {
      mode: "hidden",
      children: o.children
    }), o.subtreeFlags = R.subtreeFlags & 65011712, I !== null ? S = sa(I, S) : (S = mi(S, u, i, null), S.flags |= 2), S.return = n, o.return = n, o.sibling = S, n.child = o, wo(null, o), o = n.child, S = t.child.memoizedState, S === null ? S = $c(i) : (u = S.cachePool, u !== null ? (R = pt._currentValue, u = u.parent !== R ? {
      parent: R,
      pool: R
    } : u) : u = Lm(), S = {
      baseLanes: S.baseLanes | i,
      cachePool: u
    }), o.memoizedState = S, o.childLanes = Fc(t, v, i), n.memoizedState = Vc, wo(t.child, o)) : (Ba(n), i = t.child, t = i.sibling, i = sa(i, {
      mode: "visible",
      children: o.children
    }), i.return = n, i.sibling = null, t !== null && (v = n.deletions, v === null ? (n.deletions = [t], n.flags |= 16) : v.push(t)), n.child = i, n.memoizedState = null, i);
  }
  function qc(t, n) {
    return n = Yl({
      mode: "visible",
      children: n
    }, t.mode), n.return = t, t.child = n;
  }
  function Yl(t, n) {
    return t = un(22, t, null, n), t.lanes = 0, t;
  }
  function Xc(t, n, i) {
    return wi(n, t.child, null, i), t = qc(n, n.pendingProps.children), t.flags |= 2, n.memoizedState = null, t;
  }
  function Vp(t, n, i) {
    t.lanes |= n;
    var o = t.alternate;
    o !== null && (o.lanes |= n), uc(t.return, n, i);
  }
  function Yc(t, n, i, o, u, f) {
    var v = t.memoizedState;
    v === null ? t.memoizedState = {
      isBackwards: n,
      rendering: null,
      renderingStartTime: 0,
      last: o,
      tail: i,
      tailMode: u,
      treeForkCount: f
    } : (v.isBackwards = n, v.rendering = null, v.renderingStartTime = 0, v.last = o, v.tail = i, v.tailMode = u, v.treeForkCount = f);
  }
  function $p(t, n, i) {
    var o = n.pendingProps, u = o.revealOrder, f = o.tail;
    o = o.children;
    var v = ut.current, S = (v & 2) !== 0;
    if (S ? (v = v & 1 | 2, n.flags |= 128) : v &= 1, re(ut, v), jt(t, n, o, i), o = ze ? lo : 0, !S && t !== null && (t.flags & 128) !== 0) e: for (t = n.child; t !== null; ) {
      if (t.tag === 13) t.memoizedState !== null && Vp(t, i, n);
      else if (t.tag === 19) Vp(t, i, n);
      else if (t.child !== null) {
        t.child.return = t, t = t.child;
        continue;
      }
      if (t === n) break e;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === n) break e;
        t = t.return;
      }
      t.sibling.return = t.return, t = t.sibling;
    }
    switch (u) {
      case "forwards":
        for (i = n.child, u = null; i !== null; ) t = i.alternate, t !== null && Bl(t) === null && (u = i), i = i.sibling;
        i = u, i === null ? (u = n.child, n.child = null) : (u = i.sibling, i.sibling = null), Yc(n, !1, u, i, f, o);
        break;
      case "backwards":
      case "unstable_legacy-backwards":
        for (i = null, u = n.child, n.child = null; u !== null; ) {
          if (t = u.alternate, t !== null && Bl(t) === null) {
            n.child = u;
            break;
          }
          t = u.sibling, u.sibling = i, i = u, u = t;
        }
        Yc(n, !0, i, null, f, o);
        break;
      case "together":
        Yc(n, !1, null, null, void 0, o);
        break;
      default:
        n.memoizedState = null;
    }
    return n.child;
  }
  function ma(t, n, i) {
    if (t !== null && (n.dependencies = t.dependencies), Ia |= n.lanes, (i & n.childLanes) === 0) if (t !== null) {
      if (ir(t, n, i, !1), (i & n.childLanes) === 0) return null;
    } else return null;
    if (t !== null && n.child !== t.child) throw Error(s(153));
    if (n.child !== null) {
      for (t = n.child, i = sa(t, t.pendingProps), n.child = i, i.return = n; t.sibling !== null; ) t = t.sibling, i = i.sibling = sa(t, t.pendingProps), i.return = n;
      i.sibling = null;
    }
    return n.child;
  }
  function Wc(t, n) {
    return (t.lanes & n) !== 0 ? !0 : (t = t.dependencies, !!(t !== null && Ml(t)));
  }
  function x2(t, n, i) {
    switch (n.tag) {
      case 3:
        me(n, n.stateNode.containerInfo), Ha(n, pt, t.memoizedState.cache), pi();
        break;
      case 27:
      case 5:
        Ce(n);
        break;
      case 4:
        me(n, n.stateNode.containerInfo);
        break;
      case 10:
        Ha(n, n.type, n.memoizedProps.value);
        break;
      case 31:
        if (n.memoizedState !== null) return n.flags |= 128, wc(n), null;
        break;
      case 13:
        var o = n.memoizedState;
        if (o !== null)
          return o.dehydrated !== null ? (Ba(n), n.flags |= 128, null) : (i & n.child.childLanes) !== 0 ? Gp(t, n, i) : (Ba(n), t = ma(t, n, i), t !== null ? t.sibling : null);
        Ba(n);
        break;
      case 19:
        var u = (t.flags & 128) !== 0;
        if (o = (i & n.childLanes) !== 0, o || (ir(t, n, i, !1), o = (i & n.childLanes) !== 0), u) {
          if (o) return $p(t, n, i);
          n.flags |= 128;
        }
        if (u = n.memoizedState, u !== null && (u.rendering = null, u.tail = null, u.lastEffect = null), re(ut, ut.current), o) break;
        return null;
      case 22:
        return n.lanes = 0, Bp(t, n, i, n.pendingProps);
      case 24:
        Ha(n, pt, t.memoizedState.cache);
    }
    return ma(t, n, i);
  }
  function Fp(t, n, i) {
    if (t !== null) if (t.memoizedProps !== n.pendingProps) gt = !0;
    else {
      if (!Wc(t, i) && (n.flags & 128) === 0) return gt = !1, x2(t, n, i);
      gt = (t.flags & 131072) !== 0;
    }
    else gt = !1, ze && (n.flags & 1048576) !== 0 && xm(n, lo, n.index);
    switch (n.lanes = 0, n.tag) {
      case 16:
        e: {
          var o = n.pendingProps;
          if (t = bi(n.elementType), n.type = t, typeof t == "function") tc(t) ? (o = Ci(t, o), n.tag = 1, n = Ip(null, n, t, o, i)) : (n.tag = 0, n = Gc(null, n, t, o, i));
          else {
            if (t != null) {
              var u = t.$$typeof;
              if (u === k) {
                n.tag = 11, n = Lp(null, n, t, o, i);
                break e;
              } else if (u === K) {
                n.tag = 14, n = Hp(null, n, t, o, i);
                break e;
              }
            }
            throw n = se(t) || t, Error(s(306, n, ""));
          }
        }
        return n;
      case 0:
        return Gc(t, n, n.type, n.pendingProps, i);
      case 1:
        return o = n.type, u = Ci(o, n.pendingProps), Ip(t, n, o, u, i);
      case 3:
        e: {
          if (me(n, n.stateNode.containerInfo), t === null) throw Error(s(387));
          o = n.pendingProps;
          var f = n.memoizedState;
          u = f.element, vc(t, n), vo(n, o, null, i);
          var v = n.memoizedState;
          if (o = v.cache, Ha(n, pt, o), o !== f.cache && cc(n, [pt], i, !0), po(), o = v.element, f.isDehydrated) if (f = {
            element: o,
            isDehydrated: !1,
            cache: v.cache
          }, n.updateQueue.baseState = f, n.memoizedState = f, n.flags & 256) {
            n = Zp(t, n, o, i);
            break e;
          } else if (o !== u) {
            u = Cn(Error(s(424)), n), so(u), n = Zp(t, n, o, i);
            break e;
          } else
            for (t = n.stateNode.containerInfo, t.nodeType === 9 ? t = t.body : t = t.nodeName === "HTML" ? t.ownerDocument.body : t, Ke = Nn(t.firstChild), Lt = n, ze = !0, za = null, On = !0, i = Pm(n, null, o, i), n.child = i; i; ) i.flags = i.flags & -3 | 4096, i = i.sibling;
          else {
            if (pi(), o === u) {
              n = ma(t, n, i);
              break e;
            }
            jt(t, n, o, i);
          }
          n = n.child;
        }
        return n;
      case 26:
        return Xl(t, n), t === null ? (i = i0(n.type, null, n.pendingProps, null)) ? n.memoizedState = i : ze || (i = n.type, t = n.pendingProps, o = fs(_e.current).createElement(i), o[zt] = n, o[Yt] = t, Bt(o, i, t), Rt(o), n.stateNode = o) : n.memoizedState = i0(n.type, t.memoizedProps, n.pendingProps, t.memoizedState), null;
      case 27:
        return Ce(n), t === null && ze && (o = n.stateNode = t0(n.type, n.pendingProps, _e.current), Lt = n, On = !0, u = Ke, Fa(n.type) ? (Mf = u, Ke = Nn(o.firstChild)) : Ke = u), jt(t, n, n.pendingProps.children, i), Xl(t, n), t === null && (n.flags |= 4194304), n.child;
      case 5:
        return t === null && ze && ((u = o = Ke) && (o = tw(o, n.type, n.pendingProps, On), o !== null ? (n.stateNode = o, Lt = n, Ke = Nn(o.firstChild), On = !1, u = !0) : u = !1), u || La(n)), Ce(n), u = n.type, f = n.pendingProps, v = t !== null ? t.memoizedProps : null, o = f.children, Tf(u, f) ? o = null : v !== null && Tf(u, v) && (n.flags |= 32), n.memoizedState !== null && (u = Ec(t, n, p2, null, null, i), jo._currentValue = u), Xl(t, n), jt(t, n, o, i), n.child;
      case 6:
        return t === null && ze && ((t = i = Ke) && (i = nw(i, n.pendingProps, On), i !== null ? (n.stateNode = i, Lt = n, Ke = null, t = !0) : t = !1), t || La(n)), null;
      case 13:
        return Gp(t, n, i);
      case 4:
        return me(n, n.stateNode.containerInfo), o = n.pendingProps, t === null ? n.child = wi(n, null, o, i) : jt(t, n, o, i), n.child;
      case 11:
        return Lp(t, n, n.type, n.pendingProps, i);
      case 7:
        return jt(t, n, n.pendingProps, i), n.child;
      case 8:
        return jt(t, n, n.pendingProps.children, i), n.child;
      case 12:
        return jt(t, n, n.pendingProps.children, i), n.child;
      case 10:
        return o = n.pendingProps, Ha(n, n.type, o.value), jt(t, n, o.children, i), n.child;
      case 9:
        return u = n.type._context, o = n.pendingProps.children, gi(n), u = Ht(u), o = o(u), n.flags |= 1, jt(t, n, o, i), n.child;
      case 14:
        return Hp(t, n, n.type, n.pendingProps, i);
      case 15:
        return jp(t, n, n.type, n.pendingProps, i);
      case 19:
        return $p(t, n, i);
      case 31:
        return A2(t, n, i);
      case 22:
        return Bp(t, n, i, n.pendingProps);
      case 24:
        return gi(n), o = Ht(pt), t === null ? (u = hc(), u === null && (u = Xe, f = fc(), u.pooledCache = f, f.refCount++, f !== null && (u.pooledCacheLanes |= i), u = f), n.memoizedState = {
          parent: o,
          cache: u
        }, pc(n), Ha(n, pt, u)) : ((t.lanes & i) !== 0 && (vc(t, n), vo(n, null, null, i), po()), u = t.memoizedState, f = n.memoizedState, u.parent !== o ? (u = {
          parent: o,
          cache: o
        }, n.memoizedState = u, n.lanes === 0 && (n.memoizedState = n.updateQueue.baseState = u), Ha(n, pt, o)) : (o = f.cache, Ha(n, pt, o), o !== u.cache && cc(n, [pt], i, !0))), jt(t, n, n.pendingProps.children, i), n.child;
      case 29:
        throw n.pendingProps;
    }
    throw Error(s(156, n.tag));
  }
  function pa(t) {
    t.flags |= 4;
  }
  function Qc(t, n, i, o, u) {
    if ((n = (t.mode & 32) !== 0) && (n = !1), n) {
      if (t.flags |= 16777216, (u & 335544128) === u) if (t.stateNode.complete) t.flags |= 8192;
      else if (bv()) t.flags |= 8192;
      else throw _i = zl, mc;
    } else t.flags &= -16777217;
  }
  function qp(t, n) {
    if (n.type !== "stylesheet" || (n.state.loading & 4) !== 0) t.flags &= -16777217;
    else if (t.flags |= 16777216, !u0(n)) if (bv()) t.flags |= 8192;
    else throw _i = zl, mc;
  }
  function Wl(t, n) {
    n !== null && (t.flags |= 4), t.flags & 16384 && (n = t.tag !== 22 ? fl() : 536870912, t.lanes |= n, vr |= n);
  }
  function So(t, n) {
    if (!ze) switch (t.tailMode) {
      case "hidden":
        n = t.tail;
        for (var i = null; n !== null; ) n.alternate !== null && (i = n), n = n.sibling;
        i === null ? t.tail = null : i.sibling = null;
        break;
      case "collapsed":
        i = t.tail;
        for (var o = null; i !== null; ) i.alternate !== null && (o = i), i = i.sibling;
        o === null ? n || t.tail === null ? t.tail = null : t.tail.sibling = null : o.sibling = null;
    }
  }
  function Je(t) {
    var n = t.alternate !== null && t.alternate.child === t.child, i = 0, o = 0;
    if (n) for (var u = t.child; u !== null; ) i |= u.lanes | u.childLanes, o |= u.subtreeFlags & 65011712, o |= u.flags & 65011712, u.return = t, u = u.sibling;
    else for (u = t.child; u !== null; ) i |= u.lanes | u.childLanes, o |= u.subtreeFlags, o |= u.flags, u.return = t, u = u.sibling;
    return t.subtreeFlags |= o, t.childLanes = i, n;
  }
  function O2(t, n, i) {
    var o = n.pendingProps;
    switch (rc(n), n.tag) {
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return Je(n), null;
      case 1:
        return Je(n), null;
      case 3:
        return i = n.stateNode, o = null, t !== null && (o = t.memoizedState.cache), n.memoizedState.cache !== o && (n.flags |= 2048), fa(pt), Te(), i.pendingContext && (i.context = i.pendingContext, i.pendingContext = null), (t === null || t.child === null) && (ar(n) ? pa(n) : t === null || t.memoizedState.isDehydrated && (n.flags & 256) === 0 || (n.flags |= 1024, lc())), Je(n), null;
      case 26:
        var u = n.type, f = n.memoizedState;
        return t === null ? (pa(n), f !== null ? (Je(n), qp(n, f)) : (Je(n), Qc(n, u, null, o, i))) : f ? f !== t.memoizedState ? (pa(n), Je(n), qp(n, f)) : (Je(n), n.flags &= -16777217) : (t = t.memoizedProps, t !== o && pa(n), Je(n), Qc(n, u, t, o, i)), null;
      case 27:
        if (Oe(n), i = _e.current, u = n.type, t !== null && n.stateNode != null) t.memoizedProps !== o && pa(n);
        else {
          if (!o) {
            if (n.stateNode === null) throw Error(s(166));
            return Je(n), null;
          }
          t = le.current, ar(n) ? Mm(n, t) : (t = t0(u, o, i), n.stateNode = t, pa(n));
        }
        return Je(n), null;
      case 5:
        if (Oe(n), u = n.type, t !== null && n.stateNode != null) t.memoizedProps !== o && pa(n);
        else {
          if (!o) {
            if (n.stateNode === null) throw Error(s(166));
            return Je(n), null;
          }
          if (f = le.current, ar(n)) Mm(n, f);
          else {
            var v = fs(_e.current);
            switch (f) {
              case 1:
                f = v.createElementNS("http://www.w3.org/2000/svg", u);
                break;
              case 2:
                f = v.createElementNS("http://www.w3.org/1998/Math/MathML", u);
                break;
              default:
                switch (u) {
                  case "svg":
                    f = v.createElementNS("http://www.w3.org/2000/svg", u);
                    break;
                  case "math":
                    f = v.createElementNS("http://www.w3.org/1998/Math/MathML", u);
                    break;
                  case "script":
                    f = v.createElement("div"), f.innerHTML = "<script><\/script>", f = f.removeChild(f.firstChild);
                    break;
                  case "select":
                    f = typeof o.is == "string" ? v.createElement("select", { is: o.is }) : v.createElement("select"), o.multiple ? f.multiple = !0 : o.size && (f.size = o.size);
                    break;
                  default:
                    f = typeof o.is == "string" ? v.createElement(u, { is: o.is }) : v.createElement(u);
                }
            }
            f[zt] = n, f[Yt] = o;
            e: for (v = n.child; v !== null; ) {
              if (v.tag === 5 || v.tag === 6) f.appendChild(v.stateNode);
              else if (v.tag !== 4 && v.tag !== 27 && v.child !== null) {
                v.child.return = v, v = v.child;
                continue;
              }
              if (v === n) break e;
              for (; v.sibling === null; ) {
                if (v.return === null || v.return === n) break e;
                v = v.return;
              }
              v.sibling.return = v.return, v = v.sibling;
            }
            n.stateNode = f;
            e: switch (Bt(f, u, o), u) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                o = !!o.autoFocus;
                break e;
              case "img":
                o = !0;
                break e;
              default:
                o = !1;
            }
            o && pa(n);
          }
        }
        return Je(n), Qc(n, n.type, t === null ? null : t.memoizedProps, n.pendingProps, i), null;
      case 6:
        if (t && n.stateNode != null) t.memoizedProps !== o && pa(n);
        else {
          if (typeof o != "string" && n.stateNode === null) throw Error(s(166));
          if (t = _e.current, ar(n)) {
            if (t = n.stateNode, i = n.memoizedProps, o = null, u = Lt, u !== null) switch (u.tag) {
              case 27:
              case 5:
                o = u.memoizedProps;
            }
            t[zt] = n, t = !!(t.nodeValue === i || o !== null && o.suppressHydrationWarning === !0 || Vv(t.nodeValue, i)), t || La(n, !0);
          } else t = fs(t).createTextNode(o), t[zt] = n, n.stateNode = t;
        }
        return Je(n), null;
      case 31:
        if (i = n.memoizedState, t === null || t.memoizedState !== null) {
          if (o = ar(n), i !== null) {
            if (t === null) {
              if (!o) throw Error(s(318));
              if (t = n.memoizedState, t = t !== null ? t.dehydrated : null, !t) throw Error(s(557));
              t[zt] = n;
            } else pi(), (n.flags & 128) === 0 && (n.memoizedState = null), n.flags |= 4;
            Je(n), t = !1;
          } else i = lc(), t !== null && t.memoizedState !== null && (t.memoizedState.hydrationErrors = i), t = !0;
          if (!t)
            return n.flags & 256 ? (fn(n), n) : (fn(n), null);
          if ((n.flags & 128) !== 0) throw Error(s(558));
        }
        return Je(n), null;
      case 13:
        if (o = n.memoizedState, t === null || t.memoizedState !== null && t.memoizedState.dehydrated !== null) {
          if (u = ar(n), o !== null && o.dehydrated !== null) {
            if (t === null) {
              if (!u) throw Error(s(318));
              if (u = n.memoizedState, u = u !== null ? u.dehydrated : null, !u) throw Error(s(317));
              u[zt] = n;
            } else pi(), (n.flags & 128) === 0 && (n.memoizedState = null), n.flags |= 4;
            Je(n), u = !1;
          } else u = lc(), t !== null && t.memoizedState !== null && (t.memoizedState.hydrationErrors = u), u = !0;
          if (!u)
            return n.flags & 256 ? (fn(n), n) : (fn(n), null);
        }
        return fn(n), (n.flags & 128) !== 0 ? (n.lanes = i, n) : (i = o !== null, t = t !== null && t.memoizedState !== null, i && (o = n.child, u = null, o.alternate !== null && o.alternate.memoizedState !== null && o.alternate.memoizedState.cachePool !== null && (u = o.alternate.memoizedState.cachePool.pool), f = null, o.memoizedState !== null && o.memoizedState.cachePool !== null && (f = o.memoizedState.cachePool.pool), f !== u && (o.flags |= 2048)), i !== t && i && (n.child.flags |= 8192), Wl(n, n.updateQueue), Je(n), null);
      case 4:
        return Te(), t === null && Pv(n.stateNode.containerInfo), Je(n), null;
      case 10:
        return fa(n.type), Je(n), null;
      case 19:
        if ($(ut), o = n.memoizedState, o === null) return Je(n), null;
        if (u = (n.flags & 128) !== 0, f = o.rendering, f === null) if (u) So(o, !1);
        else {
          if (lt !== 0 || t !== null && (t.flags & 128) !== 0) for (t = n.child; t !== null; ) {
            if (f = Bl(t), f !== null) {
              for (n.flags |= 128, So(o, !1), t = f.updateQueue, n.updateQueue = t, Wl(n, t), n.subtreeFlags = 0, t = i, i = n.child; i !== null; ) Tm(i, t), i = i.sibling;
              return re(ut, ut.current & 1 | 2), ze && ua(n, o.treeForkCount), n.child;
            }
            t = t.sibling;
          }
          o.tail !== null && xt() > ts && (n.flags |= 128, u = !0, So(o, !1), n.lanes = 4194304);
        }
        else {
          if (!u) if (t = Bl(f), t !== null) {
            if (n.flags |= 128, u = !0, t = t.updateQueue, n.updateQueue = t, Wl(n, t), So(o, !0), o.tail === null && o.tailMode === "hidden" && !f.alternate && !ze) return Je(n), null;
          } else 2 * xt() - o.renderingStartTime > ts && i !== 536870912 && (n.flags |= 128, u = !0, So(o, !1), n.lanes = 4194304);
          o.isBackwards ? (f.sibling = n.child, n.child = f) : (t = o.last, t !== null ? t.sibling = f : n.child = f, o.last = f);
        }
        return o.tail !== null ? (t = o.tail, o.rendering = t, o.tail = t.sibling, o.renderingStartTime = xt(), t.sibling = null, i = ut.current, re(ut, u ? i & 1 | 2 : i & 1), ze && ua(n, o.treeForkCount), t) : (Je(n), null);
      case 22:
      case 23:
        return fn(n), _c(), o = n.memoizedState !== null, t !== null ? t.memoizedState !== null !== o && (n.flags |= 8192) : o && (n.flags |= 8192), o ? (i & 536870912) !== 0 && (n.flags & 128) === 0 && (Je(n), n.subtreeFlags & 6 && (n.flags |= 8192)) : Je(n), i = n.updateQueue, i !== null && Wl(n, i.retryQueue), i = null, t !== null && t.memoizedState !== null && t.memoizedState.cachePool !== null && (i = t.memoizedState.cachePool.pool), o = null, n.memoizedState !== null && n.memoizedState.cachePool !== null && (o = n.memoizedState.cachePool.pool), o !== i && (n.flags |= 2048), t !== null && $(yi), null;
      case 24:
        return i = null, t !== null && (i = t.memoizedState.cache), n.memoizedState.cache !== i && (n.flags |= 2048), fa(pt), Je(n), null;
      case 25:
        return null;
      case 30:
        return null;
    }
    throw Error(s(156, n.tag));
  }
  function M2(t, n) {
    switch (rc(n), n.tag) {
      case 1:
        return t = n.flags, t & 65536 ? (n.flags = t & -65537 | 128, n) : null;
      case 3:
        return fa(pt), Te(), t = n.flags, (t & 65536) !== 0 && (t & 128) === 0 ? (n.flags = t & -65537 | 128, n) : null;
      case 26:
      case 27:
      case 5:
        return Oe(n), null;
      case 31:
        if (n.memoizedState !== null) {
          if (fn(n), n.alternate === null) throw Error(s(340));
          pi();
        }
        return t = n.flags, t & 65536 ? (n.flags = t & -65537 | 128, n) : null;
      case 13:
        if (fn(n), t = n.memoizedState, t !== null && t.dehydrated !== null) {
          if (n.alternate === null) throw Error(s(340));
          pi();
        }
        return t = n.flags, t & 65536 ? (n.flags = t & -65537 | 128, n) : null;
      case 19:
        return $(ut), null;
      case 4:
        return Te(), null;
      case 10:
        return fa(n.type), null;
      case 22:
      case 23:
        return fn(n), _c(), t !== null && $(yi), t = n.flags, t & 65536 ? (n.flags = t & -65537 | 128, n) : null;
      case 24:
        return fa(pt), null;
      case 25:
        return null;
      default:
        return null;
    }
  }
  function Xp(t, n) {
    switch (rc(n), n.tag) {
      case 3:
        fa(pt), Te();
        break;
      case 26:
      case 27:
      case 5:
        Oe(n);
        break;
      case 4:
        Te();
        break;
      case 31:
        n.memoizedState !== null && fn(n);
        break;
      case 13:
        fn(n);
        break;
      case 19:
        $(ut);
        break;
      case 10:
        fa(n.type);
        break;
      case 22:
      case 23:
        fn(n), _c(), t !== null && $(yi);
        break;
      case 24:
        fa(pt);
    }
  }
  function Eo(t, n) {
    try {
      var i = n.updateQueue, o = i !== null ? i.lastEffect : null;
      if (o !== null) {
        var u = o.next;
        i = u;
        do {
          if ((i.tag & t) === t) {
            o = void 0;
            var f = i.create, v = i.inst;
            o = f(), v.destroy = o;
          }
          i = i.next;
        } while (i !== u);
      }
    } catch (S) {
      Ze(n, n.return, S);
    }
  }
  function ka(t, n, i) {
    try {
      var o = n.updateQueue, u = o !== null ? o.lastEffect : null;
      if (u !== null) {
        var f = u.next;
        o = f;
        do {
          if ((o.tag & t) === t) {
            var v = o.inst, S = v.destroy;
            if (S !== void 0) {
              v.destroy = void 0, u = n;
              var R = i, I = S;
              try {
                I();
              } catch (X) {
                Ze(u, R, X);
              }
            }
          }
          o = o.next;
        } while (o !== f);
      }
    } catch (X) {
      Ze(n, n.return, X);
    }
  }
  function Yp(t) {
    var n = t.updateQueue;
    if (n !== null) {
      var i = t.stateNode;
      try {
        Zm(n, i);
      } catch (o) {
        Ze(t, t.return, o);
      }
    }
  }
  function Wp(t, n, i) {
    i.props = Ci(t.type, t.memoizedProps), i.state = t.memoizedState;
    try {
      i.componentWillUnmount();
    } catch (o) {
      Ze(t, n, o);
    }
  }
  function To(t, n) {
    try {
      var i = t.ref;
      if (i !== null) {
        switch (t.tag) {
          case 26:
          case 27:
          case 5:
            var o = t.stateNode;
            break;
          case 30:
            o = t.stateNode;
            break;
          default:
            o = t.stateNode;
        }
        typeof i == "function" ? t.refCleanup = i(o) : i.current = o;
      }
    } catch (u) {
      Ze(t, n, u);
    }
  }
  function Wn(t, n) {
    var i = t.ref, o = t.refCleanup;
    if (i !== null) if (typeof o == "function") try {
      o();
    } catch (u) {
      Ze(t, n, u);
    } finally {
      t.refCleanup = null, t = t.alternate, t != null && (t.refCleanup = null);
    }
    else if (typeof i == "function") try {
      i(null);
    } catch (u) {
      Ze(t, n, u);
    }
    else i.current = null;
  }
  function Qp(t) {
    var n = t.type, i = t.memoizedProps, o = t.stateNode;
    try {
      e: switch (n) {
        case "button":
        case "input":
        case "select":
        case "textarea":
          i.autoFocus && o.focus();
          break e;
        case "img":
          i.src ? o.src = i.src : i.srcSet && (o.srcset = i.srcSet);
      }
    } catch (u) {
      Ze(t, t.return, u);
    }
  }
  function Kc(t, n, i) {
    try {
      var o = t.stateNode;
      Y2(o, t.type, i, n), o[Yt] = n;
    } catch (u) {
      Ze(t, t.return, u);
    }
  }
  function Kp(t) {
    return t.tag === 5 || t.tag === 3 || t.tag === 26 || t.tag === 27 && Fa(t.type) || t.tag === 4;
  }
  function Jc(t) {
    e: for (; ; ) {
      for (; t.sibling === null; ) {
        if (t.return === null || Kp(t.return)) return null;
        t = t.return;
      }
      for (t.sibling.return = t.return, t = t.sibling; t.tag !== 5 && t.tag !== 6 && t.tag !== 18; ) {
        if (t.tag === 27 && Fa(t.type) || t.flags & 2 || t.child === null || t.tag === 4) continue e;
        t.child.return = t, t = t.child;
      }
      if (!(t.flags & 2)) return t.stateNode;
    }
  }
  function ef(t, n, i) {
    var o = t.tag;
    if (o === 5 || o === 6) t = t.stateNode, n ? (i.nodeType === 9 ? i.body : i.nodeName === "HTML" ? i.ownerDocument.body : i).insertBefore(t, n) : (n = i.nodeType === 9 ? i.body : i.nodeName === "HTML" ? i.ownerDocument.body : i, n.appendChild(t), i = i._reactRootContainer, i != null || n.onclick !== null || (n.onclick = oa));
    else if (o !== 4 && (o === 27 && Fa(t.type) && (i = t.stateNode, n = null), t = t.child, t !== null)) for (ef(t, n, i), t = t.sibling; t !== null; ) ef(t, n, i), t = t.sibling;
  }
  function Ql(t, n, i) {
    var o = t.tag;
    if (o === 5 || o === 6) t = t.stateNode, n ? i.insertBefore(t, n) : i.appendChild(t);
    else if (o !== 4 && (o === 27 && Fa(t.type) && (i = t.stateNode), t = t.child, t !== null)) for (Ql(t, n, i), t = t.sibling; t !== null; ) Ql(t, n, i), t = t.sibling;
  }
  function Jp(t) {
    var n = t.stateNode, i = t.memoizedProps;
    try {
      for (var o = t.type, u = n.attributes; u.length; ) n.removeAttributeNode(u[0]);
      Bt(n, o, i), n[zt] = t, n[Yt] = i;
    } catch (f) {
      Ze(t, t.return, f);
    }
  }
  var va = !1, yt = !1, tf = !1, ev = typeof WeakSet == "function" ? WeakSet : Set, Nt = null;
  function R2(t, n) {
    if (t = t.containerInfo, Sf = ys, t = pm(t), Xu(t)) {
      if ("selectionStart" in t) var i = {
        start: t.selectionStart,
        end: t.selectionEnd
      };
      else e: {
        i = (i = t.ownerDocument) && i.defaultView || window;
        var o = i.getSelection && i.getSelection();
        if (o && o.rangeCount !== 0) {
          i = o.anchorNode;
          var u = o.anchorOffset, f = o.focusNode;
          o = o.focusOffset;
          try {
            i.nodeType, f.nodeType;
          } catch {
            i = null;
            break e;
          }
          var v = 0, S = -1, R = -1, I = 0, X = 0, J = t, Z = null;
          t: for (; ; ) {
            for (var G; J !== i || u !== 0 && J.nodeType !== 3 || (S = v + u), J !== f || o !== 0 && J.nodeType !== 3 || (R = v + o), J.nodeType === 3 && (v += J.nodeValue.length), (G = J.firstChild) !== null; )
              Z = J, J = G;
            for (; ; ) {
              if (J === t) break t;
              if (Z === i && ++I === u && (S = v), Z === f && ++X === o && (R = v), (G = J.nextSibling) !== null) break;
              J = Z, Z = J.parentNode;
            }
            J = G;
          }
          i = S === -1 || R === -1 ? null : {
            start: S,
            end: R
          };
        } else i = null;
      }
      i = i || {
        start: 0,
        end: 0
      };
    } else i = null;
    for (Ef = {
      focusedElem: t,
      selectionRange: i
    }, ys = !1, Nt = n; Nt !== null; ) if (n = Nt, t = n.child, (n.subtreeFlags & 1028) !== 0 && t !== null) t.return = n, Nt = t;
    else for (; Nt !== null; ) {
      switch (n = Nt, f = n.alternate, t = n.flags, n.tag) {
        case 0:
          if ((t & 4) !== 0 && (t = n.updateQueue, t = t !== null ? t.events : null, t !== null)) for (i = 0; i < t.length; i++) u = t[i], u.ref.impl = u.nextImpl;
          break;
        case 11:
        case 15:
          break;
        case 1:
          if ((t & 1024) !== 0 && f !== null) {
            t = void 0, i = n, u = f.memoizedProps, f = f.memoizedState, o = i.stateNode;
            try {
              var he = Ci(i.type, u);
              t = o.getSnapshotBeforeUpdate(he, f), o.__reactInternalSnapshotBeforeUpdate = t;
            } catch (we) {
              Ze(i, i.return, we);
            }
          }
          break;
        case 3:
          if ((t & 1024) !== 0) {
            if (t = n.stateNode.containerInfo, i = t.nodeType, i === 9) Af(t);
            else if (i === 1) switch (t.nodeName) {
              case "HEAD":
              case "HTML":
              case "BODY":
                Af(t);
                break;
              default:
                t.textContent = "";
            }
          }
          break;
        case 5:
        case 26:
        case 27:
        case 6:
        case 4:
        case 17:
          break;
        default:
          if ((t & 1024) !== 0) throw Error(s(163));
      }
      if (t = n.sibling, t !== null) {
        t.return = n.return, Nt = t;
        break;
      }
      Nt = n.return;
    }
  }
  function tv(t, n, i) {
    var o = i.flags;
    switch (i.tag) {
      case 0:
      case 11:
      case 15:
        ya(t, i), o & 4 && Eo(5, i);
        break;
      case 1:
        if (ya(t, i), o & 4) if (t = i.stateNode, n === null) try {
          t.componentDidMount();
        } catch (v) {
          Ze(i, i.return, v);
        }
        else {
          var u = Ci(i.type, n.memoizedProps);
          n = n.memoizedState;
          try {
            t.componentDidUpdate(u, n, t.__reactInternalSnapshotBeforeUpdate);
          } catch (v) {
            Ze(i, i.return, v);
          }
        }
        o & 64 && Yp(i), o & 512 && To(i, i.return);
        break;
      case 3:
        if (ya(t, i), o & 64 && (t = i.updateQueue, t !== null)) {
          if (n = null, i.child !== null) switch (i.child.tag) {
            case 27:
            case 5:
              n = i.child.stateNode;
              break;
            case 1:
              n = i.child.stateNode;
          }
          try {
            Zm(t, n);
          } catch (v) {
            Ze(i, i.return, v);
          }
        }
        break;
      case 27:
        n === null && o & 4 && Jp(i);
      case 26:
      case 5:
        ya(t, i), n === null && o & 4 && Qp(i), o & 512 && To(i, i.return);
        break;
      case 12:
        ya(t, i);
        break;
      case 31:
        ya(t, i), o & 4 && iv(t, i);
        break;
      case 13:
        ya(t, i), o & 4 && rv(t, i), o & 64 && (t = i.memoizedState, t !== null && (t = t.dehydrated, t !== null && (i = k2.bind(null, i), aw(t, i))));
        break;
      case 22:
        if (o = i.memoizedState !== null || va, !o) {
          n = n !== null && n.memoizedState !== null || yt, u = va;
          var f = yt;
          va = o, (yt = n) && !f ? ba(t, i, (i.subtreeFlags & 8772) !== 0) : ya(t, i), va = u, yt = f;
        }
        break;
      case 30:
        break;
      default:
        ya(t, i);
    }
  }
  function nv(t) {
    var n = t.alternate;
    n !== null && (t.alternate = null, nv(n)), t.child = null, t.deletions = null, t.sibling = null, t.tag === 5 && (n = t.stateNode, n !== null && Nu(n)), t.stateNode = null, t.return = null, t.dependencies = null, t.memoizedProps = null, t.memoizedState = null, t.pendingProps = null, t.stateNode = null, t.updateQueue = null;
  }
  var tt = null, Qt = !1;
  function ga(t, n, i) {
    for (i = i.child; i !== null; ) av(t, n, i), i = i.sibling;
  }
  function av(t, n, i) {
    if (Zt && typeof Zt.onCommitFiberUnmount == "function") try {
      Zt.onCommitFiberUnmount(si, i);
    } catch {
    }
    switch (i.tag) {
      case 26:
        yt || Wn(i, n), ga(t, n, i), i.memoizedState ? i.memoizedState.count-- : i.stateNode && (i = i.stateNode, i.parentNode.removeChild(i));
        break;
      case 27:
        yt || Wn(i, n);
        var o = tt, u = Qt;
        Fa(i.type) && (tt = i.stateNode, Qt = !1), ga(t, n, i), zo(i.stateNode), tt = o, Qt = u;
        break;
      case 5:
        yt || Wn(i, n);
      case 6:
        if (o = tt, u = Qt, tt = null, ga(t, n, i), tt = o, Qt = u, tt !== null) if (Qt) try {
          (tt.nodeType === 9 ? tt.body : tt.nodeName === "HTML" ? tt.ownerDocument.body : tt).removeChild(i.stateNode);
        } catch (f) {
          Ze(i, n, f);
        }
        else try {
          tt.removeChild(i.stateNode);
        } catch (f) {
          Ze(i, n, f);
        }
        break;
      case 18:
        tt !== null && (Qt ? (t = tt, Wv(t.nodeType === 9 ? t.body : t.nodeName === "HTML" ? t.ownerDocument.body : t, i.stateNode), Tr(t)) : Wv(tt, i.stateNode));
        break;
      case 4:
        o = tt, u = Qt, tt = i.stateNode.containerInfo, Qt = !0, ga(t, n, i), tt = o, Qt = u;
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        ka(2, i, n), yt || ka(4, i, n), ga(t, n, i);
        break;
      case 1:
        yt || (Wn(i, n), o = i.stateNode, typeof o.componentWillUnmount == "function" && Wp(i, n, o)), ga(t, n, i);
        break;
      case 21:
        ga(t, n, i);
        break;
      case 22:
        yt = (o = yt) || i.memoizedState !== null, ga(t, n, i), yt = o;
        break;
      default:
        ga(t, n, i);
    }
  }
  function iv(t, n) {
    if (n.memoizedState === null && (t = n.alternate, t !== null && (t = t.memoizedState, t !== null))) {
      t = t.dehydrated;
      try {
        Tr(t);
      } catch (i) {
        Ze(n, n.return, i);
      }
    }
  }
  function rv(t, n) {
    if (n.memoizedState === null && (t = n.alternate, t !== null && (t = t.memoizedState, t !== null && (t = t.dehydrated, t !== null)))) try {
      Tr(t);
    } catch (i) {
      Ze(n, n.return, i);
    }
  }
  function N2(t) {
    switch (t.tag) {
      case 31:
      case 13:
      case 19:
        var n = t.stateNode;
        return n === null && (n = t.stateNode = new ev()), n;
      case 22:
        return t = t.stateNode, n = t._retryCache, n === null && (n = t._retryCache = new ev()), n;
      default:
        throw Error(s(435, t.tag));
    }
  }
  function Kl(t, n) {
    var i = N2(t);
    n.forEach(function(o) {
      if (!i.has(o)) {
        i.add(o);
        var u = P2.bind(null, t, o);
        o.then(u, u);
      }
    });
  }
  function Kt(t, n) {
    var i = n.deletions;
    if (i !== null) for (var o = 0; o < i.length; o++) {
      var u = i[o], f = t, v = n, S = v;
      e: for (; S !== null; ) {
        switch (S.tag) {
          case 27:
            if (Fa(S.type)) {
              tt = S.stateNode, Qt = !1;
              break e;
            }
            break;
          case 5:
            tt = S.stateNode, Qt = !1;
            break e;
          case 3:
          case 4:
            tt = S.stateNode.containerInfo, Qt = !0;
            break e;
        }
        S = S.return;
      }
      if (tt === null) throw Error(s(160));
      av(f, v, u), tt = null, Qt = !1, f = u.alternate, f !== null && (f.return = null), u.return = null;
    }
    if (n.subtreeFlags & 13886) for (n = n.child; n !== null; ) ov(n, t), n = n.sibling;
  }
  var Pn = null;
  function ov(t, n) {
    var i = t.alternate, o = t.flags;
    switch (t.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        Kt(n, t), Jt(t), o & 4 && (ka(3, t, t.return), Eo(3, t), ka(5, t, t.return));
        break;
      case 1:
        Kt(n, t), Jt(t), o & 512 && (yt || i === null || Wn(i, i.return)), o & 64 && va && (t = t.updateQueue, t !== null && (o = t.callbacks, o !== null && (i = t.shared.hiddenCallbacks, t.shared.hiddenCallbacks = i === null ? o : i.concat(o))));
        break;
      case 26:
        var u = Pn;
        if (Kt(n, t), Jt(t), o & 512 && (yt || i === null || Wn(i, i.return)), o & 4) {
          var f = i !== null ? i.memoizedState : null;
          if (o = t.memoizedState, i === null) if (o === null) if (t.stateNode === null) {
            e: {
              o = t.type, i = t.memoizedProps, u = u.ownerDocument || u;
              t: switch (o) {
                case "title":
                  f = u.getElementsByTagName("title")[0], (!f || f[Wr] || f[zt] || f.namespaceURI === "http://www.w3.org/2000/svg" || f.hasAttribute("itemprop")) && (f = u.createElement(o), u.head.insertBefore(f, u.querySelector("head > title"))), Bt(f, o, i), f[zt] = t, Rt(f), o = f;
                  break e;
                case "link":
                  var v = l0("link", "href", u).get(o + (i.href || ""));
                  if (v) {
                    for (var S = 0; S < v.length; S++) if (f = v[S], f.getAttribute("href") === (i.href == null || i.href === "" ? null : i.href) && f.getAttribute("rel") === (i.rel == null ? null : i.rel) && f.getAttribute("title") === (i.title == null ? null : i.title) && f.getAttribute("crossorigin") === (i.crossOrigin == null ? null : i.crossOrigin)) {
                      v.splice(S, 1);
                      break t;
                    }
                  }
                  f = u.createElement(o), Bt(f, o, i), u.head.appendChild(f);
                  break;
                case "meta":
                  if (v = l0("meta", "content", u).get(o + (i.content || ""))) {
                    for (S = 0; S < v.length; S++) if (f = v[S], f.getAttribute("content") === (i.content == null ? null : "" + i.content) && f.getAttribute("name") === (i.name == null ? null : i.name) && f.getAttribute("property") === (i.property == null ? null : i.property) && f.getAttribute("http-equiv") === (i.httpEquiv == null ? null : i.httpEquiv) && f.getAttribute("charset") === (i.charSet == null ? null : i.charSet)) {
                      v.splice(S, 1);
                      break t;
                    }
                  }
                  f = u.createElement(o), Bt(f, o, i), u.head.appendChild(f);
                  break;
                default:
                  throw Error(s(468, o));
              }
              f[zt] = t, Rt(f), o = f;
            }
            t.stateNode = o;
          } else s0(u, t.type, t.stateNode);
          else t.stateNode = o0(u, o, t.memoizedProps);
          else f !== o ? (f === null ? i.stateNode !== null && (i = i.stateNode, i.parentNode.removeChild(i)) : f.count--, o === null ? s0(u, t.type, t.stateNode) : o0(u, o, t.memoizedProps)) : o === null && t.stateNode !== null && Kc(t, t.memoizedProps, i.memoizedProps);
        }
        break;
      case 27:
        Kt(n, t), Jt(t), o & 512 && (yt || i === null || Wn(i, i.return)), i !== null && o & 4 && Kc(t, t.memoizedProps, i.memoizedProps);
        break;
      case 5:
        if (Kt(n, t), Jt(t), o & 512 && (yt || i === null || Wn(i, i.return)), t.flags & 32) {
          u = t.stateNode;
          try {
            qi(u, "");
          } catch (he) {
            Ze(t, t.return, he);
          }
        }
        o & 4 && t.stateNode != null && (u = t.memoizedProps, Kc(t, u, i !== null ? i.memoizedProps : u)), o & 1024 && (tf = !0);
        break;
      case 6:
        if (Kt(n, t), Jt(t), o & 4) {
          if (t.stateNode === null) throw Error(s(162));
          o = t.memoizedProps, i = t.stateNode;
          try {
            i.nodeValue = o;
          } catch (he) {
            Ze(t, t.return, he);
          }
        }
        break;
      case 3:
        if (ms = null, u = Pn, Pn = ds(n.containerInfo), Kt(n, t), Pn = u, Jt(t), o & 4 && i !== null && i.memoizedState.isDehydrated) try {
          Tr(n.containerInfo);
        } catch (he) {
          Ze(t, t.return, he);
        }
        tf && (tf = !1, lv(t));
        break;
      case 4:
        o = Pn, Pn = ds(t.stateNode.containerInfo), Kt(n, t), Jt(t), Pn = o;
        break;
      case 12:
        Kt(n, t), Jt(t);
        break;
      case 31:
        Kt(n, t), Jt(t), o & 4 && (o = t.updateQueue, o !== null && (t.updateQueue = null, Kl(t, o)));
        break;
      case 13:
        Kt(n, t), Jt(t), t.child.flags & 8192 && t.memoizedState !== null != (i !== null && i.memoizedState !== null) && (es = xt()), o & 4 && (o = t.updateQueue, o !== null && (t.updateQueue = null, Kl(t, o)));
        break;
      case 22:
        u = t.memoizedState !== null;
        var R = i !== null && i.memoizedState !== null, I = va, X = yt;
        if (va = I || u, yt = X || R, Kt(n, t), yt = X, va = I, Jt(t), o & 8192) e: for (n = t.stateNode, n._visibility = u ? n._visibility & -2 : n._visibility | 1, u && (i === null || R || va || yt || Ai(t)), i = null, n = t; ; ) {
          if (n.tag === 5 || n.tag === 26) {
            if (i === null) {
              R = i = n;
              try {
                if (f = R.stateNode, u) v = f.style, typeof v.setProperty == "function" ? v.setProperty("display", "none", "important") : v.display = "none";
                else {
                  S = R.stateNode;
                  var J = R.memoizedProps.style, Z = J != null && J.hasOwnProperty("display") ? J.display : null;
                  S.style.display = Z == null || typeof Z == "boolean" ? "" : ("" + Z).trim();
                }
              } catch (he) {
                Ze(R, R.return, he);
              }
            }
          } else if (n.tag === 6) {
            if (i === null) {
              R = n;
              try {
                R.stateNode.nodeValue = u ? "" : R.memoizedProps;
              } catch (he) {
                Ze(R, R.return, he);
              }
            }
          } else if (n.tag === 18) {
            if (i === null) {
              R = n;
              try {
                var G = R.stateNode;
                u ? Qv(G, !0) : Qv(R.stateNode, !1);
              } catch (he) {
                Ze(R, R.return, he);
              }
            }
          } else if ((n.tag !== 22 && n.tag !== 23 || n.memoizedState === null || n === t) && n.child !== null) {
            n.child.return = n, n = n.child;
            continue;
          }
          if (n === t) break e;
          for (; n.sibling === null; ) {
            if (n.return === null || n.return === t) break e;
            i === n && (i = null), n = n.return;
          }
          i === n && (i = null), n.sibling.return = n.return, n = n.sibling;
        }
        o & 4 && (o = t.updateQueue, o !== null && (i = o.retryQueue, i !== null && (o.retryQueue = null, Kl(t, i))));
        break;
      case 19:
        Kt(n, t), Jt(t), o & 4 && (o = t.updateQueue, o !== null && (t.updateQueue = null, Kl(t, o)));
        break;
      case 30:
        break;
      case 21:
        break;
      default:
        Kt(n, t), Jt(t);
    }
  }
  function Jt(t) {
    var n = t.flags;
    if (n & 2) {
      try {
        for (var i, o = t.return; o !== null; ) {
          if (Kp(o)) {
            i = o;
            break;
          }
          o = o.return;
        }
        if (i == null) throw Error(s(160));
        switch (i.tag) {
          case 27:
            var u = i.stateNode;
            Ql(t, Jc(t), u);
            break;
          case 5:
            var f = i.stateNode;
            i.flags & 32 && (qi(f, ""), i.flags &= -33), Ql(t, Jc(t), f);
            break;
          case 3:
          case 4:
            var v = i.stateNode.containerInfo;
            ef(t, Jc(t), v);
            break;
          default:
            throw Error(s(161));
        }
      } catch (S) {
        Ze(t, t.return, S);
      }
      t.flags &= -3;
    }
    n & 4096 && (t.flags &= -4097);
  }
  function lv(t) {
    if (t.subtreeFlags & 1024) for (t = t.child; t !== null; ) {
      var n = t;
      lv(n), n.tag === 5 && n.flags & 1024 && n.stateNode.reset(), t = t.sibling;
    }
  }
  function ya(t, n) {
    if (n.subtreeFlags & 8772) for (n = n.child; n !== null; ) tv(t, n.alternate, n), n = n.sibling;
  }
  function Ai(t) {
    for (t = t.child; t !== null; ) {
      var n = t;
      switch (n.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          ka(4, n, n.return), Ai(n);
          break;
        case 1:
          Wn(n, n.return);
          var i = n.stateNode;
          typeof i.componentWillUnmount == "function" && Wp(n, n.return, i), Ai(n);
          break;
        case 27:
          zo(n.stateNode);
        case 26:
        case 5:
          Wn(n, n.return), Ai(n);
          break;
        case 22:
          n.memoizedState === null && Ai(n);
          break;
        case 30:
          Ai(n);
          break;
        default:
          Ai(n);
      }
      t = t.sibling;
    }
  }
  function ba(t, n, i) {
    for (i = i && (n.subtreeFlags & 8772) !== 0, n = n.child; n !== null; ) {
      var o = n.alternate, u = t, f = n, v = f.flags;
      switch (f.tag) {
        case 0:
        case 11:
        case 15:
          ba(u, f, i), Eo(4, f);
          break;
        case 1:
          if (ba(u, f, i), o = f, u = o.stateNode, typeof u.componentDidMount == "function") try {
            u.componentDidMount();
          } catch (I) {
            Ze(o, o.return, I);
          }
          if (o = f, u = o.updateQueue, u !== null) {
            var S = o.stateNode;
            try {
              var R = u.shared.hiddenCallbacks;
              if (R !== null) for (u.shared.hiddenCallbacks = null, u = 0; u < R.length; u++) Im(R[u], S);
            } catch (I) {
              Ze(o, o.return, I);
            }
          }
          i && v & 64 && Yp(f), To(f, f.return);
          break;
        case 27:
          Jp(f);
        case 26:
        case 5:
          ba(u, f, i), i && o === null && v & 4 && Qp(f), To(f, f.return);
          break;
        case 12:
          ba(u, f, i);
          break;
        case 31:
          ba(u, f, i), i && v & 4 && iv(u, f);
          break;
        case 13:
          ba(u, f, i), i && v & 4 && rv(u, f);
          break;
        case 22:
          f.memoizedState === null && ba(u, f, i), To(f, f.return);
          break;
        case 30:
          break;
        default:
          ba(u, f, i);
      }
      n = n.sibling;
    }
  }
  function nf(t, n) {
    var i = null;
    t !== null && t.memoizedState !== null && t.memoizedState.cachePool !== null && (i = t.memoizedState.cachePool.pool), t = null, n.memoizedState !== null && n.memoizedState.cachePool !== null && (t = n.memoizedState.cachePool.pool), t !== i && (t != null && t.refCount++, i != null && uo(i));
  }
  function af(t, n) {
    t = null, n.alternate !== null && (t = n.alternate.memoizedState.cache), n = n.memoizedState.cache, n !== t && (n.refCount++, t != null && uo(t));
  }
  function In(t, n, i, o) {
    if (n.subtreeFlags & 10256) for (n = n.child; n !== null; ) sv(t, n, i, o), n = n.sibling;
  }
  function sv(t, n, i, o) {
    var u = n.flags;
    switch (n.tag) {
      case 0:
      case 11:
      case 15:
        In(t, n, i, o), u & 2048 && Eo(9, n);
        break;
      case 1:
        In(t, n, i, o);
        break;
      case 3:
        In(t, n, i, o), u & 2048 && (t = null, n.alternate !== null && (t = n.alternate.memoizedState.cache), n = n.memoizedState.cache, n !== t && (n.refCount++, t != null && uo(t)));
        break;
      case 12:
        if (u & 2048) {
          In(t, n, i, o), t = n.stateNode;
          try {
            var f = n.memoizedProps, v = f.id, S = f.onPostCommit;
            typeof S == "function" && S(v, n.alternate === null ? "mount" : "update", t.passiveEffectDuration, -0);
          } catch (R) {
            Ze(n, n.return, R);
          }
        } else In(t, n, i, o);
        break;
      case 31:
        In(t, n, i, o);
        break;
      case 13:
        In(t, n, i, o);
        break;
      case 23:
        break;
      case 22:
        f = n.stateNode, v = n.alternate, n.memoizedState !== null ? f._visibility & 2 ? In(t, n, i, o) : Co(t, n) : f._visibility & 2 ? In(t, n, i, o) : (f._visibility |= 2, hr(t, n, i, o, (n.subtreeFlags & 10256) !== 0 || !1)), u & 2048 && nf(v, n);
        break;
      case 24:
        In(t, n, i, o), u & 2048 && af(n.alternate, n);
        break;
      default:
        In(t, n, i, o);
    }
  }
  function hr(t, n, i, o, u) {
    for (u = u && ((n.subtreeFlags & 10256) !== 0 || !1), n = n.child; n !== null; ) {
      var f = t, v = n, S = i, R = o, I = v.flags;
      switch (v.tag) {
        case 0:
        case 11:
        case 15:
          hr(f, v, S, R, u), Eo(8, v);
          break;
        case 23:
          break;
        case 22:
          var X = v.stateNode;
          v.memoizedState !== null ? X._visibility & 2 ? hr(f, v, S, R, u) : Co(f, v) : (X._visibility |= 2, hr(f, v, S, R, u)), u && I & 2048 && nf(v.alternate, v);
          break;
        case 24:
          hr(f, v, S, R, u), u && I & 2048 && af(v.alternate, v);
          break;
        default:
          hr(f, v, S, R, u);
      }
      n = n.sibling;
    }
  }
  function Co(t, n) {
    if (n.subtreeFlags & 10256) for (n = n.child; n !== null; ) {
      var i = t, o = n, u = o.flags;
      switch (o.tag) {
        case 22:
          Co(i, o), u & 2048 && nf(o.alternate, o);
          break;
        case 24:
          Co(i, o), u & 2048 && af(o.alternate, o);
          break;
        default:
          Co(i, o);
      }
      n = n.sibling;
    }
  }
  var Ao = 8192;
  function mr(t, n, i) {
    if (t.subtreeFlags & Ao) for (t = t.child; t !== null; ) uv(t, n, i), t = t.sibling;
  }
  function uv(t, n, i) {
    switch (t.tag) {
      case 26:
        mr(t, n, i), t.flags & Ao && t.memoizedState !== null && pw(i, Pn, t.memoizedState, t.memoizedProps);
        break;
      case 5:
        mr(t, n, i);
        break;
      case 3:
      case 4:
        var o = Pn;
        Pn = ds(t.stateNode.containerInfo), mr(t, n, i), Pn = o;
        break;
      case 22:
        t.memoizedState === null && (o = t.alternate, o !== null && o.memoizedState !== null ? (o = Ao, Ao = 16777216, mr(t, n, i), Ao = o) : mr(t, n, i));
        break;
      default:
        mr(t, n, i);
    }
  }
  function cv(t) {
    var n = t.alternate;
    if (n !== null && (t = n.child, t !== null)) {
      n.child = null;
      do
        n = t.sibling, t.sibling = null, t = n;
      while (t !== null);
    }
  }
  function xo(t) {
    var n = t.deletions;
    if ((t.flags & 16) !== 0) {
      if (n !== null) for (var i = 0; i < n.length; i++) {
        var o = n[i];
        Nt = o, dv(o, t);
      }
      cv(t);
    }
    if (t.subtreeFlags & 10256) for (t = t.child; t !== null; ) fv(t), t = t.sibling;
  }
  function fv(t) {
    switch (t.tag) {
      case 0:
      case 11:
      case 15:
        xo(t), t.flags & 2048 && ka(9, t, t.return);
        break;
      case 3:
        xo(t);
        break;
      case 12:
        xo(t);
        break;
      case 22:
        var n = t.stateNode;
        t.memoizedState !== null && n._visibility & 2 && (t.return === null || t.return.tag !== 13) ? (n._visibility &= -3, Jl(t)) : xo(t);
        break;
      default:
        xo(t);
    }
  }
  function Jl(t) {
    var n = t.deletions;
    if ((t.flags & 16) !== 0) {
      if (n !== null) for (var i = 0; i < n.length; i++) {
        var o = n[i];
        Nt = o, dv(o, t);
      }
      cv(t);
    }
    for (t = t.child; t !== null; ) {
      switch (n = t, n.tag) {
        case 0:
        case 11:
        case 15:
          ka(8, n, n.return), Jl(n);
          break;
        case 22:
          i = n.stateNode, i._visibility & 2 && (i._visibility &= -3, Jl(n));
          break;
        default:
          Jl(n);
      }
      t = t.sibling;
    }
  }
  function dv(t, n) {
    for (; Nt !== null; ) {
      var i = Nt;
      switch (i.tag) {
        case 0:
        case 11:
        case 15:
          ka(8, i, n);
          break;
        case 23:
        case 22:
          if (i.memoizedState !== null && i.memoizedState.cachePool !== null) {
            var o = i.memoizedState.cachePool.pool;
            o != null && o.refCount++;
          }
          break;
        case 24:
          uo(i.memoizedState.cache);
      }
      if (o = i.child, o !== null) o.return = i, Nt = o;
      else e: for (i = t; Nt !== null; ) {
        o = Nt;
        var u = o.sibling, f = o.return;
        if (nv(o), o === i) {
          Nt = null;
          break e;
        }
        if (u !== null) {
          u.return = f, Nt = u;
          break e;
        }
        Nt = f;
      }
    }
  }
  var D2 = {
    getCacheForType: function(t) {
      var n = Ht(pt), i = n.data.get(t);
      return i === void 0 && (i = t(), n.data.set(t, i)), i;
    },
    cacheSignal: function() {
      return Ht(pt).controller.signal;
    }
  }, z2 = typeof WeakMap == "function" ? WeakMap : Map, Pe = 0, Xe = null, Me = null, Ne = 0, Ie = 0, dn = null, Pa = !1, pr = !1, rf = !1, _a = 0, lt = 0, Ia = 0, xi = 0, of = 0, hn = 0, vr = 0, Oo = null, en = null, lf = !1, es = 0, hv = 0, ts = 1 / 0, ns = null, Za = null, Ct = 0, Ga = null, gr = null, wa = 0, sf = 0, uf = null, mv = null, Mo = 0, cf = null;
  function Rn() {
    return (Pe & 2) !== 0 && Ne !== 0 ? Ne & -Ne : A.T !== null ? vf() : zh();
  }
  function pv() {
    if (hn === 0) if ((Ne & 536870912) === 0 || ze) {
      var t = Et;
      Et <<= 1, (Et & 3932160) === 0 && (Et = 262144), hn = t;
    } else hn = 536870912;
    return t = cn.current, t !== null && (t.flags |= 32), hn;
  }
  function tn(t, n, i) {
    (t === Xe && (Ie === 2 || Ie === 9) || t.cancelPendingCommit !== null) && (yr(t, 0), Va(t, Ne, hn, !1)), Ii(t, i), ((Pe & 2) === 0 || t !== Xe) && (t === Xe && ((Pe & 2) === 0 && (xi |= i), lt === 4 && Va(t, Ne, hn, !1)), Sa(t));
  }
  function vv(t, n, i) {
    if ((Pe & 6) !== 0) throw Error(s(327));
    var o = !i && (n & 127) === 0 && (n & t.expiredLanes) === 0 || Ma(t, n), u = o ? j2(t, n) : df(t, n, !0), f = o;
    do {
      if (u === 0) {
        pr && !o && Va(t, n, 0, !1);
        break;
      } else {
        if (i = t.current.alternate, f && !L2(i)) {
          u = df(t, n, !1), f = !1;
          continue;
        }
        if (u === 2) {
          if (f = n, t.errorRecoveryDisabledLanes & f) var v = 0;
          else v = t.pendingLanes & -536870913, v = v !== 0 ? v : v & 536870912 ? 536870912 : 0;
          if (v !== 0) {
            n = v;
            e: {
              var S = t;
              u = Oo;
              var R = S.current.memoizedState.isDehydrated;
              if (R && (yr(S, v).flags |= 256), v = df(S, v, !1), v !== 2) {
                if (rf && !R) {
                  S.errorRecoveryDisabledLanes |= f, xi |= f, u = 4;
                  break e;
                }
                f = en, en = u, f !== null && (en === null ? en = f : en.push.apply(en, f));
              }
              u = v;
            }
            if (f = !1, u !== 2) continue;
          }
        }
        if (u === 1) {
          yr(t, 0), Va(t, n, 0, !0);
          break;
        }
        e: {
          switch (o = t, f = u, f) {
            case 0:
            case 1:
              throw Error(s(345));
            case 4:
              if ((n & 4194048) !== n) break;
            case 6:
              Va(o, n, hn, !Pa);
              break e;
            case 2:
              en = null;
              break;
            case 3:
            case 5:
              break;
            default:
              throw Error(s(329));
          }
          if ((n & 62914560) === n && (u = es + 300 - xt(), 10 < u)) {
            if (Va(o, n, hn, !Pa), ln(o, 0, !0) !== 0) break e;
            wa = n, o.timeoutHandle = Xv(gv.bind(null, o, i, en, ns, lf, n, hn, xi, vr, Pa, f, "Throttled", -0, 0), u);
            break e;
          }
          gv(o, i, en, ns, lf, n, hn, xi, vr, Pa, f, null, -0, 0);
        }
      }
      break;
    } while (!0);
    Sa(t);
  }
  function gv(t, n, i, o, u, f, v, S, R, I, X, J, Z, G) {
    if (t.timeoutHandle = -1, J = n.subtreeFlags, J & 8192 || (J & 16785408) === 16785408) {
      J = {
        stylesheets: null,
        count: 0,
        imgCount: 0,
        imgBytes: 0,
        suspenseyImages: [],
        waitingForImages: !0,
        waitingForViewTransition: !1,
        unsuspend: oa
      }, uv(n, f, J);
      var he = (f & 62914560) === f ? es - xt() : (f & 4194048) === f ? hv - xt() : 0;
      if (he = vw(J, he), he !== null) {
        wa = f, t.cancelPendingCommit = he(Cv.bind(null, t, n, f, i, o, u, v, S, R, X, J, null, Z, G)), Va(t, f, v, !I);
        return;
      }
    }
    Cv(t, n, f, i, o, u, v, S, R);
  }
  function L2(t) {
    for (var n = t; ; ) {
      var i = n.tag;
      if ((i === 0 || i === 11 || i === 15) && n.flags & 16384 && (i = n.updateQueue, i !== null && (i = i.stores, i !== null))) for (var o = 0; o < i.length; o++) {
        var u = i[o], f = u.getSnapshot;
        u = u.value;
        try {
          if (!sn(f(), u)) return !1;
        } catch {
          return !1;
        }
      }
      if (i = n.child, n.subtreeFlags & 16384 && i !== null) i.return = n, n = i;
      else {
        if (n === t) break;
        for (; n.sibling === null; ) {
          if (n.return === null || n.return === t) return !0;
          n = n.return;
        }
        n.sibling.return = n.return, n = n.sibling;
      }
    }
    return !0;
  }
  function Va(t, n, i, o) {
    n &= ~of, n &= ~xi, t.suspendedLanes |= n, t.pingedLanes &= ~n, o && (t.warmLanes |= n), o = t.expirationTimes;
    for (var u = n; 0 < u; ) {
      var f = 31 - ae(u), v = 1 << f;
      o[f] = -1, u &= ~v;
    }
    i !== 0 && Xr(t, i, n);
  }
  function as() {
    return (Pe & 6) === 0 ? (Ro(0, !1), !1) : !0;
  }
  function ff() {
    if (Me !== null) {
      if (Ie === 0) var t = Me.return;
      else t = Me, ca = vi = null, Ac(t), sr = null, fo = 0, t = Me;
      for (; t !== null; ) Xp(t.alternate, t), t = t.return;
      Me = null;
    }
  }
  function yr(t, n) {
    var i = t.timeoutHandle;
    i !== -1 && (t.timeoutHandle = -1, K2(i)), i = t.cancelPendingCommit, i !== null && (t.cancelPendingCommit = null, i()), wa = 0, ff(), Xe = t, Me = i = sa(t.current, null), Ne = n, Ie = 0, dn = null, Pa = !1, pr = Ma(t, n), rf = !1, vr = hn = of = xi = Ia = lt = 0, en = Oo = null, lf = !1, (n & 8) !== 0 && (n |= n & 32);
    var o = t.entangledLanes;
    if (o !== 0) for (t = t.entanglements, o &= n; 0 < o; ) {
      var u = 31 - ae(o), f = 1 << u;
      n |= t[u], o &= ~f;
    }
    return _a = n, Tl(), i;
  }
  function yv(t, n) {
    Ae = null, A.H = _o, n === lr || n === Dl ? (n = Bm(), Ie = 3) : n === mc ? (n = Bm(), Ie = 4) : Ie = n === Zc ? 8 : n !== null && typeof n == "object" && typeof n.then == "function" ? 6 : 1, dn = n, Me === null && (lt = 1, Fl(t, Cn(n, t.current)));
  }
  function bv() {
    var t = cn.current;
    return t === null ? !0 : (Ne & 4194048) === Ne ? Mn === null : (Ne & 62914560) === Ne || (Ne & 536870912) !== 0 ? t === Mn : !1;
  }
  function _v() {
    var t = A.H;
    return A.H = _o, t === null ? _o : t;
  }
  function wv() {
    var t = A.A;
    return A.A = D2, t;
  }
  function is() {
    lt = 4, Pa || (Ne & 4194048) !== Ne && cn.current !== null || (pr = !0), (Ia & 134217727) === 0 && (xi & 134217727) === 0 || Xe === null || Va(Xe, Ne, hn, !1);
  }
  function df(t, n, i) {
    var o = Pe;
    Pe |= 2;
    var u = _v(), f = wv();
    (Xe !== t || Ne !== n) && (ns = null, yr(t, n)), n = !1;
    var v = lt;
    e: do
      try {
        if (Ie !== 0 && Me !== null) {
          var S = Me, R = dn;
          switch (Ie) {
            case 8:
              ff(), v = 6;
              break e;
            case 3:
            case 2:
            case 9:
            case 6:
              cn.current === null && (n = !0);
              var I = Ie;
              if (Ie = 0, dn = null, br(t, S, R, I), i && pr) {
                v = 0;
                break e;
              }
              break;
            default:
              I = Ie, Ie = 0, dn = null, br(t, S, R, I);
          }
        }
        H2(), v = lt;
        break;
      } catch (X) {
        yv(t, X);
      }
    while (!0);
    return n && t.shellSuspendCounter++, ca = vi = null, Pe = o, A.H = u, A.A = f, Me === null && (Xe = null, Ne = 0, Tl()), v;
  }
  function H2() {
    for (; Me !== null; ) Sv(Me);
  }
  function j2(t, n) {
    var i = Pe;
    Pe |= 2;
    var o = _v(), u = wv();
    Xe !== t || Ne !== n ? (ns = null, ts = xt() + 500, yr(t, n)) : pr = Ma(t, n);
    e: do
      try {
        if (Ie !== 0 && Me !== null) {
          n = Me;
          var f = dn;
          t: switch (Ie) {
            case 1:
              Ie = 0, dn = null, br(t, n, f, 1);
              break;
            case 2:
            case 9:
              if (Hm(f)) {
                Ie = 0, dn = null, Ev(n);
                break;
              }
              n = function() {
                Ie !== 2 && Ie !== 9 || Xe !== t || (Ie = 7), Sa(t);
              }, f.then(n, n);
              break e;
            case 3:
              Ie = 7;
              break e;
            case 4:
              Ie = 5;
              break e;
            case 7:
              Hm(f) ? (Ie = 0, dn = null, Ev(n)) : (Ie = 0, dn = null, br(t, n, f, 7));
              break;
            case 5:
              var v = null;
              switch (Me.tag) {
                case 26:
                  v = Me.memoizedState;
                case 5:
                case 27:
                  var S = Me;
                  if (v ? u0(v) : S.stateNode.complete) {
                    Ie = 0, dn = null;
                    var R = S.sibling;
                    if (R !== null) Me = R;
                    else {
                      var I = S.return;
                      I !== null ? (Me = I, rs(I)) : Me = null;
                    }
                    break t;
                  }
              }
              Ie = 0, dn = null, br(t, n, f, 5);
              break;
            case 6:
              Ie = 0, dn = null, br(t, n, f, 6);
              break;
            case 8:
              ff(), lt = 6;
              break e;
            default:
              throw Error(s(462));
          }
        }
        B2();
        break;
      } catch (X) {
        yv(t, X);
      }
    while (!0);
    return ca = vi = null, A.H = o, A.A = u, Pe = i, Me !== null ? 0 : (Xe = null, Ne = 0, Tl(), lt);
  }
  function B2() {
    for (; Me !== null && !Pi(); ) Sv(Me);
  }
  function Sv(t) {
    var n = Fp(t.alternate, t, _a);
    t.memoizedProps = t.pendingProps, n === null ? rs(t) : Me = n;
  }
  function Ev(t) {
    var n = t, i = n.alternate;
    switch (n.tag) {
      case 15:
      case 0:
        n = Pp(i, n, n.pendingProps, n.type, void 0, Ne);
        break;
      case 11:
        n = Pp(i, n, n.pendingProps, n.type.render, n.ref, Ne);
        break;
      case 5:
        Ac(n);
      default:
        Xp(i, n), n = Me = Tm(n, _a), n = Fp(i, n, _a);
    }
    t.memoizedProps = t.pendingProps, n === null ? rs(t) : Me = n;
  }
  function br(t, n, i, o) {
    ca = vi = null, Ac(n), sr = null, fo = 0;
    var u = n.return;
    try {
      if (C2(t, u, n, i, Ne)) {
        lt = 1, Fl(t, Cn(i, t.current)), Me = null;
        return;
      }
    } catch (f) {
      if (u !== null) throw Me = u, f;
      lt = 1, Fl(t, Cn(i, t.current)), Me = null;
      return;
    }
    n.flags & 32768 ? (ze || o === 1 ? t = !0 : pr || (Ne & 536870912) !== 0 ? t = !1 : (Pa = t = !0, (o === 2 || o === 9 || o === 3 || o === 6) && (o = cn.current, o !== null && o.tag === 13 && (o.flags |= 16384))), Tv(n, t)) : rs(n);
  }
  function rs(t) {
    var n = t;
    do {
      if ((n.flags & 32768) !== 0) {
        Tv(n, Pa);
        return;
      }
      t = n.return;
      var i = O2(n.alternate, n, _a);
      if (i !== null) {
        Me = i;
        return;
      }
      if (n = n.sibling, n !== null) {
        Me = n;
        return;
      }
      Me = n = t;
    } while (n !== null);
    lt === 0 && (lt = 5);
  }
  function Tv(t, n) {
    do {
      var i = M2(t.alternate, t);
      if (i !== null) {
        i.flags &= 32767, Me = i;
        return;
      }
      if (i = t.return, i !== null && (i.flags |= 32768, i.subtreeFlags = 0, i.deletions = null), !n && (t = t.sibling, t !== null)) {
        Me = t;
        return;
      }
      Me = t = i;
    } while (t !== null);
    lt = 6, Me = null;
  }
  function Cv(t, n, i, o, u, f, v, S, R) {
    t.cancelPendingCommit = null;
    do
      os();
    while (Ct !== 0);
    if ((Pe & 6) !== 0) throw Error(s(327));
    if (n !== null) {
      if (n === t.current) throw Error(s(177));
      if (f = n.lanes | n.childLanes, f |= Ju, Ou(t, i, f, v, S, R), t === Xe && (Me = Xe = null, Ne = 0), gr = n, Ga = t, wa = i, sf = f, uf = u, mv = o, (n.subtreeFlags & 10256) !== 0 || (n.flags & 10256) !== 0 ? (t.callbackNode = null, t.callbackPriority = 0, I2(kt, function() {
        return Rv(), null;
      })) : (t.callbackNode = null, t.callbackPriority = 0), o = (n.flags & 13878) !== 0, (n.subtreeFlags & 13878) !== 0 || o) {
        o = A.T, A.T = null, u = N.p, N.p = 2, v = Pe, Pe |= 4;
        try {
          R2(t, n, i);
        } finally {
          Pe = v, N.p = u, A.T = o;
        }
      }
      Ct = 1, Av(), xv(), Ov();
    }
  }
  function Av() {
    if (Ct === 1) {
      Ct = 0;
      var t = Ga, n = gr, i = (n.flags & 13878) !== 0;
      if ((n.subtreeFlags & 13878) !== 0 || i) {
        i = A.T, A.T = null;
        var o = N.p;
        N.p = 2;
        var u = Pe;
        Pe |= 4;
        try {
          ov(n, t);
          var f = Ef, v = pm(t.containerInfo), S = f.focusedElem, R = f.selectionRange;
          if (v !== S && S && S.ownerDocument && mm(S.ownerDocument.documentElement, S)) {
            if (R !== null && Xu(S)) {
              var I = R.start, X = R.end;
              if (X === void 0 && (X = I), "selectionStart" in S) S.selectionStart = I, S.selectionEnd = Math.min(X, S.value.length);
              else {
                var J = S.ownerDocument || document, Z = J && J.defaultView || window;
                if (Z.getSelection) {
                  var G = Z.getSelection(), he = S.textContent.length, we = Math.min(R.start, he), $e = R.end === void 0 ? we : Math.min(R.end, he);
                  !G.extend && we > $e && (v = $e, $e = we, we = v);
                  var U = hm(S, we), z = hm(S, $e);
                  if (U && z && (G.rangeCount !== 1 || G.anchorNode !== U.node || G.anchorOffset !== U.offset || G.focusNode !== z.node || G.focusOffset !== z.offset)) {
                    var P = J.createRange();
                    P.setStart(U.node, U.offset), G.removeAllRanges(), we > $e ? (G.addRange(P), G.extend(z.node, z.offset)) : (P.setEnd(z.node, z.offset), G.addRange(P));
                  }
                }
              }
            }
            for (J = [], G = S; G = G.parentNode; ) G.nodeType === 1 && J.push({
              element: G,
              left: G.scrollLeft,
              top: G.scrollTop
            });
            for (typeof S.focus == "function" && S.focus(), S = 0; S < J.length; S++) {
              var W = J[S];
              W.element.scrollLeft = W.left, W.element.scrollTop = W.top;
            }
          }
          ys = !!Sf, Ef = Sf = null;
        } finally {
          Pe = u, N.p = o, A.T = i;
        }
      }
      t.current = n, Ct = 2;
    }
  }
  function xv() {
    if (Ct === 2) {
      Ct = 0;
      var t = Ga, n = gr, i = (n.flags & 8772) !== 0;
      if ((n.subtreeFlags & 8772) !== 0 || i) {
        i = A.T, A.T = null;
        var o = N.p;
        N.p = 2;
        var u = Pe;
        Pe |= 4;
        try {
          tv(t, n.alternate, n);
        } finally {
          Pe = u, N.p = o, A.T = i;
        }
      }
      Ct = 3;
    }
  }
  function Ov() {
    if (Ct === 4 || Ct === 3) {
      Ct = 0, $r();
      var t = Ga, n = gr, i = wa, o = mv;
      (n.subtreeFlags & 10256) !== 0 || (n.flags & 10256) !== 0 ? Ct = 5 : (Ct = 0, gr = Ga = null, Mv(t, t.pendingLanes));
      var u = t.pendingLanes;
      if (u === 0 && (Za = null), Mu(i), n = n.stateNode, Zt && typeof Zt.onCommitFiberRoot == "function") try {
        Zt.onCommitFiberRoot(si, n, void 0, (n.current.flags & 128) === 128);
      } catch {
      }
      if (o !== null) {
        n = A.T, u = N.p, N.p = 2, A.T = null;
        try {
          for (var f = t.onRecoverableError, v = 0; v < o.length; v++) {
            var S = o[v];
            f(S.value, { componentStack: S.stack });
          }
        } finally {
          A.T = n, N.p = u;
        }
      }
      (wa & 3) !== 0 && os(), Sa(t), u = t.pendingLanes, (i & 261930) !== 0 && (u & 42) !== 0 ? t === cf ? Mo++ : (Mo = 0, cf = t) : Mo = 0, Ro(0, !1);
    }
  }
  function Mv(t, n) {
    (t.pooledCacheLanes &= n) === 0 && (n = t.pooledCache, n != null && (t.pooledCache = null, uo(n)));
  }
  function os() {
    return Av(), xv(), Ov(), Rv();
  }
  function Rv() {
    if (Ct !== 5) return !1;
    var t = Ga, n = sf;
    sf = 0;
    var i = Mu(wa), o = A.T, u = N.p;
    try {
      N.p = 32 > i ? 32 : i, A.T = null, i = uf, uf = null;
      var f = Ga, v = wa;
      if (Ct = 0, gr = Ga = null, wa = 0, (Pe & 6) !== 0) throw Error(s(331));
      var S = Pe;
      if (Pe |= 4, fv(f.current), sv(f, f.current, v, i), Pe = S, Ro(0, !1), Zt && typeof Zt.onPostCommitFiberRoot == "function") try {
        Zt.onPostCommitFiberRoot(si, f);
      } catch {
      }
      return !0;
    } finally {
      N.p = u, A.T = o, Mv(t, n);
    }
  }
  function Nv(t, n, i) {
    n = Cn(i, n), n = Ic(t.stateNode, n, 2), t = Ei(t, n, 2), t !== null && (Ii(t, 2), Sa(t));
  }
  function Ze(t, n, i) {
    if (t.tag === 3) Nv(t, t, i);
    else for (; n !== null; ) {
      if (n.tag === 3) {
        Nv(n, t, i);
        break;
      } else if (n.tag === 1) {
        var o = n.stateNode;
        if (typeof n.type.getDerivedStateFromError == "function" || typeof o.componentDidCatch == "function" && (Za === null || !Za.has(o))) {
          t = Cn(i, t), i = Dp(2), o = Ei(n, i, 2), o !== null && (zp(i, o, n, t), Ii(o, 2), Sa(o));
          break;
        }
      }
      n = n.return;
    }
  }
  function hf(t, n, i) {
    var o = t.pingCache;
    if (o === null) {
      o = t.pingCache = new z2();
      var u = /* @__PURE__ */ new Set();
      o.set(n, u);
    } else u = o.get(n), u === void 0 && (u = /* @__PURE__ */ new Set(), o.set(n, u));
    u.has(i) || (rf = !0, u.add(i), t = U2.bind(null, t, n, i), n.then(t, t));
  }
  function U2(t, n, i) {
    var o = t.pingCache;
    o !== null && o.delete(n), t.pingedLanes |= t.suspendedLanes & i, t.warmLanes &= ~i, Xe === t && (Ne & i) === i && (lt === 4 || lt === 3 && (Ne & 62914560) === Ne && 300 > xt() - es ? (Pe & 2) === 0 && yr(t, 0) : of |= i, vr === Ne && (vr = 0)), Sa(t);
  }
  function Dv(t, n) {
    n === 0 && (n = fl()), t = hi(t, n), t !== null && (Ii(t, n), Sa(t));
  }
  function k2(t) {
    var n = t.memoizedState, i = 0;
    n !== null && (i = n.retryLane), Dv(t, i);
  }
  function P2(t, n) {
    var i = 0;
    switch (t.tag) {
      case 31:
      case 13:
        var o = t.stateNode, u = t.memoizedState;
        u !== null && (i = u.retryLane);
        break;
      case 19:
        o = t.stateNode;
        break;
      case 22:
        o = t.stateNode._retryCache;
        break;
      default:
        throw Error(s(314));
    }
    o !== null && o.delete(n), Dv(t, i);
  }
  function I2(t, n) {
    return wn(t, n);
  }
  var ls = null, _r = null, mf = !1, ss = !1, pf = !1, $a = 0;
  function Sa(t) {
    t !== _r && t.next === null && (_r === null ? ls = _r = t : _r = _r.next = t), ss = !0, mf || (mf = !0, G2());
  }
  function Ro(t, n) {
    if (!pf && ss) {
      pf = !0;
      do
        for (var i = !1, o = ls; o !== null; ) {
          if (!n) if (t !== 0) {
            var u = o.pendingLanes;
            if (u === 0) var f = 0;
            else {
              var v = o.suspendedLanes, S = o.pingedLanes;
              f = (1 << 31 - ae(42 | t) + 1) - 1, f &= u & ~(v & ~S), f = f & 201326741 ? f & 201326741 | 1 : f ? f | 2 : 0;
            }
            f !== 0 && (i = !0, jv(o, f));
          } else f = Ne, f = ln(o, o === Xe ? f : 0, o.cancelPendingCommit !== null || o.timeoutHandle !== -1), (f & 3) === 0 || Ma(o, f) || (i = !0, jv(o, f));
          o = o.next;
        }
      while (i);
      pf = !1;
    }
  }
  function Z2() {
    zv();
  }
  function zv() {
    ss = mf = !1;
    var t = 0;
    $a !== 0 && Q2() && (t = $a);
    for (var n = xt(), i = null, o = ls; o !== null; ) {
      var u = o.next, f = Lv(o, n);
      f === 0 ? (o.next = null, i === null ? ls = u : i.next = u, u === null && (_r = i)) : (i = o, (t !== 0 || (f & 3) !== 0) && (ss = !0)), o = u;
    }
    Ct !== 0 && Ct !== 5 || Ro(t, !1), $a !== 0 && ($a = 0);
  }
  function Lv(t, n) {
    for (var i = t.suspendedLanes, o = t.pingedLanes, u = t.expirationTimes, f = t.pendingLanes & -62914561; 0 < f; ) {
      var v = 31 - ae(f), S = 1 << v, R = u[v];
      R === -1 ? ((S & i) === 0 || (S & o) !== 0) && (u[v] = xu(S, n)) : R <= n && (t.expiredLanes |= S), f &= ~S;
    }
    if (n = Xe, i = Ne, i = ln(t, t === n ? i : 0, t.cancelPendingCommit !== null || t.timeoutHandle !== -1), o = t.callbackNode, i === 0 || t === n && (Ie === 2 || Ie === 9) || t.cancelPendingCommit !== null) return o !== null && o !== null && Bn(o), t.callbackNode = null, t.callbackPriority = 0;
    if ((i & 3) === 0 || Ma(t, i)) {
      if (n = i & -i, n === t.callbackPriority) return n;
      switch (o !== null && Bn(o), Mu(i)) {
        case 2:
        case 8:
          i = Ut;
          break;
        case 32:
          i = kt;
          break;
        case 268435456:
          i = ul;
          break;
        default:
          i = kt;
      }
      return o = Hv.bind(null, t), i = wn(i, o), t.callbackPriority = n, t.callbackNode = i, n;
    }
    return o !== null && o !== null && Bn(o), t.callbackPriority = 2, t.callbackNode = null, 2;
  }
  function Hv(t, n) {
    if (Ct !== 0 && Ct !== 5) return t.callbackNode = null, t.callbackPriority = 0, null;
    var i = t.callbackNode;
    if (os() && t.callbackNode !== i) return null;
    var o = Ne;
    return o = ln(t, t === Xe ? o : 0, t.cancelPendingCommit !== null || t.timeoutHandle !== -1), o === 0 ? null : (vv(t, o, n), Lv(t, xt()), t.callbackNode != null && t.callbackNode === i ? Hv.bind(null, t) : null);
  }
  function jv(t, n) {
    if (os()) return null;
    vv(t, n, !0);
  }
  function G2() {
    J2(function() {
      (Pe & 6) !== 0 ? wn(Ot, Z2) : zv();
    });
  }
  function vf() {
    if ($a === 0) {
      var t = rr;
      t === 0 && (t = ht, ht <<= 1, (ht & 261888) === 0 && (ht = 256)), $a = t;
    }
    return $a;
  }
  function Bv(t) {
    return t == null || typeof t == "symbol" || typeof t == "boolean" ? null : typeof t == "function" ? t : vl("" + t);
  }
  function Uv(t, n) {
    var i = n.ownerDocument.createElement("input");
    return i.name = n.name, i.value = n.value, t.id && i.setAttribute("form", t.id), n.parentNode.insertBefore(i, n), t = new FormData(t), i.parentNode.removeChild(i), t;
  }
  function V2(t, n, i, o, u) {
    if (n === "submit" && i && i.stateNode === u) {
      var f = Bv((u[Yt] || null).action), v = o.submitter;
      v && (n = (n = v[Yt] || null) ? Bv(n.formAction) : v.getAttribute("formAction"), n !== null && (f = n, v = null));
      var S = new _l("action", "action", null, o, u);
      t.push({
        event: S,
        listeners: [{
          instance: null,
          listener: function() {
            if (o.defaultPrevented) {
              if ($a !== 0) {
                var R = v ? Uv(u, v) : new FormData(u);
                Hc(i, {
                  pending: !0,
                  data: R,
                  method: u.method,
                  action: f
                }, null, R);
              }
            } else typeof f == "function" && (S.preventDefault(), R = v ? Uv(u, v) : new FormData(u), Hc(i, {
              pending: !0,
              data: R,
              method: u.method,
              action: f
            }, f, R));
          },
          currentTarget: u
        }]
      });
    }
  }
  for (var gf = 0; gf < Ku.length; gf++) {
    var yf = Ku[gf];
    kn(yf.toLowerCase(), "on" + (yf[0].toUpperCase() + yf.slice(1)));
  }
  kn(ym, "onAnimationEnd"), kn(bm, "onAnimationIteration"), kn(_m, "onAnimationStart"), kn("dblclick", "onDoubleClick"), kn("focusin", "onFocus"), kn("focusout", "onBlur"), kn(r2, "onTransitionRun"), kn(o2, "onTransitionStart"), kn(l2, "onTransitionCancel"), kn(wm, "onTransitionEnd"), $i("onMouseEnter", ["mouseout", "mouseover"]), $i("onMouseLeave", ["mouseout", "mouseover"]), $i("onPointerEnter", ["pointerout", "pointerover"]), $i("onPointerLeave", ["pointerout", "pointerover"]), ui("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" ")), ui("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")), ui("onBeforeInput", [
    "compositionend",
    "keypress",
    "textInput",
    "paste"
  ]), ui("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" ")), ui("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" ")), ui("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
  var No = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), $2 = new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(No));
  function kv(t, n) {
    n = (n & 4) !== 0;
    for (var i = 0; i < t.length; i++) {
      var o = t[i], u = o.event;
      o = o.listeners;
      e: {
        var f = void 0;
        if (n) for (var v = o.length - 1; 0 <= v; v--) {
          var S = o[v], R = S.instance, I = S.currentTarget;
          if (S = S.listener, R !== f && u.isPropagationStopped()) break e;
          f = S, u.currentTarget = I;
          try {
            f(u);
          } catch (X) {
            El(X);
          }
          u.currentTarget = null, f = R;
        }
        else for (v = 0; v < o.length; v++) {
          if (S = o[v], R = S.instance, I = S.currentTarget, S = S.listener, R !== f && u.isPropagationStopped()) break e;
          f = S, u.currentTarget = I;
          try {
            f(u);
          } catch (X) {
            El(X);
          }
          u.currentTarget = null, f = R;
        }
      }
    }
  }
  function Re(t, n) {
    var i = n[Ru];
    i === void 0 && (i = n[Ru] = /* @__PURE__ */ new Set());
    var o = t + "__bubble";
    i.has(o) || (Iv(n, t, 2, !1), i.add(o));
  }
  function bf(t, n, i) {
    var o = 0;
    n && (o |= 4), Iv(i, t, o, n);
  }
  var us = "_reactListening" + Math.random().toString(36).slice(2);
  function Pv(t) {
    if (!t[us]) {
      t[us] = !0, jh.forEach(function(i) {
        i !== "selectionchange" && ($2.has(i) || bf(i, !1, t), bf(i, !0, t));
      });
      var n = t.nodeType === 9 ? t : t.ownerDocument;
      n === null || n[us] || (n[us] = !0, bf("selectionchange", !1, n));
    }
  }
  function Iv(t, n, i, o) {
    switch (m0(n)) {
      case 2:
        var u = ww;
        break;
      case 8:
        u = Sw;
        break;
      default:
        u = Lf;
    }
    i = u.bind(null, n, i, t), u = void 0, !ku || n !== "touchstart" && n !== "touchmove" && n !== "wheel" || (u = !0), o ? u !== void 0 ? t.addEventListener(n, i, {
      capture: !0,
      passive: u
    }) : t.addEventListener(n, i, !0) : u !== void 0 ? t.addEventListener(n, i, { passive: u }) : t.addEventListener(n, i, !1);
  }
  function _f(t, n, i, o, u) {
    var f = o;
    if ((n & 1) === 0 && (n & 2) === 0 && o !== null) e: for (; ; ) {
      if (o === null) return;
      var v = o.tag;
      if (v === 3 || v === 4) {
        var S = o.stateNode.containerInfo;
        if (S === u) break;
        if (v === 4) for (v = o.return; v !== null; ) {
          var R = v.tag;
          if ((R === 3 || R === 4) && v.stateNode.containerInfo === u) return;
          v = v.return;
        }
        for (; S !== null; ) {
          if (v = Zi(S), v === null) return;
          if (R = v.tag, R === 5 || R === 6 || R === 26 || R === 27) {
            o = f = v;
            continue e;
          }
          S = S.parentNode;
        }
      }
      o = o.return;
    }
    Xh(function() {
      var I = f, X = Bu(i), J = [];
      e: {
        var Z = Sm.get(t);
        if (Z !== void 0) {
          var G = _l, he = t;
          switch (t) {
            case "keypress":
              if (yl(i) === 0) break e;
            case "keydown":
            case "keyup":
              G = Z_;
              break;
            case "focusin":
              he = "focus", G = Gu;
              break;
            case "focusout":
              he = "blur", G = Gu;
              break;
            case "beforeblur":
            case "afterblur":
              G = Gu;
              break;
            case "click":
              if (i.button === 2) break e;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              G = Qh;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              G = H_;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              G = G_;
              break;
            case ym:
            case bm:
            case _m:
              G = j_;
              break;
            case wm:
              G = V_;
              break;
            case "scroll":
            case "scrollend":
              G = L_;
              break;
            case "wheel":
              G = $_;
              break;
            case "copy":
            case "cut":
            case "paste":
              G = B_;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              G = Jh;
              break;
            case "toggle":
            case "beforetoggle":
              G = F_;
          }
          var we = (n & 4) !== 0, $e = !we && (t === "scroll" || t === "scrollend"), U = we ? Z !== null ? Z + "Capture" : null : Z;
          we = [];
          for (var z = I, P; z !== null; ) {
            var W = z;
            if (P = W.stateNode, W = W.tag, W !== 5 && W !== 26 && W !== 27 || P === null || U === null || (W = Kr(z, U), W != null && we.push(Do(z, W, P))), $e) break;
            z = z.return;
          }
          0 < we.length && (Z = new G(Z, he, null, i, X), J.push({
            event: Z,
            listeners: we
          }));
        }
      }
      if ((n & 7) === 0) {
        e: {
          if (Z = t === "mouseover" || t === "pointerover", G = t === "mouseout" || t === "pointerout", Z && i !== ju && (he = i.relatedTarget || i.fromElement) && (Zi(he) || he[Yr])) break e;
          if ((G || Z) && (Z = X.window === X ? X : (Z = X.ownerDocument) ? Z.defaultView || Z.parentWindow : window, G ? (he = i.relatedTarget || i.toElement, G = I, he = he ? Zi(he) : null, he !== null && ($e = d(he), we = he.tag, he !== $e || we !== 5 && we !== 27 && we !== 6) && (he = null)) : (G = null, he = I), G !== he)) {
            if (we = Qh, W = "onMouseLeave", U = "onMouseEnter", z = "mouse", (t === "pointerout" || t === "pointerover") && (we = Jh, W = "onPointerLeave", U = "onPointerEnter", z = "pointer"), $e = G == null ? Z : Qr(G), P = he == null ? Z : Qr(he), Z = new we(W, z + "leave", G, i, X), Z.target = $e, Z.relatedTarget = P, W = null, Zi(X) === I && (we = new we(U, z + "enter", he, i, X), we.target = P, we.relatedTarget = $e, W = we), $e = W, G && he) t: {
              for (we = F2, U = G, z = he, P = 0, W = U; W; W = we(W)) P++;
              W = 0;
              for (var be = z; be; be = we(be)) W++;
              for (; 0 < P - W; ) U = we(U), P--;
              for (; 0 < W - P; ) z = we(z), W--;
              for (; P--; ) {
                if (U === z || z !== null && U === z.alternate) {
                  we = U;
                  break t;
                }
                U = we(U), z = we(z);
              }
              we = null;
            }
            else we = null;
            G !== null && Zv(J, Z, G, we, !1), he !== null && $e !== null && Zv(J, $e, he, we, !0);
          }
        }
        e: {
          if (Z = I ? Qr(I) : window, G = Z.nodeName && Z.nodeName.toLowerCase(), G === "select" || G === "input" && Z.type === "file") var Ue = lm;
          else if (rm(Z)) if (sm) Ue = n2;
          else {
            Ue = e2;
            var pe = J_;
          }
          else G = Z.nodeName, !G || G.toLowerCase() !== "input" || Z.type !== "checkbox" && Z.type !== "radio" ? I && Hu(I.elementType) && (Ue = lm) : Ue = t2;
          if (Ue && (Ue = Ue(t, I))) {
            om(J, Ue, i, X);
            break e;
          }
          pe && pe(t, Z, I), t === "focusout" && I && Z.type === "number" && I.memoizedProps.value != null && Lu(Z, "number", Z.value);
        }
        switch (pe = I ? Qr(I) : window, t) {
          case "focusin":
            (rm(pe) || pe.contentEditable === "true") && (Qi = pe, Yu = I, oo = null);
            break;
          case "focusout":
            oo = Yu = Qi = null;
            break;
          case "mousedown":
            Wu = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            Wu = !1, vm(J, i, X);
            break;
          case "selectionchange":
            if (i2) break;
          case "keydown":
          case "keyup":
            vm(J, i, X);
        }
        var xe;
        if ($u) e: {
          switch (t) {
            case "compositionstart":
              var De = "onCompositionStart";
              break e;
            case "compositionend":
              De = "onCompositionEnd";
              break e;
            case "compositionupdate":
              De = "onCompositionUpdate";
              break e;
          }
          De = void 0;
        }
        else Wi ? am(t, i) && (De = "onCompositionEnd") : t === "keydown" && i.keyCode === 229 && (De = "onCompositionStart");
        De && (em && i.locale !== "ko" && (Wi || De !== "onCompositionStart" ? De === "onCompositionEnd" && Wi && (xe = Yh()) : (Na = X, Pu = "value" in Na ? Na.value : Na.textContent, Wi = !0)), pe = cs(I, De), 0 < pe.length && (De = new Kh(De, t, null, i, X), J.push({
          event: De,
          listeners: pe
        }), xe ? De.data = xe : (xe = im(i), xe !== null && (De.data = xe)))), (xe = X_ ? Y_(t, i) : W_(t, i)) && (De = cs(I, "onBeforeInput"), 0 < De.length && (pe = new Kh("onBeforeInput", "beforeinput", null, i, X), J.push({
          event: pe,
          listeners: De
        }), pe.data = xe)), V2(J, t, I, i, X);
      }
      kv(J, n);
    });
  }
  function Do(t, n, i) {
    return {
      instance: t,
      listener: n,
      currentTarget: i
    };
  }
  function cs(t, n) {
    for (var i = n + "Capture", o = []; t !== null; ) {
      var u = t, f = u.stateNode;
      if (u = u.tag, u !== 5 && u !== 26 && u !== 27 || f === null || (u = Kr(t, i), u != null && o.unshift(Do(t, u, f)), u = Kr(t, n), u != null && o.push(Do(t, u, f))), t.tag === 3) return o;
      t = t.return;
    }
    return [];
  }
  function F2(t) {
    if (t === null) return null;
    do
      t = t.return;
    while (t && t.tag !== 5 && t.tag !== 27);
    return t || null;
  }
  function Zv(t, n, i, o, u) {
    for (var f = n._reactName, v = []; i !== null && i !== o; ) {
      var S = i, R = S.alternate, I = S.stateNode;
      if (S = S.tag, R !== null && R === o) break;
      S !== 5 && S !== 26 && S !== 27 || I === null || (R = I, u ? (I = Kr(i, f), I != null && v.unshift(Do(i, I, R))) : u || (I = Kr(i, f), I != null && v.push(Do(i, I, R)))), i = i.return;
    }
    v.length !== 0 && t.push({
      event: n,
      listeners: v
    });
  }
  var q2 = /\r\n?/g, X2 = /\u0000|\uFFFD/g;
  function Gv(t) {
    return (typeof t == "string" ? t : "" + t).replace(q2, `
`).replace(X2, "");
  }
  function Vv(t, n) {
    return n = Gv(n), Gv(t) === n;
  }
  function Ve(t, n, i, o, u, f) {
    switch (i) {
      case "children":
        typeof o == "string" ? n === "body" || n === "textarea" && o === "" || qi(t, o) : (typeof o == "number" || typeof o == "bigint") && n !== "body" && qi(t, "" + o);
        break;
      case "className":
        ml(t, "class", o);
        break;
      case "tabIndex":
        ml(t, "tabindex", o);
        break;
      case "dir":
      case "role":
      case "viewBox":
      case "width":
      case "height":
        ml(t, i, o);
        break;
      case "style":
        Fh(t, o, f);
        break;
      case "data":
        if (n !== "object") {
          ml(t, "data", o);
          break;
        }
      case "src":
      case "href":
        if (o === "" && (n !== "a" || i !== "href")) {
          t.removeAttribute(i);
          break;
        }
        if (o == null || typeof o == "function" || typeof o == "symbol" || typeof o == "boolean") {
          t.removeAttribute(i);
          break;
        }
        o = vl("" + o), t.setAttribute(i, o);
        break;
      case "action":
      case "formAction":
        if (typeof o == "function") {
          t.setAttribute(i, "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");
          break;
        } else typeof f == "function" && (i === "formAction" ? (n !== "input" && Ve(t, n, "name", u.name, u, null), Ve(t, n, "formEncType", u.formEncType, u, null), Ve(t, n, "formMethod", u.formMethod, u, null), Ve(t, n, "formTarget", u.formTarget, u, null)) : (Ve(t, n, "encType", u.encType, u, null), Ve(t, n, "method", u.method, u, null), Ve(t, n, "target", u.target, u, null)));
        if (o == null || typeof o == "symbol" || typeof o == "boolean") {
          t.removeAttribute(i);
          break;
        }
        o = vl("" + o), t.setAttribute(i, o);
        break;
      case "onClick":
        o != null && (t.onclick = oa);
        break;
      case "onScroll":
        o != null && Re("scroll", t);
        break;
      case "onScrollEnd":
        o != null && Re("scrollend", t);
        break;
      case "dangerouslySetInnerHTML":
        if (o != null) {
          if (typeof o != "object" || !("__html" in o)) throw Error(s(61));
          if (i = o.__html, i != null) {
            if (u.children != null) throw Error(s(60));
            t.innerHTML = i;
          }
        }
        break;
      case "multiple":
        t.multiple = o && typeof o != "function" && typeof o != "symbol";
        break;
      case "muted":
        t.muted = o && typeof o != "function" && typeof o != "symbol";
        break;
      case "suppressContentEditableWarning":
      case "suppressHydrationWarning":
      case "defaultValue":
      case "defaultChecked":
      case "innerHTML":
      case "ref":
        break;
      case "autoFocus":
        break;
      case "xlinkHref":
        if (o == null || typeof o == "function" || typeof o == "boolean" || typeof o == "symbol") {
          t.removeAttribute("xlink:href");
          break;
        }
        i = vl("" + o), t.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", i);
        break;
      case "contentEditable":
      case "spellCheck":
      case "draggable":
      case "value":
      case "autoReverse":
      case "externalResourcesRequired":
      case "focusable":
      case "preserveAlpha":
        o != null && typeof o != "function" && typeof o != "symbol" ? t.setAttribute(i, "" + o) : t.removeAttribute(i);
        break;
      case "inert":
      case "allowFullScreen":
      case "async":
      case "autoPlay":
      case "controls":
      case "default":
      case "defer":
      case "disabled":
      case "disablePictureInPicture":
      case "disableRemotePlayback":
      case "formNoValidate":
      case "hidden":
      case "loop":
      case "noModule":
      case "noValidate":
      case "open":
      case "playsInline":
      case "readOnly":
      case "required":
      case "reversed":
      case "scoped":
      case "seamless":
      case "itemScope":
        o && typeof o != "function" && typeof o != "symbol" ? t.setAttribute(i, "") : t.removeAttribute(i);
        break;
      case "capture":
      case "download":
        o === !0 ? t.setAttribute(i, "") : o !== !1 && o != null && typeof o != "function" && typeof o != "symbol" ? t.setAttribute(i, o) : t.removeAttribute(i);
        break;
      case "cols":
      case "rows":
      case "size":
      case "span":
        o != null && typeof o != "function" && typeof o != "symbol" && !isNaN(o) && 1 <= o ? t.setAttribute(i, o) : t.removeAttribute(i);
        break;
      case "rowSpan":
      case "start":
        o == null || typeof o == "function" || typeof o == "symbol" || isNaN(o) ? t.removeAttribute(i) : t.setAttribute(i, o);
        break;
      case "popover":
        Re("beforetoggle", t), Re("toggle", t), hl(t, "popover", o);
        break;
      case "xlinkActuate":
        ra(t, "http://www.w3.org/1999/xlink", "xlink:actuate", o);
        break;
      case "xlinkArcrole":
        ra(t, "http://www.w3.org/1999/xlink", "xlink:arcrole", o);
        break;
      case "xlinkRole":
        ra(t, "http://www.w3.org/1999/xlink", "xlink:role", o);
        break;
      case "xlinkShow":
        ra(t, "http://www.w3.org/1999/xlink", "xlink:show", o);
        break;
      case "xlinkTitle":
        ra(t, "http://www.w3.org/1999/xlink", "xlink:title", o);
        break;
      case "xlinkType":
        ra(t, "http://www.w3.org/1999/xlink", "xlink:type", o);
        break;
      case "xmlBase":
        ra(t, "http://www.w3.org/XML/1998/namespace", "xml:base", o);
        break;
      case "xmlLang":
        ra(t, "http://www.w3.org/XML/1998/namespace", "xml:lang", o);
        break;
      case "xmlSpace":
        ra(t, "http://www.w3.org/XML/1998/namespace", "xml:space", o);
        break;
      case "is":
        hl(t, "is", o);
        break;
      case "innerText":
      case "textContent":
        break;
      default:
        (!(2 < i.length) || i[0] !== "o" && i[0] !== "O" || i[1] !== "n" && i[1] !== "N") && (i = D_.get(i) || i, hl(t, i, o));
    }
  }
  function wf(t, n, i, o, u, f) {
    switch (i) {
      case "style":
        Fh(t, o, f);
        break;
      case "dangerouslySetInnerHTML":
        if (o != null) {
          if (typeof o != "object" || !("__html" in o)) throw Error(s(61));
          if (i = o.__html, i != null) {
            if (u.children != null) throw Error(s(60));
            t.innerHTML = i;
          }
        }
        break;
      case "children":
        typeof o == "string" ? qi(t, o) : (typeof o == "number" || typeof o == "bigint") && qi(t, "" + o);
        break;
      case "onScroll":
        o != null && Re("scroll", t);
        break;
      case "onScrollEnd":
        o != null && Re("scrollend", t);
        break;
      case "onClick":
        o != null && (t.onclick = oa);
        break;
      case "suppressContentEditableWarning":
      case "suppressHydrationWarning":
      case "innerHTML":
      case "ref":
        break;
      case "innerText":
      case "textContent":
        break;
      default:
        if (!Bh.hasOwnProperty(i)) e: {
          if (i[0] === "o" && i[1] === "n" && (u = i.endsWith("Capture"), n = i.slice(2, u ? i.length - 7 : void 0), f = t[Yt] || null, f = f != null ? f[i] : null, typeof f == "function" && t.removeEventListener(n, f, u), typeof o == "function")) {
            typeof f != "function" && f !== null && (i in t ? t[i] = null : t.hasAttribute(i) && t.removeAttribute(i)), t.addEventListener(n, o, u);
            break e;
          }
          i in t ? t[i] = o : o === !0 ? t.setAttribute(i, "") : hl(t, i, o);
        }
    }
  }
  function Bt(t, n, i) {
    switch (n) {
      case "div":
      case "span":
      case "svg":
      case "path":
      case "a":
      case "g":
      case "p":
      case "li":
        break;
      case "img":
        Re("error", t), Re("load", t);
        var o = !1, u = !1, f;
        for (f in i) if (i.hasOwnProperty(f)) {
          var v = i[f];
          if (v != null) switch (f) {
            case "src":
              o = !0;
              break;
            case "srcSet":
              u = !0;
              break;
            case "children":
            case "dangerouslySetInnerHTML":
              throw Error(s(137, n));
            default:
              Ve(t, n, f, v, i, null);
          }
        }
        u && Ve(t, n, "srcSet", i.srcSet, i, null), o && Ve(t, n, "src", i.src, i, null);
        return;
      case "input":
        Re("invalid", t);
        var S = f = v = u = null, R = null, I = null;
        for (o in i) if (i.hasOwnProperty(o)) {
          var X = i[o];
          if (X != null) switch (o) {
            case "name":
              u = X;
              break;
            case "type":
              v = X;
              break;
            case "checked":
              R = X;
              break;
            case "defaultChecked":
              I = X;
              break;
            case "value":
              f = X;
              break;
            case "defaultValue":
              S = X;
              break;
            case "children":
            case "dangerouslySetInnerHTML":
              if (X != null) throw Error(s(137, n));
              break;
            default:
              Ve(t, n, o, X, i, null);
          }
        }
        Zh(t, f, S, R, I, v, u, !1);
        return;
      case "select":
        Re("invalid", t), o = v = f = null;
        for (u in i) if (i.hasOwnProperty(u) && (S = i[u], S != null)) switch (u) {
          case "value":
            f = S;
            break;
          case "defaultValue":
            v = S;
            break;
          case "multiple":
            o = S;
          default:
            Ve(t, n, u, S, i, null);
        }
        n = f, i = v, t.multiple = !!o, n != null ? Fi(t, !!o, n, !1) : i != null && Fi(t, !!o, i, !0);
        return;
      case "textarea":
        Re("invalid", t), f = u = o = null;
        for (v in i) if (i.hasOwnProperty(v) && (S = i[v], S != null)) switch (v) {
          case "value":
            o = S;
            break;
          case "defaultValue":
            u = S;
            break;
          case "children":
            f = S;
            break;
          case "dangerouslySetInnerHTML":
            if (S != null) throw Error(s(91));
            break;
          default:
            Ve(t, n, v, S, i, null);
        }
        Vh(t, o, u, f);
        return;
      case "option":
        for (R in i) i.hasOwnProperty(R) && (o = i[R], o != null) && (R === "selected" ? t.selected = o && typeof o != "function" && typeof o != "symbol" : Ve(t, n, R, o, i, null));
        return;
      case "dialog":
        Re("beforetoggle", t), Re("toggle", t), Re("cancel", t), Re("close", t);
        break;
      case "iframe":
      case "object":
        Re("load", t);
        break;
      case "video":
      case "audio":
        for (o = 0; o < No.length; o++) Re(No[o], t);
        break;
      case "image":
        Re("error", t), Re("load", t);
        break;
      case "details":
        Re("toggle", t);
        break;
      case "embed":
      case "source":
      case "link":
        Re("error", t), Re("load", t);
      case "area":
      case "base":
      case "br":
      case "col":
      case "hr":
      case "keygen":
      case "meta":
      case "param":
      case "track":
      case "wbr":
      case "menuitem":
        for (I in i) if (i.hasOwnProperty(I) && (o = i[I], o != null)) switch (I) {
          case "children":
          case "dangerouslySetInnerHTML":
            throw Error(s(137, n));
          default:
            Ve(t, n, I, o, i, null);
        }
        return;
      default:
        if (Hu(n)) {
          for (X in i) i.hasOwnProperty(X) && (o = i[X], o !== void 0 && wf(t, n, X, o, i, void 0));
          return;
        }
    }
    for (S in i) i.hasOwnProperty(S) && (o = i[S], o != null && Ve(t, n, S, o, i, null));
  }
  function Y2(t, n, i, o) {
    switch (n) {
      case "div":
      case "span":
      case "svg":
      case "path":
      case "a":
      case "g":
      case "p":
      case "li":
        break;
      case "input":
        var u = null, f = null, v = null, S = null, R = null, I = null, X = null;
        for (G in i) {
          var J = i[G];
          if (i.hasOwnProperty(G) && J != null) switch (G) {
            case "checked":
              break;
            case "value":
              break;
            case "defaultValue":
              R = J;
            default:
              o.hasOwnProperty(G) || Ve(t, n, G, null, o, J);
          }
        }
        for (var Z in o) {
          var G = o[Z];
          if (J = i[Z], o.hasOwnProperty(Z) && (G != null || J != null)) switch (Z) {
            case "type":
              f = G;
              break;
            case "name":
              u = G;
              break;
            case "checked":
              I = G;
              break;
            case "defaultChecked":
              X = G;
              break;
            case "value":
              v = G;
              break;
            case "defaultValue":
              S = G;
              break;
            case "children":
            case "dangerouslySetInnerHTML":
              if (G != null) throw Error(s(137, n));
              break;
            default:
              G !== J && Ve(t, n, Z, G, o, J);
          }
        }
        zu(t, v, S, R, I, X, f, u);
        return;
      case "select":
        G = v = S = Z = null;
        for (f in i) if (R = i[f], i.hasOwnProperty(f) && R != null) switch (f) {
          case "value":
            break;
          case "multiple":
            G = R;
          default:
            o.hasOwnProperty(f) || Ve(t, n, f, null, o, R);
        }
        for (u in o) if (f = o[u], R = i[u], o.hasOwnProperty(u) && (f != null || R != null)) switch (u) {
          case "value":
            Z = f;
            break;
          case "defaultValue":
            S = f;
            break;
          case "multiple":
            v = f;
          default:
            f !== R && Ve(t, n, u, f, o, R);
        }
        n = S, i = v, o = G, Z != null ? Fi(t, !!i, Z, !1) : !!o != !!i && (n != null ? Fi(t, !!i, n, !0) : Fi(t, !!i, i ? [] : "", !1));
        return;
      case "textarea":
        G = Z = null;
        for (S in i) if (u = i[S], i.hasOwnProperty(S) && u != null && !o.hasOwnProperty(S)) switch (S) {
          case "value":
            break;
          case "children":
            break;
          default:
            Ve(t, n, S, null, o, u);
        }
        for (v in o) if (u = o[v], f = i[v], o.hasOwnProperty(v) && (u != null || f != null)) switch (v) {
          case "value":
            Z = u;
            break;
          case "defaultValue":
            G = u;
            break;
          case "children":
            break;
          case "dangerouslySetInnerHTML":
            if (u != null) throw Error(s(91));
            break;
          default:
            u !== f && Ve(t, n, v, u, o, f);
        }
        Gh(t, Z, G);
        return;
      case "option":
        for (var he in i) Z = i[he], i.hasOwnProperty(he) && Z != null && !o.hasOwnProperty(he) && (he === "selected" ? t.selected = !1 : Ve(t, n, he, null, o, Z));
        for (R in o) Z = o[R], G = i[R], o.hasOwnProperty(R) && Z !== G && (Z != null || G != null) && (R === "selected" ? t.selected = Z && typeof Z != "function" && typeof Z != "symbol" : Ve(t, n, R, Z, o, G));
        return;
      case "img":
      case "link":
      case "area":
      case "base":
      case "br":
      case "col":
      case "embed":
      case "hr":
      case "keygen":
      case "meta":
      case "param":
      case "source":
      case "track":
      case "wbr":
      case "menuitem":
        for (var we in i) Z = i[we], i.hasOwnProperty(we) && Z != null && !o.hasOwnProperty(we) && Ve(t, n, we, null, o, Z);
        for (I in o) if (Z = o[I], G = i[I], o.hasOwnProperty(I) && Z !== G && (Z != null || G != null)) switch (I) {
          case "children":
          case "dangerouslySetInnerHTML":
            if (Z != null) throw Error(s(137, n));
            break;
          default:
            Ve(t, n, I, Z, o, G);
        }
        return;
      default:
        if (Hu(n)) {
          for (var $e in i) Z = i[$e], i.hasOwnProperty($e) && Z !== void 0 && !o.hasOwnProperty($e) && wf(t, n, $e, void 0, o, Z);
          for (X in o) Z = o[X], G = i[X], !o.hasOwnProperty(X) || Z === G || Z === void 0 && G === void 0 || wf(t, n, X, Z, o, G);
          return;
        }
    }
    for (var U in i) Z = i[U], i.hasOwnProperty(U) && Z != null && !o.hasOwnProperty(U) && Ve(t, n, U, null, o, Z);
    for (J in o) Z = o[J], G = i[J], !o.hasOwnProperty(J) || Z === G || Z == null && G == null || Ve(t, n, J, Z, o, G);
  }
  function $v(t) {
    switch (t) {
      case "css":
      case "script":
      case "font":
      case "img":
      case "image":
      case "input":
      case "link":
        return !0;
      default:
        return !1;
    }
  }
  function W2() {
    if (typeof performance.getEntriesByType == "function") {
      for (var t = 0, n = 0, i = performance.getEntriesByType("resource"), o = 0; o < i.length; o++) {
        var u = i[o], f = u.transferSize, v = u.initiatorType, S = u.duration;
        if (f && S && $v(v)) {
          for (v = 0, S = u.responseEnd, o += 1; o < i.length; o++) {
            var R = i[o], I = R.startTime;
            if (I > S) break;
            var X = R.transferSize, J = R.initiatorType;
            X && $v(J) && (R = R.responseEnd, v += X * (R < S ? 1 : (S - I) / (R - I)));
          }
          if (--o, n += 8 * (f + v) / (u.duration / 1e3), t++, 10 < t) break;
        }
      }
      if (0 < t) return n / t / 1e6;
    }
    return navigator.connection && (t = navigator.connection.downlink, typeof t == "number") ? t : 5;
  }
  var Sf = null, Ef = null;
  function fs(t) {
    return t.nodeType === 9 ? t : t.ownerDocument;
  }
  function Fv(t) {
    switch (t) {
      case "http://www.w3.org/2000/svg":
        return 1;
      case "http://www.w3.org/1998/Math/MathML":
        return 2;
      default:
        return 0;
    }
  }
  function qv(t, n) {
    if (t === 0) switch (n) {
      case "svg":
        return 1;
      case "math":
        return 2;
      default:
        return 0;
    }
    return t === 1 && n === "foreignObject" ? 0 : t;
  }
  function Tf(t, n) {
    return t === "textarea" || t === "noscript" || typeof n.children == "string" || typeof n.children == "number" || typeof n.children == "bigint" || typeof n.dangerouslySetInnerHTML == "object" && n.dangerouslySetInnerHTML !== null && n.dangerouslySetInnerHTML.__html != null;
  }
  var Cf = null;
  function Q2() {
    var t = window.event;
    return t && t.type === "popstate" ? t === Cf ? !1 : (Cf = t, !0) : (Cf = null, !1);
  }
  var Xv = typeof setTimeout == "function" ? setTimeout : void 0, K2 = typeof clearTimeout == "function" ? clearTimeout : void 0, Yv = typeof Promise == "function" ? Promise : void 0, J2 = typeof queueMicrotask == "function" ? queueMicrotask : typeof Yv < "u" ? function(t) {
    return Yv.resolve(null).then(t).catch(ew);
  } : Xv;
  function ew(t) {
    setTimeout(function() {
      throw t;
    });
  }
  function Fa(t) {
    return t === "head";
  }
  function Wv(t, n) {
    var i = n, o = 0;
    do {
      var u = i.nextSibling;
      if (t.removeChild(i), u && u.nodeType === 8) if (i = u.data, i === "/$" || i === "/&") {
        if (o === 0) {
          t.removeChild(u), Tr(n);
          return;
        }
        o--;
      } else if (i === "$" || i === "$?" || i === "$~" || i === "$!" || i === "&") o++;
      else if (i === "html") zo(t.ownerDocument.documentElement);
      else if (i === "head") {
        i = t.ownerDocument.head, zo(i);
        for (var f = i.firstChild; f; ) {
          var v = f.nextSibling, S = f.nodeName;
          f[Wr] || S === "SCRIPT" || S === "STYLE" || S === "LINK" && f.rel.toLowerCase() === "stylesheet" || i.removeChild(f), f = v;
        }
      } else i === "body" && zo(t.ownerDocument.body);
      i = u;
    } while (i);
    Tr(n);
  }
  function Qv(t, n) {
    var i = t;
    t = 0;
    do {
      var o = i.nextSibling;
      if (i.nodeType === 1 ? n ? (i._stashedDisplay = i.style.display, i.style.display = "none") : (i.style.display = i._stashedDisplay || "", i.getAttribute("style") === "" && i.removeAttribute("style")) : i.nodeType === 3 && (n ? (i._stashedText = i.nodeValue, i.nodeValue = "") : i.nodeValue = i._stashedText || ""), o && o.nodeType === 8) if (i = o.data, i === "/$") {
        if (t === 0) break;
        t--;
      } else i !== "$" && i !== "$?" && i !== "$~" && i !== "$!" || t++;
      i = o;
    } while (i);
  }
  function Af(t) {
    var n = t.firstChild;
    for (n && n.nodeType === 10 && (n = n.nextSibling); n; ) {
      var i = n;
      switch (n = n.nextSibling, i.nodeName) {
        case "HTML":
        case "HEAD":
        case "BODY":
          Af(i), Nu(i);
          continue;
        case "SCRIPT":
        case "STYLE":
          continue;
        case "LINK":
          if (i.rel.toLowerCase() === "stylesheet") continue;
      }
      t.removeChild(i);
    }
  }
  function tw(t, n, i, o) {
    for (; t.nodeType === 1; ) {
      var u = i;
      if (t.nodeName.toLowerCase() !== n.toLowerCase()) {
        if (!o && (t.nodeName !== "INPUT" || t.type !== "hidden")) break;
      } else if (o) {
        if (!t[Wr]) switch (n) {
          case "meta":
            if (!t.hasAttribute("itemprop")) break;
            return t;
          case "link":
            if (f = t.getAttribute("rel"), f === "stylesheet" && t.hasAttribute("data-precedence")) break;
            if (f !== u.rel || t.getAttribute("href") !== (u.href == null || u.href === "" ? null : u.href) || t.getAttribute("crossorigin") !== (u.crossOrigin == null ? null : u.crossOrigin) || t.getAttribute("title") !== (u.title == null ? null : u.title)) break;
            return t;
          case "style":
            if (t.hasAttribute("data-precedence")) break;
            return t;
          case "script":
            if (f = t.getAttribute("src"), (f !== (u.src == null ? null : u.src) || t.getAttribute("type") !== (u.type == null ? null : u.type) || t.getAttribute("crossorigin") !== (u.crossOrigin == null ? null : u.crossOrigin)) && f && t.hasAttribute("async") && !t.hasAttribute("itemprop")) break;
            return t;
          default:
            return t;
        }
      } else if (n === "input" && t.type === "hidden") {
        var f = u.name == null ? null : "" + u.name;
        if (u.type === "hidden" && t.getAttribute("name") === f) return t;
      } else return t;
      if (t = Nn(t.nextSibling), t === null) break;
    }
    return null;
  }
  function nw(t, n, i) {
    if (n === "") return null;
    for (; t.nodeType !== 3; )
      if ((t.nodeType !== 1 || t.nodeName !== "INPUT" || t.type !== "hidden") && !i || (t = Nn(t.nextSibling), t === null)) return null;
    return t;
  }
  function Kv(t, n) {
    for (; t.nodeType !== 8; )
      if ((t.nodeType !== 1 || t.nodeName !== "INPUT" || t.type !== "hidden") && !n || (t = Nn(t.nextSibling), t === null)) return null;
    return t;
  }
  function xf(t) {
    return t.data === "$?" || t.data === "$~";
  }
  function Of(t) {
    return t.data === "$!" || t.data === "$?" && t.ownerDocument.readyState !== "loading";
  }
  function aw(t, n) {
    var i = t.ownerDocument;
    if (t.data === "$~") t._reactRetry = n;
    else if (t.data !== "$?" || i.readyState !== "loading") n();
    else {
      var o = function() {
        n(), i.removeEventListener("DOMContentLoaded", o);
      };
      i.addEventListener("DOMContentLoaded", o), t._reactRetry = o;
    }
  }
  function Nn(t) {
    for (; t != null; t = t.nextSibling) {
      var n = t.nodeType;
      if (n === 1 || n === 3) break;
      if (n === 8) {
        if (n = t.data, n === "$" || n === "$!" || n === "$?" || n === "$~" || n === "&" || n === "F!" || n === "F") break;
        if (n === "/$" || n === "/&") return null;
      }
    }
    return t;
  }
  var Mf = null;
  function Jv(t) {
    t = t.nextSibling;
    for (var n = 0; t; ) {
      if (t.nodeType === 8) {
        var i = t.data;
        if (i === "/$" || i === "/&") {
          if (n === 0) return Nn(t.nextSibling);
          n--;
        } else i !== "$" && i !== "$!" && i !== "$?" && i !== "$~" && i !== "&" || n++;
      }
      t = t.nextSibling;
    }
    return null;
  }
  function e0(t) {
    t = t.previousSibling;
    for (var n = 0; t; ) {
      if (t.nodeType === 8) {
        var i = t.data;
        if (i === "$" || i === "$!" || i === "$?" || i === "$~" || i === "&") {
          if (n === 0) return t;
          n--;
        } else i !== "/$" && i !== "/&" || n++;
      }
      t = t.previousSibling;
    }
    return null;
  }
  function t0(t, n, i) {
    switch (n = fs(i), t) {
      case "html":
        if (t = n.documentElement, !t) throw Error(s(452));
        return t;
      case "head":
        if (t = n.head, !t) throw Error(s(453));
        return t;
      case "body":
        if (t = n.body, !t) throw Error(s(454));
        return t;
      default:
        throw Error(s(451));
    }
  }
  function zo(t) {
    for (var n = t.attributes; n.length; ) t.removeAttributeNode(n[0]);
    Nu(t);
  }
  var Dn = /* @__PURE__ */ new Map(), n0 = /* @__PURE__ */ new Set();
  function ds(t) {
    return typeof t.getRootNode == "function" ? t.getRootNode() : t.nodeType === 9 ? t : t.ownerDocument;
  }
  var Ea = N.d;
  N.d = {
    f: iw,
    r: rw,
    D: ow,
    C: lw,
    L: sw,
    m: uw,
    X: fw,
    S: cw,
    M: dw
  };
  function iw() {
    var t = Ea.f(), n = as();
    return t || n;
  }
  function rw(t) {
    var n = Gi(t);
    n !== null && n.tag === 5 && n.type === "form" ? wp(n) : Ea.r(t);
  }
  var wr = typeof document > "u" ? null : document;
  function a0(t, n, i) {
    var o = wr;
    if (o && typeof n == "string" && n) {
      var u = En(n);
      u = 'link[rel="' + t + '"][href="' + u + '"]', typeof i == "string" && (u += '[crossorigin="' + i + '"]'), n0.has(u) || (n0.add(u), t = {
        rel: t,
        crossOrigin: i,
        href: n
      }, o.querySelector(u) === null && (n = o.createElement("link"), Bt(n, "link", t), Rt(n), o.head.appendChild(n)));
    }
  }
  function ow(t) {
    Ea.D(t), a0("dns-prefetch", t, null);
  }
  function lw(t, n) {
    Ea.C(t, n), a0("preconnect", t, n);
  }
  function sw(t, n, i) {
    Ea.L(t, n, i);
    var o = wr;
    if (o && t && n) {
      var u = 'link[rel="preload"][as="' + En(n) + '"]';
      n === "image" && i && i.imageSrcSet ? (u += '[imagesrcset="' + En(i.imageSrcSet) + '"]', typeof i.imageSizes == "string" && (u += '[imagesizes="' + En(i.imageSizes) + '"]')) : u += '[href="' + En(t) + '"]';
      var f = u;
      switch (n) {
        case "style":
          f = Sr(t);
          break;
        case "script":
          f = Er(t);
      }
      Dn.has(f) || (t = w({
        rel: "preload",
        href: n === "image" && i && i.imageSrcSet ? void 0 : t,
        as: n
      }, i), Dn.set(f, t), o.querySelector(u) !== null || n === "style" && o.querySelector(Lo(f)) || n === "script" && o.querySelector(Ho(f)) || (n = o.createElement("link"), Bt(n, "link", t), Rt(n), o.head.appendChild(n)));
    }
  }
  function uw(t, n) {
    Ea.m(t, n);
    var i = wr;
    if (i && t) {
      var o = n && typeof n.as == "string" ? n.as : "script", u = 'link[rel="modulepreload"][as="' + En(o) + '"][href="' + En(t) + '"]', f = u;
      switch (o) {
        case "audioworklet":
        case "paintworklet":
        case "serviceworker":
        case "sharedworker":
        case "worker":
        case "script":
          f = Er(t);
      }
      if (!Dn.has(f) && (t = w({
        rel: "modulepreload",
        href: t
      }, n), Dn.set(f, t), i.querySelector(u) === null)) {
        switch (o) {
          case "audioworklet":
          case "paintworklet":
          case "serviceworker":
          case "sharedworker":
          case "worker":
          case "script":
            if (i.querySelector(Ho(f))) return;
        }
        o = i.createElement("link"), Bt(o, "link", t), Rt(o), i.head.appendChild(o);
      }
    }
  }
  function cw(t, n, i) {
    Ea.S(t, n, i);
    var o = wr;
    if (o && t) {
      var u = Vi(o).hoistableStyles, f = Sr(t);
      n = n || "default";
      var v = u.get(f);
      if (!v) {
        var S = {
          loading: 0,
          preload: null
        };
        if (v = o.querySelector(Lo(f))) S.loading = 5;
        else {
          t = w({
            rel: "stylesheet",
            href: t,
            "data-precedence": n
          }, i), (i = Dn.get(f)) && Rf(t, i);
          var R = v = o.createElement("link");
          Rt(R), Bt(R, "link", t), R._p = new Promise(function(I, X) {
            R.onload = I, R.onerror = X;
          }), R.addEventListener("load", function() {
            S.loading |= 1;
          }), R.addEventListener("error", function() {
            S.loading |= 2;
          }), S.loading |= 4, hs(v, n, o);
        }
        v = {
          type: "stylesheet",
          instance: v,
          count: 1,
          state: S
        }, u.set(f, v);
      }
    }
  }
  function fw(t, n) {
    Ea.X(t, n);
    var i = wr;
    if (i && t) {
      var o = Vi(i).hoistableScripts, u = Er(t), f = o.get(u);
      f || (f = i.querySelector(Ho(u)), f || (t = w({
        src: t,
        async: !0
      }, n), (n = Dn.get(u)) && Nf(t, n), f = i.createElement("script"), Rt(f), Bt(f, "link", t), i.head.appendChild(f)), f = {
        type: "script",
        instance: f,
        count: 1,
        state: null
      }, o.set(u, f));
    }
  }
  function dw(t, n) {
    Ea.M(t, n);
    var i = wr;
    if (i && t) {
      var o = Vi(i).hoistableScripts, u = Er(t), f = o.get(u);
      f || (f = i.querySelector(Ho(u)), f || (t = w({
        src: t,
        async: !0,
        type: "module"
      }, n), (n = Dn.get(u)) && Nf(t, n), f = i.createElement("script"), Rt(f), Bt(f, "link", t), i.head.appendChild(f)), f = {
        type: "script",
        instance: f,
        count: 1,
        state: null
      }, o.set(u, f));
    }
  }
  function i0(t, n, i, o) {
    var u = (u = _e.current) ? ds(u) : null;
    if (!u) throw Error(s(446));
    switch (t) {
      case "meta":
      case "title":
        return null;
      case "style":
        return typeof i.precedence == "string" && typeof i.href == "string" ? (n = Sr(i.href), i = Vi(u).hoistableStyles, o = i.get(n), o || (o = {
          type: "style",
          instance: null,
          count: 0,
          state: null
        }, i.set(n, o)), o) : {
          type: "void",
          instance: null,
          count: 0,
          state: null
        };
      case "link":
        if (i.rel === "stylesheet" && typeof i.href == "string" && typeof i.precedence == "string") {
          t = Sr(i.href);
          var f = Vi(u).hoistableStyles, v = f.get(t);
          if (v || (u = u.ownerDocument || u, v = {
            type: "stylesheet",
            instance: null,
            count: 0,
            state: {
              loading: 0,
              preload: null
            }
          }, f.set(t, v), (f = u.querySelector(Lo(t))) && !f._p && (v.instance = f, v.state.loading = 5), Dn.has(t) || (i = {
            rel: "preload",
            as: "style",
            href: i.href,
            crossOrigin: i.crossOrigin,
            integrity: i.integrity,
            media: i.media,
            hrefLang: i.hrefLang,
            referrerPolicy: i.referrerPolicy
          }, Dn.set(t, i), f || hw(u, t, i, v.state))), n && o === null) throw Error(s(528, ""));
          return v;
        }
        if (n && o !== null) throw Error(s(529, ""));
        return null;
      case "script":
        return n = i.async, i = i.src, typeof i == "string" && n && typeof n != "function" && typeof n != "symbol" ? (n = Er(i), i = Vi(u).hoistableScripts, o = i.get(n), o || (o = {
          type: "script",
          instance: null,
          count: 0,
          state: null
        }, i.set(n, o)), o) : {
          type: "void",
          instance: null,
          count: 0,
          state: null
        };
      default:
        throw Error(s(444, t));
    }
  }
  function Sr(t) {
    return 'href="' + En(t) + '"';
  }
  function Lo(t) {
    return 'link[rel="stylesheet"][' + t + "]";
  }
  function r0(t) {
    return w({}, t, {
      "data-precedence": t.precedence,
      precedence: null
    });
  }
  function hw(t, n, i, o) {
    t.querySelector('link[rel="preload"][as="style"][' + n + "]") ? o.loading = 1 : (n = t.createElement("link"), o.preload = n, n.addEventListener("load", function() {
      return o.loading |= 1;
    }), n.addEventListener("error", function() {
      return o.loading |= 2;
    }), Bt(n, "link", i), Rt(n), t.head.appendChild(n));
  }
  function Er(t) {
    return '[src="' + En(t) + '"]';
  }
  function Ho(t) {
    return "script[async]" + t;
  }
  function o0(t, n, i) {
    if (n.count++, n.instance === null) switch (n.type) {
      case "style":
        var o = t.querySelector('style[data-href~="' + En(i.href) + '"]');
        if (o) return n.instance = o, Rt(o), o;
        var u = w({}, i, {
          "data-href": i.href,
          "data-precedence": i.precedence,
          href: null,
          precedence: null
        });
        return o = (t.ownerDocument || t).createElement("style"), Rt(o), Bt(o, "style", u), hs(o, i.precedence, t), n.instance = o;
      case "stylesheet":
        u = Sr(i.href);
        var f = t.querySelector(Lo(u));
        if (f) return n.state.loading |= 4, n.instance = f, Rt(f), f;
        o = r0(i), (u = Dn.get(u)) && Rf(o, u), f = (t.ownerDocument || t).createElement("link"), Rt(f);
        var v = f;
        return v._p = new Promise(function(S, R) {
          v.onload = S, v.onerror = R;
        }), Bt(f, "link", o), n.state.loading |= 4, hs(f, i.precedence, t), n.instance = f;
      case "script":
        return f = Er(i.src), (u = t.querySelector(Ho(f))) ? (n.instance = u, Rt(u), u) : (o = i, (u = Dn.get(f)) && (o = w({}, i), Nf(o, u)), t = t.ownerDocument || t, u = t.createElement("script"), Rt(u), Bt(u, "link", o), t.head.appendChild(u), n.instance = u);
      case "void":
        return null;
      default:
        throw Error(s(443, n.type));
    }
    else n.type === "stylesheet" && (n.state.loading & 4) === 0 && (o = n.instance, n.state.loading |= 4, hs(o, i.precedence, t));
    return n.instance;
  }
  function hs(t, n, i) {
    for (var o = i.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'), u = o.length ? o[o.length - 1] : null, f = u, v = 0; v < o.length; v++) {
      var S = o[v];
      if (S.dataset.precedence === n) f = S;
      else if (f !== u) break;
    }
    f ? f.parentNode.insertBefore(t, f.nextSibling) : (n = i.nodeType === 9 ? i.head : i, n.insertBefore(t, n.firstChild));
  }
  function Rf(t, n) {
    t.crossOrigin ??= n.crossOrigin, t.referrerPolicy ??= n.referrerPolicy, t.title ??= n.title;
  }
  function Nf(t, n) {
    t.crossOrigin ??= n.crossOrigin, t.referrerPolicy ??= n.referrerPolicy, t.integrity ??= n.integrity;
  }
  var ms = null;
  function l0(t, n, i) {
    if (ms === null) {
      var o = /* @__PURE__ */ new Map(), u = ms = /* @__PURE__ */ new Map();
      u.set(i, o);
    } else u = ms, o = u.get(i), o || (o = /* @__PURE__ */ new Map(), u.set(i, o));
    if (o.has(t)) return o;
    for (o.set(t, null), i = i.getElementsByTagName(t), u = 0; u < i.length; u++) {
      var f = i[u];
      if (!(f[Wr] || f[zt] || t === "link" && f.getAttribute("rel") === "stylesheet") && f.namespaceURI !== "http://www.w3.org/2000/svg") {
        var v = f.getAttribute(n) || "";
        v = t + v;
        var S = o.get(v);
        S ? S.push(f) : o.set(v, [f]);
      }
    }
    return o;
  }
  function s0(t, n, i) {
    t = t.ownerDocument || t, t.head.insertBefore(i, n === "title" ? t.querySelector("head > title") : null);
  }
  function mw(t, n, i) {
    if (i === 1 || n.itemProp != null) return !1;
    switch (t) {
      case "meta":
      case "title":
        return !0;
      case "style":
        if (typeof n.precedence != "string" || typeof n.href != "string" || n.href === "") break;
        return !0;
      case "link":
        if (typeof n.rel != "string" || typeof n.href != "string" || n.href === "" || n.onLoad || n.onError) break;
        return n.rel === "stylesheet" ? (t = n.disabled, typeof n.precedence == "string" && t == null) : !0;
      case "script":
        if (n.async && typeof n.async != "function" && typeof n.async != "symbol" && !n.onLoad && !n.onError && n.src && typeof n.src == "string") return !0;
    }
    return !1;
  }
  function u0(t) {
    return !(t.type === "stylesheet" && (t.state.loading & 3) === 0);
  }
  function pw(t, n, i, o) {
    if (i.type === "stylesheet" && (typeof o.media != "string" || matchMedia(o.media).matches !== !1) && (i.state.loading & 4) === 0) {
      if (i.instance === null) {
        var u = Sr(o.href), f = n.querySelector(Lo(u));
        if (f) {
          n = f._p, n !== null && typeof n == "object" && typeof n.then == "function" && (t.count++, t = ps.bind(t), n.then(t, t)), i.state.loading |= 4, i.instance = f, Rt(f);
          return;
        }
        f = n.ownerDocument || n, o = r0(o), (u = Dn.get(u)) && Rf(o, u), f = f.createElement("link"), Rt(f);
        var v = f;
        v._p = new Promise(function(S, R) {
          v.onload = S, v.onerror = R;
        }), Bt(f, "link", o), i.instance = f;
      }
      t.stylesheets === null && (t.stylesheets = /* @__PURE__ */ new Map()), t.stylesheets.set(i, n), (n = i.state.preload) && (i.state.loading & 3) === 0 && (t.count++, i = ps.bind(t), n.addEventListener("load", i), n.addEventListener("error", i));
    }
  }
  var Df = 0;
  function vw(t, n) {
    return t.stylesheets && t.count === 0 && gs(t, t.stylesheets), 0 < t.count || 0 < t.imgCount ? function(i) {
      var o = setTimeout(function() {
        if (t.stylesheets && gs(t, t.stylesheets), t.unsuspend) {
          var f = t.unsuspend;
          t.unsuspend = null, f();
        }
      }, 6e4 + n);
      0 < t.imgBytes && Df === 0 && (Df = 62500 * W2());
      var u = setTimeout(function() {
        if (t.waitingForImages = !1, t.count === 0 && (t.stylesheets && gs(t, t.stylesheets), t.unsuspend)) {
          var f = t.unsuspend;
          t.unsuspend = null, f();
        }
      }, (t.imgBytes > Df ? 50 : 800) + n);
      return t.unsuspend = i, function() {
        t.unsuspend = null, clearTimeout(o), clearTimeout(u);
      };
    } : null;
  }
  function ps() {
    if (this.count--, this.count === 0 && (this.imgCount === 0 || !this.waitingForImages)) {
      if (this.stylesheets) gs(this, this.stylesheets);
      else if (this.unsuspend) {
        var t = this.unsuspend;
        this.unsuspend = null, t();
      }
    }
  }
  var vs = null;
  function gs(t, n) {
    t.stylesheets = null, t.unsuspend !== null && (t.count++, vs = /* @__PURE__ */ new Map(), n.forEach(gw, t), vs = null, ps.call(t));
  }
  function gw(t, n) {
    if (!(n.state.loading & 4)) {
      var i = vs.get(t);
      if (i) var o = i.get(null);
      else {
        i = /* @__PURE__ */ new Map(), vs.set(t, i);
        for (var u = t.querySelectorAll("link[data-precedence],style[data-precedence]"), f = 0; f < u.length; f++) {
          var v = u[f];
          (v.nodeName === "LINK" || v.getAttribute("media") !== "not all") && (i.set(v.dataset.precedence, v), o = v);
        }
        o && i.set(null, o);
      }
      u = n.instance, v = u.getAttribute("data-precedence"), f = i.get(v) || o, f === o && i.set(null, u), i.set(v, u), this.count++, o = ps.bind(this), u.addEventListener("load", o), u.addEventListener("error", o), f ? f.parentNode.insertBefore(u, f.nextSibling) : (t = t.nodeType === 9 ? t.head : t, t.insertBefore(u, t.firstChild)), n.state.loading |= 4;
    }
  }
  var jo = {
    $$typeof: H,
    Provider: null,
    Consumer: null,
    _currentValue: te,
    _currentValue2: te,
    _threadCount: 0
  };
  function yw(t, n, i, o, u, f, v, S, R) {
    this.tag = 1, this.containerInfo = t, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = qr(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = qr(0), this.hiddenUpdates = qr(null), this.identifierPrefix = o, this.onUncaughtError = u, this.onCaughtError = f, this.onRecoverableError = v, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = R, this.incompleteTransitions = /* @__PURE__ */ new Map();
  }
  function bw(t, n, i, o, u, f, v, S, R, I, X, J) {
    return t = new yw(t, n, i, v, R, I, X, J, S), n = 1, f === !0 && (n |= 24), f = un(3, null, null, n), t.current = f, f.stateNode = t, n = fc(), n.refCount++, t.pooledCache = n, n.refCount++, f.memoizedState = {
      element: o,
      isDehydrated: i,
      cache: n
    }, pc(f), t;
  }
  function _w(t) {
    return t ? (t = er, t) : er;
  }
  function c0(t, n, i, o, u, f) {
    u = _w(u), o.context === null ? o.context = u : o.pendingContext = u, o = Si(n), o.payload = { element: i }, f = f === void 0 ? null : f, f !== null && (o.callback = f), i = Ei(t, o, n), i !== null && (tn(i, t, n), mo(i, t, n));
  }
  function f0(t, n) {
    if (t = t.memoizedState, t !== null && t.dehydrated !== null) {
      var i = t.retryLane;
      t.retryLane = i !== 0 && i < n ? i : n;
    }
  }
  function zf(t, n) {
    f0(t, n), (t = t.alternate) && f0(t, n);
  }
  function d0(t) {
    if (t.tag === 13 || t.tag === 31) {
      var n = hi(t, 67108864);
      n !== null && tn(n, t, 67108864), zf(t, 67108864);
    }
  }
  function h0(t) {
    if (t.tag === 13 || t.tag === 31) {
      var n = Rn();
      n = Dh(n);
      var i = hi(t, n);
      i !== null && tn(i, t, n), zf(t, n);
    }
  }
  var ys = !0;
  function ww(t, n, i, o) {
    var u = A.T;
    A.T = null;
    var f = N.p;
    try {
      N.p = 2, Lf(t, n, i, o);
    } finally {
      N.p = f, A.T = u;
    }
  }
  function Sw(t, n, i, o) {
    var u = A.T;
    A.T = null;
    var f = N.p;
    try {
      N.p = 8, Lf(t, n, i, o);
    } finally {
      N.p = f, A.T = u;
    }
  }
  function Lf(t, n, i, o) {
    if (ys) {
      var u = Hf(o);
      if (u === null) _f(t, n, o, bs, i), p0(t, o);
      else if (Tw(u, t, n, i, o)) o.stopPropagation();
      else if (p0(t, o), n & 4 && -1 < Ew.indexOf(t)) {
        for (; u !== null; ) {
          var f = Gi(u);
          if (f !== null) switch (f.tag) {
            case 3:
              if (f = f.stateNode, f.current.memoizedState.isDehydrated) {
                var v = Tt(f.pendingLanes);
                if (v !== 0) {
                  var S = f;
                  for (S.pendingLanes |= 2, S.entangledLanes |= 2; v; ) {
                    var R = 1 << 31 - ae(v);
                    S.entanglements[1] |= R, v &= ~R;
                  }
                  Sa(f), (Pe & 6) === 0 && (ts = xt() + 500, Ro(0, !1));
                }
              }
              break;
            case 31:
            case 13:
              S = hi(f, 2), S !== null && tn(S, f, 2), as(), zf(f, 2);
          }
          if (f = Hf(o), f === null && _f(t, n, o, bs, i), f === u) break;
          u = f;
        }
        u !== null && o.stopPropagation();
      } else _f(t, n, o, null, i);
    }
  }
  function Hf(t) {
    return t = Bu(t), jf(t);
  }
  var bs = null;
  function jf(t) {
    if (bs = null, t = Zi(t), t !== null) {
      var n = d(t);
      if (n === null) t = null;
      else {
        var i = n.tag;
        if (i === 13) {
          if (t = h(n), t !== null) return t;
          t = null;
        } else if (i === 31) {
          if (t = m(n), t !== null) return t;
          t = null;
        } else if (i === 3) {
          if (n.stateNode.current.memoizedState.isDehydrated) return n.tag === 3 ? n.stateNode.containerInfo : null;
          t = null;
        } else n !== t && (t = null);
      }
    }
    return bs = t, null;
  }
  function m0(t) {
    switch (t) {
      case "beforetoggle":
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "toggle":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 2;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 8;
      case "message":
        switch (ve()) {
          case Ot:
            return 2;
          case Ut:
            return 8;
          case kt:
          case Fr:
            return 32;
          case ul:
            return 268435456;
          default:
            return 32;
        }
      default:
        return 32;
    }
  }
  var Bf = !1, qa = null, Xa = null, Ya = null, Bo = /* @__PURE__ */ new Map(), Uo = /* @__PURE__ */ new Map(), Wa = [], Ew = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");
  function p0(t, n) {
    switch (t) {
      case "focusin":
      case "focusout":
        qa = null;
        break;
      case "dragenter":
      case "dragleave":
        Xa = null;
        break;
      case "mouseover":
      case "mouseout":
        Ya = null;
        break;
      case "pointerover":
      case "pointerout":
        Bo.delete(n.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        Uo.delete(n.pointerId);
    }
  }
  function ko(t, n, i, o, u, f) {
    return t === null || t.nativeEvent !== f ? (t = {
      blockedOn: n,
      domEventName: i,
      eventSystemFlags: o,
      nativeEvent: f,
      targetContainers: [u]
    }, n !== null && (n = Gi(n), n !== null && d0(n)), t) : (t.eventSystemFlags |= o, n = t.targetContainers, u !== null && n.indexOf(u) === -1 && n.push(u), t);
  }
  function Tw(t, n, i, o, u) {
    switch (n) {
      case "focusin":
        return qa = ko(qa, t, n, i, o, u), !0;
      case "dragenter":
        return Xa = ko(Xa, t, n, i, o, u), !0;
      case "mouseover":
        return Ya = ko(Ya, t, n, i, o, u), !0;
      case "pointerover":
        var f = u.pointerId;
        return Bo.set(f, ko(Bo.get(f) || null, t, n, i, o, u)), !0;
      case "gotpointercapture":
        return f = u.pointerId, Uo.set(f, ko(Uo.get(f) || null, t, n, i, o, u)), !0;
    }
    return !1;
  }
  function v0(t) {
    var n = Zi(t.target);
    if (n !== null) {
      var i = d(n);
      if (i !== null) {
        if (n = i.tag, n === 13) {
          if (n = h(i), n !== null) {
            t.blockedOn = n, Lh(t.priority, function() {
              h0(i);
            });
            return;
          }
        } else if (n === 31) {
          if (n = m(i), n !== null) {
            t.blockedOn = n, Lh(t.priority, function() {
              h0(i);
            });
            return;
          }
        } else if (n === 3 && i.stateNode.current.memoizedState.isDehydrated) {
          t.blockedOn = i.tag === 3 ? i.stateNode.containerInfo : null;
          return;
        }
      }
    }
    t.blockedOn = null;
  }
  function _s(t) {
    if (t.blockedOn !== null) return !1;
    for (var n = t.targetContainers; 0 < n.length; ) {
      var i = Hf(t.nativeEvent);
      if (i === null) {
        i = t.nativeEvent;
        var o = new i.constructor(i.type, i);
        ju = o, i.target.dispatchEvent(o), ju = null;
      } else return n = Gi(i), n !== null && d0(n), t.blockedOn = i, !1;
      n.shift();
    }
    return !0;
  }
  function g0(t, n, i) {
    _s(t) && i.delete(n);
  }
  function Cw() {
    Bf = !1, qa !== null && _s(qa) && (qa = null), Xa !== null && _s(Xa) && (Xa = null), Ya !== null && _s(Ya) && (Ya = null), Bo.forEach(g0), Uo.forEach(g0);
  }
  function ws(t, n) {
    t.blockedOn === n && (t.blockedOn = null, Bf || (Bf = !0, a.unstable_scheduleCallback(a.unstable_NormalPriority, Cw)));
  }
  var Ss = null;
  function y0(t) {
    Ss !== t && (Ss = t, a.unstable_scheduleCallback(a.unstable_NormalPriority, function() {
      Ss === t && (Ss = null);
      for (var n = 0; n < t.length; n += 3) {
        var i = t[n], o = t[n + 1], u = t[n + 2];
        if (typeof o != "function") {
          if (jf(o || i) === null) continue;
          break;
        }
        var f = Gi(i);
        f !== null && (t.splice(n, 3), n -= 3, Hc(f, {
          pending: !0,
          data: u,
          method: i.method,
          action: o
        }, o, u));
      }
    }));
  }
  function Tr(t) {
    function n(R) {
      return ws(R, t);
    }
    qa !== null && ws(qa, t), Xa !== null && ws(Xa, t), Ya !== null && ws(Ya, t), Bo.forEach(n), Uo.forEach(n);
    for (var i = 0; i < Wa.length; i++) {
      var o = Wa[i];
      o.blockedOn === t && (o.blockedOn = null);
    }
    for (; 0 < Wa.length && (i = Wa[0], i.blockedOn === null); ) v0(i), i.blockedOn === null && Wa.shift();
    if (i = (t.ownerDocument || t).$$reactFormReplay, i != null) for (o = 0; o < i.length; o += 3) {
      var u = i[o], f = i[o + 1], v = u[Yt] || null;
      if (typeof f == "function") v || y0(i);
      else if (v) {
        var S = null;
        if (f && f.hasAttribute("formAction")) {
          if (u = f, v = f[Yt] || null) S = v.formAction;
          else if (jf(u) !== null) continue;
        } else S = v.action;
        typeof S == "function" ? i[o + 1] = S : (i.splice(o, 3), o -= 3), y0(i);
      }
    }
  }
  function Aw() {
    function t(f) {
      f.canIntercept && f.info === "react-transition" && f.intercept({
        handler: function() {
          return new Promise(function(v) {
            return u = v;
          });
        },
        focusReset: "manual",
        scroll: "manual"
      });
    }
    function n() {
      u !== null && (u(), u = null), o || setTimeout(i, 20);
    }
    function i() {
      if (!o && !navigation.transition) {
        var f = navigation.currentEntry;
        f && f.url != null && navigation.navigate(f.url, {
          state: f.getState(),
          info: "react-transition",
          history: "replace"
        });
      }
    }
    if (typeof navigation == "object") {
      var o = !1, u = null;
      return navigation.addEventListener("navigate", t), navigation.addEventListener("navigatesuccess", n), navigation.addEventListener("navigateerror", n), setTimeout(i, 100), function() {
        o = !0, navigation.removeEventListener("navigate", t), navigation.removeEventListener("navigatesuccess", n), navigation.removeEventListener("navigateerror", n), u !== null && (u(), u = null);
      };
    }
  }
  function Uf(t) {
    this._internalRoot = t;
  }
  kf.prototype.render = Uf.prototype.render = function(t) {
    var n = this._internalRoot;
    if (n === null) throw Error(s(409));
    var i = n.current;
    c0(i, Rn(), t, n, null, null);
  }, kf.prototype.unmount = Uf.prototype.unmount = function() {
    var t = this._internalRoot;
    if (t !== null) {
      this._internalRoot = null;
      var n = t.containerInfo;
      c0(t.current, 2, null, t, null, null), as(), n[Yr] = null;
    }
  };
  function kf(t) {
    this._internalRoot = t;
  }
  kf.prototype.unstable_scheduleHydration = function(t) {
    if (t) {
      var n = zh();
      t = {
        blockedOn: null,
        target: t,
        priority: n
      };
      for (var i = 0; i < Wa.length && n !== 0 && n < Wa[i].priority; i++) ;
      Wa.splice(i, 0, t), i === 0 && v0(t);
    }
  };
  var b0 = r.version;
  if (b0 !== "19.2.8") throw Error(s(527, b0, "19.2.8"));
  N.findDOMNode = function(t) {
    var n = t._reactInternals;
    if (n === void 0)
      throw typeof t.render == "function" ? Error(s(188)) : (t = Object.keys(t).join(","), Error(s(268, t)));
    return t = p(n), t = t !== null ? _(t) : null, t = t === null ? null : t.stateNode, t;
  };
  var xw = {
    bundleType: 0,
    version: "19.2.8",
    rendererPackageName: "react-dom",
    currentDispatcherRef: A,
    reconcilerVersion: "19.2.8"
  };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var Es = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Es.isDisabled && Es.supportsFiber) try {
      si = Es.inject(xw), Zt = Es;
    } catch {
    }
  }
  e.createRoot = function(t, n) {
    if (!c(t)) throw Error(s(299));
    var i = !1, o = "", u = S2, f = E2, v = T2;
    return n != null && (n.unstable_strictMode === !0 && (i = !0), n.identifierPrefix !== void 0 && (o = n.identifierPrefix), n.onUncaughtError !== void 0 && (u = n.onUncaughtError), n.onCaughtError !== void 0 && (f = n.onCaughtError), n.onRecoverableError !== void 0 && (v = n.onRecoverableError)), n = bw(t, 1, !1, null, null, i, o, null, u, f, v, Aw), t[Yr] = n.current, Pv(t), new Uf(n);
  };
})), v7 = /* @__PURE__ */ bn(((e, a) => {
  function r() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r);
      } catch (l) {
        console.error(l);
      }
  }
  r(), a.exports = p7();
})), g7 = v7();
async function y7(e) {
  if (e === "en-US") return {};
  try {
    const a = await fetch(`/_sites/dispatch-assets/sites-widget-locales/${encodeURIComponent(e)}.json`);
    if (!a.ok) return {};
    const r = await a.json();
    return r === null || typeof r != "object" || Array.isArray(r) ? {} : Object.fromEntries(Object.entries(r).filter(([l, s]) => l.startsWith("sites.dispatch.widget.") && Array.isArray(s)));
  } catch {
    return {};
  }
}
function b7({ onMount: e }) {
  return (0, b.useLayoutEffect)(e, [e]), null;
}
function Ud(e, a, r = {}) {
  if (!r.isolatedDocument && Bd()) return {
    ready: Promise.resolve(),
    dispose: () => {
    }
  };
  const l = document.createElement("div");
  l.dataset.sitesWidget = e.kind, document.body.append(l);
  let s, c;
  const d = () => {
    c?.disconnect(), s?.unmount(), l.remove();
  };
  return r.isolatedDocument || (c = new MutationObserver(() => {
    Bd() && d();
  }), c.observe(document.documentElement, { childList: !0 })), {
    ready: (async () => {
      const h = EE(e.locale ?? "") ?? "en-US", m = r.isolatedDocument ? l : l.attachShadow({ mode: "open" }), y = document.createElement("style");
      y.textContent = `
      ${r.isolatedDocument ? "html, body { margin: 0; background: transparent; color-scheme: light dark; }" : ""}
      :host {
        all: initial !important;
        display: block !important;
        inset: 0 !important;
        pointer-events: none !important;
        position: fixed !important;
        z-index: 2147483647 !important;
      }
    `;
      const p = document.createElement("style");
      p.textContent = "._Button_wzun0_1{--button-press-scale:.96;--button-surface-transition:background-color .15s ease, box-shadow .15s ease, transform .15s ease;--button-size:32px;--button-icon-size:18px;--button-gutter:12px;all:initial;box-sizing:border-box;color:var(--button-text-color);cursor:pointer;font:inherit;height:var(--button-size);padding:0 var(--button-gutter);-webkit-user-select:none;user-select:none;white-space:nowrap;flex-shrink:0;gap:6px;font-weight:500;display:inline-block;position:relative}._Button_wzun0_1:before,._Button_wzun0_1:after{border-radius:inherit;content:\"\";pointer-events:none;transition:var(--button-surface-transition);will-change:transform;position:absolute;inset:0}._Button_wzun0_1:before{background:var(--button-background-color)}._Button_wzun0_1:focus{outline:0}._Button_wzun0_1:focus-visible:after{outline:2px solid var(--button-ring-color,currentColor);outline-offset:var(--button-ring-offset,2px)}._Button_wzun0_1[data-size=lg]{--button-size:36px}._Button_wzun0_1[data-icon-size=lg]{--button-icon-size:20px}._Button_wzun0_1:where([data-pill]){padding-inline:calc(var(--button-gutter) * 1.33);border-radius:9999px}._Button_wzun0_1[data-uniform]{width:var(--button-size);padding:0}._Button_wzun0_1:where([data-variant=solid][data-color=primary]){--button-background-color:var(--lightningcss-light,#181818)var(--lightningcss-dark,#f3f3f3);--button-background-color-hover:var(--lightningcss-light,#303030)var(--lightningcss-dark,#ededed);--button-background-color-active:var(--lightningcss-light,#414141)var(--lightningcss-dark,#dcdcdc);--button-text-color:var(--lightningcss-light,#fff)var(--lightningcss-dark,#0d0d0d)}._Button_wzun0_1:where([data-variant=solid][data-color=secondary]){--button-background-color:#fff;--button-background-color-hover:#f7f7f7;--button-background-color-active:#ededed;--button-text-color:#171717}._Button_wzun0_1:where([data-variant=ghost],[data-variant=outline]){--button-background-color:transparent;--button-background-color-hover:var(--lightningcss-light,#0d0d0d14)var(--lightningcss-dark,#ffffff1f);--button-background-color-active:var(--lightningcss-light,#0d0d0d1f)var(--lightningcss-dark,#ffffff29);--button-text-color:var(--lightningcss-light,#0d0d0d)var(--lightningcss-dark,#fff)}._Button_wzun0_1:where([data-variant=outline]){--button-border-color:var(--lightningcss-light,#0d0d0d1f)var(--lightningcss-dark,#ffffff24)}._Button_wzun0_1:where([data-variant=outline]):before{box-shadow:inset 0 0 0 1px var(--button-border-color)}._Button_wzun0_1:where([data-variant=ghost][data-color=secondary],[data-variant=outline][data-color=secondary]){--button-text-color:var(--lightningcss-light,#5d5d5d)var(--lightningcss-dark,#afafaf)}._Button_wzun0_1:not(:disabled):hover:before{background:var(--button-background-color-hover)}._Button_wzun0_1:not(:disabled):active:before{background:var(--button-background-color-active);transform:scale(var(--button-press-scale))}._Button_wzun0_1:not(:disabled):active:after{transform:scale(var(--button-press-scale))}._Button_wzun0_1[data-disabled]{cursor:default;opacity:.32}._Button_wzun0_1:disabled{cursor:default}._Button_wzun0_1 svg:not([data-no-autosize]){height:var(--button-icon-size);width:var(--button-icon-size)}._ButtonInner_wzun0_137{align-items:center;gap:inherit;justify-content:center;width:100%;height:100%;transition:opacity .15s .1s;display:flex;position:relative}._Button_wzun0_1[data-loading] ._ButtonInner_wzun0_137{opacity:0;transition:opacity .3s}._Button_wzun0_1>._ButtonLoader_wzun0_154{z-index:3;pointer-events:none;justify-content:center;align-items:center;display:flex;position:absolute;inset:0}._Button_wzun0_1>._ButtonLoader_wzun0_154[data-entering]{opacity:0}._Button_wzun0_1>._ButtonLoader_wzun0_154[data-exiting]{opacity:1}._Button_wzun0_1>._ButtonLoader_wzun0_154[data-entering-active],._Button_wzun0_1>._ButtonLoader_wzun0_154[data-entering][data-interrupted]{opacity:1;transition:opacity .15s}._Button_wzun0_1>._ButtonLoader_wzun0_154[data-exiting-active],._Button_wzun0_1>._ButtonLoader_wzun0_154[data-exiting][data-interrupted]{opacity:0;transition:opacity .15s}@media (prefers-reduced-motion:reduce){._Button_wzun0_1:before,._Button_wzun0_1:after,._Button_wzun0_1 ._ButtonInner_wzun0_137,._Button_wzun0_1>._ButtonLoader_wzun0_154{transition:none}}._LoadingIndicator_1mmfp_1{width:var(--indicator-size,1em);height:var(--indicator-size,1em);animation:_rotate_1mmfp_1 var(--indicator-rotate-duration,.8s) linear infinite;flex-shrink:0;transition:opacity .15s;display:inline-block;position:relative}._LoadingIndicator_1mmfp_1:before{border:var(--indicator-stroke,2px) solid var(--indicator-color,currentcolor);content:\"\";border-radius:50%;display:block;position:absolute;inset:0;-webkit-mask-image:conic-gradient(#0000,#000);mask-image:conic-gradient(#0000,#000)}._LoadingIndicator_1mmfp_1:after{width:var(--indicator-stroke,2px);height:var(--indicator-stroke,2px);margin-left:calc(var(--indicator-stroke,2px) * -1 / 2);background-color:var(--indicator-color,currentcolor);content:\"\";border-radius:100%;display:block;position:absolute;top:0;left:50%}@keyframes _rotate_1mmfp_1{0%{transform:rotate(0)}to{transform:rotate(1turn)}}._TransitionGroupChild_1d6a5_1{display:block}._Image_1l1xj_1{opacity:0;transition:opacity .3s var(--transition-ease-basic,ease);display:block}._Image_1l1xj_1[data-loaded]{opacity:1}@media (prefers-reduced-motion:reduce){._Image_1l1xj_1{transition:none}}._Tooltip_arpo7_1{border-radius:var(--tooltip-border-radius);max-width:300px;animation-name:_scale-in_arpo7_1;animation-duration:.25s;animation-timing-function:var(--cubic-enter);background:var(--tooltip-background-color);box-shadow:var(--tooltip-box-shadow);color:var(--tooltip-text-color);font-size:var(--tooltip-font-size);font-weight:var(--tooltip-font-weight);line-height:var(--tooltip-line-height);transform-origin:var(--radix-tooltip-content-transform-origin);transition:background-color .15s}._Tooltip_arpo7_1[data-state=closed]{animation:_scale-out_arpo7_1 .25s var(--cubic-enter)}._Tooltip_arpo7_1[data-clickable=false]{cursor:default}._Tooltip_arpo7_1[data-clickable=true]{cursor:pointer}@media (hover:hover){._Tooltip_arpo7_1[data-compact=true][data-clickable=true]:hover{background:var(--tooltip-compact-interactive-background-color-hover);color:var(--tooltip-compact-interactive-text-color-hover)}}._Tooltip_arpo7_1[data-gutter-size=sm]{padding:var(--tooltip-padding-sm)}._Tooltip_arpo7_1[data-gutter-size=md]{padding:var(--tooltip-padding-md)}._Tooltip_arpo7_1[data-gutter-size=lg]{padding:var(--tooltip-padding-lg)}._Tooltip_arpo7_1[data-compact=true]{padding:var(--tooltip-compact-padding);background:var(--tooltip-compact-background-color);color:var(--tooltip-compact-text-color);font-size:var(--tooltip-compact-font-size);font-weight:var(--tooltip-compact-font-weight)}@keyframes _scale-in_arpo7_1{0%{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}@keyframes _scale-out_arpo7_1{0%{opacity:1;transform:scale(1)}to{opacity:0;transform:scale(.97)}}._TriggerDecorator_arpo7_86{cursor:pointer;transition:text-decoration .2s var(--cubic-exit);-webkit-text-decoration:underline dotted #0000;text-decoration:underline dotted #0000;display:inline-flex}._TriggerDecorator_arpo7_86:focus{outline:0}._TriggerDecorator_arpo7_86[data-state*=open]{-webkit-text-decoration-color:var(--color-text-tertiary);text-decoration-color:var(--color-text-tertiary);transition-timing-function:var(--cubic-enter)}._Layout_1a5g1_1{flex-shrink:0;transition-property:height,width;display:block;position:relative}._Layout_1a5g1_1[data-clip=true]{overflow:hidden}._Layout_1a5g1_1[data-direction=in]{transition-delay:var(--tg-layout-enter-delay);transition-duration:var(--tg-layout-enter-duration);transition-timing-function:var(--tg-layout-enter-timing-function)}._Layout_1a5g1_1[data-direction=out]{transition-delay:var(--tg-layout-exit-delay);transition-duration:var(--tg-layout-exit-duration);transition-timing-function:var(--tg-layout-exit-timing-function)}._Layout_1a5g1_1[data-direction=move]{transition-delay:var(--tg-layout-move-delay);transition-duration:var(--tg-layout-move-duration);transition-timing-function:var(--tg-layout-move-timing-function)}._Layout_1a5g1_1[data-interrupted=true]{transition-delay:0s}._TransitionItem_1a5g1_34{will-change:var(--tg-will-change,auto);flex-shrink:0}._TransitionItem_1a5g1_34[data-entering],._TransitionItem_1a5g1_34[data-exiting]{width:100%;position:absolute;top:0;left:0}._Layout_1a5g1_1[data-dimension=width]>._TransitionItem_1a5g1_34[data-entering],._Layout_1a5g1_1[data-dimension=width]>._TransitionItem_1a5g1_34[data-exiting]{width:auto}._Layout_1a5g1_1[data-resize-contents][data-dimension=width]>._TransitionItem_1a5g1_34[data-entering]{width:100%}._Layout_1a5g1_1[data-item-anchor=end]>._TransitionItem_1a5g1_34[data-entering],._Layout_1a5g1_1[data-item-anchor=end]>._TransitionItem_1a5g1_34[data-exiting]{bottom:0;top:initial}._Layout_1a5g1_1[data-item-anchor=end][data-dimension=width]>._TransitionItem_1a5g1_34[data-entering],._Layout_1a5g1_1[data-item-anchor=end][data-dimension=width]>._TransitionItem_1a5g1_34[data-exiting]{left:initial;right:0}._Layout_1a5g1_1[data-item-anchor=center]>._TransitionItem_1a5g1_34:is([data-entering],[data-exiting]){top:50%;translate:0 -50%}._Layout_1a5g1_1[data-item-anchor=center][data-dimension=width]>._TransitionItem_1a5g1_34:is([data-entering],[data-exiting]){top:0;left:50%;translate:-50%}._TransitionItem_1a5g1_34[data-entering]{filter:var(--tg-initial-filter);opacity:var(--tg-initial-opacity);transform:var(--tg-initial-transform)}._TransitionItem_1a5g1_34[data-exiting]{filter:var(--tg-enter-filter);opacity:var(--tg-enter-opacity);transform:var(--tg-enter-transform)}._TransitionItem_1a5g1_34[data-entering-active],._TransitionItem_1a5g1_34[data-entering][data-interrupted]{filter:var(--tg-enter-filter);opacity:var(--tg-enter-opacity);transform:var(--tg-enter-transform);transition:opacity var(--tg-enter-duration) var(--tg-enter-timing-function) var(--tg-enter-delay), transform var(--tg-enter-duration) var(--tg-enter-timing-function) var(--tg-enter-delay), filter var(--tg-enter-duration) var(--tg-enter-timing-function) var(--tg-enter-delay)}._TransitionItem_1a5g1_34[data-exiting-active],._TransitionItem_1a5g1_34[data-exiting][data-interrupted]{filter:var(--tg-exit-filter);opacity:var(--tg-exit-opacity);transform:var(--tg-exit-transform);transition:opacity var(--tg-exit-duration) var(--tg-exit-timing-function) var(--tg-exit-delay), transform var(--tg-exit-duration) var(--tg-exit-timing-function) var(--tg-exit-delay), filter var(--tg-exit-duration) var(--tg-exit-timing-function) var(--tg-exit-delay)}._Theme_1ewnz_2{--lightningcss-light:initial;--lightningcss-dark: ;color-scheme:light dark;--cubic-enter:cubic-bezier(.19, 1, .22, 1);--cubic-exit:cubic-bezier(.8, 0, .4, 1);--tooltip-border-radius:9999px;--tooltip-background-color:#1d1d1d;--tooltip-text-color:#fff;--tooltip-box-shadow:0 4px 12px #0000001f;--tooltip-font-size:14px;--tooltip-font-weight:500;--tooltip-line-height:20px;--tooltip-padding-sm:8px 12px;--tooltip-padding-md:5px 12px;--tooltip-padding-lg:14px 18px;--tooltip-compact-padding:2px 8px;--tooltip-compact-background-color:var(--lightningcss-light,#303030)var(--lightningcss-dark,#afafaf);--tooltip-compact-text-color:var(--lightningcss-light,#fff)var(--lightningcss-dark,#0d0d0d);--tooltip-compact-interactive-background-color-hover:var(--lightningcss-light,#414141)var(--lightningcss-dark,#8f8f8f);--tooltip-compact-interactive-text-color-hover:var(--lightningcss-light,#fff)var(--lightningcss-dark,#0d0d0d);--tooltip-compact-font-size:14px;--tooltip-compact-font-weight:400;font-family:ui-sans-serif,-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif}@media (prefers-color-scheme:dark){._Theme_1ewnz_2{--lightningcss-light: ;--lightningcss-dark:initial}}._Portal_1ewnz_35{pointer-events:none;z-index:2147483647;position:relative}._Tooltip_1ewnz_41{box-sizing:border-box;cursor:default;letter-spacing:0;pointer-events:auto;text-align:center;border:1px solid #ffffff1f}._SharingTooltip_1ewnz_51{--tooltip-border-radius:14px;--tooltip-background-color:var(--tooltip-compact-background-color);--tooltip-text-color:var(--tooltip-compact-text-color);text-wrap:pretty}._HideHint_1ewnz_58{--tooltip-border-radius:14px;--tooltip-padding-md:10px 12px;pointer-events:auto;text-align:left;border:0;width:280px}._SharingHint_1ewnz_68,._SharingHint_1ewnz_68>span{overflow-wrap:anywhere;display:block}._HideHintContent_1ewnz_74{align-items:center;gap:12px;display:flex}._HideHintText_1ewnz_80{flex:1;min-width:0}._Shortcut_1ewnz_85{flex-shrink:0;gap:4px;display:inline-flex}._Shortcut_1ewnz_85 kbd{box-sizing:border-box;font:inherit;background:#ffffff17;border:1px solid #ffffff24;border-radius:5px;justify-content:center;align-items:center;min-width:22px;height:22px;padding:0 4px;font-size:12px;display:inline-flex;box-shadow:0 1px 1px #ffffff1f}@media (prefers-reduced-motion:reduce){._Portal_1ewnz_35 ._Tooltip_1ewnz_41[data-state]{animation:none}}._Widget_1oafq_1,._Widget_1oafq_1 *,._Widget_1oafq_1 :before,._Widget_1oafq_1 :after{box-sizing:border-box}._Widget_1oafq_1{--button-ring-color:#171717;--button-ring-offset:3px;--widget-surface:#ffffffc7;--widget-surface-highlight:#ffffffc7;--widget-text:#171717;--widget-text-secondary:#444;--widget-text-tertiary:var(--lightningcss-light,#8f8f8f)var(--lightningcss-dark,#afafaf);--widget-placeholder:#777;--widget-border:#0d0d0d1f;--widget-border-highlight:#0d0d0d2e;--widget-control-hover:#0d0d0d0f;--widget-control-active:#0d0d0d1a;--widget-shadow:#00000024;all:initial;box-sizing:border-box;color:var(--widget-text);--lightningcss-light:initial;--lightningcss-dark: ;color-scheme:light dark;pointer-events:auto;z-index:2147483647;font-family:ui-sans-serif,-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;position:fixed}@media (prefers-color-scheme:dark){._Widget_1oafq_1{--lightningcss-light: ;--lightningcss-dark:initial}}._Widget_1oafq_1{pointer-events:none;bottom:auto;right:auto}._Widget_1oafq_1[data-snapping]{transition:left var(--widget-snap-duration) cubic-bezier(.2, .8, .2, 1), top var(--widget-snap-duration) cubic-bezier(.2, .8, .2, 1)}._LandingShadow_1oafq_46{box-sizing:border-box;pointer-events:none;z-index:2147483646;background:#64748b29;border-radius:18px;position:fixed;box-shadow:0 4px 20px #00000014}._WidgetEntrance_1oafq_56[data-entering]{opacity:0;transform:translateY(4px)}._WidgetEntrance_1oafq_56[data-entering-active]{opacity:1;transition:opacity .18s cubic-bezier(.19,1,.22,1),transform .18s cubic-bezier(.19,1,.22,1);transform:translateY(0)}._WidgetExit_1oafq_69[data-exiting]{opacity:0}._WidgetExit_1oafq_69{contain:paint;pointer-events:none;z-index:2147483647;position:fixed;inset:0}._Widget_1oafq_1[data-tucked] ._Shell_1oafq_82{width:64px;height:64px;transform:translate(var(--tuck-x), var(--tuck-y));border-radius:32px}._Widget_1oafq_1[data-peek-phase=expanded] ._Shell_1oafq_82{width:88px;height:88px;transform:translate(calc(var(--tuck-x) - 12px), calc(var(--tuck-y) - 12px));--widget-morph-easing:cubic-bezier(.2, 1.4, .4, 1);border-radius:32px}._Widget_1oafq_1[data-quiet-tuck] ._Shell_1oafq_82{--widget-morph-duration:.22s;--widget-morph-easing:ease}._Widget_1oafq_1[data-peek-phase=away] ._Shell_1oafq_82{transform:translate(calc(var(--tuck-x) + var(--corner-x-direction) * 80px), calc(var(--tuck-y) + var(--corner-y-direction) * 80px));--widget-morph-duration:.36s;--widget-morph-easing:cubic-bezier(.55, 0, .85, .4)}._Widget_1oafq_1[data-peek-phase=tucked]:not([data-quiet-tuck]) ._ToolbarPanel_1oafq_115 ._Shell_1oafq_82{--widget-morph-duration:.15s;--widget-morph-easing:ease-out}._ShellControls_1oafq_120{width:max-content;transition:opacity .12s .14s}._Widget_1oafq_1[data-tucked] ._ShellControls_1oafq_120{opacity:0;transition:opacity .1s}._Launcher_1oafq_130{cursor:pointer;font:inherit;color:var(--widget-text);white-space:nowrap;-webkit-user-select:none;user-select:none;z-index:1;background:0 0;border:0;justify-content:center;align-items:center;gap:12px;min-width:137px;height:36px;padding:0 40px;font-size:13px;font-weight:400;display:inline-flex}._LauncherRow_1oafq_153{position:relative}._LauncherLabel_1oafq_157{line-height:20px;display:inline-block}._Widget_1oafq_1[data-dragging] ._Launcher_1oafq_130{cursor:grabbing}._CornerTarget_1oafq_167{cursor:pointer;pointer-events:auto;touch-action:none;z-index:2147483647;background:0 0;border:0;width:44px;height:44px;padding:0;position:fixed}._CornerTarget_1oafq_167:hover,._CornerTarget_1oafq_167:focus-visible{width:52px;height:52px}._CornerTarget_1oafq_167:focus-visible{outline:2px solid var(--button-ring-color);outline-offset:-3px}._Widget_1oafq_1[data-corner=top-left] ._CornerTarget_1oafq_167{border-radius:0 0 32px;top:0;left:0}._Widget_1oafq_1[data-corner=top-right] ._CornerTarget_1oafq_167{border-radius:0 0 0 32px;top:0;right:0}._Widget_1oafq_1[data-corner=bottom-left] ._CornerTarget_1oafq_167{border-radius:0 32px 0 0;bottom:0;left:0}._Widget_1oafq_1[data-corner=bottom-right] ._CornerTarget_1oafq_167{border-radius:32px 0 0;bottom:0;right:0}._Widget_1oafq_1[data-corner=bottom-center] ._CornerTarget_1oafq_167{border-radius:32px 32px 0 0;bottom:0;left:50%;transform:translate(-50%)}._Panel_1oafq_203 ._LogoButton_1oafq_203[data-variant][data-color]{--button-background-color-hover:var(--widget-control-hover);--button-background-color-active:var(--widget-control-active);--button-text-color:var(--widget-text);--button-size:28px;z-index:2;position:absolute;top:4px;left:4px}._LogoButton_1oafq_203:focus-visible:before{background:var(--button-background-color-hover)}._Shell_1oafq_82{--widget-morph-duration:.42s;--widget-morph-easing:cubic-bezier(.4, 0, .2, 1);pointer-events:auto;width:var(--widget-surface-width,137px);height:var(--widget-surface-height,36px);transition:transform var(--widget-morph-duration) var(--widget-morph-easing), width var(--widget-morph-duration) var(--widget-morph-easing), height var(--widget-morph-duration) var(--widget-morph-easing), border-radius var(--widget-morph-duration) var(--widget-morph-easing), opacity .15s ease;border-radius:18px;position:relative;transform:translate(0)}._Panel_1oafq_203[data-expanded] ._Shell_1oafq_82,._WidgetEntrance_1oafq_56[data-entering] ._ToolbarPanel_1oafq_115 ._Shell_1oafq_82{transition:none}._Widget_1oafq_1:not([data-tucked]) ._Shell_1oafq_82:has(._ShellContent_1oafq_248[data-entering],._ShellContent_1oafq_248[data-exiting]){transition-property:transform,border-radius,opacity}._ShellLayout_1oafq_252{border-radius:inherit;width:max-content;min-height:36px;transition-property:width}._ShellContent_1oafq_248{z-index:1;min-height:36px;position:relative}._Widget_1oafq_1[data-corner^=top] ._ShellContent_1oafq_248:is([data-entering],[data-exiting]){top:0;bottom:auto}._Widget_1oafq_1[data-corner^=bottom] ._ShellContent_1oafq_248:is([data-entering],[data-exiting]){top:auto;bottom:0}._ShellContent_1oafq_248[data-exiting],._ShellContent_1oafq_248[data-exiting] *{pointer-events:none}._Shell_1oafq_82:before{-webkit-backdrop-filter:var(--sites-toolbar-backdrop-filter,blur(18px) saturate(1.25));backdrop-filter:var(--sites-toolbar-backdrop-filter,blur(18px) saturate(1.25));background:var(--sites-toolbar-glass,var(--widget-surface));border-radius:inherit;box-shadow:0 0 0 1px var(--widget-border), 0 10px 30px var(--widget-shadow), 0 2px 6px #00000014;content:\"\";pointer-events:none;will-change:transform;transition:background-color .15s,box-shadow .15s,transform .15s;position:absolute;inset:0}._Shell_1oafq_82:hover:before,._Shell_1oafq_82:focus-within:before{background:var(--sites-toolbar-glass,var(--widget-surface-highlight))}._Shell_1oafq_82:after{border-radius:inherit;content:\"\";pointer-events:none;transition:transform .15s;position:absolute;inset:0}._Panel_1oafq_203:not([data-expanded]) ._Shell_1oafq_82:has(._Launcher_1oafq_130:focus-visible):after{outline:var(--sharing-focus-ring,2px solid var(--button-ring-color));outline-offset:var(--sharing-focus-ring-offset,var(--button-ring-offset))}._Shell_1oafq_82:has(._Launcher_1oafq_130:active):before{transform:scale(.98)}._Shell_1oafq_82:has(._Launcher_1oafq_130:active):after{transform:scale(.98)}._LauncherLogo_1oafq_325{flex:none;width:18px;height:18px;display:block}._LauncherLogo_1oafq_325[data-entering] img[data-loaded]{transform-origin:50%;animation:.7s cubic-bezier(.22,1,.36,1) both _blossomEntrance_1oafq_1}@keyframes _blossomEntrance_1oafq_1{0%{transform:rotate(-60deg)scale(.9)}to{transform:rotate(0)scale(1)}}._Panel_1oafq_203{--widget-panel-width:min(var(--widget-composer-width,360px), calc(100vw - 48px));width:var(--widget-panel-width);flex-direction:column;align-items:flex-start;display:flex;position:relative}._Widget_1oafq_1[data-sharing-open] :is(._ToolbarPanel_1oafq_115,._Shell_1oafq_82){width:max-content}._Panel_1oafq_203:is(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi)){align-items:flex-end}._Composer_1oafq_361{min-height:36px;width:var(--widget-panel-width);background:0 0;grid-template-columns:minmax(0,1fr) 24px;align-items:end;gap:8px;padding:6px;display:grid;overflow:hidden}._ShellLayout_1oafq_252[data-resize-contents] ._Composer_1oafq_361{width:100%}._Textarea_1oafq_377{all:initial;box-sizing:border-box;color:var(--widget-text);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;resize:none;align-self:center;width:calc(100% - 12px);height:24px;min-height:24px;max-height:180px;margin-left:12px;padding:3px 0;font-family:inherit;font-size:14px;font-weight:400;line-height:18px;transition:none;display:block;overflow-y:auto}._Textarea_1oafq_377::placeholder{color:var(--widget-placeholder);opacity:1}._Textarea_1oafq_377:placeholder-shown{white-space:pre;overflow-x:hidden}._Textarea_1oafq_377:focus{outline:0}._ComposerFooter_1oafq_415{justify-content:flex-end;display:flex}._ComposerTooltip_1oafq_420{--tooltip-border-radius:12px;--tooltip-background-color:var(--tooltip-compact-background-color);--tooltip-text-color:var(--tooltip-compact-text-color)}._ComposerArrow_1oafq_426{transition:transform .16s ease-out;transform:rotate(0)}._ComposerArrow_1oafq_426[data-open]{transform:rotate(45deg)}@media (prefers-reduced-motion:reduce){._ComposerArrow_1oafq_426{transition:none}}._Panel_1oafq_203 ._SendButton_1oafq_439[data-variant][data-color]{--button-size:24px;--button-icon-size:16px;align-self:end}:where(._Widget_1oafq_1:not([data-tucked])) ._ToolbarPanel_1oafq_115 ._Shell_1oafq_82{border-radius:22px;height:auto}._ToolbarPanel_1oafq_115 ._ShellLayout_1oafq_252[data-resize-contents]>._ShellContent_1oafq_248[data-entering]{position:relative}._ToolbarPanel_1oafq_115 ._ShellContent_1oafq_248[data-exiting]:has(._Composer_1oafq_361){width:100%}._ToolbarPanel_1oafq_115 ._ShellContent_1oafq_248[data-exiting]:has(._Composer_1oafq_361) ._Composer_1oafq_361{width:100%}._ToolbarPanel_1oafq_115 ._Composer_1oafq_361{grid-template-columns:minmax(0,1fr) 28px;padding:8px}._ToolbarPanel_1oafq_115 ._Textarea_1oafq_377{height:28px;min-height:28px;padding-block:4px;font-size:15px;line-height:20px}._ToolbarPanel_1oafq_115 ._SendButton_1oafq_439[data-variant][data-color]{--button-size:28px;--button-icon-size:16px;--button-background-color:var(--lightningcss-light,#171717)var(--lightningcss-dark,#f3f3f3);--button-background-color-hover:var(--lightningcss-light,#303030)var(--lightningcss-dark,#e5e5e5);--button-background-color-active:var(--lightningcss-light,#444)var(--lightningcss-dark,#d4d4d4);--button-text-color:var(--lightningcss-light,#fff)var(--lightningcss-dark,#171717)}._Launcher_1oafq_130:focus{outline:0}._Panel_1oafq_203 ._LauncherDismissButton_1oafq_494[data-variant][data-color]{--button-background-color-hover:var(--widget-control-hover);--button-background-color-active:var(--widget-control-active);--button-text-color:var(--widget-text-tertiary);--button-size:28px;--button-icon-size:16px;opacity:0;pointer-events:none;z-index:2;transition:opacity 80ms;position:absolute;bottom:4px;right:4px}._LauncherDismissButton_1oafq_494:focus-visible:before{background:var(--button-background-color-hover)}._Panel_1oafq_203:not([data-expanded]) ._LauncherDismissButton_1oafq_494[data-variant][data-color]{opacity:1;pointer-events:auto}._Panel_1oafq_203:not([data-expanded]) ._Shell_1oafq_82:has(._ShellContent_1oafq_248[data-entering]) ._LauncherDismissButton_1oafq_494[data-variant][data-color]{opacity:0;pointer-events:none}@media (prefers-reduced-motion:reduce){._WidgetEntrance_1oafq_56[data-entering]{opacity:1;transition:none;transform:none}._Widget_1oafq_1[data-snapping],._LauncherLogo_1oafq_325[data-entering] img[data-loaded],._Widget_1oafq_1[data-tucked] ._Shell_1oafq_82,._Widget_1oafq_1[data-peek-phase] ._Shell_1oafq_82,._Widget_1oafq_1[data-quiet-tuck] ._Shell_1oafq_82,._ShellControls_1oafq_120,._Widget_1oafq_1[data-tucked] ._ShellControls_1oafq_120,._Composer_1oafq_361,._Launcher_1oafq_130,._Launcher_1oafq_130:before,._Shell_1oafq_82,._ShellLayout_1oafq_252,._Shell_1oafq_82:before,._Shell_1oafq_82:after,._Panel_1oafq_203 ._LauncherDismissButton_1oafq_494[data-variant][data-color],._Textarea_1oafq_377{transition:none;animation:none}}@media (hover:hover){._Shell_1oafq_82:hover{--widget-border:var(--widget-border-highlight)}}@media (prefers-color-scheme:dark){._Widget_1oafq_1{--button-ring-color:#fff;--widget-surface:#282828c2;--widget-surface-highlight:#383838c2;--widget-text:#f5f5f5;--widget-text-secondary:#d0d0d0;--widget-placeholder:#aaa;--widget-border:#ffffff24;--widget-border-highlight:#ffffff38;--widget-control-hover:#ffffff1a;--widget-control-active:#ffffff29;--widget-shadow:#0000004d}._LauncherLogo_1oafq_325{filter:invert()}}@media (max-width:520px){._Textarea_1oafq_377{font-size:16px}._Panel_1oafq_203{--widget-panel-width:calc(100vw - 32px)}}._Shell_1oafq_82:has([data-toolbar-menu-mounted]):before{visibility:hidden}._Shell_1oafq_82:has([data-toolbar-menu-mounted]):after{visibility:hidden}._SharingClose_1oafq_596{gap:12px;min-width:0;padding-block:0;padding-inline:10px 16px}._SharingClose_1oafq_596 svg{width:16px;height:16px}._Widget_1oafq_1[data-sharing-open] ._SharingClose_1oafq_596:focus{outline:none}._Shell_1oafq_82:has(._SharingClose_1oafq_596):before{background:var(--sites-toolbar-action-glass)}._Shell_1oafq_82:has(._SharingClose_1oafq_596:active):before{transform:scale(.94)}._Shell_1oafq_82:has(._SharingClose_1oafq_596:active):after{transform:scale(.94)}._Shell_1oafq_82:has([data-menu-open]){pointer-events:none}._Widget_1lfcb_1{--safe-top:env(safe-area-inset-top,0px);--safe-right:env(safe-area-inset-right,0px);--safe-bottom:env(safe-area-inset-bottom,0px);--safe-left:env(safe-area-inset-left,0px);pointer-events:auto;width:max-content;max-width:calc(100vw - 32px);height:52px}._Widget_1lfcb_1[data-mobile-widget-menu-open]{pointer-events:none}._Widget_1lfcb_1[data-mobile-widget-snapping]{transition:left var(--widget-snap-duration) cubic-bezier(.2, .8, .2, 1), top var(--widget-snap-duration) cubic-bezier(.2, .8, .2, 1)}@media (prefers-reduced-motion:reduce){._Widget_1lfcb_1[data-mobile-widget-snapping]{transition:none}}._Launcher_1lfcb_27,._Action_1lfcb_28,._EditAction_1lfcb_29,._MoreAction_1lfcb_30{-webkit-tap-highlight-color:transparent;-webkit-touch-callout:none;-webkit-user-select:none;user-select:none}._Launcher_1lfcb_27:before,._Menu_1lfcb_39:before{border:1px solid var(--widget-border);-webkit-backdrop-filter:blur(18px)saturate(1.25);backdrop-filter:blur(18px)saturate(1.25);background:var(--widget-surface);box-shadow:0 4px 20px var(--widget-shadow);color:var(--widget-text)}._Launcher_1lfcb_27{cursor:grab;isolation:isolate;touch-action:none;border-radius:26px;grid-template-columns:44px minmax(0,1fr) 44px;align-items:center;height:52px;padding:4px;transition:opacity .14s .11s;display:grid;position:relative}._Launcher_1lfcb_27:before{z-index:-1;border-radius:inherit;content:\"\";pointer-events:none;transition:transform var(--press-duration,.24s) ease-out;position:absolute;inset:0}:where(._Widget_1lfcb_1[data-mobile-widget-pressed]) ._Launcher_1lfcb_27:before{--press-duration:.1s;transform:scale(.96)}:where(._Widget_1lfcb_1[data-mobile-widget-menu-open]) ._Launcher_1lfcb_27{opacity:0;pointer-events:none;transition-duration:80ms;transition-delay:0s}:where(._Widget_1lfcb_1[data-mobile-widget-menu-mounted]) ._Launcher_1lfcb_27:before{visibility:hidden}._Launcher_1lfcb_27 img{pointer-events:none;justify-self:center}@media (prefers-color-scheme:dark){._Launcher_1lfcb_27 img{filter:invert()}}:where(._Widget_1lfcb_1[data-mobile-widget-dragging]) ._Launcher_1lfcb_27{cursor:grabbing}@media (prefers-reduced-motion:reduce){._Launcher_1lfcb_27,._Launcher_1lfcb_27:before{transition:none}}._EditAction_1lfcb_29,._MoreAction_1lfcb_30{min-width:44px;height:44px;color:inherit;cursor:pointer;font:inherit;background:0 0;border:0;border-radius:22px;justify-content:center;align-items:center;padding:0;font-size:16px;line-height:20px;text-decoration:none;display:flex}._EditAction_1lfcb_29{overflow-wrap:anywhere;text-align:center;min-width:0;padding:0 8px}._MoreAction_1lfcb_30{color:var(--widget-text-tertiary)}._MoreAction_1lfcb_30 svg{width:24px;height:24px}._Menu_1lfcb_39{--surface-easing:cubic-bezier(.2, .8, .2, 1);--surface-duration:.25s;--surface-inset:var(--closed-top) var(--closed-right) var(--closed-bottom) var(--closed-left);--surface-radius:26px;z-index:2147483646;opacity:0;pointer-events:none;border-radius:24px;width:min(200px,100vw - 32px);max-width:calc(100vw - 32px);padding:0;display:block;position:relative}._Menu_1lfcb_39:focus{outline:none}._Menu_1lfcb_39:before{inset:var(--surface-inset);border-radius:var(--surface-radius);content:\"\";pointer-events:none;transition:inset var(--surface-duration) var(--surface-easing), border-radius var(--surface-duration) var(--surface-easing);position:absolute}._Menu_1lfcb_39[data-mobile-widget-positioned]{opacity:1;pointer-events:auto}._Menu_1lfcb_39[data-mobile-widget-positioned][data-state=open]{--surface-duration:.38s;--surface-inset:0px;--surface-radius:24px}._Menu_1lfcb_39[data-state=closed]{animation:_menu-exit_1lfcb_1 var(--surface-duration) both;pointer-events:none}@media (prefers-reduced-motion:reduce){._Menu_1lfcb_39[data-state=closed],._Menu_1lfcb_39:before{transition:none;animation:none}}._Actions_1lfcb_204{clip-path:inset(var(--surface-inset) round var(--surface-radius));opacity:0;transition:clip-path var(--surface-duration) var(--surface-easing), opacity 60ms ease;flex-direction:column;padding:8px;display:flex;position:relative}:where(._Menu_1lfcb_39[data-mobile-widget-positioned][data-state=open]) ._Actions_1lfcb_204{opacity:1;transition:clip-path var(--surface-duration) var(--surface-easing), opacity .18s ease 80ms}@media (prefers-reduced-motion:reduce){._Actions_1lfcb_204{transition:none}}@keyframes _menu-exit_1lfcb_1{0%,to{visibility:visible}}._Action_1lfcb_28{min-height:48px;color:inherit;cursor:pointer;font:inherit;overflow-wrap:anywhere;text-align:start;background:0 0;border:0;border-radius:20px;align-items:center;gap:12px;padding:10px 12px;font-size:16px;text-decoration:none;display:flex}._Action_1lfcb_28 svg{flex:none;width:20px;height:20px}._Action_1lfcb_28:active{background:var(--widget-control-active)}@media (hover:hover){._Action_1lfcb_28:hover{background:var(--widget-control-hover)}}._Action_1lfcb_28:focus-visible,._EditAction_1lfcb_29:focus-visible,._MoreAction_1lfcb_30:focus-visible{outline:2px solid var(--button-ring-color);outline-offset:2px}._Launcher_6xtjb_1,._Launcher_6xtjb_1[data-mobile]{cursor:grab;-webkit-user-select:none;user-select:none;align-items:center;gap:4px;width:max-content;max-width:calc(100vw - 48px);height:36px;padding:4px;transition:opacity .22s 60ms;display:flex}:is(._Launcher_6xtjb_1,._Launcher_6xtjb_1[data-mobile]):active{cursor:grabbing}:is(._Launcher_6xtjb_1,._Launcher_6xtjb_1[data-mobile])[data-menu-open]{opacity:0;pointer-events:none;transition-duration:80ms;transition-delay:0s}@media (prefers-reduced-motion:reduce){._Launcher_6xtjb_1,._Launcher_6xtjb_1[data-mobile]{transition:none}}._Launcher_6xtjb_1 ._Logo_6xtjb_32{place-items:center;width:28px;height:28px;display:grid}._Divider_6xtjb_38{background:var(--widget-border);flex:none;width:1px;height:12px}@media (hover:hover){._Launcher_6xtjb_1:has(._Shortcut_6xtjb_45:hover) ._Divider_6xtjb_38{opacity:0}._Divider_6xtjb_38:has(+._More_6xtjb_46:hover){opacity:0}}._Ghost_6xtjb_50[data-variant=ghost]{--button-background-color-hover:var(--lightningcss-light,#0000000f)var(--lightningcss-dark,#ffffff1f);--button-background-color-active:var(--lightningcss-light,#0000001a)var(--lightningcss-dark,#ffffff2e);--button-text-color:var(--widget-text)}._Ghost_6xtjb_50[data-variant=ghost]:focus-visible:after{outline:none}._Ghost_6xtjb_50[data-variant=ghost]:focus-visible:not(:disabled):not(:active):before{background:var(--button-background-color-hover)}._Launcher_6xtjb_1 ._Shortcut_6xtjb_45,._Launcher_6xtjb_1 ._More_6xtjb_46{--button-size:28px;--button-icon-size:16px;font-size:13px}._Launcher_6xtjb_1 ._Shortcut_6xtjb_45{flex-shrink:1;gap:6px;min-width:0;margin-inline:-3px;padding:0 11px}._Label_6xtjb_84{text-overflow:ellipsis;overflow:hidden}._More_6xtjb_46[data-variant=ghost]{--button-text-color:var(--widget-text-tertiary)}._Menu_6xtjb_91[data-state]{width:max-content;min-width:184px;max-width:none}._Menu_6xtjb_91:before{outline:1px solid var(--widget-border);-webkit-backdrop-filter:var(--sites-toolbar-backdrop-filter);backdrop-filter:var(--sites-toolbar-backdrop-filter);background:var(--sites-toolbar-glass);border:0}._Menu_6xtjb_91 ._MenuActions_6xtjb_104{padding:6px}._MenuDivider_6xtjb_107{border:0;border-top:1px solid var(--widget-border);margin:4px 10px}._MenuAction_6xtjb_104{--button-icon-size:20px;text-align:start;white-space:nowrap;border-radius:9999px;align-items:center;gap:10px;height:auto;min-height:38px;padding:7px 10px;font-size:13px;line-height:20px;text-decoration:none;display:flex}._MenuAction_6xtjb_104>span{justify-content:flex-start}._MenuAction_6xtjb_104 svg{flex-shrink:0}._MenuAction_6xtjb_104:before{transition-property:transform}._Launcher_6xtjb_1[data-mobile]{max-width:calc(100vw - 32px)}._Launcher_6xtjb_1[data-mobile]:not([data-menu-open]){pointer-events:auto}._Launcher_6xtjb_1[data-mobile][data-toolbar-menu-mounted]:before{visibility:hidden}._Menu_6xtjb_91[data-mobile]{max-width:calc(100vw - 32px)}._Menu_6xtjb_91[data-mobile] ._MenuAction_6xtjb_104{white-space:normal}:where([data-mobile-widget-dragging]) ._Launcher_6xtjb_1:before{box-shadow:none}._Widget_lanvw_1{pointer-events:none;height:auto}._CloseButton_lanvw_7[data-variant]{--button-size:36px;--button-icon-size:16px;--button-text-color:var(--widget-text);--button-background-color:var(--widget-surface);--button-background-color-hover:var(--widget-surface);--button-background-color-active:var(--widget-surface);pointer-events:auto;gap:12px;padding-block:0;padding-inline:10px 16px;font-size:13px}._CloseButton_lanvw_7[data-variant]:before{border:1px solid var(--widget-border);-webkit-backdrop-filter:blur(18px)saturate(1.25);backdrop-filter:blur(18px)saturate(1.25);box-shadow:0 4px 20px var(--widget-shadow)}._RemixTooltip_6yzd8_1{color:#fff;pointer-events:auto;text-align:start;background:#3a83f7;border-radius:12px;width:min(300px,100vw - 32px);padding:16px;font-size:13px;line-height:18px;position:absolute;bottom:calc(100% + 22px);right:0;box-shadow:0 12px 24px #0000001f}@media (prefers-reduced-motion:no-preference){._RemixTooltip_6yzd8_1{animation:.36s ease-out _remixTooltipFadeIn_6yzd8_1}}@keyframes _remixTooltipFadeIn_6yzd8_1{0%{opacity:0}to{opacity:1}}._RemixTooltip_6yzd8_1:after{--arrow-inset:max(12px, 50% - 7px + (var(--widget-surface-width) - var(--widget-panel-width)) / 2);background:inherit;content:\"\";height:14px;bottom:-7px;right:var(--arrow-inset);width:14px;position:absolute;transform:rotate(45deg)}[data-corner$=left] ._RemixTooltip_6yzd8_1{left:0;right:auto}[data-corner$=left] ._RemixTooltip_6yzd8_1:after{left:var(--arrow-inset);right:auto}[data-corner=bottom-center] ._RemixTooltip_6yzd8_1{left:50%;right:auto;translate:-50%}[data-corner=bottom-center] ._RemixTooltip_6yzd8_1:after{right:calc(50% - 7px)}[data-corner^=top] ._RemixTooltip_6yzd8_1{top:calc(100% + 22px);bottom:auto}[data-corner^=top] ._RemixTooltip_6yzd8_1:after{top:-7px;bottom:auto}._RemixTooltip_6yzd8_1 strong{letter-spacing:-.08px;padding-inline-end:24px;font-weight:500;display:block}._RemixTooltip_6yzd8_1 p{margin:8px 0 0}._RemixTooltip_6yzd8_1 ._CloseButton_6yzd8_68[data-variant=ghost]{--button-size:24px;--button-icon-size:16px;--button-text-color:white;--button-ring-color:white;--button-background-color-hover:#0000001f;--button-background-color-active:#0003;inset-inline-end:12px;border-radius:4px;position:absolute;top:12px}._Banner_1iivt_1,._Banner_1iivt_1 *,._Banner_1iivt_1 :before,._Banner_1iivt_1 :after{box-sizing:border-box}._Banner_1iivt_1{all:initial;box-sizing:border-box;color:#171717;--lightningcss-light:initial;--lightningcss-dark: ;color-scheme:light;pointer-events:auto;z-index:2147483647;background:#fff;border-radius:24px;align-items:center;width:min(640px,100vw - 48px);min-height:68px;padding:12px 14px 12px 20px;font-family:ui-sans-serif,-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;display:flex;position:fixed;top:24px;left:50%;transform:translate(-50%);box-shadow:0 0 0 1px #0d0d0d1a,0 10px 15px -3px #0000001a,0 4px 6px -4px #0000001a}._Content_1iivt_34{flex:1;justify-content:space-between;align-items:center;min-width:0;display:flex}._Message_1iivt_42{overflow-wrap:break-word;flex:1;min-width:0;font-size:14px;line-height:1.5}._OwnerName_1iivt_50{font-weight:600}._Actions_1iivt_54{flex:none;align-items:center;gap:8px;margin-left:16px;display:flex}._EditLink_1iivt_62,._DismissButton_1iivt_63{--scale:.985;font:inherit;isolation:isolate;border:0;justify-content:center;align-items:center;transition:color .15s;display:inline-flex;position:relative}._EditLink_1iivt_62:before,._DismissButton_1iivt_63:before{border-radius:inherit;content:\"\";will-change:transform;z-index:-1;transition:background-color .15s,opacity .15s,transform .15s;position:absolute;inset:0}._EditLink_1iivt_62{color:#fff;white-space:nowrap;background:0 0;border-radius:9999px;flex:none;gap:6px;min-height:36px;padding:0 16px;font-size:13px;font-weight:400;text-decoration:none}._EditLink_1iivt_62 svg{width:18px;height:18px}._EditLink_1iivt_62:before{background:#171717}._EditLink_1iivt_62:hover:before{background:#2f2f2f}._EditLink_1iivt_62:active:before{transform:scale(var(--scale));background:#3a3a3a}._EditLink_1iivt_62:focus-visible,._DismissButton_1iivt_63:focus-visible{outline-offset:2px;outline:2px solid #0d6efd}._DismissButton_1iivt_63{color:#5f5f5f;cursor:pointer;background:0 0;border-radius:9999px;flex:none;width:36px;height:36px;padding:0;font-size:20px}._DismissButton_1iivt_63:before{opacity:0;transform:scale(var(--scale));background:#f2f2f2}._DismissButton_1iivt_63:hover{color:#171717}._DismissButton_1iivt_63:hover:before{opacity:1;transform:scale(1)}._DismissButton_1iivt_63:active:before{opacity:1;transform:scale(var(--scale));background:#e8e8e8}@media (prefers-reduced-motion:reduce){._EditLink_1iivt_62,._EditLink_1iivt_62:before,._DismissButton_1iivt_63,._DismissButton_1iivt_63:before{transition:none}}@media (max-width:520px){._Banner_1iivt_1{width:calc(100vw - 24px);padding:14px 16px 16px 20px;top:12px}._Content_1iivt_34{flex-wrap:wrap;gap:12px}._Message_1iivt_42{flex-basis:calc(100% - 48px)}._Actions_1iivt_54{display:contents}._EditLink_1iivt_62{order:2}._DismissButton_1iivt_63{order:1;align-self:flex-start}}._ModalHost_19oai_1{--widget-composer-width:336px;--sites-toolbar-glass:var(--lightningcss-light,#ffffffc7)var(--lightningcss-dark,#21212199);--sites-toolbar-action-glass:var(--lightningcss-light,#ffffffc7)var(--lightningcss-dark,#18181899);--sites-toolbar-backdrop-filter:blur(52px);--lightningcss-light:initial;--lightningcss-dark: ;color-scheme:light dark;pointer-events:none;background:0 0;border:0;width:100vw;max-width:none;height:100dvh;max-height:none;margin:0;padding:0;position:fixed;inset:0;overflow:visible}@media (prefers-color-scheme:dark){._ModalHost_19oai_1{--lightningcss-light: ;--lightningcss-dark:initial}}._ModalHost_19oai_1[data-sharing-open]{pointer-events:auto}._ModalHost_19oai_1[data-share-login][data-sharing-open]{--sharing-focus-ring:1.5px solid var(--lightningcss-light,#0d0d0d)var(--lightningcss-dark,#ececec);--sharing-focus-ring-offset:2.5px}._ModalHost_19oai_1[data-share-login][data-sharing-open] :is([data-share-action],[data-toolbar-sharing-close]):focus-visible:after{outline:var(--sharing-focus-ring);outline-offset:var(--sharing-focus-ring-offset)}._ModalHost_19oai_1[data-share-login][data-sharing-open] ._FallbackFrameHost_19oai_40:focus{outline:none}._ModalHost_19oai_1::backdrop{background:0 0}._ModalHost_19oai_1[data-sharing-open] ._FrameHost_19oai_49[data-panel-ready],._ModalHost_19oai_1[data-sharing-open] ._FallbackFrameHost_19oai_40{visibility:visible;pointer-events:auto;transition:none}._Prompt_19oai_57{--sharing-initial-loading-height:160px;--sharing-notice-max-height:max(0px, calc(100cqh - 24px));box-sizing:border-box;max-height:var(--sharing-notice-max-height);padding:var(--sharing-padding);overscroll-behavior:contain;text-align:center;pointer-events:auto;flex-direction:column;justify-content:safe center;align-items:center;gap:16px;margin:12px;display:flex;position:relative;overflow:auto}._Prompt_19oai_57[data-login-notice]{text-align:start;justify-content:flex-start;align-items:stretch;gap:8px}._Prompt_19oai_57[data-login-notice] ._PromptFooter_19oai_82{margin-block-start:4px}._Prompt_19oai_57[data-error]{text-align:start;grid-template-columns:auto minmax(0,1fr);align-items:start;gap:4px 12px;display:grid}._Prompt_19oai_57[data-error] :is(._PromptTitle_19oai_94,._PromptDescription_19oai_94,._PromptFooter_19oai_82){grid-column:2}._Prompt_19oai_57[data-error] ._PromptFooter_19oai_82{margin-block-start:8px}._Prompt_19oai_57[data-error] [data-share-action]{align-items:center;display:inline-flex}._Prompt_19oai_57[data-loading]{height:var(--sharing-initial-loading-height)}._Prompt_19oai_57 [data-share-action]{max-inline-size:100%;height:auto;min-height:var(--button-size);white-space:normal;text-align:center;padding-block:4px}._PromptTitle_19oai_94,._PromptDescription_19oai_94{overflow-wrap:anywhere;flex-shrink:0;margin:0}._PromptTitle_19oai_94{font-size:16px;font-weight:600;line-height:1.35}._PromptDescription_19oai_94{text-wrap:pretty}._PromptErrorIcon_19oai_139{grid-area:1/1/span 2;margin-block-start:1px;font-size:20px}._Surface_19oai_146[data-notice-measured] ._Prompt_19oai_57[data-loading]{height:calc(100% - 24px)}@media (max-width:360px){._Prompt_19oai_57{--sharing-initial-loading-height:176px;padding:16px}}@media (prefers-reduced-motion:no-preference){._Prompt_19oai_57[data-waiting] ._PromptDescription_19oai_94{animation:.15s ease-out both _sharing-waiting-enter_19oai_1}}@keyframes _sharing-waiting-enter_19oai_1{0%{opacity:0}to{opacity:1}}._FrameHost_19oai_49,._FallbackFrameHost_19oai_40{--sharing-max-height:584px;--sharing-resize-duration:.22s;--sharing-enter-y:16px;--sharing-exit-y:10px;z-index:2147483647;width:min(504px,100vw - 8px);height:min(var(--sharing-max-height), calc(100dvh - 88px));max-height:var(--sharing-max-height);pointer-events:none;visibility:hidden;transition:visibility .18s step-end;position:absolute;bottom:60px;right:12px}:is(._FrameHost_19oai_49,._FallbackFrameHost_19oai_40)[data-placement=top]{--sharing-enter-y:-16px;--sharing-exit-y:-10px}._FallbackFrameHost_19oai_40{container-type:size}._FrameHost_19oai_49[data-placement=top]>._Glass_19oai_204,._FallbackFrameHost_19oai_40[data-placement=top] ._Surface_19oai_146,._FallbackFrameHost_19oai_40[data-placement=top] ._FallbackFrame_19oai_40{top:0;bottom:auto}._Dialog_19oai_210[data-placement=top]{top:12px;bottom:auto}._Surface_19oai_146{pointer-events:none;width:min(100%,384px);max-height:100%;animation:.18s both _sharing-fallback-exit_19oai_1;display:flow-root;position:absolute;inset:auto 0 0 auto}._Surface_19oai_146:before{content:\"\";opacity:0;transition:opacity .18s;position:absolute;inset:12px}._FallbackFrameHost_19oai_40[data-controls] ._Surface_19oai_146{width:100%}._FallbackFrameHost_19oai_40[data-dock=left] :is(._Surface_19oai_146,._FallbackFrame_19oai_40){left:0;right:auto}._FallbackFrameHost_19oai_40[data-dock=center] :is(._Surface_19oai_146,._FallbackFrame_19oai_40){left:50%;right:auto;translate:-50%}._ModalHost_19oai_1[data-sharing-open] ._Surface_19oai_146{animation:.24s cubic-bezier(.2,.8,.2,1) both _sharing-fallback-enter_19oai_1}._ModalHost_19oai_1[data-sharing-open] ._Surface_19oai_146[data-initial-size]{transition:height var(--sharing-resize-duration) ease, width var(--sharing-resize-duration) ease}._ModalHost_19oai_1[data-sharing-open] ._Surface_19oai_146:before{opacity:1;transition:opacity .24s cubic-bezier(.2,.8,.2,1)}._Controls_19oai_265{pointer-events:none;position:absolute;inset:0}._FallbackFrame_19oai_40{--lightningcss-light:initial;--lightningcss-dark: ;color-scheme:light dark;opacity:0;pointer-events:none;background:0 0;border:0;width:100cqw;height:100cqh;position:absolute;inset:auto 0 0 auto}@media (prefers-color-scheme:dark){._FallbackFrame_19oai_40{--lightningcss-light: ;--lightningcss-dark:initial}}._FallbackFrameHost_19oai_40[data-controls] ._FallbackFrame_19oai_40{opacity:1;pointer-events:auto}._ModalHost_19oai_1[data-sharing-open] ._FallbackFrameHost_19oai_40[data-controls] ._Controls_19oai_265{animation:_sharing-reveal_19oai_1 var(--sharing-resize-duration) ease}@keyframes _sharing-reveal_19oai_1{0%{opacity:var(--sharing-enter-opacity,0);clip-path:inset(12px round 24px)}to{opacity:1;clip-path:inset(12px round 24px)}}._Controls_19oai_265:has(._FallbackFrame_19oai_40:not([data-user-role=owner],[data-user-role=editor])){--sharing-enter-opacity:1}._Frame_19oai_49{--lightningcss-light:initial;--lightningcss-dark: ;color-scheme:light dark;background:0 0;border:0;width:100%;height:100%;display:block;position:relative}@media (prefers-color-scheme:dark){._Frame_19oai_49{--lightningcss-light: ;--lightningcss-dark:initial}}._Frame_19oai_49:not([data-user-role=owner],[data-user-role=editor]){--sharing-enter-opacity:1}._Glass_19oai_204,._Surface_19oai_146:before{background:var(--lightningcss-light,#ffffffb8)var(--lightningcss-dark,var(--sites-toolbar-glass));-webkit-backdrop-filter:var(--sites-toolbar-backdrop-filter);backdrop-filter:var(--sites-toolbar-backdrop-filter);border-radius:24px;box-shadow:0 0 0 1px var(--lightningcss-light,#20212433)var(--lightningcss-dark,#ffffff1a),0 8px 32px #0000001a}._Glass_19oai_204{pointer-events:none;max-height:calc(100% - 24px);position:absolute;inset:auto 12px 12px}._FrameHost_19oai_49[data-panel-ready]>._Frame_19oai_49,._FrameHost_19oai_49[data-panel-ready]>._Glass_19oai_204{animation:.18s both _sharing-exit_19oai_1}._ModalHost_19oai_1[data-sharing-open] ._FrameHost_19oai_49[data-panel-ready]>._Frame_19oai_49,._ModalHost_19oai_1[data-sharing-open] ._FrameHost_19oai_49[data-panel-ready]>._Glass_19oai_204{animation:.24s cubic-bezier(.2,.8,.2,1) both _sharing-enter_19oai_1}._ModalHost_19oai_1,._Root_19oai_349{--ink:var(--lightningcss-light,#171717)var(--lightningcss-dark,#f3f3f3);--sharing-padding:20px}._Prompt_19oai_57,._Root_19oai_349{color:var(--ink);font:14px/1.45 ui-sans-serif,-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif}._Root_19oai_349{--border:var(--lightningcss-light,#0d0d0d33)var(--lightningcss-dark,#ffffff40);--surface:var(--lightningcss-light,#fff)var(--lightningcss-dark,#242424);--hover:var(--lightningcss-light,#0000000f)var(--lightningcss-dark,#ffffff1f);--active:var(--lightningcss-light,#0000001a)var(--lightningcss-dark,#ffffff2e);--muted:var(--lightningcss-light,#777)var(--lightningcss-dark,#aaa);--error:var(--lightningcss-light,#b42828)var(--lightningcss-dark,#ff9191);pointer-events:none;--lightningcss-light:initial;--lightningcss-dark: ;color-scheme:light dark;position:fixed;inset:0}@media (prefers-color-scheme:dark){._Root_19oai_349{--lightningcss-light: ;--lightningcss-dark:initial}}._Root_19oai_349 *{box-sizing:border-box}._Dialog_19oai_210{pointer-events:auto;background:0 0;border:0;border-radius:24px;outline:none;flex-direction:column;max-height:calc(100% - 24px);padding:0;display:flex;position:absolute;inset:auto 12px 12px;overflow:hidden}._Dialog_19oai_210[data-state=closed]{pointer-events:none;animation:.18s both _sharing-retain_19oai_1}._Body_19oai_403{flex-direction:column;min-height:0;display:flex}._Header_19oai_408{flex-direction:column;flex-shrink:0;padding:20px 20px 0;display:flex}._AccessList_19oai_414{--fade-top:0px;--fade-bottom:0px;overscroll-behavior:contain;min-height:0;-webkit-mask-image:linear-gradient(to bottom, transparent, black var(--fade-top), black calc(100% - var(--fade-bottom)), transparent);mask-image:linear-gradient(to bottom, transparent, black var(--fade-top), black calc(100% - var(--fade-bottom)), transparent);overflow:auto}._AccessList_19oai_414[data-scroll-cutoff]{--fade-top:16px}._AccessList_19oai_414[data-scroll-cutoff-below]{--fade-bottom:16px}._AccessListContent_19oai_435{padding-inline:20px}._Title_19oai_438{overflow-wrap:anywhere;margin:0 0 24px;font-size:18px;font-weight:500;line-height:1.3}._Dialog_19oai_210[data-read-only] ._Title_19oai_438{margin-bottom:0}._Section_19oai_448{margin:20px 0 8px;font-size:14px;font-weight:400}._Results_19oai_453{width:var(--radix-popover-trigger-width);max-width:var(--radix-popover-content-available-width);max-height:min(256px, var(--radix-popover-content-available-height));z-index:1;background:var(--lightningcss-light,#fff)var(--lightningcss-dark,#292929);border-radius:14px;outline:none;padding:6px;overflow:auto;box-shadow:0 8px 28px #00000029,0 0 0 1px var(--lightningcss-light,#00000014)var(--lightningcss-dark,#ffffff1f)}._Result_19oai_453{text-align:start;white-space:normal;width:100%;height:auto;min-height:52px;color:var(--ink);border-radius:8px;gap:10px;padding:8px;font-weight:400}._Result_19oai_453[data-variant]{--button-background-color-hover:var(--hover);--button-background-color-active:var(--active)}._Result_19oai_453>span{justify-content:flex-start}._Result_19oai_453:not(:disabled):hover:before{background:var(--hover)}._Result_19oai_453:before{transition-property:transform}._Person_19oai_497{align-items:center;gap:12px;padding:8px 0;display:flex}._GroupAvatar_19oai_503{--button-icon-size:16px}._GroupAvatar_19oai_503>svg{width:16px;height:16px}._Identity_19oai_512{overflow-wrap:anywhere;flex-direction:column;flex:1;min-width:0;display:flex}._Secondary_19oai_519{color:var(--muted);font-size:13px}._Role_19oai_523{max-width:130px;margin-inline-end:-8px}._Role_19oai_523[data-variant]{color:var(--muted)}._RoleMenu_19oai_532{--select-menu-width:240px;text-wrap:pretty}._AccessMode_19oai_537{align-self:flex-start;height:44px;margin-inline-start:-8px;padding:0 8px;padding-inline-end:13px}._AccessModeLabel_19oai_545{align-items:center;gap:8px;min-height:44px;margin:0;display:flex}._AccessModeIcon_19oai_552{flex-shrink:0;justify-content:center;align-items:center;width:28px;height:28px;display:inline-flex}._AccessModeIcon_19oai_552>svg{width:20px;height:20px}._ReadOnlyRole_19oai_565{color:var(--muted);padding-inline-end:4px}._Footer_19oai_569,._PromptFooter_19oai_82{flex-shrink:0;justify-content:flex-end;gap:8px;display:flex}._Footer_19oai_569{padding:var(--sharing-padding)}._FooterLeading_19oai_579{margin-inline-end:auto}._AdvancedHeader_19oai_582 ._Title_19oai_438{margin-bottom:16px}._AdvancedFooter_19oai_585{padding-top:16px}._InviteRole_19oai_589{height:var(--tag-input-height);color:var(--muted);flex-shrink:0}._InviteRole_19oai_589[data-variant]{gap:6px;padding-inline:10px 6px}._RemixSetting_19oai_599{align-items:center;gap:8px;padding-block:8px 12px;display:flex}._RemixInfo_19oai_605{color:var(--muted);cursor:default;background:0 0;border:0;flex-shrink:0;padding:2px;display:inline-flex}._RemixExplanation_19oai_614{--tooltip-border-radius:12px;--tooltip-compact-padding:12px 16px;--tooltip-line-height:1.45}._RemixSwitch_19oai_619{flex-shrink:0;margin-inline-start:auto}._RemixSetting_19oai_599>label{cursor:pointer}._Copy_19oai_626{color:var(--ink);background:0 0;gap:8px;padding:0 16px;font-size:13px}._Copy_19oai_626[data-variant]{--button-background-color-hover:var(--hover);--button-background-color-active:var(--active)}._Copy_19oai_626:before{box-shadow:inset 0 0 0 1px var(--border)}._Error_19oai_643{color:var(--error);flex-shrink:0;margin:12px 20px;font-size:13px}._Notice_19oai_649{color:var(--muted);padding:8px 0;font-size:13px}._SearchHint_19oai_654{margin:0;padding:12px}._SearchLoading_19oai_658{place-items:center;min-height:calc(1lh + 16px);display:grid}._EmptyResults_19oai_664{color:var(--muted);margin:0;padding:12px;font-size:14px;line-height:20px}@media (max-width:480px){._Role_19oai_523{max-width:105px}}@keyframes _sharing-retain_19oai_1{0%,to{visibility:visible}}@keyframes _sharing-fallback-enter_19oai_1{0%{transform:translateY(var(--sharing-enter-y))}to{transform:translateY(0)}}@keyframes _sharing-fallback-exit_19oai_1{0%{transform:translateY(0)}to{transform:translateY(var(--sharing-exit-y))}}@keyframes _sharing-enter_19oai_1{0%{opacity:var(--sharing-enter-opacity,0);transform:translateY(var(--sharing-enter-y))}to{opacity:1;transform:translateY(0)}}@keyframes _sharing-exit_19oai_1{0%{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(var(--sharing-exit-y))}}@media (prefers-reduced-motion:reduce){._Surface_19oai_146:before,._ModalHost_19oai_1[data-sharing-open] ._Surface_19oai_146:before{transition:none}._FrameHost_19oai_49,._FallbackFrameHost_19oai_40{--sharing-resize-duration:0s;transition:none}._Dialog_19oai_210[data-state],._ModalHost_19oai_1 ._FrameHost_19oai_49>._Frame_19oai_49,._ModalHost_19oai_1 ._FrameHost_19oai_49>._Glass_19oai_204,._Surface_19oai_146,._ModalHost_19oai_1[data-sharing-open] ._FallbackFrameHost_19oai_40 ._Surface_19oai_146,._ModalHost_19oai_1[data-sharing-open] ._FallbackFrameHost_19oai_40[data-controls] ._Controls_19oai_265,._Prompt_19oai_57 span{animation:none}}._Avatar_1qach_1{--avatar-radius:50%;--avatar-font-size-scaling:.4;--avatar-overflow-font-size-scaling-one:.4;--avatar-overflow-font-size-scaling-two:.32;--avatar-overflow-font-size-scaling-three:.28;--avatar-image-border-color:var(--lightningcss-light,#00000014)var(--lightningcss-dark,#ffffff1f);--font-weight-semibold:600;width:var(--avatar-size);height:var(--avatar-size);border-radius:var(--avatar-radius);transition:background-color .3s var(--cubic-enter);-webkit-user-select:none;user-select:none;flex-grow:0;flex-shrink:0;justify-content:center;align-items:center;display:inline-flex;position:relative;overflow:hidden}._Avatar_1qach_1[type=button]{cursor:pointer}._Avatar_1qach_1[type=button]:focus-visible{outline:2px solid var(--avatar-ring-color);outline-offset:2px}._Avatar_1qach_1{color:var(--lightningcss-light,#5d5d5d)var(--lightningcss-dark,#d1d1d1);background-color:var(--lightningcss-light,#0000000f)var(--lightningcss-dark,#ffffff1f)}._AvatarImageContainer_1qach_47{border-radius:inherit}._AvatarImageContainer_1qach_47:after{border:1px solid var(--avatar-image-border-color);border-radius:inherit;content:\"\";pointer-events:none;display:block;position:absolute;inset:0}._AvatarImage_1qach_47{border-radius:inherit;object-fit:cover;opacity:0;pointer-events:none;width:100%;height:100%;transition:all .15s;position:absolute;top:0;left:0}._AvatarImage_1qach_47[data-loaded]{opacity:1}._AvatarInitial_1qach_79{font-size:calc(var(--avatar-size) * var(--avatar-font-size-scaling));font-weight:var(--font-weight-semibold)}._AvatarInitial_1qach_79[data-letter-count=\"2\"]{font-size:calc(var(--avatar-size) * var(--avatar-font-size-scaling) * .75)}._AvatarOverflowCount_1qach_90{font-size:calc(var(--avatar-size) * var(--avatar-overflow-font-size-scaling-three));font-weight:var(--font-weight-semibold)}._AvatarOverflowCount_1qach_90[data-letter-count=\"2\"]{font-size:calc(var(--avatar-size) * var(--avatar-overflow-font-size-scaling-two))}._AvatarOverflowCount_1qach_90[data-letter-count=\"1\"]{font-size:calc(var(--avatar-size) * var(--avatar-overflow-font-size-scaling-one))}._AvatarOverflowCountSymbol_1qach_113{top:calc(-1 * var(--avatar-size) / 24);margin-left:-1px;position:relative}._AvatarIcon_1qach_119{font-size:calc(var(--avatar-size) * .7);flex-grow:0;flex-shrink:0;display:block}._Trigger_168v9_3{color:var(--lightningcss-light,#171717)var(--lightningcss-dark,#f3f3f3);border-radius:8px;gap:8px;max-width:100%;font-size:14px}._Trigger_168v9_3[data-pill]{border-radius:9999px}._Trigger_168v9_3[data-variant],._Action_168v9_14[data-variant]{--button-background-color-active:var(--lightningcss-light,#0000001a)var(--lightningcss-dark,#ffffff2e)}._Trigger_168v9_3:before{background:0 0}._Trigger_168v9_3[aria-busy=true]{opacity:1;cursor:wait}._Trigger_168v9_3:not(:disabled):hover:before,._Trigger_168v9_3[data-state=open]:before{background:var(--lightningcss-light,#0000000f)var(--lightningcss-dark,#ffffff1f)}._Trigger_168v9_3 ._Chevron_168v9_31{color:var(--lightningcss-light,#777)var(--lightningcss-dark,#aaa);flex-shrink:0;width:14px;height:14px}._Label_168v9_37{text-overflow:ellipsis;overflow:hidden}._Thumbnail_168v9_41{background:0 0;border-radius:8px;flex-shrink:0;justify-content:center;align-items:center;width:28px;height:28px;display:inline-flex}._Thumbnail_168v9_41 svg{width:20px;height:20px}._MenuList_168v9_55{pointer-events:auto;box-sizing:border-box;min-width:min(220px,100vw - 24px);width:var(--select-menu-width,max-content);max-width:min(280px,100vw - 24px);max-height:var(--radix-popover-content-available-height);color:var(--lightningcss-light,#171717)var(--lightningcss-dark,#f3f3f3);transform-origin:var(--radix-popover-content-transform-origin);-webkit-user-select:none;user-select:none;z-index:1;background:var(--lightningcss-light,#fff)var(--lightningcss-dark,#292929);border-radius:14px;font:14px/20px ui-sans-serif,-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;animation:.18s cubic-bezier(.19,1,.22,1) _enter_168v9_1;overflow:auto;box-shadow:0 8px 28px #00000029,0 0 0 1px var(--lightningcss-light,#00000014)var(--lightningcss-dark,#ffffff1f)}._MenuList_168v9_55:focus,._OptionsList_168v9_81:focus{outline:none}._OptionsList_168v9_81{padding:6px}._Option_168v9_81{cursor:pointer;overflow-wrap:anywhere;padding:10px;scroll-margin:15px 0;position:relative}._Option_168v9_81:before{content:\"\";opacity:0;background:var(--lightningcss-light,#0000000f)var(--lightningcss-dark,#ffffff1f);border-radius:8px;display:block;position:absolute;inset:0;transform:scale(.98)}._Option_168v9_81[data-highlight]:before{opacity:1;transform:scale(1)}._Option_168v9_81[data-highlight]:active:before{transform:scale(.98)}._Option_168v9_81[data-disabled]{cursor:not-allowed}._Option_168v9_81[data-disabled] ._OptionText_168v9_115>:first-child,._Option_168v9_81[data-disabled] ._OptionInner_168v9_116>svg,._Option_168v9_81[data-disabled] ._OptionIndicatorSlot_168v9_117{opacity:.5}._Option_168v9_81[data-disabled]:before{display:none}._Option_168v9_81[aria-busy=true]{cursor:wait;opacity:1}._Option_168v9_81[aria-busy=true]:before{display:block}._OptionInner_168v9_116{align-items:center;gap:10px;display:flex;position:relative}._OptionInner_168v9_116>svg{flex-shrink:0;width:20px;height:20px}._OptionText_168v9_115{flex-direction:column;flex:1;min-width:0;display:flex}._Description_168v9_147{white-space:normal;color:var(--lightningcss-light,#6e6e6e)var(--lightningcss-dark,#aaa);font-size:12px;font-weight:400;line-height:18px}._OptionIndicatorSlot_168v9_117{flex-shrink:0;width:16px;height:16px;margin-inline-start:auto;display:flex}._OptionIndicatorSlot_168v9_117 svg{width:16px;height:16px}._ActionsContainer_168v9_165{border-top:1px solid var(--lightningcss-light,#eee)var(--lightningcss-dark,#444);padding:6px}._Action_168v9_14{color:var(--lightningcss-light,#b42318)var(--lightningcss-dark,#ff8583);border-radius:8px;width:100%;font-size:14px}._Action_168v9_14>span{justify-content:flex-start}._Action_168v9_14:before{transition-property:transform}._ActionIndicator_168v9_181{color:var(--lightningcss-light,#6e6e6e)var(--lightningcss-dark,#aaa);margin-inline-start:auto}._Action_168v9_14:not(:disabled):hover:before{background:var(--lightningcss-light,#0000000f)var(--lightningcss-dark,#ffffff1f)}@keyframes _enter_168v9_1{0%{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}@media (prefers-reduced-motion:reduce){._MenuList_168v9_55{animation:none}}._Container_kb33f_2{--tag-input-padding-inline-start:var(--tag-input-tag-spacing);--tag-input-padding-inline-end:var(--tag-input-tag-spacing);min-height:calc((var(--min-rows) * var(--tag-input-height)) + ((var(--min-rows) + 1) * var(--tag-input-tag-spacing)));padding:var(--tag-input-tag-spacing) var(--tag-input-padding-inline-end) var(--tag-input-tag-spacing) var(--tag-input-padding-inline-start);cursor:text;border-radius:8px;outline:0;transition:box-shadow .15s;position:relative;overflow:hidden;box-shadow:inset 0 0 0 1px var(--lightningcss-light,#0d0d0d29)var(--lightningcss-dark,#ffffff40)}._Container_kb33f_2[data-disabled]{pointer-events:none}@media (hover:hover){._Container_kb33f_2:not([data-disabled]):hover{box-shadow:inset 0 0 0 1px var(--lightningcss-light,#afafaf)var(--lightningcss-dark,#5d5d5d)}}._Container_kb33f_2:not([data-disabled])[data-focused]{box-shadow:inset 0 0 0 1px var(--lightningcss-light,#0d0d0d80)var(--lightningcss-dark,#ffffff80)}._Container_kb33f_2[data-empty]:not([data-has-start-adornment]){--tag-input-padding-inline-start:12px}._Container_kb33f_2[data-empty]:not([data-has-end-adornment]){--tag-input-padding-inline-end:12px}._Container_kb33f_2:where([data-size=md]){--tag-input-font-size:14px;--tag-input-height:20px;--tag-input-tag-spacing:6px}._Container_kb33f_2:where([data-size=lg]){--tag-input-font-size:14px;--tag-input-height:24px;--tag-input-tag-spacing:6px}._Container_kb33f_2:where([data-size=xl]){--tag-input-font-size:16px;--tag-input-height:24px;--tag-input-tag-spacing:8px}._Container_kb33f_2:where([data-size=\"2xl\"]){--tag-input-font-size:16px;--tag-input-height:28px;--tag-input-tag-spacing:8px}._Container_kb33f_2:where([data-size=\"3xl\"]){--tag-input-font-size:16px;--tag-input-height:32px;--tag-input-tag-spacing:8px}._TagInput_kb33f_89{margin-bottom:calc(var(--tag-input-tag-spacing) * -1);font-size:0;line-height:0;display:flow-root}._StartAdornment_kb33f_96,._EndAdornment_kb33f_97{min-width:var(--tag-input-height);max-width:calc(100% - var(--tag-input-tag-spacing));height:var(--tag-input-height);color:#8f8f8f;font-size:var(--tag-input-font-size);justify-content:center;align-items:center;line-height:1;display:inline-flex}:is(._StartAdornment_kb33f_96,._EndAdornment_kb33f_97)>*{max-width:100%}._StartAdornment_kb33f_96{margin-right:var(--tag-input-tag-spacing);margin-bottom:var(--tag-input-tag-spacing);vertical-align:top}._EndAdornment_kb33f_97{margin-bottom:var(--tag-input-tag-spacing);margin-left:var(--tag-input-tag-spacing);float:right}._Tag_kb33f_89{max-width:100%;height:var(--tag-input-height);margin-right:var(--tag-input-tag-spacing);margin-bottom:var(--tag-input-tag-spacing);color:var(--lightningcss-light,#282828)var(--lightningcss-dark,#fff);cursor:pointer;background-color:var(--lightningcss-light,#0000000f)var(--lightningcss-dark,#ffffff1f);border-radius:8px;outline:none;align-items:center;padding:4px 4px 4px 8px;line-height:1.4;transition:background-color .15s;display:inline-flex;overflow:hidden;box-shadow:inset 0 0 0 1px var(--lightningcss-light,#00000014)var(--lightningcss-dark,#ffffff1f)}@media (hover:hover){._Tag_kb33f_89:hover{background-color:var(--lightningcss-light,#0000001a)var(--lightningcss-dark,#ffffff2e)}}._Tag_kb33f_89:focus{background-color:var(--lightningcss-light,#0000001a)var(--lightningcss-dark,#ffffff2e)}._Container_kb33f_2[data-disabled] ._Tag_kb33f_89{color:#8f8f8f}._Tag_kb33f_89[data-invalid]{color:var(--lightningcss-light,#ba2623)var(--lightningcss-dark,#fa423e);background-color:#ffd9d9}@media (hover:hover){._Tag_kb33f_89[data-invalid]:hover{background-color:#ffc6c5}}._Tag_kb33f_89[data-invalid]:focus{background-color:#ffc6c5}._Tag_kb33f_89[data-duplicate]{animation:.5s _shake_kb33f_1}._Tag_kb33f_89 ._TagRemove_kb33f_177{appearance:none;font:inherit;cursor:pointer;background:0 0;border:0;padding:0}._Tag_kb33f_89 ._TagRemove_kb33f_177:focus-visible{outline-offset:2px;outline:2px solid}._Tag_kb33f_89 ._TagRemove_kb33f_177{color:inherit;opacity:.7;align-items:center;margin-left:4px;transition:opacity .15s;display:flex;position:relative}@media (hover:hover){._Tag_kb33f_89 ._TagRemove_kb33f_177:hover{opacity:1}}._TagContent_kb33f_205{white-space:nowrap;align-items:center;min-width:0;max-width:100%;line-height:1;display:flex;overflow:hidden}._TagValue_kb33f_215{min-width:0;max-width:100%;font-size:var(--tag-input-font-size);text-overflow:ellipsis;white-space:nowrap;line-height:normal;display:block;overflow:hidden}._TagValue_kb33f_215>*{vertical-align:top}._InputContainer_kb33f_230{max-width:100%;margin-bottom:var(--tag-input-tag-spacing);vertical-align:top;align-items:center;display:inline-flex}._InputWrapper_kb33f_238{width:100%;overflow:hidden}._InputMeasure_kb33f_243{font-size:var(--tag-input-font-size);visibility:hidden;white-space:nowrap;position:absolute}._Input_kb33f_230{min-width:20px;height:var(--tag-input-height);box-shadow:none;color:var(--lightningcss-light,#282828)var(--lightningcss-dark,#dcdcdc);font-family:inherit;font-size:var(--tag-input-font-size);white-space:nowrap;background:0 0;border:0;border-radius:0;padding:0;line-height:1.4;display:block}._Input_kb33f_230:focus{outline:0}._Input_kb33f_230::-webkit-search-cancel-button{appearance:none}._Input_kb33f_230::placeholder,._Input_kb33f_230:disabled{color:#8f8f8f}._Input_kb33f_230:-webkit-any(:-webkit-autofill,:-webkit-autofill){color:var(--lightningcss-light,#282828)var(--lightningcss-dark,#dcdcdc)!important;-webkit-text-fill-color:var(--lightningcss-light,#282828)var(--lightningcss-dark,#dcdcdc)!important;transition:background-color 0s 50000s,box-shadow 0s 50000s,filter 0s 50000s!important}._Input_kb33f_230:is(:autofill,:autofill){color:var(--lightningcss-light,#282828)var(--lightningcss-dark,#dcdcdc)!important;-webkit-text-fill-color:var(--lightningcss-light,#282828)var(--lightningcss-dark,#dcdcdc)!important;transition:background-color 0s 50000s,box-shadow 0s 50000s,filter 0s 50000s!important}._Limit_kb33f_296{color:var(--lightningcss-light,#282828)var(--lightningcss-dark,#dcdcdc);font-variant-numeric:tabular-nums;width:100%;margin-top:2px;font-size:12px}._Limit_kb33f_296>span{margin-inline:1px}._Limit_kb33f_296{text-align:right}@keyframes _shake_kb33f_1{0%{transform:translate(0)}20%,60%{transform:translate(-5px)}40%,80%{transform:translate(5px)}to{transform:translate(0)}}._Container_244h6_2{--switch-track-width:32px;--switch-track-height:19px;--switch-track-color:var(--lightningcss-light,#dfdfdf)var(--lightningcss-dark,#414141);--switch-track-color-hover:var(--lightningcss-light,#cdcdcd)var(--lightningcss-dark,#4f4f4f);--switch-track-color-checked:var(--lightningcss-light,#181818)var(--lightningcss-dark,#0285ff);--switch-track-color-checked-disabled:var(--lightningcss-light,#afafaf)var(--lightningcss-dark,#003f7a);--switch-track-color-disabled:var(--lightningcss-light,#ededed)var(--lightningcss-dark,#303030);--switch-thumb-offset:3px;--switch-thumb-size:calc(var(--switch-track-height) - 2 * var(--switch-thumb-offset));--switch-thumb-shadow:0 1px 2px #0003;--switch-thumb-color:#fff;--switch-thumb-color-disabled:var(--lightningcss-light,#fff)var(--lightningcss-dark,#cdcdcd);--switch-label-gap:8px;-webkit-user-select:none;user-select:none;font-size:14px;line-height:20px;display:flex;position:relative}._Container_244h6_2[data-has-label]{align-items:flex-start}._Container_244h6_2[data-label-position=start]{flex-direction:row-reverse}._Track_244h6_34{width:var(--switch-track-width);max-width:var(--switch-track-width);height:var(--switch-track-height);background:var(--switch-track-color);cursor:pointer;border:0;border-radius:9999px;flex-shrink:0;padding:0;transition:background-color .25s cubic-bezier(.65,0,.35,1);position:relative}@media (hover:hover){._Track_244h6_34:where(:not([data-disabled],[data-state=checked])):hover{background:var(--switch-track-color-hover)}}[data-has-label] ._Track_244h6_34{top:var(--switch-track-top-offset,1px)}._Track_244h6_34:focus-visible{outline-offset:2px;outline:2px solid var(--lightningcss-light,#0169cc)var(--lightningcss-dark,#0285ff)}._Track_244h6_34[data-state=checked]{background:var(--switch-track-color-checked)}._Track_244h6_34[data-disabled],._Track_244h6_34[aria-disabled=true]{background:var(--switch-track-color-disabled);cursor:not-allowed}:is(._Track_244h6_34[data-disabled],._Track_244h6_34[aria-disabled=true])[data-state=checked]{background:var(--switch-track-color-checked-disabled)}._Thumb_244h6_82{top:var(--switch-thumb-offset);left:var(--switch-thumb-offset);width:var(--switch-thumb-size);height:var(--switch-thumb-size);background:var(--switch-thumb-color);box-shadow:var(--switch-thumb-shadow);border-radius:9999px;transition:transform .25s cubic-bezier(.65,0,.35,1);display:block;position:absolute}[data-state=checked] ._Thumb_244h6_82{transform:translateX(calc(var(--switch-track-width) - var(--switch-thumb-size) - var(--switch-thumb-offset) * 2))}._Thumb_244h6_82[data-disabled]{background:var(--switch-thumb-color-disabled);box-shadow:none}._Label_244h6_109{cursor:pointer}[data-label-position=end] ._Label_244h6_109{padding-left:var(--switch-label-gap)}[data-label-position=start] ._Label_244h6_109{padding-right:var(--switch-label-gap)}[data-disabled] ._Label_244h6_109{cursor:not-allowed}\n/*$vite$:1*/";
      const _ = document.createElement("div");
      _.className = Ft.Theme;
      const w = document.createElement("div");
      w.className = Be(Ft.Theme, Ft.Portal), w.lang = h, w.dir = Oa(h), m.append(y, p, _, w);
      const E = await y7(h);
      if (l.isConnected) {
        if (!r.isolatedDocument && typeof l.showPopover == "function") {
          l.popover = "manual";
          try {
            l.showPopover(), l.matches(":popover-open") || l.removeAttribute("popover");
          } catch {
            l.removeAttribute("popover");
          }
        }
        await new Promise((x, C) => {
          s = (0, g7.createRoot)(_, { onUncaughtError: C }), s.render(/* @__PURE__ */ (0, g.jsx)(_E, {
            locale: h,
            defaultLocale: $o,
            messages: E,
            onError: (T) => {
              if (T.code !== "MISSING_TRANSLATION") throw T;
            },
            children: /* @__PURE__ */ (0, g.jsxs)($b, {
              container: w,
              children: [a({
                shadowHost: l,
                onDismiss: d
              }), /* @__PURE__ */ (0, g.jsx)(b7, { onMount: x })]
            })
          }));
        });
      }
    })(),
    dispose: d
  };
}
var _7 = Pt({
  type: zi("sites-toolbar-summary"),
  label: _t().min(1).max(256),
  icon: gn([
    "lock",
    "globe",
    "people",
    "building"
  ])
}).strict(), w7 = oy({
  type: zi("sites-toolbar-analytics-role"),
  site_user_role: gn(fy)
}), S7 = Pt({
  type: gn(["sites-toolbar-open-sharing", "sites-toolbar-close-sharing"]),
  placement: gn(["top", "bottom"]).optional()
}).strict(), E7 = oy({
  type: zi("sites-toolbar-sharing-unavailable"),
  reason: gn(["login", "unavailable"])
}), T7 = Pt({ type: zi("sites-toolbar-sharing-closed") }).strict(), C7 = Pt({
  type: zi("sites-toolbar-sharing-size"),
  height: eh().finite().positive().max(1e4)
}).strict();
function f_(e, a, r) {
  return a !== null && e.source === a && e.origin === r;
}
var A7 = {
  private: "lock",
  admins: "lock",
  public: "globe",
  workspace: "building",
  inviteOnly: "people",
  people: "people",
  share: "people",
  manageAccess: "people"
};
function x7(e, a) {
  let r;
  return e.kind === "workspace" ? r = e.workspace_name || a.formatMessage(ne.workspace) : e.kind === "people" ? r = a.formatMessage(ne.people, { count: e.count }) : r = a.formatMessage(e.kind === "manageAccess" ? ne.manageAccess : ne[e.kind]), {
    type: "sites-toolbar-summary",
    label: r.slice(0, 256),
    icon: A7[e.kind]
  };
}
var O7 = (e) => /* @__PURE__ */ (0, g.jsx)("svg", {
  width: "1em",
  height: "1em",
  viewBox: "0 0 24 24",
  fill: "currentColor",
  ...e,
  children: /* @__PURE__ */ (0, g.jsx)("path", {
    d: "M12.8534 5.314C12.4635 4.67593 11.5368 4.67593 11.1468 5.314L3.71295 17.4785C3.30573 18.1449 3.7853 19 4.56623 19H19.434C20.2149 19 20.6945 18.1449 20.2873 17.4785L12.8534 5.314ZM9.44027 4.2711C10.6101 2.3569 13.3902 2.3569 14.56 4.2711L21.9938 16.4356C23.2155 18.4347 21.7768 21 19.434 21H4.56623C2.22344 21 0.784738 18.4347 2.00639 16.4356L9.44027 4.2711ZM12.0001 8.99999C12.5524 8.99999 13.0001 9.44771 13.0001 9.99999V13C13.0001 13.5523 12.5524 14 12.0001 14C11.4478 14 11.0001 13.5523 11.0001 13V9.99999C11.0001 9.44771 11.4478 8.99999 12.0001 8.99999ZM10.8517 16.5001C10.8517 15.865 11.3665 15.3501 12.0017 15.3501C12.6368 15.3501 13.1517 15.8649 13.1517 16.5001C13.1517 17.1352 12.6368 17.6501 12.0017 17.6501C11.3665 17.6501 10.8517 17.1352 10.8517 16.5001Z",
    fill: "currentColor"
  })
}), M7 = "_ModalHost_19oai_1", R7 = "_FallbackFrameHost_19oai_40", N7 = "_FrameHost_19oai_49", D7 = "_Prompt_19oai_57", z7 = "_PromptFooter_19oai_82", L7 = "_PromptTitle_19oai_94", H7 = "_PromptDescription_19oai_94", j7 = "_PromptErrorIcon_19oai_139", B7 = "_Surface_19oai_146", U7 = "_Glass_19oai_204", k7 = "_FallbackFrame_19oai_40", P7 = "_Dialog_19oai_210", I7 = "_Controls_19oai_265", Z7 = "_Frame_19oai_49", G7 = "_Root_19oai_349", V7 = "_Body_19oai_403", $7 = "_Header_19oai_408", F7 = "_AccessList_19oai_414", q7 = "_AccessListContent_19oai_435", X7 = "_Title_19oai_438", Y7 = "_Section_19oai_448", W7 = "_Results_19oai_453", Q7 = "_Result_19oai_453", K7 = "_Person_19oai_497", J7 = "_GroupAvatar_19oai_503", eO = "_Identity_19oai_512", tO = "_Secondary_19oai_519", nO = "_Role_19oai_523", aO = "_RoleMenu_19oai_532", iO = "_AccessMode_19oai_537", rO = "_AccessModeLabel_19oai_545", oO = "_AccessModeIcon_19oai_552", lO = "_ReadOnlyRole_19oai_565", sO = "_Footer_19oai_569", uO = "_FooterLeading_19oai_579", cO = "_AdvancedHeader_19oai_582", fO = "_AdvancedFooter_19oai_585", dO = "_InviteRole_19oai_589", hO = "_RemixSetting_19oai_599", mO = "_RemixInfo_19oai_605", pO = "_RemixExplanation_19oai_614", vO = "_RemixSwitch_19oai_619", gO = "_Copy_19oai_626", yO = "_Notice_19oai_649", bO = "_SearchHint_19oai_654", _O = "_SearchLoading_19oai_658", wO = "_EmptyResults_19oai_664", fe = {
  ModalHost: M7,
  FallbackFrameHost: R7,
  FrameHost: N7,
  Prompt: D7,
  PromptFooter: z7,
  PromptTitle: L7,
  PromptDescription: H7,
  PromptErrorIcon: j7,
  Surface: B7,
  "sharing-waiting-enter": "_sharing-waiting-enter_19oai_1",
  Glass: U7,
  FallbackFrame: k7,
  Dialog: P7,
  "sharing-fallback-exit": "_sharing-fallback-exit_19oai_1",
  "sharing-fallback-enter": "_sharing-fallback-enter_19oai_1",
  Controls: I7,
  "sharing-reveal": "_sharing-reveal_19oai_1",
  Frame: Z7,
  "sharing-exit": "_sharing-exit_19oai_1",
  "sharing-enter": "_sharing-enter_19oai_1",
  Root: G7,
  "sharing-retain": "_sharing-retain_19oai_1",
  Body: V7,
  Header: $7,
  AccessList: F7,
  AccessListContent: q7,
  Title: X7,
  Section: Y7,
  Results: W7,
  Result: Q7,
  Person: K7,
  GroupAvatar: J7,
  Identity: eO,
  Secondary: tO,
  Role: nO,
  RoleMenu: aO,
  AccessMode: iO,
  AccessModeLabel: rO,
  AccessModeIcon: oO,
  ReadOnlyRole: lO,
  Footer: sO,
  FooterLeading: uO,
  AdvancedHeader: cO,
  AdvancedFooter: fO,
  InviteRole: dO,
  RemixSetting: hO,
  RemixInfo: mO,
  RemixExplanation: pO,
  RemixSwitch: vO,
  Copy: gO,
  Error: "_Error_19oai_643",
  Notice: yO,
  SearchHint: bO,
  SearchLoading: _O,
  EmptyResults: wO
}, SO = 1e3;
function EO({ ref: e, status: a, titleId: r, descriptionId: l, isOwner: s, sharingUrl: c, startLogin: d }) {
  const { formatMessage: h, locale: m } = Fe(), [y, p] = (0, b.useState)(null), _ = (0, b.useRef)(void 0);
  (0, b.useEffect)(() => () => window.clearTimeout(_.current), []);
  const w = a === "loading" || a === "ready", E = a === "error", x = a === "sign-in" || a === "waiting", C = a === "waiting" && y !== null, T = a === "waiting" && y !== "sign-in", M = h(E ? ne.shareLoadErrorTitle : s ? ne.shareSignInTitleOwner : ne.shareSignInTitleViewer), D = h(E ? ne.shareLoadError : T ? ne.shareWaiting : ne.shareSignIn), j = w ? h(ne.shareLoading) : void 0;
  function H() {
    p(T ? "waiting" : "sign-in"), window.clearTimeout(_.current), _.current = window.setTimeout(() => p(null), SO), d();
  }
  const k = x ? /* @__PURE__ */ (0, g.jsx)(ft, {
    pill: !0,
    size: "lg",
    "data-share-action": !0,
    loading: C,
    onClick: H,
    children: h(T ? ne.shareRetry : ne.shareContinue)
  }) : c && /* @__PURE__ */ (0, g.jsx)(ah, {
    pill: !0,
    size: "lg",
    "data-share-action": !0,
    href: c.href,
    target: "_blank",
    rel: "noopener noreferrer",
    children: h(ne.shareOpenSettings)
  });
  return /* @__PURE__ */ (0, g.jsxs)("div", {
    ref: e,
    className: fe.Prompt,
    "data-login-notice": x ? "" : void 0,
    "data-error": E ? "" : void 0,
    "data-waiting": T ? "" : void 0,
    "data-loading": w ? "" : void 0,
    dir: Oa(m),
    lang: m,
    children: [/* @__PURE__ */ (0, g.jsx)(rh, {
      role: "status",
      "aria-label": j,
      children: j ?? (E || T ? D : null)
    }), w ? /* @__PURE__ */ (0, g.jsx)(Yo, { size: 24 }) : /* @__PURE__ */ (0, g.jsxs)(g.Fragment, { children: [
      E && /* @__PURE__ */ (0, g.jsx)(O7, {
        className: fe.PromptErrorIcon,
        "aria-hidden": "true",
        focusable: "false"
      }),
      /* @__PURE__ */ (0, g.jsx)("h2", {
        className: fe.PromptTitle,
        id: r,
        children: M
      }),
      /* @__PURE__ */ (0, g.jsx)("p", {
        className: fe.PromptDescription,
        id: l,
        children: D
      }),
      k && /* @__PURE__ */ (0, g.jsx)("div", {
        className: fe.PromptFooter,
        children: k
      })
    ] })]
  });
}
function TO({ context: e, store: a, siteTitle: r }) {
  const l = Fe(), s = e.shareLoginEnabled === !0, c = (0, b.useRef)(null), d = (0, b.useRef)(null), h = (0, b.useRef)(null), m = (0, b.useRef)(null), y = (0, b.useId)(), p = (0, b.useId)(), { sharingStatus: _, sharingOpen: w, placement: E, summary: x, config: C, actions: T } = au(a), M = (0, b.useRef)(null), [{ version: D, attempt: j }, H] = (0, b.useState)({
    version: 0,
    attempt: null
  });
  (0, b.useEffect)(() => {
    const ue = () => M.current?.dispose();
    if (s)
      return window.addEventListener("pagehide", ue), () => {
        window.removeEventListener("pagehide", ue), ue();
      };
  }, [s]);
  const k = C?.current_user_role ?? e.currentUserRole ?? "owner", [B, Q] = (0, b.useState)(null), [K, q] = (0, b.useState)(null), [F, ee] = (0, b.useState)(null), [ce, V] = (0, b.useState)(null);
  (0, b.useLayoutEffect)(() => {
    if (!F) return;
    const ue = () => {
      V(Math.ceil(F.getBoundingClientRect().height) + 24);
    }, me = new ResizeObserver(ue);
    return me.observe(F, { box: "border-box" }), ue(), () => me.disconnect();
  }, [F]);
  function ie(ue) {
    q(null), H(({ version: me }) => ({
      version: me + 1,
      attempt: ue
    }));
  }
  const se = new URL("/", e.toolbarOrigin);
  se.searchParams.set("site_origin", window.location.origin), se.hash = new URLSearchParams({
    account_id: e.accountId ?? "",
    locale: e.locale,
    ...j && { attempt: j }
  }).toString();
  const L = (0, b.useCallback)(() => {
    c.current?.contentWindow?.postMessage({ type: "sites-toolbar-close-sharing" }, e.toolbarOrigin), V(null), T.closeSharing();
  }, [e.toolbarOrigin, T]);
  (0, b.useLayoutEffect)(() => {
    const ue = h.current;
    if (ue) {
      if (w)
        ue.close(), ue.showModal(), (s && a.getState().sharingStatus !== "ready" ? d.current : c.current)?.focus({ preventScroll: !0 });
      else if (ue.matches(":modal")) {
        ue.close(), ue.show();
        const me = ue.getRootNode(), Te = document.activeElement, Ce = me instanceof ShadowRoot ? me.activeElement : null, Oe = requestAnimationFrame(() => {
          s && (document.activeElement !== Te || me instanceof ShadowRoot && me.activeElement !== Ce) || (m.current?.isConnected ? m.current : ue.querySelector("[data-toolbar-sharing-trigger]"))?.focus({ preventScroll: !0 });
        });
        return () => cancelAnimationFrame(Oe);
      }
    }
  }, [
    w,
    s,
    a
  ]), (0, b.useLayoutEffect)(() => {
    if (!w) return;
    const ue = h.current, me = d.current;
    if (!ue || !me) return;
    let Te = null;
    const Ce = () => {
      const dt = ue.querySelector("[data-toolbar-sharing-close]");
      if (!dt) return;
      const St = dt.closest("[data-corner]") ?? dt;
      St !== Te && (Te && Oe.unobserve(Te), Te = St, Oe.observe(Te), qe.observe(Te, {
        attributes: !0,
        attributeFilter: ["style", "data-corner"]
      }));
      const rt = dt.getBoundingClientRect(), on = Te.dataset.corner;
      s && (me.dataset.dock = on?.split("-").at(-1) ?? "right");
      const Xt = CO(on, rt, me.offsetWidth);
      me.style.left = `${Math.max(4, Math.min(Xt, window.innerWidth - me.offsetWidth - 4))}px`, me.style.right = "auto", me.style.top = E === "top" ? `${rt.bottom}px` : "auto", me.style.bottom = E === "bottom" ? `${window.innerHeight - rt.top}px` : "auto";
      const jn = window.visualViewport, _n = jn?.offsetTop ?? 0, wn = _n + (jn?.height ?? window.innerHeight), Bn = E === "top" ? wn - rt.bottom : rt.top - _n;
      me.style.height = `${Math.max(0, Bn - 4)}px`;
    }, Oe = new ResizeObserver(Ce);
    Oe.observe(me);
    const qe = new MutationObserver(Ce);
    return qe.observe(ue, {
      childList: !0,
      subtree: !0
    }), window.addEventListener("resize", Ce), window.visualViewport?.addEventListener("resize", Ce), window.visualViewport?.addEventListener("scroll", Ce), Ce(), () => {
      Oe.disconnect(), qe.disconnect(), window.removeEventListener("resize", Ce), window.visualViewport?.removeEventListener("resize", Ce), window.visualViewport?.removeEventListener("scroll", Ce);
    };
  }, [
    w,
    E,
    s
  ]);
  const A = _ === "ready", N = A && K !== null, te = s && w && !N, oe = te && _ !== "loading" && !A, Ee = (0, b.useCallback)((ue) => {
    const me = c.current?.contentWindow;
    C?.current_user_role && me?.postMessage({
      type: "sites-toolbar-analytics-role",
      site_user_role: C.current_user_role
    }, e.toolbarOrigin), me?.postMessage({
      type: "sites-toolbar-open-sharing",
      placement: ue
    }, e.toolbarOrigin);
  }, [C?.current_user_role, e.toolbarOrigin]);
  (0, b.useEffect)(() => {
    s && w && A && Ee(E);
  }, [
    s,
    w,
    A,
    E,
    Ee
  ]), (0, b.useEffect)(() => {
    const ue = (me) => {
      if (!f_(me, c.current?.contentWindow ?? null, e.toolbarOrigin)) return;
      const Te = _7.safeParse(me.data), Ce = E7.safeParse(me.data), Oe = M.current, qe = Oe && j === Oe.id;
      if (Te.success) {
        if (Oe && !qe) return;
        T.confirmAccess(Te.data), Oe?.dispose();
      } else if (s && Ce.success) {
        if (Oe && !qe) return;
        Oe?.dispose(), T.sharingUnavailable(Ce.data.reason === "login" && !qe ? "sign-in" : "error");
      } else if (T7.safeParse(me.data).success) L();
      else {
        const dt = C7.safeParse(me.data);
        if (dt.success) {
          const St = dt.data.height;
          q((rt) => rt?.height === St ? rt : {
            height: St,
            first: rt === null
          });
        }
      }
    };
    return window.addEventListener("message", ue), () => window.removeEventListener("message", ue);
  }, [
    e.toolbarOrigin,
    L,
    T,
    j,
    s
  ]);
  const O = (ue) => {
    m.current = ue, e.shareLoginEnabled && !M.current && (_ === "sign-in" || _ === "error") && ie(null);
    const me = ue?.getBoundingClientRect(), Te = me && me.top + me.height / 2 < window.innerHeight / 2 ? "top" : "bottom";
    T.openSharing(Te), s || Ee(Te);
  }, $ = () => {
    M.current?.dispose();
    try {
      const ue = crypto.randomUUID(), me = new BroadcastChannel(P4(ue)), Te = Date.now() + 900 * 1e3, Ce = () => {
        clearTimeout(Oe), me.close(), M.current?.id === ue && (M.current = null);
      }, Oe = window.setTimeout(() => {
        Ce(), T.expireLogin();
      }, 900 * 1e3);
      M.current = {
        id: ue,
        dispose: Ce
      }, T.waitForLogin(), me.onmessage = ({ data: dt }) => {
        M.current?.id !== ue || dt !== "sites-toolbar-auth-complete" || Date.now() >= Te || (me.onmessage = null, T.beginLoading(), ie(ue));
      };
      const qe = new URL(k4, location.origin);
      qe.searchParams.set("attempt", ue), window.open(qe.href, "_blank", "noopener");
    } catch {
      M.current?.dispose(), T.sharingUnavailable("error");
    }
  }, re = s ? H1(e) : null;
  re?.searchParams.set("sharing", "1");
  const le = s ? C?.access_summary ?? { kind: k === "owner" ? "manageAccess" : "share" } : void 0, ye = x ?? (le ? x7(le, l) : null), _e = /* @__PURE__ */ (0, g.jsx)("iframe", {
    inert: s ? !A || !w : void 0,
    "aria-hidden": s ? !A || !w : void 0,
    ref: c,
    title: l.formatMessage(ne.share),
    src: se.toString(),
    className: s ? fe.FallbackFrame : fe.Frame,
    "data-user-role": k,
    allow: "clipboard-write",
    referrerPolicy: "no-referrer",
    sandbox: "allow-scripts allow-same-origin"
  }, D);
  return /* @__PURE__ */ (0, g.jsxs)("dialog", {
    open: !0,
    ref: h,
    className: fe.ModalHost,
    "data-share-login": s ? "" : void 0,
    "data-sharing-open": w ? "" : void 0,
    role: w ? "dialog" : "presentation",
    "aria-label": w && !oe ? l.formatMessage(ne.share) : void 0,
    "aria-labelledby": oe ? y : void 0,
    "aria-describedby": oe ? p : void 0,
    onCancel: (ue) => {
      ue.preventDefault(), L();
    },
    onClick: (ue) => {
      ue.target === ue.currentTarget && w && L();
    },
    children: [
      C && (x || e.shareLoginEnabled) && B && /* @__PURE__ */ (0, g.jsx)($b, {
        container: B,
        children: /* @__PURE__ */ (0, g.jsx)(c_, {
          accountId: e.accountId,
          chatgptOrigin: e.chatgptOrigin,
          projectId: e.projectId,
          siteTitle: r,
          config: C,
          toolbar: {
            currentUserRole: k,
            remixEnabled: C.remix_enabled !== !1,
            summary: ye,
            hideSharingHint: !x && (le?.kind === "manageAccess" || le?.kind === "share" || le?.kind === "admins"),
            openSharing: O,
            sharingOpen: w,
            anchorSharingClose: s && w,
            closeSharing: L,
            settingsUrl: H1(e)?.toString(),
            remixUrl: Tu({
              accountId: e.accountId,
              chatgptOrigin: e.chatgptOrigin,
              query: l.formatMessage(ne.remixPrompt, { site: Pr(r, e.projectId) })
            }).toString()
          }
        })
      }),
      /* @__PURE__ */ (0, g.jsx)("div", { ref: Q }),
      /* @__PURE__ */ (0, g.jsx)("div", {
        ref: d,
        className: s ? fe.FallbackFrameHost : fe.FrameHost,
        "data-panel-ready": !s && K !== null ? "" : void 0,
        "data-placement": E,
        "data-controls": N ? "" : void 0,
        tabIndex: s ? -1 : void 0,
        inert: !w,
        "aria-hidden": !w,
        children: s ? /* @__PURE__ */ (0, g.jsxs)("div", {
          className: fe.Surface,
          "data-notice-measured": ce !== null ? "" : void 0,
          "data-initial-size": N && K.first && ce !== null ? "" : void 0,
          style: { height: N ? K.height + 24 : ce ?? void 0 },
          children: [te && /* @__PURE__ */ (0, g.jsx)(EO, {
            ref: ee,
            status: _,
            titleId: y,
            descriptionId: p,
            isOwner: k === "owner",
            sharingUrl: re,
            startLogin: $
          }), /* @__PURE__ */ (0, g.jsx)("div", {
            className: fe.Controls,
            children: _e
          })]
        }) : /* @__PURE__ */ (0, g.jsxs)(g.Fragment, { children: [K !== null && /* @__PURE__ */ (0, g.jsx)("div", {
          className: fe.Glass,
          "aria-hidden": "true",
          style: { height: K.height }
        }), _e] })
      })
    ]
  });
}
function CO(e, a, r) {
  return e?.endsWith("left") ? a.left - 12 : e?.endsWith("center") ? (a.left + a.right - r) / 2 : a.right + 12 - r;
}
function AO(e) {
  return qd()((a) => ({
    sharingOpen: !1,
    sharingStatus: "loading",
    placement: "bottom",
    summary: null,
    config: null,
    actions: {
      openSharing: (r) => a({
        sharingOpen: !0,
        placement: r
      }),
      closeSharing: () => a({ sharingOpen: !1 }),
      beginLoading: () => a({
        summary: null,
        sharingStatus: "loading"
      }),
      waitForLogin: () => a({ sharingStatus: "waiting" }),
      expireLogin: () => a((r) => r.sharingStatus === "waiting" ? { sharingStatus: "sign-in" } : r),
      sharingUnavailable: (r) => {
        e && a({
          summary: null,
          sharingStatus: r
        });
      },
      confirmAccess: (r) => a({
        summary: r,
        sharingStatus: "ready"
      }),
      setConfig: (r) => a({ config: r })
    }
  }));
}
var kd = Pt({
  account_user_id: _t(),
  name: _t().nullable().optional(),
  email: _t().nullable().optional(),
  avatar_url: _t().nullable().optional(),
  role: gn([
    "owner",
    "editor",
    "viewer"
  ]).nullable().optional(),
  is_external: $t().nullable().optional()
}), d_ = Pt({
  id: _t(),
  name: _t(),
  size: eh(),
  role: gn(["viewer", "editor"]).nullable().optional()
}), q1 = Pt({
  project_id: _t(),
  title: _t(),
  url: _t().nullable(),
  workspace_name: _t().nullable().optional(),
  available_access_modes: Zn(gn([
    "custom",
    "workspace_all",
    "public"
  ])).nullable(),
  can_invite_external_visitors: $t(),
  can_manage_editors: $t(),
  can_request_edit_access: $t().optional(),
  can_manage_access: $t().default(!0),
  show_site_collaborators: $t().default(!0),
  uses_page_sharing: $t().optional(),
  personal_editor_access: gn(["remove", "invite"]).nullish(),
  read_only_user_ids: Zn(_t()).optional(),
  read_only_group_ids: Zn(_t()).optional(),
  has_private_tunnels: $t(),
  remix_enabled: $t().nullish(),
  access_policy: Pt({
    access_mode: gn([
      "custom",
      "workspace_all",
      "public",
      "admins_only"
    ]),
    allowed_users: Zn(kd),
    allowed_editors: Zn(kd).default([]),
    allowed_groups: Zn(d_),
    allowed_workspace_group_ids: Zn(_t()),
    allowed_tenant_group_ids: Zn(_t())
  }).nullable()
}), xO = Pt({
  users: Zn(kd),
  workspace_groups: Zn(d_),
  has_more_users: $t(),
  has_more_groups: $t(),
  people_lookup_unavailable: $t().optional()
}), h_ = class extends Error {
};
function OO(e, a, r, l) {
  let s = !1;
  async function c(d, h, m) {
    const y = d === "access" || d === "access/save" && s, p = await fetch(new URL(`/_internal/sites_widget/${d}`, e), {
      method: "POST",
      credentials: "include",
      cache: "no-store",
      redirect: "error",
      headers: {
        "Content-Type": "application/json",
        Accept: y ? "application/json; page-sharing=1" : "application/json"
      },
      body: JSON.stringify(h),
      signal: m ? AbortSignal.any([m, AbortSignal.timeout(15e3)]) : AbortSignal.timeout(15e3)
    });
    if (!p.ok) {
      if ([401, 409].includes(p.status)) {
        if ((await p.json().catch(() => null))?.error === "chatgpt_session_required")
          throw d !== "auth/session" && d !== "access" && r?.(), new h_();
      } else await p.body?.cancel();
      throw new Error("Toolbar request failed");
    }
    return p;
  }
  return {
    logInteraction(d) {
      At(d, e);
    },
    async load() {
      await (await c("auth/session", l ? { attempt: l } : {})).body?.cancel();
      const d = q1.parse(await (await c("access", {})).json());
      return s = d.uses_page_sharing === !0, d;
    },
    async requestEditAccess() {
      const d = await c("access/request-edit", {});
      if (await d.body?.cancel(), d.status !== 204) throw new Error("Unexpected request-edit response");
    },
    async save(d, h) {
      await a();
      const m = async (p) => q1.parse(await (await c("access/save", p)).json());
      let y;
      for (const p of d.recipient_changes ?? [])
        y = await m({
          ...d,
          recipient_changes: [p]
        }), h?.(y);
      return y ?? m(d);
    },
    async search(d, h) {
      return xO.parse(await (await c("access/search", {
        query: d,
        limit: 20,
        offset: 0
      }, h)).json());
    }
  };
}
function Cu(e) {
  const a = e.access_policy;
  if (!a) return [];
  const r = new Map(a.allowed_users.map((l) => [l.account_user_id, l]));
  for (const l of a.allowed_editors) r.get(l.account_user_id)?.role !== "owner" && r.set(l.account_user_id, {
    ...l,
    role: "editor"
  });
  return [...r.values()].sort((l, s) => +(s.role === "owner") - +(l.role === "owner"));
}
function X1(e, a, r = !1, l) {
  if (e.role === "owner") throw new Error("Cannot change Site ownership");
  if (r && l != null && e.role === "editor" && e.email && a !== "editor") return {
    editor_changes: { remove_editor_account_user_ids: [e.account_user_id] },
    viewer_changes: a === "viewer" ? { add_external_visitor_emails: [e.email] } : { remove_external_visitor_emails: [e.email] }
  };
  if (r && !e.is_external) return { recipient_changes: [{
    recipient: e.account_user_id,
    role: a === "remove" ? null : a
  }] };
  if (e.is_external) {
    if (a === "editor") {
      if (r && l === "invite" && e.email) return { recipient_changes: [{ editor_email: e.email }] };
      throw new Error("External visitors cannot edit");
    }
    if (a === "viewer") return {};
    if (!e.email) throw new Error("Incomplete sharing recipients");
    return r ? { recipient_changes: [{
      email: e.email,
      role: null
    }] } : { viewer_changes: { remove_external_visitor_emails: [e.email] } };
  }
  const s = e.account_user_id, c = { viewer_changes: { remove_viewer_account_user_ids: [s] } };
  return a === "viewer" && (c.viewer_changes = { add_viewer_account_user_ids: [s] }), a === "editor" ? c.editor_changes = { add_editor_account_user_ids: [s] } : e.role === "editor" && (c.editor_changes = { remove_editor_account_user_ids: [s] }), c;
}
var MO = "_Avatar_1qach_1", RO = "_AvatarImageContainer_1qach_47", NO = "_AvatarImage_1qach_47", DO = "_AvatarInitial_1qach_79", zO = "_AvatarOverflowCount_1qach_90", LO = "_AvatarOverflowCountSymbol_1qach_113", HO = "_AvatarIcon_1qach_119", Bi = {
  Avatar: MO,
  AvatarImageContainer: RO,
  AvatarImage: NO,
  AvatarInitial: DO,
  AvatarOverflowCount: zO,
  AvatarOverflowCountSymbol: LO,
  AvatarIcon: HO
}, eu = (e) => {
  const a = BO(e.imageUrl);
  return /* @__PURE__ */ (0, g.jsx)(jO, {
    ...e,
    imageUrl: a
  });
}, jO = (e) => {
  const { className: a, size: r, overflowCount: l, name: s, initials: c = "first", color: d = "secondary", variant: h = "soft", imageUrl: m, Icon: y, tooltipComponent: p, ..._ } = e, [w, E] = (0, b.useState)(), x = (0, b.useRef)(m);
  (0, b.useEffect)(() => {
    m !== x.current && ((w === "error" || !m) && E(void 0), x.current = m);
  }, [m, w]);
  const C = !!(_.onPointerDown || _.onClick), T = /* @__PURE__ */ (0, g.jsx)(C ? "button" : "span", {
    className: Be(Bi.Avatar, a),
    style: { "--avatar-size": `${r ?? 40}px` },
    role: C ? void 0 : "presentation",
    "data-color": d,
    "data-variant": h,
    type: C ? "button" : void 0,
    ..._,
    children: m && w !== "error" ? /* @__PURE__ */ (0, g.jsx)(UO, {
      status: w,
      url: m,
      onError: () => E("error"),
      onLoad: () => E("loaded")
    }) : y ? /* @__PURE__ */ (0, g.jsx)(y, { className: Bi.AvatarIcon }) : l ? /* @__PURE__ */ (0, g.jsx)(PO, { count: l }) : /* @__PURE__ */ (0, g.jsx)(kO, {
      name: s,
      initials: c
    })
  });
  return !s || !p ? T : /* @__PURE__ */ (0, g.jsx)(p, {
    content: s,
    children: T
  });
}, BO = (e) => {
  if (e?.startsWith("https://") && !(e.includes("gravatar.com") && e.includes("cdn.auth0.com")))
    return e;
}, UO = ({ url: e, status: a, onLoad: r, onError: l }) => /* @__PURE__ */ (0, g.jsx)("span", {
  className: Bi.AvatarImageContainer,
  children: /* @__PURE__ */ (0, g.jsx)("img", {
    src: e,
    referrerPolicy: "no-referrer",
    className: Bi.AvatarImage,
    "data-loaded": a === "loaded" ? "" : void 0,
    onLoad: r,
    onError: l,
    alt: "",
    role: "presentation"
  })
}), kO = ({ name: e = "", initials: a }) => {
  const r = (0, b.useMemo)(() => {
    if (a === "firstlast") {
      const l = e.trim().split(/\s+/);
      return ([...l[0].toUpperCase()][0] ?? "") + (l.length > 1 ? [...l[l.length - 1].toUpperCase()][0] : "");
    } else
      return e.charAt(0).toUpperCase();
  }, [e, a]);
  return /* @__PURE__ */ (0, g.jsx)("span", {
    className: Bi.AvatarInitial,
    "data-letter-count": a === "firstlast" ? [...r].length : void 0,
    children: r
  });
}, PO = ({ count: e }) => {
  const a = (0, b.useMemo)(() => new Intl.NumberFormat("en", {
    notation: "compact",
    compactDisplay: "short",
    maximumFractionDigits: 0
  }).format(e).toLocaleLowerCase(), [e]);
  return /* @__PURE__ */ (0, g.jsxs)("span", {
    className: Bi.AvatarOverflowCount,
    "data-letter-count": a.length,
    children: [/* @__PURE__ */ (0, g.jsx)("span", {
      className: Bi.AvatarOverflowCountSymbol,
      children: "+"
    }), a]
  });
}, m_ = (e) => /* @__PURE__ */ (0, g.jsx)("svg", {
  width: "1em",
  height: "1em",
  viewBox: "0 0 24 24",
  fill: "currentColor",
  ...e,
  children: /* @__PURE__ */ (0, g.jsx)("path", {
    fillRule: "evenodd",
    d: "M18.063 5.674a1 1 0 0 1 .263 1.39l-7.5 11a1 1 0 0 1-1.533.143l-4.5-4.5a1 1 0 1 1 1.414-1.414l3.647 3.647 6.82-10.003a1 1 0 0 1 1.39-.263Z",
    clipRule: "evenodd"
  })
}), IO = (e) => /* @__PURE__ */ (0, g.jsx)("svg", {
  width: "1em",
  height: "1em",
  viewBox: "0 0 24 24",
  fill: "currentColor",
  ...e,
  children: /* @__PURE__ */ (0, g.jsx)("path", {
    fillRule: "evenodd",
    d: "M4.293 8.293a1 1 0 0 1 1.414 0L12 14.586l6.293-6.293a1 1 0 1 1 1.414 1.414l-7 7a1 1 0 0 1-1.414 0l-7-7a1 1 0 0 1 0-1.414Z",
    clipRule: "evenodd"
  })
}), ZO = "_Trigger_168v9_3", GO = "_Action_168v9_14", VO = "_Chevron_168v9_31", $O = "_Label_168v9_37", FO = "_Thumbnail_168v9_41", qO = "_MenuList_168v9_55", XO = "_enter_168v9_1", YO = "_OptionsList_168v9_81", WO = "_Option_168v9_81", QO = "_OptionText_168v9_115", KO = "_OptionInner_168v9_116", JO = "_OptionIndicatorSlot_168v9_117", eM = "_Description_168v9_147", tM = "_ActionsContainer_168v9_165", nM = "_ActionIndicator_168v9_181", nn = {
  Trigger: ZO,
  Action: GO,
  Chevron: VO,
  Label: $O,
  Thumbnail: FO,
  MenuList: qO,
  enter: XO,
  OptionsList: YO,
  Option: WO,
  OptionText: QO,
  OptionInner: KO,
  OptionIndicatorSlot: JO,
  Description: eM,
  ActionsContainer: tM,
  ActionIndicator: nM
};
function Vs({ value: e, options: a, onChange: r, disabled: l, loading: s = !1, className: c, menuClassName: d, align: h = "start", pill: m = !0, action: y, ...p }) {
  const [_, w] = (0, b.useState)(!1), [E, x] = (0, b.useState)(null), C = (0, b.useRef)(!1), T = s || E !== null, [M, D] = (0, b.useState)(e), j = (0, b.useRef)(null), H = (0, b.useRef)(null), k = sl(), B = (0, b.useId)(), Q = (0, b.useRef)({
    text: "",
    time: 0
  }), K = E?.previousValue ?? e, q = a.find((A) => A.value === K), F = a.filter((A) => !A.disabled), ee = (A) => `${B}-${encodeURIComponent(A)}`, ce = (A) => {
    T || C.current || l && A || (A && (D(F.find((N) => N.value === e)?.value ?? F[0]?.value ?? e), Q.current = {
      text: "",
      time: 0
    }), w(A));
  }, V = async (A, N) => {
    if (l || T || C.current) return;
    const te = performance.now();
    C.current = !0;
    try {
      const oe = N();
      if (!oe || typeof oe.then != "function") {
        C.current = !1, w(!1);
        return;
      }
      x({
        ...A,
        previousValue: e
      }), await oe;
    } finally {
      const oe = 400 - (performance.now() - te);
      C.current && oe > 0 && await new Promise((Ee) => window.setTimeout(Ee, oe)), C.current = !1, x(null), w(!1);
    }
  }, ie = (A) => {
    l || T || C.current || A.disabled || (D(A.value), V({ value: A.value }, () => r(A)));
  }, se = (A) => {
    A && (D(A.value), H.current?.querySelector(`#${CSS.escape(ee(A.value))}`)?.scrollIntoView({ block: "nearest" }));
  };
  function L(A) {
    return E && "value" in E && E.value === A.value ? /* @__PURE__ */ (0, g.jsx)(Yo, { size: 16 }) : !E && A.value === e ? /* @__PURE__ */ (0, g.jsx)(m_, {}) : null;
  }
  return /* @__PURE__ */ (0, g.jsxs)(yu, {
    open: _,
    onOpenChange: ce,
    children: [/* @__PURE__ */ (0, g.jsx)(Th, {
      asChild: !0,
      children: /* @__PURE__ */ (0, g.jsxs)(ft, {
        pill: m,
        ref: j,
        className: Be(nn.Trigger, c),
        variant: "ghost",
        color: "secondary",
        disabled: l || T,
        "aria-busy": T || void 0,
        ...p,
        "aria-haspopup": "listbox",
        "aria-controls": _ ? B : void 0,
        onKeyDown: (A) => {
          (A.key === "ArrowDown" || A.key === "ArrowUp") && (A.preventDefault(), A.stopPropagation(), ce(!0));
        },
        children: [
          q?.icon && /* @__PURE__ */ (0, g.jsx)("span", {
            className: nn.Thumbnail,
            children: q.icon
          }),
          /* @__PURE__ */ (0, g.jsx)("span", {
            className: nn.Label,
            children: q?.label
          }),
          /* @__PURE__ */ (0, g.jsx)(IO, {
            className: nn.Chevron,
            "data-no-autosize": !0
          })
        ]
      })
    }), /* @__PURE__ */ (0, g.jsx)(bu, {
      container: j.current?.closest('[role="dialog"]') ?? k,
      children: /* @__PURE__ */ (0, g.jsxs)(_u, {
        className: Be(nn.MenuList, d),
        align: h,
        sideOffset: 5,
        collisionPadding: 12,
        onOpenAutoFocus: (A) => {
          A.preventDefault(), H.current?.focus({ preventScroll: !0 });
        },
        onEscapeKeyDown: (A) => {
          A.stopPropagation(), T && A.preventDefault();
        },
        onInteractOutside: (A) => {
          T && A.preventDefault();
        },
        children: [/* @__PURE__ */ (0, g.jsx)("div", {
          ref: H,
          id: B,
          className: nn.OptionsList,
          role: "listbox",
          "aria-busy": T || void 0,
          "aria-disabled": l || T,
          tabIndex: 0,
          ...p,
          "aria-activedescendant": a.some((A) => A.value === M) ? ee(M) : void 0,
          onKeyDown: (A) => {
            if (l || T) {
              A.preventDefault();
              return;
            }
            const N = F.findIndex((te) => te.value === M);
            switch (A.key) {
              case "ArrowDown":
                A.preventDefault(), se(F[Math.min(N + 1, F.length - 1)]);
                break;
              case "ArrowUp":
                A.preventDefault(), se(F[Math.max(N - 1, 0)]);
                break;
              case "Home":
                A.preventDefault(), se(F[0]);
                break;
              case "End":
                A.preventDefault(), se(F.at(-1));
                break;
              case "Enter":
              case " ": {
                A.preventDefault();
                const te = F.find((oe) => oe.value === M);
                te && ie(te);
                break;
              }
              default: {
                if (A.key.length !== 1 || A.ctrlKey || A.metaKey || A.altKey) return;
                A.preventDefault();
                const te = Date.now(), oe = (te - Q.current.time < 500 ? Q.current.text : "") + A.key.toLocaleLowerCase();
                Q.current = {
                  text: oe,
                  time: te
                }, se(F.find((Ee) => Ee.label.toLocaleLowerCase().startsWith(oe)));
              }
            }
          },
          children: a.map((A) => /* @__PURE__ */ (0, g.jsx)("div", {
            id: ee(A.value),
            className: nn.Option,
            role: "option",
            "aria-selected": A.value === K,
            "aria-busy": E !== null && "value" in E && E.value === A.value || void 0,
            "aria-disabled": l || T || A.disabled,
            "data-selected": A.value === K ? "" : void 0,
            "data-highlight": A.value === M ? "" : void 0,
            "data-disabled": l || T || A.disabled ? "" : void 0,
            onPointerMove: () => {
              !l && !T && !A.disabled && D(A.value);
            },
            onClick: () => ie(A),
            children: /* @__PURE__ */ (0, g.jsxs)("div", {
              className: nn.OptionInner,
              children: [
                A.icon,
                /* @__PURE__ */ (0, g.jsxs)("span", {
                  className: nn.OptionText,
                  children: [/* @__PURE__ */ (0, g.jsx)("span", { children: A.label }), A.description && /* @__PURE__ */ (0, g.jsx)("span", {
                    className: nn.Description,
                    children: A.description
                  })]
                }),
                /* @__PURE__ */ (0, g.jsx)("span", {
                  className: nn.OptionIndicatorSlot,
                  children: L(A)
                })
              ]
            })
          }, A.value))
        }), y && /* @__PURE__ */ (0, g.jsx)("div", {
          className: nn.ActionsContainer,
          children: /* @__PURE__ */ (0, g.jsxs)(ft, {
            variant: "ghost",
            color: "secondary",
            className: nn.Action,
            disabled: l || T,
            onClick: () => {
              V({ action: !0 }, y.onSelect);
            },
            children: [y.label, E && "action" in E && /* @__PURE__ */ (0, g.jsx)(Yo, {
              className: nn.ActionIndicator,
              size: 16
            })]
          })
        })]
      })
    })]
  });
}
var p_ = (e) => /* @__PURE__ */ (0, g.jsxs)("svg", {
  width: "1em",
  height: "1em",
  viewBox: "0 0 16 16",
  fill: "currentColor",
  ...e,
  children: [
    /* @__PURE__ */ (0, g.jsx)("path", {
      d: "M8.00002 8.6543C10.0676 8.65454 11.7647 10.2413 11.9405 12.2637C11.9655 12.5524 11.7515 12.8067 11.4629 12.832C11.1741 12.8571 10.9197 12.6433 10.8946 12.3545C10.7655 10.87 9.51819 9.70532 8.00002 9.70508C6.48179 9.70522 5.23552 10.87 5.10647 12.3545C5.08139 12.6432 4.8258 12.8568 4.53713 12.832C4.24852 12.8067 4.03452 12.5524 4.05959 12.2637C4.23531 10.2412 5.93232 8.65443 8.00002 8.6543Z",
      fill: "currentColor"
    }),
    /* @__PURE__ */ (0, g.jsx)("path", {
      d: "M3.35744 8.87598C3.64673 8.85709 3.89611 9.07594 3.91506 9.36523C3.93395 9.65452 3.7151 9.9039 3.4258 9.92285C2.27831 9.99807 1.35691 10.9051 1.25783 12.0459C1.23271 12.3345 0.978105 12.5482 0.689475 12.5234C0.400692 12.4983 0.185993 12.2438 0.210959 11.9551C0.354799 10.2988 1.6914 8.98511 3.35744 8.87598Z",
      fill: "currentColor"
    }),
    /* @__PURE__ */ (0, g.jsx)("path", {
      d: "M12.6367 8.87598C14.3028 8.9851 15.6394 10.2988 15.7832 11.9551C15.8082 12.2439 15.5935 12.4984 15.3047 12.5234C15.0161 12.5482 14.7615 12.3345 14.7364 12.0459C14.6373 10.9051 13.7159 9.99806 12.5684 9.92285C12.2791 9.90389 12.0602 9.65451 12.0791 9.36523C12.0981 9.07595 12.3475 8.8571 12.6367 8.87598Z",
      fill: "currentColor"
    }),
    /* @__PURE__ */ (0, g.jsx)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M2.67092 4.30859C3.69683 4.3089 4.52927 5.14102 4.52932 6.16699C4.52905 7.19278 3.6967 8.02509 2.67092 8.02539C1.64488 8.02539 0.812786 7.19297 0.812522 6.16699C0.812574 5.14083 1.64475 4.30859 2.67092 4.30859ZM2.67092 5.35938C2.22465 5.35938 1.86238 5.72073 1.86233 6.16699C1.86259 6.61307 2.22478 6.97559 2.67092 6.97559C3.1168 6.97528 3.47827 6.61288 3.47854 6.16699C3.47848 5.72092 3.11693 5.35968 2.67092 5.35938Z",
      fill: "currentColor"
    }),
    /* @__PURE__ */ (0, g.jsx)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M13.3242 4.30859C14.3504 4.30859 15.1826 5.14083 15.1826 6.16699C15.1824 7.19297 14.3503 8.02539 13.3242 8.02539C12.2983 8.02533 11.4661 7.19293 11.4658 6.16699C11.4659 5.14087 12.2981 4.30866 13.3242 4.30859ZM13.3242 5.35938C12.878 5.35944 12.5167 5.72077 12.5166 6.16699C12.5169 6.61303 12.8782 6.97552 13.3242 6.97559C13.7704 6.97559 14.1326 6.61307 14.1328 6.16699C14.1328 5.72073 13.7705 5.35938 13.3242 5.35938Z",
      fill: "currentColor"
    }),
    /* @__PURE__ */ (0, g.jsx)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M8.00002 3.2793C9.26655 3.27955 10.2938 4.30668 10.294 5.57324C10.294 6.83991 9.26663 7.86694 8.00002 7.86719C6.7333 7.86707 5.70608 6.83999 5.70608 5.57324C5.7062 4.3066 6.73338 3.27942 8.00002 3.2793ZM8.00002 4.33008C7.31328 4.3302 6.75698 4.8865 6.75686 5.57324C6.75686 6.26009 7.3132 6.81726 8.00002 6.81738C8.68673 6.81713 9.24416 6.26001 9.24416 5.57324C9.24404 4.88658 8.68665 4.33033 8.00002 4.33008Z",
      fill: "currentColor"
    })
  ]
}), aM = "_Container_kb33f_2", iM = "_TagInput_kb33f_89", rM = "_StartAdornment_kb33f_96", oM = "_EndAdornment_kb33f_97", lM = "_Tag_kb33f_89", sM = "_shake_kb33f_1", uM = "_TagRemove_kb33f_177", cM = "_TagContent_kb33f_205", fM = "_TagValue_kb33f_215", dM = "_InputContainer_kb33f_230", hM = "_InputWrapper_kb33f_238", mM = "_InputMeasure_kb33f_243", pM = "_Input_kb33f_230", vM = "_Limit_kb33f_296", mn = {
  Container: aM,
  TagInput: iM,
  StartAdornment: rM,
  EndAdornment: oM,
  Tag: lM,
  shake: sM,
  TagRemove: uM,
  TagContent: cM,
  TagValue: fM,
  InputContainer: dM,
  InputWrapper: hM,
  InputMeasure: mM,
  Input: pM,
  Limit: vM
}, gM = 10, Y1 = 20, yM = 500, bM = ({ value: e, label: a }) => /* @__PURE__ */ (0, g.jsx)(g.Fragment, { children: a ?? e }), W1 = (e) => {
  const a = Number.parseFloat(e);
  return Number.isFinite(a) ? a : 0;
}, Nr = (e) => typeof Element < "u" && e instanceof Element ? e : typeof Node < "u" && e instanceof Node ? e.parentElement : null, Q1 = (e) => !!Nr(e)?.closest("[data-tag]"), cd = (e) => !!Nr(e)?.closest("[data-tag-input-adornment]"), _M = b.memo(function({ disabled: a, getRemoveLabel: r, tags: l, duplicateTags: s, TagView: c, inert: d, onSelectTag: h, onRemoveTag: m }) {
  return /* @__PURE__ */ (0, g.jsx)(g.Fragment, { children: Array.from(l.values()).map((y) => /* @__PURE__ */ (0, g.jsxs)("div", {
    className: mn.Tag,
    tabIndex: -1,
    onClick: () => h(y.value),
    "data-tag": y.value,
    "data-tag-input-flow-item": "",
    "data-invalid": y.valid ? void 0 : "",
    "data-duplicate": s.has(y.value) ? "" : void 0,
    inert: d || a,
    children: [/* @__PURE__ */ (0, g.jsx)("span", {
      className: mn.TagContent,
      title: y.label ?? y.value,
      children: /* @__PURE__ */ (0, g.jsx)("span", {
        className: mn.TagValue,
        children: /* @__PURE__ */ (0, g.jsx)(c, { ...y })
      })
    }), !d && /* @__PURE__ */ (0, g.jsx)("button", {
      type: "button",
      disabled: a,
      className: mn.TagRemove,
      onClick: (p) => {
        p.stopPropagation(), m(y.value);
      },
      "aria-label": r(y),
      children: /* @__PURE__ */ (0, g.jsx)(ai, {
        height: 14,
        width: 14,
        "aria-hidden": "true"
      })
    })]
  }, y.value)) });
}), wM = (e) => {
  const { defaultValue: a = [], inputValue: r, onInputChange: l, inputRef: s, inputProps: c, allowCustomTags: d = !0, getRemoveLabel: h, value: m, size: y = "xl", onChange: p, validator: _, maxTags: w, placeholder: E = "", autoComplete: x, autoFocus: C = !1, rows: T = 1, delimiters: M = [",", " "], disabled: D, inert: j, id: H, className: k, TagView: B = bM, startAdornment: Q, endAdornment: K } = e, [q, F] = (0, b.useState)(a), ee = m ?? q, ce = m !== void 0, V = (0, b.useMemo)(() => new Map(ee.map((ae) => [ae.value, ae])), [ee]), [ie, se] = (0, b.useState)(""), L = r ?? ie, A = (ae) => {
    l?.(ae), r === void 0 && se(ae);
  }, [N, te] = (0, b.useState)(C), [oe, Ee] = (0, b.useState)(null), [O, $] = (0, b.useState)(/* @__PURE__ */ new Set()), [re, le] = (0, b.useState)(0), [ye, _e] = (0, b.useState)(0), ue = Gs(_), me = Gs(p), Te = (0, b.useRef)(null), Ce = s ?? Te, Oe = (0, b.useRef)(null), qe = (0, b.useRef)(null), dt = (0, b.useRef)(null), St = (0, b.useRef)(null), rt = !w || V.size < w, on = !!Q, Xt = !!K;
  (0, b.useEffect)(() => {
    if (!N || !Oe.current) return;
    const ae = Ce.current ?? Oe.current;
    if (oe === null) ae.focus();
    else {
      const Se = Array.from(Oe.current.querySelectorAll("[data-tag]")).find((Qe) => Qe.dataset.tag === oe);
      Se ? Se.focus() : ae.focus();
    }
  }, [
    N,
    oe,
    rt
  ]);
  const jn = V.size === 0 ? E : void 0;
  (0, b.useLayoutEffect)(() => {
    if (!Xt || !St.current) {
      _e(0);
      return;
    }
    const ae = St.current, Se = () => {
      const Mt = Math.ceil(ae.getBoundingClientRect().width);
      _e((ht) => ht === Mt ? ht : Mt);
    };
    if (Se(), typeof ResizeObserver > "u") return;
    const Qe = new ResizeObserver(Se);
    return Qe.observe(ae), () => {
      Qe.disconnect();
    };
  }, [Xt, K]), (0, b.useLayoutEffect)(() => {
    if (!qe.current || !dt.current) return;
    const ae = qe.current, Se = () => {
      if (!dt.current) return;
      const Mt = ae.getBoundingClientRect(), ht = W1(getComputedStyle(ae).getPropertyValue("--tag-input-tag-spacing")), Et = Array.from(ae.querySelectorAll("[data-tag-input-flow-item]")), mt = Et[Et.length - 1], Tt = mt?.getBoundingClientRect(), ln = Mt.left, Ma = Mt.right, xu = Tt ? Tt.right : ln, fl = mt ? W1(getComputedStyle(mt).marginRight) : 0, qr = !Tt || Math.abs(Tt.top - Mt.top) < 1, Ii = Ma - (Xt && qr && ye > 0 ? ye + ht : 0);
      dt.current.textContent = L || jn || "";
      const Ou = dt.current.getBoundingClientRect().width + gM, Xr = Math.max(0, Ii - xu - fl), dl = Math.max(0, Ma - ln);
      Ou <= Xr ? le(Math.max(Y1, Xr)) : le(Math.max(Y1, dl));
    };
    Se();
    const Qe = new ResizeObserver(Se);
    return Qe.observe(ae), () => Qe.disconnect();
  }, [
    L,
    ye,
    Xt,
    jn,
    y,
    Q,
    V,
    B
  ]);
  const _n = (ae) => {
    const Se = new Map(V);
    let Qe = !1;
    for (const ht of ae) {
      const Et = ht.trim();
      if (!Et) continue;
      if (Se.has(Et)) {
        $((Tt) => new Set(Tt).add(Et)), setTimeout(() => $((Tt) => {
          const ln = new Set(Tt);
          return ln.delete(Et), ln;
        }), yM);
        continue;
      }
      const mt = ue.current?.(Et) ?? !0;
      Se.set(Et, {
        value: Et,
        valid: mt
      }), Qe = !0;
    }
    if (!Qe) return;
    const Mt = Array.from(Se.values());
    me.current?.(Mt), ce || F(Mt);
  }, wn = (ae) => {
    _n([ae]);
  }, Bn = (0, b.useCallback)((ae) => {
    const Se = new Map(V);
    Se.delete(ae);
    const Qe = Array.from(Se.values());
    me.current?.(Qe), ce || F(Qe), oe === ae && Ee(null);
  }, [
    ce,
    me,
    oe,
    V
  ]), Pi = () => {
    if (V.size === 0) return;
    const ae = Array.from(V.keys());
    if (oe === null) Ee(ae[ae.length - 1]);
    else {
      const Se = ae.indexOf(oe);
      Ee(ae[Math.max(0, Se - 1)]);
    }
  }, $r = () => {
    if (oe === null) return;
    const ae = Array.from(V.keys()), Se = ae.indexOf(oe) + 1;
    Se < ae.length ? Ee(ae[Se]) : Ee(null);
  }, xt = () => {
    const ae = Ce.current;
    return ae ? ae.selectionStart === 0 && ae.selectionEnd === 0 : !0;
  }, ve = (0, b.useCallback)(() => {
    Ee(null), te(!0), (Ce.current ?? Oe.current)?.focus({ preventScroll: !0 });
  }, []), Ot = (0, b.useCallback)((ae) => {
    Bn(ae), ve();
  }, [ve, Bn]), Ut = () => {
    te(!1), Ee(null), d && L && (wn(L), A(""));
  }, kt = (ae) => {
    if (D || j || ae.defaultPrevented || ae.nativeEvent.isComposing) return;
    const Se = Nr(ae.target);
    !Se || !Oe.current?.contains(Se) || cd(Se) || (ae.key === "ArrowLeft" || ae.key === "ArrowUp" ? xt() && (ae.preventDefault(), Pi()) : ae.key === "ArrowRight" || ae.key === "ArrowDown" ? oe !== null && (ae.preventDefault(), $r()) : ae.key === "Backspace" && (oe !== null ? (ae.preventDefault(), Bn(oe)) : xt() && Pi()));
  }, Fr = (ae) => {
    c?.onKeyDown?.(ae), !(!d || D || j || ae.defaultPrevented || ae.nativeEvent.isComposing) && (ae.key === "Enter" || M.includes(ae.key) ? (ae.preventDefault(), L && (wn(L), A(""))) : ae.key === "Tab" && L && (ae.preventDefault(), wn(L), A("")));
  }, ul = (ae) => {
    if (!d) return;
    let Se = [ae.clipboardData.getData("Text")];
    for (const Qe of M) {
      const Mt = [];
      for (const ht of Se) Mt.push(...ht.split(Qe));
      Se = Mt;
    }
    Se = Se.filter(Boolean), Se.length > 1 && (ae.preventDefault(), _n(Se));
  }, cl = (ae) => {
    const Se = Nr(ae.target);
    if (D || j || ae.button > 0 || ae.defaultPrevented || !Se || !ae.currentTarget.contains(Se)) return;
    const Qe = ae.currentTarget, Mt = ae.nativeEvent, ht = ae.currentTarget.ownerDocument, Et = ht.activeElement;
    setTimeout(() => {
      if (!Qe.isConnected || Mt.defaultPrevented) return;
      const mt = ht.activeElement;
      mt && mt !== Et && mt !== ht.body && mt !== ht.documentElement && mt !== Oe.current && mt !== Ce.current || ve();
    });
  }, Au = (ae) => {
    const Se = Nr(ae.target);
    if (!(!Se || !Oe.current?.contains(Se)) && !cd(Se) && (te(!0), !Q1(Se) && (Ee(null), Ce.current && !Ce.current.contains(Se)))) {
      ae.preventDefault();
      const { left: Qe, right: Mt, top: ht, bottom: Et } = Ce.current.getBoundingClientRect(), { clientX: mt, clientY: Tt } = ae;
      if (ae.detail === 1) {
        if (Tt < ht || mt < Qe) Ce.current.setSelectionRange(0, 0);
        else if (Tt > Et || mt > Mt) {
          const ln = Ce.current.value.length;
          Ce.current.setSelectionRange(ln, ln);
        }
      } else Ce.current.select();
    }
  }, si = (ae) => {
    const Se = Nr(ae.target);
    !Se || !Oe.current?.contains(Se) || Q1(Se) || cd(Se) || te(!0);
  }, Zt = (ae) => {
    if (!(!ae.relatedTarget || !(ae.relatedTarget instanceof Node))) {
      if (Oe.current && Oe.current.contains(ae.relatedTarget)) {
        Ce.current && Ce.current.contains(ae.relatedTarget) && Ee(null);
        return;
      }
      Ut();
    }
  }, Un = Gs(Ut);
  return (0, b.useEffect)(() => {
    const ae = Oe.current?.ownerDocument, Se = (Qe) => {
      Qe.target instanceof Node && Qe.target.isConnected && !Oe.current?.contains(Qe.target) && Un.current();
    };
    return ae?.addEventListener("mousedown", Se), () => ae?.removeEventListener("mousedown", Se);
  }, [Un]), /* @__PURE__ */ (0, g.jsxs)(g.Fragment, { children: [/* @__PURE__ */ (0, g.jsx)("div", {
    className: Be(mn.Container, k),
    ref: Oe,
    onKeyDown: kt,
    onMouseDown: Au,
    onFocus: si,
    onBlur: Zt,
    "data-size": y,
    "data-focused": N ? "" : void 0,
    "data-empty": V.size === 0 ? "" : void 0,
    "data-has-start-adornment": on ? "" : void 0,
    "data-has-end-adornment": Xt ? "" : void 0,
    tabIndex: -1,
    style: { "--min-rows": T },
    "data-disabled": D ? "" : void 0,
    inert: j,
    children: /* @__PURE__ */ (0, g.jsxs)("div", {
      className: mn.TagInput,
      ref: qe,
      children: [
        on && /* @__PURE__ */ (0, g.jsx)("div", {
          className: mn.StartAdornment,
          "data-tag-input-adornment": "",
          "data-tag-input-flow-item": "",
          onPointerDownCapture: cl,
          children: Q
        }),
        Xt && /* @__PURE__ */ (0, g.jsx)("div", {
          className: mn.EndAdornment,
          ref: St,
          "data-tag-input-adornment": "",
          onPointerDownCapture: cl,
          children: K
        }),
        /* @__PURE__ */ (0, g.jsx)(_M, {
          disabled: D,
          getRemoveLabel: h,
          tags: V,
          duplicateTags: O,
          TagView: B,
          inert: j,
          onSelectTag: Ee,
          onRemoveTag: Ot
        }),
        rt && /* @__PURE__ */ (0, g.jsxs)("div", {
          className: mn.InputContainer,
          children: [/* @__PURE__ */ (0, g.jsx)("span", {
            ref: dt,
            className: mn.InputMeasure
          }), /* @__PURE__ */ (0, g.jsx)("div", {
            className: mn.InputWrapper,
            children: /* @__PURE__ */ (0, g.jsx)("input", {
              ...c,
              "data-lpignore": !0,
              "data-1p-ignore": !0,
              id: H,
              className: mn.Input,
              ref: Ce,
              value: L,
              onChange: (ae) => {
                A(ae.target.value);
              },
              onPaste: ul,
              onKeyDown: Fr,
              placeholder: jn,
              style: { width: re },
              disabled: D,
              autoComplete: x,
              inert: j
            })
          })]
        })
      ]
    })
  }), w && /* @__PURE__ */ (0, g.jsxs)("div", {
    className: mn.Limit,
    children: [
      V.size,
      /* @__PURE__ */ (0, g.jsx)("span", { children: "/" }),
      w
    ]
  })] });
};
function K1(e) {
  switch (e.kind) {
    case "person":
      return `person:${e.person.account_user_id}`;
    case "email":
      return `email:${e.email.toLowerCase()}`;
    case "group":
      return `group:${e.id}`;
  }
}
function tu(e) {
  return e.kind === "person" ? !e.person.is_external : e.kind === "group";
}
function Pd(e, a) {
  return e.can_manage_editors && !(e.uses_page_sharing && a.kind === "group") && (tu(a) || e.uses_page_sharing === !0 && e.personal_editor_access === "invite");
}
function J1() {
  return {
    recipients: [],
    inviteRole: "viewer"
  };
}
function SM(e, a) {
  const r = {}, l = e.access_policy;
  if (!l || !e.can_manage_access) return r;
  if (e.uses_page_sharing)
    return a.recipients.length ? { recipient_changes: a.recipients.map((h) => {
      const m = Pd(e, h) ? a.inviteRole : "viewer";
      return h.kind === "email" ? m === "editor" ? { editor_email: h.email } : {
        email: h.email,
        role: "viewer"
      } : h.kind === "group" ? {
        recipient: h.id,
        recipient_type: "group",
        role: m
      } : {
        recipient: h.person.account_user_id,
        role: m
      };
    }) } : r;
  const s = {}, c = {}, d = new Set(l.allowed_workspace_group_ids);
  for (const h of a.recipients) {
    const m = e.can_manage_editors && tu(h) ? a.inviteRole : "viewer";
    if (h.kind === "person") {
      const y = h.person.account_user_id;
      m === "editor" ? (c.add_editor_account_user_ids ??= []).push(y) : (s.add_viewer_account_user_ids ??= []).push(y);
    } else h.kind === "email" ? (s.add_external_visitor_emails ??= []).push(h.email) : m === "editor" ? (c.add_editor_group_ids ??= []).push(h.id) : d.add(h.id);
  }
  return Object.keys(s).length && (r.viewer_changes = s), Object.keys(c).length && (r.editor_changes = c), (d.size !== l.allowed_workspace_group_ids.length || l.allowed_workspace_group_ids.some((h) => !d.has(h))) && (r.allowed_workspace_group_ids = [...d]), r;
}
function EM({ access: e, api: a, saving: r, remixEnabled: l, recipients: s, onRecipientsChange: c, role: d, onRoleChange: h }) {
  const m = Fe().formatMessage, [y, p] = (0, b.useState)(""), [_, w] = (0, b.useState)(null), [E, x] = (0, b.useState)(!1), [C, T] = (0, b.useState)(!1), M = (0, b.useRef)(null), D = (0, b.useRef)(null), j = (0, b.useId)(), H = y.trim(), k = s.every(tu), B = s.every((N) => Pd(e, N)), Q = l !== !0 || !s.some(tu) ? m(ne.viewerDescriptionShort) : k ? m(ne.viewerRemixDescription) : m(ne.viewerMixedRemixDescription, { workspace: e.workspace_name || m(ne.workspace) }), K = !!H && !C, q = (N) => {
    const te = Array.from(D.current?.querySelectorAll("button:not(:disabled)") ?? []), oe = te.findIndex((O) => O === document.activeElement);
    let Ee = oe + N;
    oe < 0 && (Ee = N === 1 ? 0 : te.length - 1), Ee < 0 || Ee >= te.length ? M.current?.focus() : te[Ee]?.focus();
  };
  (0, b.useEffect)(() => {
    if (w(null), x(!1), !H) return;
    const N = new AbortController(), te = setTimeout(() => {
      a.search(H, N.signal).then((oe) => {
        N.signal.aborted || w(oe);
      }).catch(() => {
        N.signal.aborted || x(!0);
      });
    }, 250);
    return () => {
      clearTimeout(te), N.abort();
    };
  }, [a, H]);
  const F = e.access_policy;
  if (!F) return null;
  const ee = Cu(e), ce = _?.users.filter((N) => !ee.some((te) => te.account_user_id === N.account_user_id) && !s.some((te) => te.kind === "person" && te.person.account_user_id === N.account_user_id)) ?? [], V = (_?.workspace_groups ?? []).filter((N) => !F.allowed_groups.some((te) => te.id === N.id) && !s.some((te) => te.kind === "group" && te.id === N.id)), ie = V3().safeParse(H), se = _ && !_.people_lookup_unavailable && (e.can_invite_external_visitors || e.personal_editor_access === "invite") && ie.success && !s.some((N) => N.kind === "email" && N.email.toLowerCase() === H.toLowerCase()) && ![...ee, ..._.users].some((N) => N.email?.toLowerCase() === H.toLowerCase()), L = (N) => {
    Pd(e, N) || h("viewer"), c([...s, N]), p(""), M.current?.focus();
  };
  function A() {
    return E ? /* @__PURE__ */ (0, g.jsx)("p", {
      role: "alert",
      className: fe.Error,
      children: m(ne.searchError)
    }) : _ ? /* @__PURE__ */ (0, g.jsxs)(g.Fragment, { children: [
      ce.map((N) => /* @__PURE__ */ (0, g.jsxs)(ft, {
        color: "secondary",
        variant: "ghost",
        className: fe.Result,
        disabled: r,
        onClick: () => L({
          kind: "person",
          person: N
        }),
        children: [/* @__PURE__ */ (0, g.jsx)(eu, {
          size: 32,
          imageUrl: N.avatar_url ?? void 0,
          name: N.name || N.email || void 0
        }), /* @__PURE__ */ (0, g.jsxs)("span", {
          className: fe.Identity,
          children: [/* @__PURE__ */ (0, g.jsx)("span", { children: N.name || N.email }), /* @__PURE__ */ (0, g.jsx)("span", {
            className: fe.Secondary,
            children: N.email
          })]
        })]
      }, N.account_user_id)),
      V.map((N) => /* @__PURE__ */ (0, g.jsxs)(ft, {
        color: "secondary",
        variant: "ghost",
        className: fe.Result,
        disabled: r,
        onClick: () => L({
          kind: "group",
          id: N.id,
          name: N.name
        }),
        children: [/* @__PURE__ */ (0, g.jsx)(eu, {
          size: 32,
          Icon: p_,
          className: fe.GroupAvatar
        }), /* @__PURE__ */ (0, g.jsxs)("span", {
          className: fe.Identity,
          children: [/* @__PURE__ */ (0, g.jsx)("span", { children: N.name }), /* @__PURE__ */ (0, g.jsx)("span", {
            className: fe.Secondary,
            children: m(ne.members, { count: N.size })
          })]
        })]
      }, N.id)),
      se && /* @__PURE__ */ (0, g.jsx)(ft, {
        color: "secondary",
        variant: "ghost",
        className: fe.Result,
        disabled: r,
        onClick: () => L({
          kind: "email",
          email: H
        }),
        children: m(ne.invite, { email: H })
      }),
      !se && ce.length === 0 && V.length === 0 && /* @__PURE__ */ (0, g.jsx)("p", {
        className: fe.EmptyResults,
        children: m(_.people_lookup_unavailable ? ne.peopleSearchUnavailable : ne.noResults)
      }),
      (_.has_more_users || _.has_more_groups) && /* @__PURE__ */ (0, g.jsx)("p", {
        className: `${fe.Notice} ${fe.SearchHint}`,
        children: m(ne.more)
      })
    ] }) : /* @__PURE__ */ (0, g.jsx)("p", {
      role: "status",
      "aria-label": m(ne.searching),
      className: `${fe.Notice} ${fe.SearchLoading}`,
      children: /* @__PURE__ */ (0, g.jsx)(Yo, { size: 16 })
    });
  }
  return /* @__PURE__ */ (0, g.jsxs)(yu, {
    open: K,
    onOpenChange: (N) => {
      r || T(!N);
    },
    children: [/* @__PURE__ */ (0, g.jsx)(Eh, {
      asChild: !0,
      children: /* @__PURE__ */ (0, g.jsx)("div", { children: /* @__PURE__ */ (0, g.jsx)(wM, {
        size: "lg",
        value: s.map((N) => ({
          value: K1(N),
          label: N.kind === "person" ? N.person.name || N.person.email || N.person.account_user_id : N.kind === "email" ? N.email : N.name,
          valid: !0
        })),
        onChange: (N) => {
          const te = new Set(N.map((oe) => oe.value));
          c(s.filter((oe) => te.has(K1(oe))));
        },
        getRemoveLabel: (N) => m(ne.removeRecipient, { name: N.label ?? N.value }),
        inputRef: M,
        inputValue: y,
        onInputChange: (N) => {
          T(!1), p(N), N.trim() !== H && (w(null), x(!1));
        },
        allowCustomTags: !1,
        placeholder: m(ne.search),
        autoComplete: "off",
        disabled: r,
        inputProps: {
          type: "search",
          autoCorrect: "off",
          autoCapitalize: "none",
          spellCheck: !1,
          maxLength: 200,
          "aria-label": m(ne.search),
          "aria-haspopup": "dialog",
          "aria-expanded": K,
          "aria-controls": K ? j : void 0,
          onFocus: () => T(!1),
          onKeyDown: (N) => {
            K && !N.nativeEvent.isComposing && (N.key === "ArrowDown" || N.key === "ArrowUp") && (N.preventDefault(), q(N.key === "ArrowDown" ? 1 : -1));
          }
        },
        endAdornment: s.length > 0 && /* @__PURE__ */ (0, g.jsx)(Vs, {
          className: fe.InviteRole,
          menuClassName: fe.RoleMenu,
          value: d,
          "aria-label": m(ne.inviteRole),
          disabled: r,
          align: "end",
          options: [{
            value: "viewer",
            label: m(ne.viewer),
            description: Q
          }, ...e.can_manage_editors ? [{
            value: "editor",
            label: m(ne.editor),
            description: m(B ? ne.editorDescriptionShort : ne.editorWorkspaceOnlyDescription),
            disabled: !B
          }] : []],
          onChange: ({ value: N }) => h(N)
        })
      }) })
    }), /* @__PURE__ */ (0, g.jsx)(bu, {
      container: M.current?.closest('[role="dialog"]'),
      children: /* @__PURE__ */ (0, g.jsx)(_u, {
        ref: D,
        id: j,
        className: fe.Results,
        "aria-label": m(ne.search),
        "aria-busy": r || !_ && !E,
        align: "start",
        sideOffset: 6,
        collisionPadding: 12,
        onOpenAutoFocus: (N) => N.preventDefault(),
        onCloseAutoFocus: (N) => N.preventDefault(),
        onEscapeKeyDown: (N) => {
          N.stopPropagation(), r ? N.preventDefault() : M.current?.focus();
        },
        onInteractOutside: (N) => {
          (r || N.target === M.current) && N.preventDefault();
        },
        onKeyDown: (N) => {
          (N.key === "ArrowDown" || N.key === "ArrowUp") && (N.preventDefault(), r || q(N.key === "ArrowDown" ? 1 : -1));
        },
        children: A()
      })
    })]
  });
}
var TM = (e) => /* @__PURE__ */ (0, g.jsx)("svg", {
  width: "1em",
  height: "1em",
  viewBox: "0 0 24 24",
  fill: "currentColor",
  ...e,
  children: /* @__PURE__ */ (0, g.jsx)("path", {
    d: "M18.2929 5.7071C16.4743 3.88849 13.5257 3.88849 11.7071 5.7071L10.7071 6.7071C10.3166 7.09763 9.68341 7.09763 9.29289 6.7071C8.90236 6.31658 8.90236 5.68341 9.29289 5.29289L10.2929 4.29289C12.8926 1.69322 17.1074 1.69322 19.7071 4.29289C22.3068 6.89255 22.3068 11.1074 19.7071 13.7071L18.7071 14.7071C18.3166 15.0976 17.6834 15.0976 17.2929 14.7071C16.9024 14.3166 16.9024 13.6834 17.2929 13.2929L18.2929 12.2929C20.1115 10.4743 20.1115 7.52572 18.2929 5.7071ZM15.7071 8.29289C16.0976 8.68341 16.0976 9.31658 15.7071 9.7071L9.7071 15.7071C9.31658 16.0976 8.68341 16.0976 8.29289 15.7071C7.90236 15.3166 7.90236 14.6834 8.29289 14.2929L14.2929 8.29289C14.6834 7.90236 15.3166 7.90236 15.7071 8.29289ZM6.7071 9.29289C7.09763 9.68341 7.09763 10.3166 6.7071 10.7071L5.7071 11.7071C3.88849 13.5257 3.88849 16.4743 5.7071 18.2929C7.52572 20.1115 10.4743 20.1115 12.2929 18.2929L13.2929 17.2929C13.6834 16.9024 14.3166 16.9024 14.7071 17.2929C15.0976 17.6834 15.0976 18.3166 14.7071 18.7071L13.7071 19.7071C11.1074 22.3068 6.89255 22.3068 4.29289 19.7071C1.69322 17.1074 1.69322 12.8926 4.29289 10.2929L5.29289 9.29289C5.68341 8.90236 6.31658 8.90236 6.7071 9.29289Z",
    fill: "currentColor"
  })
}), CM = (e) => /* @__PURE__ */ (0, g.jsxs)("svg", {
  width: "1em",
  height: "1em",
  viewBox: "0 0 24 24",
  fill: "currentColor",
  ...e,
  children: [
    /* @__PURE__ */ (0, g.jsx)("path", {
      d: "M13 12C13 11.4477 12.5523 11 12 11C11.4477 11 11 11.4477 11 12V16C11 16.5523 11.4477 17 12 17C12.5523 17 13 16.5523 13 16V12Z",
      fill: "currentColor"
    }),
    /* @__PURE__ */ (0, g.jsx)("path", {
      d: "M12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2ZM4 12C4 7.58172 7.58172 4 12 4C16.4183 4 20 7.58172 20 12C20 16.4183 16.4183 20 12 20C7.58172 20 4 16.4183 4 12Z",
      fill: "currentColor"
    }),
    /* @__PURE__ */ (0, g.jsx)("path", {
      d: "M12 9.30005C12.6351 9.30005 13.15 8.78518 13.15 8.15005C13.15 7.51492 12.6351 7.00005 12 7.00005C11.3649 7.00005 10.85 7.51492 10.85 8.15005C10.85 8.78518 11.3649 9.30005 12 9.30005Z",
      fill: "currentColor"
    })
  ]
}), AM = "_Container_244h6_2", xM = "_Track_244h6_34", OM = "_Thumb_244h6_82", MM = "_Label_244h6_109", Us = {
  Container: AM,
  Track: xM,
  Thumb: OM,
  Label: MM
}, RM = ({ className: e, label: a, id: r, disabled: l, inert: s, labelPosition: c = "end", ...d }) => {
  const h = (0, b.useId)(), m = r ?? h;
  return /* @__PURE__ */ (0, g.jsxs)("div", {
    className: Be(Us.Container, e),
    "data-disabled": l ? "" : void 0,
    "data-has-label": a ? "" : void 0,
    "data-label-position": c,
    inert: s,
    children: [/* @__PURE__ */ (0, g.jsx)(y5, {
      id: m,
      className: Us.Track,
      disabled: l,
      inert: s,
      ...d,
      children: /* @__PURE__ */ (0, g.jsx)(b5, { className: Us.Thumb })
    }), a && /* @__PURE__ */ (0, g.jsx)("label", {
      htmlFor: m,
      className: Us.Label,
      children: a
    })]
  });
}, eg = 400, NM = 150, v_ = 0.99, Ta = class extends Error {
  constructor() {
    super("Sharing requires an interaction with the visible dialog");
  }
};
function g_(e) {
  return "IntersectionObserverEntry" in e && "isVisible" in e.IntersectionObserverEntry.prototype;
}
function y_(e, a) {
  return e.isIntersecting && e.intersectionRatio >= v_ && e.boundingClientRect.width > 0 && e.boundingClientRect.height > 0 && (!a || e.isVisible === !0);
}
function b_(e) {
  return {
    threshold: [v_],
    ...e ? {
      trackVisibility: !0,
      delay: 100
    } : {}
  };
}
function DM(e) {
  const a = e.ownerDocument, r = g_(a.defaultView);
  return new Promise((l, s) => {
    const c = new IntersectionObserver(([h]) => {
      clearTimeout(d), c.disconnect(), h && y_(h, r) && e.isConnected && a.visibilityState === "visible" && e.closest('[role="dialog"][data-state="open"]') ? l() : s(new Ta());
    }, b_(r)), d = setTimeout(() => {
      c.disconnect(), s(new Ta());
    }, 1e3);
    c.observe(e);
  });
}
function zM(e, a) {
  const r = e.ownerDocument, l = r.defaultView, s = g_(l);
  let c = null, d = null, h = 0, m = !1, y;
  const p = () => {
    clearTimeout(y), y = void 0, a?.(!1), d = null, h++;
  }, _ = (C) => {
    for (const T of C) y_(T, s) ? d === null && (d = performance.now(), a && (y = l.setTimeout(() => {
      y = void 0, a(!m && d !== null && r.visibilityState === "visible" && r.hasFocus());
    }, eg))) : p();
  }, w = new IntersectionObserver(_, b_(s));
  w.observe(e);
  const E = () => {
    p(), w.takeRecords(), w.unobserve(e), m || w.observe(e);
  };
  r.addEventListener("visibilitychange", E), l.addEventListener("blur", E), l.addEventListener("focus", E);
  const x = (C) => {
    _(w.takeRecords());
    const T = C.getBoundingClientRect();
    return !m && e.isConnected && e.contains(C) && r.visibilityState === "visible" && r.hasFocus() && d !== null && performance.now() - d >= eg && T.width > 0 && T.height > 0 && T.top >= 0 && T.left >= 0 && T.bottom <= l.innerHeight && T.right <= l.innerWidth;
  };
  return {
    capture(C) {
      c = C;
    },
    async authorize() {
      const C = c;
      c = null;
      const T = C?.type === "click" || C?.type === "keydown" && ["Enter", " "].includes(C.key) && !C.repeat;
      let M = C?.composedPath().find((H) => H instanceof Element)?.closest("button, [role=option], [role=listbox]");
      const D = M?.getAttribute("aria-activedescendant");
      if (D && (M = e.querySelector(`#${CSS.escape(D)}`)), !C?.isTrusted || C.eventPhase === Event.NONE || !T || !l.navigator.userActivation?.isActive || !M || !x(M)) throw new Ta();
      const j = h;
      if (await new Promise((H) => l.setTimeout(H, NM)), !x(M) || h !== j) throw new Ta();
    },
    dispose() {
      m = !0, c = null, p(), w.disconnect(), r.removeEventListener("visibilitychange", E), l.removeEventListener("blur", E), l.removeEventListener("focus", E);
    }
  };
}
function LM(e) {
  let a = -1 / 0, r = 0, l = !1;
  return qd()((s, c) => ({
    access: null,
    unavailable: null,
    open: !1,
    openSession: 0,
    placement: "bottom",
    mutation: null,
    error: null,
    actions: {
      load: async (d) => {
        const h = ++r;
        l = !0;
        try {
          const m = await e.load();
          if (d.aborted || h !== r) return;
          m.access_policy ? (a = Date.now(), s({
            access: m,
            unavailable: null
          })) : c().access || s({ unavailable: "unavailable" });
        } catch (m) {
          if (d.aborted || h !== r) return;
          m instanceof h_ ? s({ unavailable: "login" }) : c().access || s({ unavailable: "unavailable" });
        } finally {
          h === r && (l = !1);
        }
      },
      open: (d = "bottom") => {
        const h = !c().open;
        h && e.logInteraction("toolbar_sharing_opened"), s((m) => ({
          open: !0,
          openSession: m.openSession + (h ? 1 : 0),
          placement: d,
          error: null
        })), h && !l && !c().mutation && Date.now() - a >= 3e4 && c().actions.load(new AbortController().signal);
      },
      close: () => {
        c().open && e.logInteraction("toolbar_sharing_closed"), s({
          open: !1,
          error: null
        });
      },
      setError: (d) => s({ error: d }),
      save: async (d, h = null, m) => {
        if (c().mutation || c().access?.can_manage_access === !1) return !1;
        ++r, l = !1, s({
          mutation: { control: h },
          error: null
        });
        const y = (_) => {
          a = Date.now(), s((w) => ({ access: {
            ..._,
            workspace_name: _.workspace_name ?? w.access?.workspace_name
          } }));
        }, p = new Promise((_) => setTimeout(_, h === "remix" ? 300 : 400));
        try {
          const [_] = await Promise.all([e.save(d, (w) => {
            y(w), m?.();
          }), p]);
          return y(_), s({ mutation: null }), e.logInteraction("toolbar_sharing_update_succeeded"), !0;
        } catch (_) {
          return await p, s({ error: _ instanceof Ta ? "interactionRequired" : "error" }), (d.access_mode !== void 0 || d.recipient_changes !== void 0 || d.editor_changes !== void 0) && !(_ instanceof Ta) && await c().actions.load(new AbortController().signal), s({ mutation: null }), e.logInteraction(_ instanceof Ta ? "toolbar_sharing_update_blocked" : "toolbar_sharing_update_failed"), !1;
        }
      }
    }
  }));
}
function HM({ siteOrigin: e, shareAttempt: a }) {
  const r = Fe(), l = r.formatMessage, s = (0, b.useRef)(null), c = (0, b.useMemo)(() => OO(e, async () => {
    if (!s.current) throw new Ta();
    await s.current.authorize();
  }, () => window.parent.postMessage({
    type: "sites-toolbar-sharing-unavailable",
    reason: "login"
  }, e), a), [e, a]), { access: d, unavailable: h, open: m, openSession: y, placement: p, mutation: _, error: w, actions: E } = au((0, b.useMemo)(() => LM(c), [c])), { save: x } = E, C = _ !== null, T = d?.can_manage_access === !1, [M, D] = (0, b.useState)("idle"), j = (0, b.useRef)(null), [H, k] = (0, b.useState)(null);
  (0, b.useEffect)(() => {
    if (H === null) return;
    const O = window.setTimeout(() => k(null), 5e3);
    return () => window.clearTimeout(O);
  }, [H]);
  const [B, Q] = (0, b.useState)(null), [K, q] = (0, b.useState)(!1);
  (0, b.useEffect)(() => {
    if (!m || !T || !B) return;
    const O = requestAnimationFrame(() => B.focus({ preventScroll: !0 }));
    return () => cancelAnimationFrame(O);
  }, [
    m,
    T,
    B
  ]), (0, b.useLayoutEffect)(() => {
    if (!B) return;
    const O = zM(B, q);
    return s.current = O, () => {
      s.current = null, O.dispose();
    };
  }, [B]), (0, b.useLayoutEffect)(() => {
    if (!B) return;
    const O = () => {
      window.parent.postMessage({
        type: "sites-toolbar-sharing-size",
        height: B.getBoundingClientRect().height
      }, e);
    }, $ = new ResizeObserver(O);
    return $.observe(B), O(), () => $.disconnect();
  }, [B, e]), (0, b.useEffect)(() => {
    const O = ($) => {
      if (!f_($, window.parent, e)) return;
      const re = w7.safeParse($.data);
      if (re.success) {
        my({ site_user_role: re.data.site_user_role });
        return;
      }
      const le = S7.safeParse($.data);
      le.success && (le.data.type === "sites-toolbar-open-sharing" ? E.open(le.data.placement) : E.close(), k(null));
    };
    return window.addEventListener("message", O), () => window.removeEventListener("message", O);
  }, [e, E]), (0, b.useEffect)(() => {
    const O = new AbortController();
    return E.load(O.signal), () => O.abort();
  }, [E]), (0, b.useEffect)(() => {
    h && window.parent.postMessage({
      type: "sites-toolbar-sharing-unavailable",
      reason: h
    }, e);
  }, [h, e]);
  const F = d?.access_policy, ee = d ? Cu(d) : [], ce = d?.workspace_name || l(ne.workspace), V = F?.access_mode, ie = F?.allowed_groups ?? [];
  function se() {
    return V === "admins_only" ? l(ne.admins) : V === "public" ? l(ne.public) : V === "workspace_all" ? ce : d?.show_site_collaborators === !1 || ie.length ? l(ne.inviteOnly) : ee.length > 1 ? l(ne.people, { count: ee.length }) : l(ne.private);
  }
  function L() {
    return V === "public" ? "globe" : V === "workspace_all" ? "building" : ie.length || ee.length > 1 ? "people" : "lock";
  }
  const A = se(), N = L();
  (0, b.useEffect)(() => {
    F && window.parent.postMessage({
      type: "sites-toolbar-summary",
      label: A.slice(0, 256),
      icon: N
    }, e);
  }, [
    F,
    A,
    N,
    e
  ]);
  const te = () => {
    E.close(), window.parent.postMessage({ type: "sites-toolbar-sharing-closed" }, e);
  };
  if (!d || !F) return null;
  const oe = /* @__PURE__ */ (0, g.jsxs)(ft, {
    ref: j,
    className: fe.Copy,
    color: "secondary",
    variant: "ghost",
    pill: !0,
    size: "lg",
    onClick: async () => {
      const O = d.url ?? e;
      try {
        await navigator.clipboard.writeText(O), k(Date.now()), c.logInteraction("toolbar_copy_link_succeeded");
      } catch {
        E.setError("copyError"), c.logInteraction("toolbar_copy_link_failed");
      }
    },
    children: [H !== null ? /* @__PURE__ */ (0, g.jsx)(m_, {
      "aria-hidden": "true",
      focusable: "false"
    }) : /* @__PURE__ */ (0, g.jsx)(TM, {
      "aria-hidden": "true",
      focusable: "false"
    }), l(H !== null ? ne.copied : ne.copy)]
  }), Ee = w ? /* @__PURE__ */ (0, g.jsx)("p", {
    role: "alert",
    className: fe.Error,
    children: l(ne[w])
  }) : null;
  return /* @__PURE__ */ (0, g.jsx)("div", {
    className: fe.Root,
    dir: Oa(r.locale),
    children: /* @__PURE__ */ (0, g.jsx)(ZA, {
      modal: !1,
      open: m,
      onOpenChange: (O) => {
        O ? E.open(p) : C || te();
      },
      children: /* @__PURE__ */ (0, g.jsxs)(GA, {
        ref: Q,
        onClickCapture: (O) => s.current?.capture(O.nativeEvent),
        onKeyDownCapture: (O) => s.current?.capture(O.nativeEvent),
        className: fe.Dialog,
        "data-placement": p,
        "data-read-only": T || void 0,
        "aria-describedby": void 0,
        onOpenAutoFocus: (O) => {
          T && O.preventDefault();
        },
        onCloseAutoFocus: (O) => {
          O.preventDefault();
        },
        children: [
          /* @__PURE__ */ (0, g.jsx)("div", {
            className: fe.Body,
            children: T ? /* @__PURE__ */ (0, g.jsx)(BM, { access: d }) : /* @__PURE__ */ (0, g.jsx)(jM, {
              access: d,
              api: c,
              saving: C,
              visibilityReady: K,
              tooltipContainer: B,
              savingControl: _?.control,
              save: x,
              onClose: te,
              copyLink: oe,
              error: Ee,
              onClearError: () => E.setError(null)
            }, y)
          }),
          T && Ee,
          T && /* @__PURE__ */ (0, g.jsxs)("div", {
            className: fe.Footer,
            children: [
              d.can_request_edit_access && /* @__PURE__ */ (0, g.jsx)(ft, {
                className: `${fe.Copy} ${fe.FooterLeading}`,
                color: "secondary",
                variant: "ghost",
                pill: !0,
                size: "lg",
                loading: M === "sending",
                disabled: M === "sent",
                onClick: async (O) => {
                  if (!O.nativeEvent.isTrusted) return;
                  const $ = O.currentTarget, re = O.detail === 0;
                  D("sending"), E.setError(null);
                  const le = new Promise((ye) => window.setTimeout(ye, 400));
                  try {
                    await DM($), await c.requestEditAccess().finally(() => le);
                    const ye = $.ownerDocument;
                    re && $.isConnected && ye.hasFocus() && (ye.activeElement === $ || ye.activeElement === ye.body) && j.current?.focus({ preventScroll: !0 }), D("sent");
                  } catch (ye) {
                    D("idle"), E.setError(ye instanceof Ta ? "interactionRequired" : "requestEditError");
                  }
                },
                children: l(M === "sent" ? ne.editRequested : ne.requestEditAccess)
              }, M === "sent" ? "requested" : "request-edit-access"),
              oe,
              /* @__PURE__ */ (0, g.jsx)(rh, {
                role: "status",
                children: M === "sent" ? l(ne.editRequested) : ""
              })
            ]
          })
        ]
      })
    })
  });
}
function jM({ access: e, api: a, saving: r, visibilityReady: l, tooltipContainer: s, savingControl: c, save: d, onClose: h, copyLink: m, error: y, onClearError: p }) {
  const { formatMessage: _ } = Fe(), w = E_(e), [E, x] = (0, b.useState)(J1), [C, T] = (0, b.useState)(0), [M, D] = (0, b.useState)(null), [j, H] = (0, b.useState)(!1), k = e.access_policy;
  if (!k) return null;
  const B = SM(e, E), Q = e.available_access_modes, K = e.remix_enabled != null, q = M ?? e.remix_enabled, F = e.workspace_name ? _(ne.remixWorkspace, { workspace: e.workspace_name }) : _(ne.remixViewers);
  function ee(V, ie) {
    if (!k || ie === (V.role ?? "viewer")) return;
    if (e.uses_page_sharing) return d({ recipient_changes: [{
      recipient: V.id,
      recipient_type: "group",
      role: ie === "remove" ? null : ie
    }] }, `group:${V.id}`);
    const se = k.allowed_workspace_group_ids.filter((A) => A !== V.id), L = { allowed_workspace_group_ids: ie === "viewer" ? [...se, V.id] : se };
    return ie === "editor" ? L.editor_changes = { add_editor_group_ids: [V.id] } : V.role === "editor" && (L.editor_changes = { remove_editor_group_ids: [V.id] }), d(L, `group:${V.id}`);
  }
  function ce(V, ie) {
    return [{
      value: "viewer",
      label: _(ne.viewer),
      description: _(q === !0 && ie ? ne.viewerRemixDescription : ne.viewerDescriptionShort)
    }, ...V ? [{
      value: "editor",
      label: _(ne.editor),
      description: _(ie ? ne.editorDescriptionShort : ne.editorWorkspaceOnlyDescription),
      disabled: !ie
    }] : []];
  }
  return j && K ? /* @__PURE__ */ (0, g.jsxs)(g.Fragment, { children: [
    /* @__PURE__ */ (0, g.jsxs)("div", {
      className: `${fe.Header} ${fe.AdvancedHeader}`,
      children: [/* @__PURE__ */ (0, g.jsx)(Fy, {
        className: fe.Title,
        children: _(ne.advancedSettings)
      }), /* @__PURE__ */ (0, g.jsxs)("div", {
        className: fe.RemixSetting,
        children: [
          /* @__PURE__ */ (0, g.jsx)("label", {
            id: "toolbar-remix-label",
            htmlFor: "toolbar-remix",
            children: F
          }),
          /* @__PURE__ */ (0, g.jsx)(Vn, {
            portalContainer: s,
            compact: !0,
            content: _(ne.remixExplanation),
            contentClassName: fe.RemixExplanation,
            side: "top",
            maxWidth: 300,
            children: /* @__PURE__ */ (0, g.jsx)("button", {
              type: "button",
              className: fe.RemixInfo,
              "aria-label": _(ne.remixInfo),
              children: /* @__PURE__ */ (0, g.jsx)(CM, {
                width: 16,
                height: 16,
                "aria-hidden": "true",
                focusable: "false"
              })
            })
          }),
          /* @__PURE__ */ (0, g.jsx)(RM, {
            id: "toolbar-remix",
            className: fe.RemixSwitch,
            "aria-labelledby": "toolbar-remix-label",
            checked: q === !0,
            disabled: r || q == null,
            "aria-disabled": !l || void 0,
            onCheckedChange: async (V) => {
              if (l) {
                D(V);
                try {
                  await d({ remix_enabled: V }, "remix");
                } finally {
                  D(null);
                }
              }
            }
          })
        ]
      })]
    }),
    y,
    /* @__PURE__ */ (0, g.jsx)("div", {
      className: `${fe.Footer} ${fe.AdvancedFooter}`,
      children: /* @__PURE__ */ (0, g.jsx)(ft, {
        autoFocus: !0,
        className: `${fe.Copy} ${fe.FooterLeading}`,
        color: "secondary",
        variant: "ghost",
        pill: !0,
        size: "lg",
        loading: r,
        onClick: () => {
          p(), H(!1);
        },
        children: _(ne.back)
      })
    })
  ] }) : /* @__PURE__ */ (0, g.jsxs)(g.Fragment, { children: [
    /* @__PURE__ */ (0, g.jsxs)(__, {
      access: e,
      children: [e.show_site_collaborators && /* @__PURE__ */ (0, g.jsx)(EM, {
        access: e,
        api: a,
        saving: r,
        remixEnabled: q,
        recipients: E.recipients,
        role: E.inviteRole,
        onRecipientsChange: (V) => x((ie) => ({
          ...ie,
          recipients: V
        })),
        onRoleChange: (V) => x((ie) => ({
          ...ie,
          inviteRole: V
        }))
      }, C), /* @__PURE__ */ (0, g.jsx)(S_, { children: /* @__PURE__ */ (0, g.jsx)(Vs, {
        className: fe.AccessMode,
        pill: !1,
        "aria-labelledby": "toolbar-link-access",
        loading: c === "access",
        value: k.access_mode,
        disabled: r || !Q?.length,
        options: [.../* @__PURE__ */ new Set([...Q ?? [], k.access_mode])].map(w),
        onChange: ({ value: V }) => {
          if (V !== "admins_only" && V !== k.access_mode) return d({ access_mode: V }, "access");
        }
      }) })]
    }),
    /* @__PURE__ */ (0, g.jsxs)(w_, {
      hidden: !e.show_site_collaborators,
      children: [Cu(e).map((V) => {
        const ie = V.role ?? "viewer";
        return /* @__PURE__ */ (0, g.jsx)(T_, {
          person: V,
          children: V.role === "owner" || e.read_only_user_ids?.includes(V.account_user_id) ? /* @__PURE__ */ (0, g.jsx)(nu, { role: ie }) : /* @__PURE__ */ (0, g.jsx)(Vs, {
            className: fe.Role,
            menuClassName: fe.RoleMenu,
            align: "end",
            "aria-label": _(ne.role, { name: V.name || V.email || "" }),
            loading: c === `person:${V.account_user_id}`,
            value: ie,
            disabled: r || V.role === "editor" && !e.can_manage_editors || !!(V.is_external && !V.email),
            options: ce(e.can_manage_editors || V.role === "editor", !V.is_external || e.personal_editor_access === "invite"),
            onChange: ({ value: se }) => {
              if (se !== ie) return d(X1(V, se, e.uses_page_sharing, e.personal_editor_access), `person:${V.account_user_id}`);
            },
            action: {
              label: _(ne.remove),
              onSelect: () => d(X1(V, "remove", e.uses_page_sharing, e.personal_editor_access), `person:${V.account_user_id}`)
            }
          })
        }, V.account_user_id);
      }), k.allowed_groups.map((V) => {
        const ie = V.role ?? "viewer";
        return k.allowed_tenant_group_ids.includes(V.id) || e.read_only_group_ids?.includes(V.id) ? /* @__PURE__ */ (0, g.jsx)(Id, {
          group: V,
          children: /* @__PURE__ */ (0, g.jsx)(nu, { role: ie })
        }, V.id) : /* @__PURE__ */ (0, g.jsx)(Id, {
          group: V,
          children: /* @__PURE__ */ (0, g.jsx)(Vs, {
            className: fe.Role,
            menuClassName: fe.RoleMenu,
            align: "end",
            loading: c === `group:${V.id}`,
            value: ie,
            "aria-label": _(ne.role, { name: V.name }),
            disabled: r || V.role === "editor" && !e.can_manage_editors,
            options: ce(!e.uses_page_sharing && (e.can_manage_editors || V.role === "editor"), !0),
            onChange: ({ value: se }) => ee(V, se),
            action: {
              label: _(ne.remove),
              onSelect: () => ee(V, "remove")
            }
          })
        }, V.id);
      })]
    }),
    /* @__PURE__ */ (0, g.jsxs)("div", {
      className: fe.Footer,
      children: [K && /* @__PURE__ */ (0, g.jsxs)(ft, {
        className: `${fe.Copy} ${fe.FooterLeading}`,
        color: "secondary",
        variant: "ghost",
        pill: !0,
        size: "lg",
        disabled: r,
        onClick: () => {
          p(), H(!0);
        },
        children: [/* @__PURE__ */ (0, g.jsx)(s_, { "aria-hidden": "true" }), _(ne.advanced)]
      }), E.recipients.length > 0 ? /* @__PURE__ */ (0, g.jsxs)(g.Fragment, { children: [/* @__PURE__ */ (0, g.jsx)(ft, {
        color: "primary",
        variant: "ghost",
        pill: !0,
        size: "lg",
        disabled: r,
        onClick: h,
        children: _(ne.cancel)
      }), /* @__PURE__ */ (0, g.jsx)(ft, {
        color: "primary",
        pill: !0,
        size: "lg",
        loading: c === "invite",
        disabled: r || !Object.keys(B).length,
        onClick: async () => {
          await d(B, "invite", () => x((V) => ({
            ...V,
            recipients: V.recipients.slice(1)
          }))) && (x(J1()), T((V) => V + 1));
        },
        children: _(ne.commitInvites)
      })] }) : m]
    }),
    y
  ] });
}
function BM({ access: e }) {
  const a = E_(e), r = e.access_policy;
  if (!r) return null;
  const l = a(r.access_mode);
  return /* @__PURE__ */ (0, g.jsxs)(g.Fragment, { children: [/* @__PURE__ */ (0, g.jsx)(__, {
    access: e,
    children: /* @__PURE__ */ (0, g.jsx)(S_, { children: /* @__PURE__ */ (0, g.jsxs)("p", {
      className: fe.AccessModeLabel,
      children: [/* @__PURE__ */ (0, g.jsx)("span", {
        className: fe.AccessModeIcon,
        children: l.icon
      }), l.label]
    }) })
  }), /* @__PURE__ */ (0, g.jsxs)(w_, {
    hidden: !e.show_site_collaborators,
    readOnly: !0,
    children: [Cu(e).map((s) => /* @__PURE__ */ (0, g.jsx)(T_, {
      person: s,
      children: /* @__PURE__ */ (0, g.jsx)(nu, { role: s.role })
    }, s.account_user_id)), r.allowed_groups.map((s) => /* @__PURE__ */ (0, g.jsx)(Id, {
      group: s,
      children: /* @__PURE__ */ (0, g.jsx)(nu, { role: s.role })
    }, s.id))]
  })] });
}
function __({ access: e, children: a }) {
  const { formatMessage: r } = Fe();
  return /* @__PURE__ */ (0, g.jsxs)("div", {
    className: fe.Header,
    children: [
      /* @__PURE__ */ (0, g.jsx)(UM, { title: e.title }),
      a,
      e.show_site_collaborators && /* @__PURE__ */ (0, g.jsx)("h2", {
        className: fe.Section,
        id: "toolbar-who-has-access",
        children: r(ne.who)
      })
    ]
  });
}
function w_({ children: e, hidden: a, readOnly: r }) {
  const [l, s] = (0, b.useState)(null), [c, d] = (0, b.useState)(!1), [h, m] = (0, b.useState)(!1);
  return (0, b.useLayoutEffect)(() => {
    if (!l) return;
    const y = () => {
      d(l.scrollTop > 1), m(l.scrollHeight - l.clientHeight - l.scrollTop > 1);
    }, p = new ResizeObserver(y);
    return p.observe(l), l.firstElementChild && p.observe(l.firstElementChild), l.addEventListener("scroll", y, { passive: !0 }), y(), () => {
      p.disconnect(), l.removeEventListener("scroll", y);
    };
  }, [l]), a ? null : /* @__PURE__ */ (0, g.jsx)("div", {
    className: fe.AccessList,
    ref: s,
    role: "region",
    "aria-labelledby": "toolbar-who-has-access",
    tabIndex: r ? 0 : void 0,
    "data-scroll-cutoff": c || void 0,
    "data-scroll-cutoff-below": h || void 0,
    children: /* @__PURE__ */ (0, g.jsx)("div", {
      className: fe.AccessListContent,
      children: e
    })
  });
}
function UM({ title: e }) {
  const { formatMessage: a } = Fe();
  return /* @__PURE__ */ (0, g.jsx)(Fy, {
    className: fe.Title,
    children: a(ne.title, { title: e })
  });
}
function S_({ children: e }) {
  const { formatMessage: a } = Fe();
  return /* @__PURE__ */ (0, g.jsxs)(g.Fragment, { children: [/* @__PURE__ */ (0, g.jsx)("h2", {
    className: fe.Section,
    id: "toolbar-link-access",
    children: a(ne.linkAccess)
  }), e] });
}
function E_(e) {
  const { formatMessage: a } = Fe(), r = e.workspace_name || a(ne.workspace);
  return (l) => {
    const s = {
      value: l,
      disabled: !e.available_access_modes?.some((c) => c === l)
    };
    switch (l) {
      case "public":
        return {
          ...s,
          label: a(ne.anyone),
          icon: /* @__PURE__ */ (0, g.jsx)(o_, {
            "aria-hidden": "true",
            focusable: "false"
          }),
          description: a(ne.publicDescription)
        };
      case "workspace_all":
        return {
          ...s,
          label: a(ne.everyone, { workspace: r }),
          icon: /* @__PURE__ */ (0, g.jsx)(l_, {
            "aria-hidden": "true",
            focusable: "false"
          }),
          description: a(ne.workspaceDescription)
        };
      default:
        return {
          ...s,
          label: a(l === "admins_only" ? ne.admins : ne.invited),
          icon: /* @__PURE__ */ (0, g.jsx)(r_, {
            "aria-hidden": "true",
            focusable: "false"
          }),
          description: a(ne.privateDescription)
        };
    }
  };
}
function T_({ person: e, children: a }) {
  return /* @__PURE__ */ (0, g.jsxs)("div", {
    className: fe.Person,
    children: [
      /* @__PURE__ */ (0, g.jsx)(eu, {
        name: e.name || e.email || "?",
        imageUrl: e.avatar_url ?? void 0,
        size: 32
      }),
      /* @__PURE__ */ (0, g.jsxs)("div", {
        className: fe.Identity,
        children: [/* @__PURE__ */ (0, g.jsx)("div", { children: e.name || e.email }), e.name && /* @__PURE__ */ (0, g.jsx)("div", {
          className: fe.Secondary,
          children: e.email
        })]
      }),
      a
    ]
  });
}
function Id({ group: e, children: a }) {
  const { formatMessage: r } = Fe();
  return /* @__PURE__ */ (0, g.jsxs)("div", {
    className: fe.Person,
    children: [
      /* @__PURE__ */ (0, g.jsx)(eu, {
        size: 32,
        Icon: p_,
        className: fe.GroupAvatar
      }),
      /* @__PURE__ */ (0, g.jsxs)("div", {
        className: fe.Identity,
        children: [e.name, /* @__PURE__ */ (0, g.jsx)("div", {
          className: fe.Secondary,
          children: r(ne.members, { count: e.size })
        })]
      }),
      a
    ]
  });
}
function nu({ role: e }) {
  const { formatMessage: a } = Fe();
  return /* @__PURE__ */ (0, g.jsx)("span", {
    className: fe.ReadOnlyRole,
    children: a(ne[e ?? "viewer"])
  });
}
function tR() {
  if (window.self === window.top) return;
  const e = new URLSearchParams(location.search).get("site_origin"), a = document.body.dataset.chatgptOrigin;
  if (!e || !["https://chatgpt.com", "https://chatgpt-staging.com"].includes(a ?? "")) return;
  const r = new URLSearchParams(location.hash.slice(1)), l = Ud({
    kind: "sites-toolbar",
    toolbarOrigin: location.origin,
    chatgptOrigin: a,
    accountId: r.get("account_id") || null,
    locale: r.get("locale") || navigator.language,
    projectId: null,
    projectTitle: null
  }, () => /* @__PURE__ */ (0, g.jsx)(HM, {
    siteOrigin: e,
    shareAttempt: r.get("attempt")
  }), { isolatedDocument: !0 });
  l.ready.catch(l.dispose);
}
function nR(e) {
  if (e.kind === "preview-annotations") return;
  try {
    if (window.self !== window.top) return;
  } catch {
    return;
  }
  if (Vw(navigator.userAgent) || Bd()) return;
  if (Xs()) {
    if (e.mobileEnabled !== !0) return;
    e.kind !== "sites-toolbar" && e.kind !== "auto" && (e = {
      ...e,
      kind: "editor-composer"
    });
  }
  const a = Z4();
  if (e.kind === "auto") {
    const r = e, l = a.then((s) => s?.current_user_role ? s : null);
    if (r.toolbarOrigin && r.viewerRemixEnabled) {
      fd({
        ...r,
        ...r.shareLoginOrigin && { shareLoginEnabled: !0 },
        kind: "sites-toolbar",
        currentUserRole: "viewer",
        toolbarOrigin: r.toolbarOrigin
      }, l);
      return;
    }
    l.then((s) => {
      if (!s) return;
      const c = Bw(r, s, Xs());
      c && fd({
        ...r,
        ...c
      }, l);
    }).catch(() => {
    });
    return;
  }
  fd(e, a);
}
function fd(e, a) {
  const r = e.projectTitle?.trim() || document.title.trim() || window.location.hostname;
  if (e.kind === "sites-toolbar") {
    const l = AO(e.shareLoginEnabled === !0), s = Ud(e, () => /* @__PURE__ */ (0, g.jsx)(TO, {
      context: e,
      store: l,
      siteTitle: r
    }));
    s.ready.catch(s.dispose), a.then((c) => {
      if (!c || (c.current_user_role ?? e.currentUserRole) === "viewer") return s.dispose();
      l.getState().actions.setConfig(c);
    }, s.dispose);
    return;
  }
  a.then((l) => {
    if (!l) return;
    const s = Ud(e, ({ onDismiss: c }) => e.kind === "editor-composer" ? /* @__PURE__ */ (0, g.jsx)(c_, {
      accountId: e.accountId,
      chatgptOrigin: e.chatgptOrigin,
      projectId: e.projectId,
      siteTitle: r,
      config: l
    }) : /* @__PURE__ */ (0, g.jsx)(f7, {
      accountId: e.accountId,
      chatgptOrigin: e.chatgptOrigin,
      ownerName: e.ownerName,
      projectId: e.projectId,
      siteTitle: r,
      editContext: l.edit_context,
      onDismiss: c
    }));
    s.ready.catch(s.dispose);
  }).catch(() => {
  });
}
export {
  nR as mountAutoSiteWidget,
  nR as mountSiteWidget,
  tR as mountSitesToolbarFrame
};
